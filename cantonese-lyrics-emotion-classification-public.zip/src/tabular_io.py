"""Small, explicit CSV/XLSX readers for human-reviewed project artifacts."""

from __future__ import annotations

from pathlib import Path

import pandas as pd


def read_tabular_file(
    path: Path,
    preferred_sheet: str | None = None,
) -> pd.DataFrame:
    suffix = path.suffix.lower()
    if suffix in {".csv", ".txt"}:
        return pd.read_csv(path)
    if suffix in {".xlsx", ".xlsm"}:
        workbook = pd.ExcelFile(path, engine="openpyxl")
        if preferred_sheet is not None:
            if preferred_sheet not in workbook.sheet_names:
                raise ValueError(
                    f"{path} is missing worksheet {preferred_sheet!r}; "
                    f"available={workbook.sheet_names}"
                )
            sheet_name: str | int = preferred_sheet
        else:
            sheet_name = workbook.sheet_names[0]
        return pd.read_excel(workbook, sheet_name=sheet_name)
    raise ValueError(f"Unsupported table format for {path}; use CSV or XLSX")


def read_annotation_file(path: Path) -> pd.DataFrame:
    preferred = "Annotations" if path.suffix.lower() in {".xlsx", ".xlsm"} else None
    return read_tabular_file(path, preferred_sheet=preferred)
