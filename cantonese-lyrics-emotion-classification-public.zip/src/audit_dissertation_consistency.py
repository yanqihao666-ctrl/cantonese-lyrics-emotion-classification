"""Audit dissertation terminology, research questions and design constants."""

from __future__ import annotations

import argparse
import json
import re
from pathlib import Path

import yaml


class DissertationConsistencyError(ValueError):
    """Raised when dissertation sources drift from their declared contract."""


QUESTION_PATTERN = re.compile(r"^[1-4]\.\s+((?:How|What)\b.+\?)\s*$")


def _read_yaml(path: Path) -> dict:
    with path.open("r", encoding="utf-8") as handle:
        value = yaml.safe_load(handle)
    if not isinstance(value, dict):
        raise DissertationConsistencyError(f"{path} is not a YAML mapping")
    return value


def _read_text(path: Path) -> str:
    if not path.is_file():
        raise DissertationConsistencyError(f"Required file is missing: {path}")
    return path.read_text(encoding="utf-8")


def _extract_questions(text: str) -> list[str]:
    questions: list[str] = []
    for line in text.splitlines():
        match = QUESTION_PATTERN.match(line)
        if match:
            questions.append(match.group(1))
    return questions


def _check_chapter_headings(
    project_root: Path, chapter_files: dict
) -> dict[str, object]:
    checked: list[str] = []
    for raw_chapter, relative_path in chapter_files.items():
        chapter = int(raw_chapter)
        path = project_root / str(relative_path)
        text = _read_text(path)
        first_nonempty = next(
            (line for line in text.splitlines() if line.strip()), ""
        )
        expected_prefix = f"# Chapter {chapter}:"
        if not first_nonempty.startswith(expected_prefix):
            raise DissertationConsistencyError(
                f"{relative_path} must begin with {expected_prefix!r}"
            )

        headings = [
            line
            for line in text.splitlines()
            if line.startswith("## ")
        ]
        if not headings:
            raise DissertationConsistencyError(
                f"{relative_path} contains no level-two chapter headings"
            )
        wrong = [
            heading
            for heading in headings
            if not heading.startswith(f"## {chapter}.")
        ]
        if wrong:
            raise DissertationConsistencyError(
                f"{relative_path} has headings outside Chapter {chapter}: "
                f"{wrong[:3]}"
            )
        checked.append(str(relative_path))

    return {
        "chapter_files_checked": checked,
        "chapter_count": len(checked),
    }


def _check_base_config(contract: dict, base: dict) -> dict[str, object]:
    task = contract["task"]
    evaluation = contract["evaluation"]
    base_data = base.get("data", {})

    for key in ["unit", "id_column", "parent_song_column"]:
        contract_key = {
            "unit": "unit",
            "id_column": "case_id_column",
            "parent_song_column": "parent_song_column",
        }[key]
        if base_data.get(key) != task.get(contract_key):
            raise DissertationConsistencyError(
                f"Task identity drift for {key}: "
                f"{base_data.get(key)!r} != {task.get(contract_key)!r}"
            )

    observed_classes = base_data.get("classes")
    if observed_classes != task["labels"]:
        raise DissertationConsistencyError(
            f"Class order drift: {observed_classes!r} != {task['labels']!r}"
        )

    observed_primary = base.get("evaluation", {}).get("primary_metric")
    if observed_primary != task["primary_metric"]:
        raise DissertationConsistencyError(
            f"Primary metric drift: {observed_primary!r}"
        )

    observed_secondary = base.get("evaluation", {}).get(
        "secondary_metrics"
    )
    if (
        not isinstance(observed_secondary, list)
        or len(observed_secondary) != len(task["secondary_metrics"])
        or set(observed_secondary) != set(task["secondary_metrics"])
    ):
        raise DissertationConsistencyError(
            "Secondary metric set has drifted"
        )

    observed_seeds = base.get("evaluation", {}).get("random_seeds")
    if observed_seeds != evaluation["split_seeds"]:
        raise DissertationConsistencyError(
            f"Split-seed drift: {observed_seeds!r}"
        )

    curves = base.get("learning_curves", {})
    if curves.get("partition_seed") != evaluation["learning_curve_seed"]:
        raise DissertationConsistencyError("Learning-curve seed has drifted")
    if curves.get("outer_folds") != list(
        range(1, evaluation["outer_folds"] + 1)
    ):
        raise DissertationConsistencyError(
            "Learning-curve outer-fold list has drifted"
        )
    if curves.get("fractions") != evaluation["learning_curve_fractions"]:
        raise DissertationConsistencyError(
            "Learning-curve fractions have drifted"
        )

    configured_models = {
        item["model"]: item["revision"]
        for item in base.get("transformer_models", {}).get("candidates", [])
    }
    declared_models = (
        contract["required_transformers"]
        + contract["exploratory_transformers"]
    )
    for item in declared_models:
        observed_revision = configured_models.get(item["model_id"])
        if observed_revision != item["revision"]:
            raise DissertationConsistencyError(
                f"Model revision drift for {item['model_id']}: "
                f"{observed_revision!r}"
            )

    expected_partitions = (
        len(evaluation["split_seeds"]) * evaluation["outer_folds"]
    )
    if expected_partitions != evaluation["expected_partitions"]:
        raise DissertationConsistencyError(
            "Expected partition count is inconsistent with seeds × folds"
        )

    return {
        "labels": observed_classes,
        "task_unit": base_data["unit"],
        "case_id_column": base_data["id_column"],
        "parent_song_column": base_data["parent_song_column"],
        "primary_metric": observed_primary,
        "split_seeds": observed_seeds,
        "expected_partitions": expected_partitions,
        "model_revisions_checked": len(declared_models),
    }


def audit_dissertation_consistency(
    project_root: Path,
    contract_path: Path | None = None,
    base_config_path: Path | None = None,
) -> dict[str, object]:
    project_root = project_root.resolve()
    contract_path = contract_path or (
        project_root / "configs" / "dissertation_contract.yaml"
    )
    base_config_path = base_config_path or (
        project_root / "configs" / "base.yaml"
    )
    contract = _read_yaml(contract_path)
    base = _read_yaml(base_config_path)

    required_contract_keys = {
        "title",
        "aim",
        "research_questions",
        "chapter_files",
        "task",
        "evaluation",
        "required_transformers",
        "exploratory_transformers",
        "placeholder_policy",
        "forbidden_drift_phrases",
    }
    missing_keys = required_contract_keys.difference(contract)
    if missing_keys:
        raise DissertationConsistencyError(
            f"Dissertation contract is missing keys: {sorted(missing_keys)}"
        )

    chapter_result = _check_chapter_headings(
        project_root, contract["chapter_files"]
    )

    text_paths = {
        "README.md",
        "docs/research_plan.md",
        *map(str, contract["chapter_files"].values()),
    }
    texts = {
        relative_path: _read_text(project_root / relative_path)
        for relative_path in sorted(text_paths)
    }

    aim_files = ["docs/research_plan.md", "docs/introduction_draft.md"]
    for relative_path in aim_files:
        if contract["aim"] not in texts[relative_path]:
            raise DissertationConsistencyError(
                f"Canonical aim is missing from {relative_path}"
            )

    question_files = [
        "README.md",
        "docs/introduction_draft.md",
        "docs/methodology_draft.md",
    ]
    canonical_questions = contract["research_questions"]
    for relative_path in question_files:
        observed = _extract_questions(texts[relative_path])
        if observed != canonical_questions:
            raise DissertationConsistencyError(
                f"Research-question drift in {relative_path}: {observed!r}"
            )

    primary_model_names = {
        item["display_name"] for item in contract["required_transformers"]
    }
    model_name_files = [
        "docs/research_plan.md",
        "docs/introduction_draft.md",
        "docs/results_chapter_template.md",
    ]
    for relative_path in model_name_files:
        missing_names = [
            name
            for name in sorted(primary_model_names)
            if name not in texts[relative_path]
        ]
        if missing_names:
            raise DissertationConsistencyError(
                f"{relative_path} is missing primary model names: "
                f"{missing_names}"
            )

    placeholder_policy = contract["placeholder_policy"]
    allowed_placeholder_files = set(placeholder_policy["allowed_files"])
    placeholder_counts: dict[str, int] = {}
    for relative_path, text in texts.items():
        count = sum(
            text.count(token) for token in placeholder_policy["tokens"]
        )
        if count and relative_path not in allowed_placeholder_files:
            raise DissertationConsistencyError(
                f"Result placeholder found outside approved template: "
                f"{relative_path}"
            )
        placeholder_counts[relative_path] = count

    combined_text = "\n".join(texts.values())
    stale_phrases = [
        phrase
        for phrase in contract["forbidden_drift_phrases"]
        if phrase in combined_text
    ]
    if stale_phrases:
        raise DissertationConsistencyError(
            f"Stale dissertation wording detected: {stale_phrases}"
        )

    base_result = _check_base_config(contract, base)
    checks = {
        "canonical_aim": "pass",
        "canonical_research_questions": "pass",
        "chapter_numbering": "pass",
        "task_and_metrics": "pass",
        "evaluation_constants": "pass",
        "model_revisions": "pass",
        "placeholder_scope": "pass",
        "forbidden_drift_phrases": "pass",
    }
    return {
        "status": "pass",
        "checks": checks,
        "check_count": len(checks),
        "research_question_count": len(canonical_questions),
        "aim_files_checked": aim_files,
        "research_question_files_checked": question_files,
        "placeholder_counts": placeholder_counts,
        **chapter_result,
        **base_result,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path("."))
    parser.add_argument("--contract", type=Path)
    parser.add_argument("--base-config", type=Path)
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    project_root = args.project_root.resolve()
    contract = (
        args.contract.resolve()
        if args.contract
        else project_root / "configs" / "dissertation_contract.yaml"
    )
    base_config = (
        args.base_config.resolve()
        if args.base_config
        else project_root / "configs" / "base.yaml"
    )
    report = audit_dissertation_consistency(
        project_root,
        contract_path=contract,
        base_config_path=base_config,
    )
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
