"""Binary high-arousal and tenderness screens for the v2 review queue."""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


def parse(text: str) -> tuple[int | None, int, str]:
    decision_match = re.search(r'"decision"\s*:\s*([01])', text)
    confidence_match = re.search(r'"confidence"\s*:\s*([1-5])', text)
    evidence_match = re.search(r'"evidence"\s*:\s*"([^"]*)', text)
    decision = int(decision_match.group(1)) if decision_match else None
    confidence = int(confidence_match.group(1)) if confidence_match else 1
    evidence = evidence_match.group(1) if evidence_match else text[:400]
    return decision, confidence, evidence


def make_prompt(row: pd.Series, target: str) -> str:
    if target == "anger_tension":
        question = """Does the section's DOMINANT perceived affect show negative HIGH arousal: anger, resentment, confrontation, protest, jealousy, fear, anxiety, pressure, panic or agitation?
Return decision 1 only when activation is explicit in the local wording. Return 0 for grief, loneliness, regret or resignation without agitation, even if the topic is painful."""
    else:
        question = """Does the section's DOMINANT perceived affect show positive LOW arousal: tenderness, reassurance, peace, acceptance, gentle affection, contentment or emotional safety?
Return decision 1 only when positive low-arousal affect is explicit. Return 0 for neutral narration, sadness, or energetic excitement."""
    return f"""{question}

Song: {row['title']} — {row['artist']}
Section: {row['lyrics']}

Return JSON only: {{"decision":0,"confidence":1,"evidence":"quote or paraphrase the decisive local wording"}}
Confidence is an integer from 1 to 5. Do not consider dataset balance."""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B-Instruct")
    parser.add_argument("--revision", required=True)
    parser.add_argument("--batch-size", type=int, default=4)
    args = parser.parse_args()
    queue = pd.read_csv(args.input)
    tasks: list[dict[str, object]] = []
    for _, row in queue.iterrows():
        if bool(row["review_for_anger_tension"]):
            tasks.append({**row.to_dict(), "screen_target": "anger_tension"})
        if bool(row["review_for_calm_tenderness"]):
            tasks.append({**row.to_dict(), "screen_target": "calm_tenderness"})
    task_frame = pd.DataFrame(tasks)
    existing: dict[str, dict[str, object]] = {}
    if args.output.exists():
        prior = pd.read_csv(args.output)
        existing = {
            f"{row['case_id']}::{row['screen_target']}": row.to_dict()
            for _, row in prior.iterrows()
        }

    tokenizer = AutoTokenizer.from_pretrained(args.model, revision=args.revision)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        revision=args.revision,
        dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        low_cpu_mem_usage=True,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()
    rows = list(existing.values())
    keys = task_frame.apply(lambda row: f"{row['case_id']}::{row['screen_target']}", axis=1)
    pending = task_frame.loc[~keys.isin(existing)].copy()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    for start in range(0, len(pending), args.batch_size):
        batch = pending.iloc[start : start + args.batch_size]
        rendered = [
            tokenizer.apply_chat_template(
                [
                    {"role": "system", "content": "Answer the binary Cantonese lyric annotation question. Output JSON only."},
                    {"role": "user", "content": make_prompt(row, row["screen_target"])},
                ],
                tokenize=False,
                add_generation_prompt=True,
            )
            for _, row in batch.iterrows()
        ]
        inputs = tokenizer(rendered, return_tensors="pt", padding=True, truncation=True, max_length=1024).to(device)
        with torch.inference_mode():
            outputs = model.generate(
                **inputs,
                max_new_tokens=90,
                do_sample=False,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        prompt_length = inputs["input_ids"].shape[1]
        decoded = [tokenizer.decode(value[prompt_length:], skip_special_tokens=True).strip() for value in outputs]
        for (_, source), raw in zip(batch.iterrows(), decoded):
            decision, confidence, evidence = parse(raw)
            rows.append(
                {
                    "case_id": source["case_id"],
                    "screen_target": source["screen_target"],
                    "screen_decision": decision,
                    "screen_confidence": confidence,
                    "screen_evidence": evidence,
                    "screen_parse_ok": decision is not None,
                    "model_name": args.model,
                    "model_revision": args.revision,
                    "screened_at_utc": datetime.now(timezone.utc).isoformat(),
                }
            )
        pd.DataFrame(rows).sort_values(["case_id", "screen_target"]).to_csv(args.output, index=False, encoding="utf-8-sig")
        print(f"screened={len(rows)}/{len(task_frame)}", flush=True)

    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "tasks": len(task_frame),
        "candidate_sections": int(task_frame["case_id"].nunique()),
        "model": args.model,
        "revision": args.revision,
        "warning": "AI screening only; not human gold and not an automatic relabelling decision.",
    }
    args.output.with_suffix(".metadata.json").write_text(json.dumps(metadata, indent=2), encoding="utf-8")


if __name__ == "__main__":
    main()
