"""Build an explicitly non-gold dataset for end-to-end development runs."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd


LABELS = {"joy", "sadness", "anger", "calmness"}


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_silver_development_dataset(
    source: pd.DataFrame,
    candidates: pd.DataFrame,
    minimum_prompt_agreement: float = 2 / 3,
) -> tuple[pd.DataFrame, dict[str, object]]:
    """Join source sections to usable candidates without claiming gold quality."""

    source_required = {"case_id", "corpus_song_id", "artist", "lyrics"}
    candidate_required = {
        "case_id",
        "candidate_label",
        "prompt_agreement",
        "mean_top_two_margin",
        "candidate_method",
        "candidate_model_revision",
    }
    missing_source = sorted(source_required.difference(source.columns))
    missing_candidates = sorted(candidate_required.difference(candidates.columns))
    if missing_source:
        raise ValueError(f"Source is missing columns: {missing_source}")
    if missing_candidates:
        raise ValueError(f"Candidates are missing columns: {missing_candidates}")
    if source["case_id"].isna().any() or source["case_id"].duplicated().any():
        raise ValueError("Source case_id must be present and unique")
    if candidates["case_id"].isna().any() or candidates["case_id"].duplicated().any():
        raise ValueError("Candidate case_id must be present and unique")
    if set(source["case_id"].astype(str)) != set(candidates["case_id"].astype(str)):
        raise ValueError("Source and candidate files must cover identical case_id values")
    if not 0 < minimum_prompt_agreement <= 1:
        raise ValueError("minimum_prompt_agreement must lie in (0, 1]")

    candidate_columns = [
        "case_id",
        "candidate_label",
        "prompt_agreement",
        "mean_top_two_margin",
        "candidate_method",
        "candidate_model_revision",
    ]
    if "candidate_tied" in candidates.columns:
        candidate_columns.append("candidate_tied")
    joined = source.merge(
        candidates[candidate_columns],
        on="case_id",
        how="left",
        validate="one_to_one",
    )
    joined["candidate_label"] = (
        joined["candidate_label"].astype("string").str.strip().str.lower()
    )
    invalid = sorted(
        set(joined["candidate_label"].dropna()).difference(LABELS)
    )
    if invalid:
        raise ValueError(f"Invalid candidate labels: {invalid}")
    joined["prompt_agreement"] = pd.to_numeric(
        joined["prompt_agreement"],
        errors="coerce",
    )
    joined["mean_top_two_margin"] = pd.to_numeric(
        joined["mean_top_two_margin"],
        errors="coerce",
    )
    eligible = (
        joined["candidate_label"].notna()
        & joined["prompt_agreement"].ge(minimum_prompt_agreement)
    )
    development = joined.loc[eligible].copy()
    development["emotion"] = development["candidate_label"]
    development["label_quality"] = "silver"
    development["label_status"] = "ai_candidate_development_only"
    development["formal_evaluation_eligible"] = False
    development = development.sort_values("case_id").reset_index(drop=True)

    class_counts = (
        development["emotion"]
        .value_counts()
        .reindex(sorted(LABELS), fill_value=0)
        .to_dict()
    )
    artist_groups = (
        development[["emotion", "artist"]]
        .drop_duplicates()
        .groupby("emotion")["artist"]
        .nunique()
        .reindex(sorted(LABELS), fill_value=0)
        .to_dict()
    )
    metadata: dict[str, object] = {
        "source_rows": len(source),
        "candidate_rows": len(candidates),
        "included_development_rows": len(development),
        "excluded_rows": int((~eligible).sum()),
        "minimum_prompt_agreement": minimum_prompt_agreement,
        "class_counts": {key: int(value) for key, value in class_counts.items()},
        "artist_groups_per_class": {
            key: int(value) for key, value in artist_groups.items()
        },
        "source_songs": int(development["corpus_song_id"].nunique()),
        "artists": int(development["artist"].nunique()),
        "label_quality": "silver",
        "formal_evaluation_eligible": False,
        "warning": (
            "AI candidate labels are for software development only and must not "
            "be reported as human-gold model performance."
        ),
    }
    return development, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("candidates", type=Path)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("data/processed/section_silver_development.csv"),
    )
    parser.add_argument("--minimum-prompt-agreement", type=float, default=2 / 3)
    args = parser.parse_args()

    development, metadata = build_silver_development_dataset(
        pd.read_csv(args.source),
        pd.read_csv(args.candidates),
        minimum_prompt_agreement=args.minimum_prompt_agreement,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    development.to_csv(args.output, index=False, encoding="utf-8-sig")
    metadata.update(
        {
            "source_path": str(args.source),
            "source_sha256": file_sha256(args.source),
            "candidate_path": str(args.candidates),
            "candidate_sha256": file_sha256(args.candidates),
            "output_path": str(args.output),
            "output_sha256": file_sha256(args.output),
        }
    )
    metadata_path = args.output.with_suffix(".metadata.json")
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
