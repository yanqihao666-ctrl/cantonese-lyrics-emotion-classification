"""Select one classical configuration per outer partition using validation only."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd

from src.statistical_analysis import validate_predictions


SELECTED_MODEL_KEY = "classical::validation_selected"


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def discover_classical_runs(inputs: list[Path]) -> list[Path]:
    """Return run directories containing the three required classical artifacts."""

    discovered: set[Path] = set()
    for input_path in inputs:
        if input_path.is_file() and input_path.name == "metrics.csv":
            discovered.add(input_path.parent.resolve())
        elif input_path.is_dir():
            if (input_path / "metrics.csv").exists():
                discovered.add(input_path.resolve())
            for metrics_path in input_path.rglob("metrics.csv"):
                discovered.add(metrics_path.parent.resolve())
        else:
            raise FileNotFoundError(input_path)
    if not discovered:
        raise ValueError("No classical fixed-partition runs found")
    for run_dir in discovered:
        missing = [
            name
            for name in ["metrics.csv", "predictions.csv", "run_metadata.json"]
            if not (run_dir / name).exists()
        ]
        if missing:
            raise ValueError(f"{run_dir} is missing artifacts: {missing}")
    return sorted(discovered)


def _load_metadata(path: Path) -> dict[str, object]:
    try:
        metadata = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise ValueError(f"Unreadable metadata: {path}") from error
    required = {
        "partition_seed",
        "outer_fold",
        "input_sha256",
        "shared_fixed_partition",
    }
    missing = sorted(required.difference(metadata))
    if missing:
        raise ValueError(f"{path} is missing trace fields: {missing}")
    if metadata["shared_fixed_partition"] is not True:
        raise ValueError(f"{path} is not a shared fixed-partition run")
    return metadata


def select_classical_runs(
    run_dirs: list[Path],
    primary_metric: str = "macro_f1",
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    """Create a leakage-free composite from validation-selected configurations."""

    if not run_dirs:
        raise ValueError("At least one classical run is required")
    selected_parts: list[pd.DataFrame] = []
    audit_parts: list[pd.DataFrame] = []
    source_artifacts: list[dict[str, object]] = []
    identities: set[tuple[int, int]] = set()

    for run_dir in sorted(Path(path).resolve() for path in run_dirs):
        metrics_path = run_dir / "metrics.csv"
        predictions_path = run_dir / "predictions.csv"
        metadata_path = run_dir / "run_metadata.json"
        metadata = _load_metadata(metadata_path)
        partition_seed = int(metadata["partition_seed"])
        outer_fold = int(metadata["outer_fold"])
        identity = (partition_seed, outer_fold)
        if identity in identities:
            raise ValueError(f"Duplicate classical partition identity: {identity}")
        identities.add(identity)

        metrics = pd.read_csv(metrics_path)
        required_metrics = {
            "model_key",
            "feature_set",
            "model",
            "evaluation_split",
            primary_metric,
        }
        missing_metrics = sorted(required_metrics.difference(metrics.columns))
        if missing_metrics:
            raise ValueError(f"{metrics_path} is missing columns: {missing_metrics}")
        validation = metrics.loc[metrics["evaluation_split"] == "validation"].copy()
        test_metrics = metrics.loc[metrics["evaluation_split"] == "test"].copy()
        if validation.empty or test_metrics.empty:
            raise ValueError(f"{metrics_path} requires validation and test rows")
        if validation["model_key"].duplicated().any():
            raise ValueError(f"{metrics_path} has duplicate validation configurations")
        if set(validation["model_key"]) != set(test_metrics["model_key"]):
            raise ValueError(f"{metrics_path} has inconsistent validation/test configurations")
        if not np.isfinite(pd.to_numeric(validation[primary_metric], errors="coerce")).all():
            raise ValueError(f"{metrics_path} contains invalid validation {primary_metric}")

        ranked = validation.sort_values(
            [primary_metric, "model_key"],
            ascending=[False, True],
            kind="mergesort",
        ).reset_index(drop=True)
        ranked["validation_rank"] = np.arange(1, len(ranked) + 1)
        selected_source_key = str(ranked.loc[0, "model_key"])
        ranked["selected"] = ranked["model_key"] == selected_source_key
        ranked["partition_seed"] = partition_seed
        ranked["outer_fold"] = outer_fold
        ranked["selection_rule"] = (
            f"highest validation {primary_metric}; lexicographic model_key tie-break"
        )
        ranked = ranked.merge(
            test_metrics[["model_key", primary_metric]].rename(
                columns={primary_metric: f"test_{primary_metric}"}
            ),
            on="model_key",
            how="left",
            validate="one_to_one",
        )
        audit_parts.append(ranked)

        predictions = pd.read_csv(predictions_path)
        if "case_id" not in predictions.columns and "corpus_song_id" in predictions.columns:
            predictions["case_id"] = predictions["corpus_song_id"]
        required_predictions = {
            "model_key",
            "evaluation_split",
            "partition_seed",
            "outer_fold",
            "case_id",
            "true_label",
            "predicted_label",
        }
        missing_predictions = sorted(required_predictions.difference(predictions.columns))
        if missing_predictions:
            raise ValueError(
                f"{predictions_path} is missing columns: {missing_predictions}"
            )
        observed_identity = set(
            zip(
                predictions["partition_seed"].astype(int),
                predictions["outer_fold"].astype(int),
            )
        )
        if observed_identity != {identity}:
            raise ValueError(
                f"{predictions_path} identity {sorted(observed_identity)} "
                f"does not match metadata {identity}"
            )
        selected = predictions.loc[
            (predictions["evaluation_split"] == "test")
            & (predictions["model_key"] == selected_source_key)
        ].copy()
        if selected.empty:
            raise ValueError(
                f"{predictions_path} has no test predictions for {selected_source_key}"
            )
        selected["source_model_key"] = selected["model_key"]
        selected["model_key"] = SELECTED_MODEL_KEY
        selected_parts.append(selected)
        source_artifacts.append(
            {
                "partition_seed": partition_seed,
                "outer_fold": outer_fold,
                "input_sha256": metadata["input_sha256"],
                "metrics_path": str(metrics_path),
                "metrics_sha256": file_sha256(metrics_path),
                "predictions_path": str(predictions_path),
                "predictions_sha256": file_sha256(predictions_path),
                "metadata_path": str(metadata_path),
                "metadata_sha256": file_sha256(metadata_path),
                "selected_source_model_key": selected_source_key,
            }
        )

    combined = validate_predictions(pd.concat(selected_parts, ignore_index=True))
    combined = combined.sort_values(
        ["partition_seed", "outer_fold", "case_id"]
    ).reset_index(drop=True)
    audit = pd.concat(audit_parts, ignore_index=True).sort_values(
        ["partition_seed", "outer_fold", "validation_rank"]
    )
    metadata_output: dict[str, object] = {
        "selected_model_key": SELECTED_MODEL_KEY,
        "primary_selection_metric": primary_metric,
        "selection_data_role": "validation",
        "tie_break": "model_key ascending lexicographic order",
        "partitions": len(identities),
        "partition_identities": [
            {"partition_seed": seed, "outer_fold": fold}
            for seed, fold in sorted(identities)
        ],
        "source_artifacts": source_artifacts,
        "test_metric_used_for_selection": False,
    }
    return combined, audit, metadata_output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/formal/classical_validation_selection"),
    )
    parser.add_argument("--primary-metric", default="macro_f1")
    parser.add_argument("--expected-partitions", type=int, default=15)
    parser.add_argument("--allow-partial-grid", action="store_true")
    args = parser.parse_args()

    run_dirs = discover_classical_runs(args.inputs)
    predictions, audit, metadata = select_classical_runs(
        run_dirs,
        primary_metric=args.primary_metric,
    )
    if not args.allow_partial_grid and metadata["partitions"] != args.expected_partitions:
        raise ValueError(
            f"Expected {args.expected_partitions} partitions, found "
            f"{metadata['partitions']}"
        )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    predictions.to_csv(
        args.output_dir / "selected_test_predictions.csv",
        index=False,
        encoding="utf-8-sig",
    )
    audit.to_csv(
        args.output_dir / "selection_audit.csv",
        index=False,
        encoding="utf-8-sig",
    )
    (args.output_dir / "selection_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "partitions": metadata["partitions"],
                "prediction_rows": len(predictions),
                "selected_model_key": SELECTED_MODEL_KEY,
                "output_dir": str(args.output_dir),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
