"""Position-calibrated four-class scoring for the 6,000 lyric sections.

Instead of generating a label, this module reads the next-token logits for
single-token options A-D. Every emotion occupies every option position once.
For each permutation, a content-free prior is subtracted before mapped scores
are averaged. This directly addresses the severe option-order bias observed in
the rejected generation pilot.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import math
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


LABELS = ("joy", "sadness", "anger", "calmness")
OPTIONS = ("A", "B", "C", "D")
MODEL = "Qwen/Qwen2.5-3B-Instruct"
REVISION = "aa8e72537993ba99e69dfaafa59ed015b17504d1"
DEFINITIONS = {
    "joy": "joy（喜悦、希望、庆祝、兴奋、热烈爱意）",
    "sadness": "sadness（失落、孤独、遗憾、离别、痛苦思念）",
    "anger": "anger（愤怒、怨恨、指责、抗议、对抗）",
    "calmness": "calmness（平和、安慰、温柔、释然、宁静）",
}
PERMUTATIONS = [
    ("joy", "sadness", "anger", "calmness"),
    ("sadness", "anger", "calmness", "joy"),
    ("anger", "calmness", "joy", "sadness"),
    ("calmness", "joy", "sadness", "anger"),
]


def prompt(lyrics: str, permutation: tuple[str, ...]) -> str:
    choices = "\n".join(
        f"{option}. {DEFINITIONS[label]}"
        for option, label in zip(OPTIONS, permutation)
    )
    return (
        "选择歌词叙述者最强的主要情绪：\n"
        f"{choices}\n"
        "爱不自动等于joy；痛苦思念属sadness；明确指责或对抗才属anger。"
        "只答A/B/C/D。\n"
        f"歌词片段：\n{lyrics}\n答案："
    )


def map_option_scores(
    option_scores: np.ndarray, permutation: tuple[str, ...]
) -> dict[str, float]:
    if option_scores.shape != (4,):
        raise ValueError("Expected four option scores")
    return {label: float(option_scores[index]) for index, label in enumerate(permutation)}


def aggregate_calibrated_scores(
    calibrated_by_permutation: list[dict[str, float]],
) -> dict[str, object]:
    if len(calibrated_by_permutation) != len(PERMUTATIONS):
        raise ValueError("Expected one score map per permutation")
    means = {
        label: float(np.mean([item[label] for item in calibrated_by_permutation]))
        for label in LABELS
    }
    values = np.array([means[label] for label in LABELS], dtype=float)
    probabilities = np.exp(values - values.max())
    probabilities /= probabilities.sum()
    order = np.argsort(probabilities)[::-1]
    label = LABELS[int(order[0])]
    alternative = LABELS[int(order[1])]
    margin = float(probabilities[order[0]] - probabilities[order[1]])
    entropy = float(-np.sum(probabilities * np.log(probabilities + 1e-12)) / math.log(4))
    permutation_winners = [
        max(LABELS, key=lambda candidate: item[candidate])
        for item in calibrated_by_permutation
    ]
    return {
        "emotion": label,
        "alternative_label": alternative,
        "confidence_margin": margin,
        "normalised_entropy": entropy,
        "permutation_unanimous": len(set(permutation_winners)) == 1,
        "permutation_vote_count": permutation_winners.count(label),
        "permutation_winners": "|".join(permutation_winners),
        **{f"score_{key}": means[key] for key in LABELS},
        **{f"probability_{key}": float(probabilities[i]) for i, key in enumerate(LABELS)},
    }


def _load_model():
    tokenizer = AutoTokenizer.from_pretrained(MODEL, revision=REVISION, local_files_only=True)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    option_ids = [tokenizer.encode(value, add_special_tokens=False) for value in OPTIONS]
    if any(len(value) != 1 for value in option_ids):
        raise RuntimeError(f"A-D must be single tokens, got {option_ids}")
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model = AutoModelForCausalLM.from_pretrained(
        MODEL,
        revision=REVISION,
        local_files_only=True,
        dtype=torch.float16 if device.type == "cuda" else torch.float32,
        low_cpu_mem_usage=True,
    ).to(device).eval()
    return tokenizer, model, device, [value[0] for value in option_ids]


def _option_logits(tokenizer, model, device, option_ids: list[int], prompts: list[str]) -> np.ndarray:
    rendered = [
        tokenizer.apply_chat_template(
            [
                {
                    "role": "system",
                    "content": "你是严谨的粤语歌词情绪标注员，严格按文字证据判断。",
                },
                {"role": "user", "content": value},
            ],
            tokenize=False,
            add_generation_prompt=True,
        )
        for value in prompts
    ]
    inputs = tokenizer(
        rendered, return_tensors="pt", padding=True, truncation=True, max_length=288
    ).to(device)
    with torch.inference_mode():
        logits = model(**inputs).logits[:, -1, option_ids]
    return logits.float().cpu().numpy()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    parser.add_argument("--checkpoint", type=Path, required=True)
    parser.add_argument("--batch-size", type=int, default=32)
    parser.add_argument("--prioritise-original", action="store_true")
    args = parser.parse_args()
    frame = pd.read_csv(args.input_csv, low_memory=False)
    if len(frame) != 6000 or frame["case_id"].duplicated().any():
        raise ValueError("Expected exactly 6,000 unique cases")
    if args.prioritise_original:
        frame = frame.assign(
            _priority=~frame["source_cohort"].eq("original_680")
        ).sort_values(["_priority", "case_id"], kind="stable").drop(columns="_priority")
    tokenizer, model, device, option_ids = _load_model()
    priors = []
    for permutation in PERMUTATIONS:
        prior = _option_logits(
            tokenizer, model, device, option_ids, [prompt("内容未知", permutation)]
        )[0]
        priors.append(prior)

    existing = pd.read_csv(args.checkpoint) if args.checkpoint.exists() else pd.DataFrame()
    done = set(existing.get("case_id", pd.Series(dtype=str)).astype(str))
    rows = existing.to_dict(orient="records")
    pending = frame.loc[~frame["case_id"].astype(str).isin(done)]
    for start in range(0, len(pending), args.batch_size):
        batch = pending.iloc[start : start + args.batch_size]
        per_item: list[list[dict[str, float]]] = [[] for _ in range(len(batch))]
        for permutation_index, permutation in enumerate(PERMUTATIONS):
            logits = _option_logits(
                tokenizer,
                model,
                device,
                option_ids,
                [prompt(str(value), permutation) for value in batch["lyrics"]],
            )
            calibrated = logits - priors[permutation_index][None, :]
            for item_index, option_scores in enumerate(calibrated):
                per_item[item_index].append(map_option_scores(option_scores, permutation))
        for (_, source), scores in zip(batch.iterrows(), per_item):
            rows.append({"case_id": source["case_id"], **aggregate_calibrated_scores(scores)})
        args.checkpoint.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).to_csv(args.checkpoint, index=False, encoding="utf-8-sig")
        print(f"scored: {len(rows)}/{len(frame)}", flush=True)

    scored = pd.DataFrame(rows)
    output = frame.drop(
        columns=[
            "emotion",
            "expanded_ai_label",
            "alternative_label",
            "ai_confidence_1_to_5",
            "needs_human_review",
            "annotator_type",
            "model_name",
            "model_revision",
            "annotated_at_utc",
            "development_label_source",
        ],
        errors="ignore",
    ).merge(scored, on="case_id", validate="one_to_one")
    output["expanded_ai_label"] = output["emotion"]
    output["needs_human_review"] = (
        output["confidence_margin"].lt(0.15)
        | output["permutation_vote_count"].lt(3)
    )
    output["ai_confidence_1_to_5"] = pd.cut(
        output["confidence_margin"],
        bins=[-1, 0.05, 0.15, 0.30, 0.50, 1.0],
        labels=[1, 2, 3, 4, 5],
    ).astype(int)
    output["label_status"] = "position_calibrated_ai_assisted_development_label"
    output["development_label_source"] = "qwen_four_permutation_calibrated_logit_scoring"
    output["annotator_type"] = "AI research-assisted scoring"
    output["model_name"] = MODEL
    output["model_revision"] = REVISION
    output["development_only"] = True
    output["formal_evaluation_eligible"] = False
    output["annotated_at_utc"] = datetime.now(timezone.utc).isoformat()
    output["historical_label_agreement"] = (
        output["historical_emotion"].isna()
        | output["historical_emotion"].eq(output["emotion"])
    )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output_csv, index=False, encoding="utf-8-sig")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(output),
        "label_counts": output["emotion"].value_counts().to_dict(),
        "permutation_unanimous_rate": float(output["permutation_unanimous"].mean()),
        "needs_human_review": int(output["needs_human_review"].sum()),
        "mean_confidence_margin": float(output["confidence_margin"].mean()),
        "historical_680_agreement_rate": float(
            output.loc[output["source_cohort"].eq("original_680"), "historical_label_agreement"].mean()
        ),
        "model": MODEL,
        "revision": REVISION,
        "device": str(device),
        "method": "four cyclic option permutations; content-free logit calibration; mean mapped score",
        "formal_evaluation_eligible": False,
        "warning": "AI-assisted development labels; not independent human gold.",
        "input_sha256": hashlib.sha256(args.input_csv.read_bytes()).hexdigest(),
        "output_sha256": hashlib.sha256(args.output_csv.read_bytes()).hexdigest(),
    }
    args.output_csv.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
