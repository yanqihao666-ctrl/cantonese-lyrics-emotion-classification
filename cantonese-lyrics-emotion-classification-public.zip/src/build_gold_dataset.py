"""Build a frozen gold dataset without overwriting raw human annotations."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from src.annotation_agreement import (
    ADJUDICATION_DECISION_COLUMNS,
    FLAG_COLUMNS,
    LABELS,
    _normalise_boolean,
    calculate_agreement,
    validate_annotations,
)
from src.tabular_io import read_annotation_file, read_tabular_file


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def resolve_item_id_column(
    source: pd.DataFrame,
    key: pd.DataFrame,
    requested: str | None = None,
) -> str:
    if requested is not None:
        if requested not in source.columns or requested not in key.columns:
            raise ValueError(
                f"Requested item identifier {requested!r} must exist in both "
                "the source corpus and researcher key"
            )
        return requested
    for candidate in ["case_id", "corpus_song_id"]:
        if candidate in source.columns and candidate in key.columns:
            return candidate
    raise ValueError(
        "Source corpus and researcher key require a shared case_id or corpus_song_id"
    )


def validate_researcher_key(
    key: pd.DataFrame,
    item_id_column: str = "corpus_song_id",
) -> pd.DataFrame:
    required = {"annotation_id", item_id_column}
    missing = sorted(required.difference(key.columns))
    if missing:
        raise ValueError(f"Researcher key is missing columns: {missing}")
    if key[list(required)].isna().any().any():
        raise ValueError("Researcher key identifiers cannot be missing")
    if (
        key["annotation_id"].duplicated().any()
        or key[item_id_column].duplicated().any()
    ):
        raise ValueError("Researcher key identifiers must be one-to-one")
    return key.copy()


def validate_adjudication_decisions(
    decisions: pd.DataFrame,
    required_ids: set[str],
) -> pd.DataFrame:
    required_columns = {"annotation_id", *ADJUDICATION_DECISION_COLUMNS}
    missing = sorted(required_columns.difference(decisions.columns))
    if missing:
        raise ValueError(f"Adjudication file is missing columns: {missing}")
    if decisions["annotation_id"].isna().any() or decisions["annotation_id"].duplicated().any():
        raise ValueError("Adjudication annotation_id must be present and unique")
    observed_ids = set(decisions["annotation_id"].astype(str))
    if observed_ids != required_ids:
        missing_ids = sorted(required_ids.difference(observed_ids))
        extra_ids = sorted(observed_ids.difference(required_ids))
        raise ValueError(
            f"Adjudication IDs do not match required queue; "
            f"missing={missing_ids}, extra={extra_ids}"
        )

    clean = decisions.copy()
    clean["annotation_id"] = clean["annotation_id"].astype(str)
    for column in [
        "adjudicated_label",
        "exclusion_reason",
        "adjudicator_rationale",
        "adjudicator_code",
        "adjudication_date",
    ]:
        clean[column] = clean[column].fillna("").astype(str).str.strip()
    raw_include = clean["include_in_gold"].fillna("").astype(str).str.strip()
    if raw_include.eq("").any():
        raise ValueError("Every adjudication requires an include_in_gold decision")
    clean["include_in_gold"] = _normalise_boolean(clean["include_in_gold"])
    clean["adjudicated_label"] = clean["adjudicated_label"].str.lower()
    included_invalid = clean.loc[
        clean["include_in_gold"]
        & ~clean["adjudicated_label"].isin(LABELS),
        "adjudicated_label",
    ]
    if not included_invalid.empty:
        raise ValueError(
            f"Included adjudications require a valid label: "
            f"{sorted(included_invalid.unique())}"
        )
    for column in ["adjudicator_rationale", "adjudicator_code", "adjudication_date"]:
        if clean[column].eq("").any():
            raise ValueError(f"Every adjudication requires {column}")
    excluded = ~clean["include_in_gold"]
    if (
        clean.loc[excluded, "exclusion_reason"].eq("").any()
    ):
        raise ValueError("Excluded items require an exclusion_reason")
    parsed_dates = pd.to_datetime(clean["adjudication_date"], errors="coerce")
    if parsed_dates.isna().any():
        raise ValueError("adjudication_date must be a valid date")
    clean["adjudication_date"] = parsed_dates.dt.strftime("%Y-%m-%d")
    return clean


def build_gold_dataset(
    source: pd.DataFrame,
    researcher_key: pd.DataFrame,
    annotator_a: pd.DataFrame,
    annotator_b: pd.DataFrame,
    adjudication_decisions: pd.DataFrame,
    item_id_column: str | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    """Return the included gold rows, lyric-free decision audit and metadata."""

    item_id_column = resolve_item_id_column(
        source,
        researcher_key,
        requested=item_id_column,
    )
    if (
        source[item_id_column].isna().any()
        or source[item_id_column].duplicated().any()
    ):
        raise ValueError(f"Source {item_id_column} must be present and unique")
    key = validate_researcher_key(
        researcher_key,
        item_id_column=item_id_column,
    )
    if set(source[item_id_column].astype(str)) != set(
        key[item_id_column].astype(str)
    ):
        raise ValueError("Source corpus and researcher key item IDs differ")

    a = validate_annotations(annotator_a, "annotator_a")
    b = validate_annotations(annotator_b, "annotator_b")
    annotation_ids = set(key["annotation_id"].astype(str))
    if set(a["annotation_id"].astype(str)) != annotation_ids:
        raise ValueError("Annotator A IDs differ from researcher key")
    if set(b["annotation_id"].astype(str)) != annotation_ids:
        raise ValueError("Annotator B IDs differ from researcher key")

    agreement_summary, _, required_queue = calculate_agreement(a, b)
    required_ids = set(required_queue["annotation_id"].astype(str))
    decisions = validate_adjudication_decisions(
        adjudication_decisions,
        required_ids=required_ids,
    )

    a_columns = ["annotation_id", "human_label", "confidence_1_to_5", *FLAG_COLUMNS]
    b_columns = ["annotation_id", "human_label", "confidence_1_to_5", *FLAG_COLUMNS]
    merged = a[a_columns].merge(
        b[b_columns],
        on="annotation_id",
        suffixes=("_a", "_b"),
        validate="one_to_one",
    )
    requirement_columns = [
        "annotation_id",
        "requires_adjudication",
        "adjudication_reasons",
    ]
    requirements = required_queue[requirement_columns].copy()
    requirements["requires_adjudication"] = True
    merged = merged.merge(
        requirements,
        on="annotation_id",
        how="left",
        validate="one_to_one",
    )
    merged["requires_adjudication"] = (
        merged["requires_adjudication"].fillna(False).astype(bool)
    )
    merged["adjudication_reasons"] = merged["adjudication_reasons"].fillna("")
    merged = merged.merge(
        decisions,
        on="annotation_id",
        how="left",
        validate="one_to_one",
    )

    consensus = ~merged["requires_adjudication"]
    merged.loc[consensus, "include_in_gold"] = True
    merged.loc[consensus, "adjudicated_label"] = merged.loc[
        consensus, "human_label_a"
    ]
    merged.loc[consensus, "adjudicator_rationale"] = "independent_label_agreement"
    merged.loc[consensus, "adjudicator_code"] = "not_applicable"
    merged.loc[consensus, "adjudication_date"] = ""
    merged.loc[consensus, "exclusion_reason"] = ""
    merged["include_in_gold"] = merged["include_in_gold"].astype(bool)
    merged["final_label"] = merged["adjudicated_label"].where(
        merged["include_in_gold"],
        "",
    )
    merged["label_source"] = "independent_agreement"
    merged.loc[merged["requires_adjudication"], "label_source"] = "adjudication"

    identity_columns = ["annotation_id", item_id_column]
    if "corpus_song_id" in key.columns and item_id_column != "corpus_song_id":
        identity_columns.append("corpus_song_id")
    audit = key[identity_columns].merge(
        merged,
        on="annotation_id",
        validate="one_to_one",
    )
    audit_columns = [
        "annotation_id",
        item_id_column,
        *(
            ["corpus_song_id"]
            if "corpus_song_id" in audit.columns
            and item_id_column != "corpus_song_id"
            else []
        ),
        "human_label_a",
        "human_label_b",
        "confidence_1_to_5_a",
        "confidence_1_to_5_b",
        *[
            f"{column}_{annotator}"
            for column in FLAG_COLUMNS
            for annotator in ["a", "b"]
        ],
        "requires_adjudication",
        "adjudication_reasons",
        "include_in_gold",
        "exclusion_reason",
        "adjudicated_label",
        "final_label",
        "label_source",
        "adjudicator_rationale",
        "adjudicator_code",
        "adjudication_date",
    ]
    audit = audit[audit_columns].sort_values(item_id_column).reset_index(drop=True)

    final_map = audit.loc[
        audit["include_in_gold"],
        [item_id_column, "annotation_id", "final_label", "label_source"],
    ].rename(columns={"final_label": "emotion"})
    gold = source.copy()
    gold[item_id_column] = gold[item_id_column].astype(str)
    final_map[item_id_column] = final_map[item_id_column].astype(str)
    gold = gold.merge(
        final_map,
        on=item_id_column,
        how="inner",
        validate="one_to_one",
    )
    if gold.empty:
        raise ValueError("Adjudication excluded every source item")
    invalid_final = sorted(set(gold["emotion"]).difference(LABELS))
    if invalid_final:
        raise ValueError(f"Gold output contains invalid labels: {invalid_final}")

    class_distribution = (
        gold["emotion"].value_counts().reindex(LABELS, fill_value=0).to_dict()
    )
    if "artist" in gold.columns:
        artist_groups_per_class = (
            gold.groupby("emotion")["artist"]
            .nunique()
            .reindex(LABELS, fill_value=0)
            .to_dict()
        )
    else:
        artist_groups_per_class = None
    metadata: dict[str, object] = {
        "item_id_column": item_id_column,
        "source_items": len(source),
        "included_items": len(gold),
        "excluded_items": int((~audit["include_in_gold"]).sum()),
        "required_adjudication_items": len(required_ids),
        "agreement_summary": agreement_summary,
        "class_distribution": class_distribution,
        "all_four_labels_present": all(class_distribution[label] > 0 for label in LABELS),
        "artist_groups_per_class": artist_groups_per_class,
        "supports_five_fold_artist_grouping": (
            all(artist_groups_per_class[label] >= 5 for label in LABELS)
            if artist_groups_per_class is not None
            else None
        ),
        "distinct_artists": int(gold["artist"].nunique())
        if "artist" in gold.columns
        else None,
        "distinct_songs": int(gold["corpus_song_id"].nunique())
        if "corpus_song_id" in gold.columns
        else None,
        "exclusion_reasons": (
            audit.loc[~audit["include_in_gold"], "exclusion_reason"]
            .value_counts()
            .to_dict()
        ),
        "raw_annotations_overwritten": False,
    }
    return gold, audit, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_corpus", type=Path)
    parser.add_argument("researcher_key", type=Path)
    parser.add_argument("annotator_a", type=Path)
    parser.add_argument("annotator_b", type=Path)
    parser.add_argument("adjudication_decisions", type=Path)
    parser.add_argument(
        "--item-id-column",
        default=None,
        help="Unique annotation/modelling unit; defaults to case_id when available.",
    )
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("data/processed"),
    )
    args = parser.parse_args()

    paths = {
        "source_corpus": args.source_corpus,
        "researcher_key": args.researcher_key,
        "annotator_a": args.annotator_a,
        "annotator_b": args.annotator_b,
        "adjudication_decisions": args.adjudication_decisions,
    }
    gold, audit, metadata = build_gold_dataset(
        read_tabular_file(args.source_corpus),
        read_tabular_file(args.researcher_key),
        read_annotation_file(args.annotator_a),
        read_annotation_file(args.annotator_b),
        read_tabular_file(args.adjudication_decisions),
        item_id_column=args.item_id_column,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    gold_path = args.output_dir / "gold_labelled.csv"
    audit_path = args.output_dir / "gold_decision_audit.csv"
    gold.to_csv(gold_path, index=False, encoding="utf-8-sig")
    audit.to_csv(audit_path, index=False, encoding="utf-8-sig")
    metadata.update(
        {
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "inputs": {
                name: {"path": str(path), "sha256": file_sha256(path)}
                for name, path in paths.items()
            },
            "gold_path": str(gold_path),
            "gold_sha256": file_sha256(gold_path),
            "audit_path": str(audit_path),
            "audit_sha256": file_sha256(audit_path),
        }
    )
    (args.output_dir / "gold_freeze_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "included_items": metadata["included_items"],
                "excluded_items": metadata["excluded_items"],
                "required_adjudication_items": metadata[
                    "required_adjudication_items"
                ],
                "gold_sha256": metadata["gold_sha256"],
                "output_dir": str(args.output_dir),
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
