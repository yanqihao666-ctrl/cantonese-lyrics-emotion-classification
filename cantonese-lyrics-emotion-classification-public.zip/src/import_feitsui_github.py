"""Build research-only lyric sections from the Feitsui GitHub BSON dump.

The repository code is MIT licensed, but that does not establish a licence to
redistribute the underlying song lyrics.  Outputs from this module therefore
belong under an ignored ``data/research_only`` directory and retain source URL,
repository revision and content hashes for auditability.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from collections import defaultdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable, Iterator

import pandas as pd


SOURCE_REPOSITORY = "https://github.com/yqbeyond/feitsui"
SOURCE_REVISION = "6189bcc2db41a59531714f938a4a96aac631d068"
SOURCE_NOTICE = (
    "Research-only local derivative. Repository software is MIT licensed; "
    "copyright status of the underlying lyrics is not established. Do not "
    "redistribute lyric text."
)

_TIMESTAMP = re.compile(r"\[\d{1,2}:\d{2}(?:[.:]\d{1,3})?\]")
_SPACES = re.compile(r"[\t\u3000 ]+")
_NON_CONTENT = re.compile(
    r"^(?:作词|作詞|作曲|编曲|編曲|监制|監製|填词|填詞|歌手|歌曲|歌词|歌詞|"
    r"主唱|制作|製作|专辑|專輯|旁白|独白|獨白|合唱|和声|和聲)\s*[:：]",
    flags=re.IGNORECASE,
)
_HAN = re.compile(r"[\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaff]")
_KEEP_FOR_HASH = re.compile(r"[^\u3400-\u4dbf\u4e00-\u9fff\uf900-\ufaffA-Za-z0-9]+")
_T2S = None


def sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def normalise_line(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or ""))
    text = _TIMESTAMP.sub("", text)
    text = text.replace("\r", "").strip()
    return _SPACES.sub(" ", text)


def content_key(value: str) -> str:
    return _KEEP_FOR_HASH.sub("", unicodedata.normalize("NFKC", value)).casefold()


def cross_source_content_key(value: str) -> str:
    """Canonical key that also collapses Traditional/Simplified variants."""
    global _T2S
    try:
        from opencc import OpenCC

        if _T2S is None:
            _T2S = OpenCC("t2s")
        value = _T2S.convert(value)
    except ImportError:  # pragma: no cover - dependency checked in production
        pass
    return content_key(value)


def is_usable_lyric_line(value: str) -> bool:
    """Return True for a Chinese lyric line and False for Jyutping/metadata."""
    line = normalise_line(value)
    if not line or _NON_CONTENT.match(line):
        return False
    han = len(_HAN.findall(line))
    visible = len(re.sub(r"\s+", "", line))
    if han < 3 or visible == 0:
        return False
    return han / visible >= 0.35


def chinese_lyric_lines(raw_lyric: object) -> list[str]:
    lines: list[str] = []
    for raw_line in str(raw_lyric or "").splitlines():
        line = normalise_line(raw_line)
        if is_usable_lyric_line(line):
            lines.append(line)
    return lines


def segment_lines(
    lines: Iterable[str],
    *,
    min_chars: int = 24,
    max_chars: int = 90,
) -> list[str]:
    """Create non-overlapping two- or three-line sections of similar scale."""
    values = [normalise_line(line) for line in lines if normalise_line(line)]
    sections: list[str] = []
    seen: set[str] = set()
    index = 0
    while index + 1 < len(values):
        group = values[index : index + 2]
        char_count = len(content_key("".join(group)))
        consumed = 2
        if char_count < min_chars and index + 2 < len(values):
            group.append(values[index + 2])
            consumed = 3
            char_count = len(content_key("".join(group)))
        section = "\n".join(group)
        key = content_key(section)
        if min_chars <= char_count <= max_chars and key not in seen:
            sections.append(section)
            seen.add(key)
        index += consumed
    return sections


def _decode_bson(path: Path) -> Iterator[dict]:
    try:
        from bson import decode_file_iter
    except ImportError as exc:  # pragma: no cover - environment-specific
        raise RuntimeError(
            "Reading the Feitsui dump requires pymongo (which provides bson)."
        ) from exc
    with path.open("rb") as handle:
        yield from decode_file_iter(handle)


def build_artist_lookup(singer_documents: Iterable[dict]) -> dict[str, list[str]]:
    """Map song URLs to artists in the source's Cantonese catalogue.

    ``mandarin`` is retained by the source as auxiliary counterpart metadata;
    it is not a reliable language flag for the current lyric and is therefore
    deliberately not used as a filter.
    """
    mapping: dict[str, set[str]] = defaultdict(set)
    for singer in singer_documents:
        artist = normalise_line(singer.get("name") or singer.get("english_name"))
        if not artist:
            continue
        for song in singer.get("songs") or []:
            url = str(song.get("url") or "").strip()
            if url:
                mapping[url].add(artist)
    return {url: sorted(artists) for url, artists in mapping.items()}


def build_candidate_frame(
    lyric_documents: Iterable[dict],
    artist_lookup: dict[str, list[str]],
) -> tuple[pd.DataFrame, dict[str, int]]:
    rows: list[dict[str, object]] = []
    audit = defaultdict(int)
    global_hashes: set[str] = set()
    for document in lyric_documents:
        audit["source_songs"] += 1
        url = str(document.get("url") or "").strip()
        artists = artist_lookup.get(url, [])
        if len(artists) != 1:
            audit["excluded_missing_or_ambiguous_artist"] += 1
            continue
        title = normalise_line(document.get("title"))
        if not title:
            audit["excluded_missing_title"] += 1
            continue
        sections = segment_lines(chinese_lyric_lines(document.get("lyric")))
        if not sections:
            audit["excluded_no_usable_sections"] += 1
            continue
        source_song_key = url.rstrip("/").rsplit("/", 1)[-1]
        song_id = f"FEITSUI-{source_song_key}"
        for section_index, lyrics in enumerate(sections, start=1):
            key = content_key(lyrics)
            lyric_hash = sha256_text(key)
            if lyric_hash in global_hashes:
                audit["excluded_global_duplicate_sections"] += 1
                continue
            global_hashes.add(lyric_hash)
            rows.append(
                {
                    "case_id": f"{song_id}-SEC{section_index:02d}",
                    "corpus_song_id": song_id,
                    "section_index": section_index,
                    "section_type": "two_or_three_line_excerpt",
                    "lyrics": lyrics,
                    "character_count": len(key),
                    "title": title,
                    "artist": artists[0],
                    "source_url": url,
                    "source_dataset": "Feitsui GitHub dump",
                    "source_repository": SOURCE_REPOSITORY,
                    "source_revision": SOURCE_REVISION,
                    "source_software_license": "MIT",
                    "underlying_lyrics_licence": "not_established",
                    "research_only": True,
                    "redistribution_permitted": False,
                    "source_notice": SOURCE_NOTICE,
                    "lyric_content_sha256": lyric_hash,
                    "label_status": "unlabelled",
                    "formal_evaluation_eligible": False,
                }
            )
    audit["candidate_sections"] = len(rows)
    frame = pd.DataFrame(rows)
    if not frame.empty:
        frame = frame.sort_values(
            ["artist", "corpus_song_id", "section_index"], kind="stable"
        ).reset_index(drop=True)
    return frame, dict(audit)


def balanced_select(
    candidates: pd.DataFrame,
    n_rows: int,
    *,
    random_seed: int = 42,
    max_sections_per_artist: int = 40,
    max_sections_per_song: int = 3,
) -> pd.DataFrame:
    """Round-robin sample across artists after deterministic within-artist shuffle."""
    if n_rows <= 0:
        return candidates.iloc[0:0].copy()
    pool = candidates.groupby("corpus_song_id", group_keys=False).head(
        max_sections_per_song
    )
    artist_groups: dict[str, list[int]] = {}
    for artist, group in pool.groupby("artist", sort=True):
        shuffled = group.sample(frac=1.0, random_state=random_seed)
        artist_groups[str(artist)] = shuffled.index.tolist()[:max_sections_per_artist]
    selected: list[int] = []
    cursor = 0
    artists = sorted(artist_groups)
    while len(selected) < n_rows:
        added = False
        for artist in artists:
            values = artist_groups[artist]
            if cursor < len(values):
                selected.append(values[cursor])
                added = True
                if len(selected) == n_rows:
                    break
        if not added:
            break
        cursor += 1
    if len(selected) != n_rows:
        raise ValueError(
            f"Only {len(selected)} balanced rows available; requested {n_rows}. "
            "Increase the artist or song cap only after auditing concentration."
        )
    result = pool.loc[selected].copy().reset_index(drop=True)
    result["selection_seed"] = random_seed
    result["selection_rank"] = range(1, len(result) + 1)
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("lyric_bson", type=Path)
    parser.add_argument("singers_bson", type=Path)
    parser.add_argument("output_csv", type=Path)
    parser.add_argument("--select", type=int, default=5320)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--max-sections-per-artist", type=int, default=40)
    parser.add_argument("--max-sections-per-song", type=int, default=3)
    parser.add_argument(
        "--exclude-csv",
        type=Path,
        help="CSV whose lyric text must not be duplicated after script conversion.",
    )
    args = parser.parse_args()

    lookup = build_artist_lookup(_decode_bson(args.singers_bson))
    candidates, audit = build_candidate_frame(_decode_bson(args.lyric_bson), lookup)
    if args.exclude_csv:
        exclusion_frame = pd.read_csv(args.exclude_csv)
        if "lyrics" not in exclusion_frame:
            raise ValueError("--exclude-csv must contain a lyrics column")
        excluded_keys = set(exclusion_frame["lyrics"].map(cross_source_content_key))
        candidate_keys = candidates["lyrics"].map(cross_source_content_key)
        cross_source_matches = int(candidate_keys.isin(excluded_keys).sum())
        candidates = candidates.loc[~candidate_keys.isin(excluded_keys)].copy()
        audit["excluded_cross_source_duplicate_sections"] = cross_source_matches
    selected = balanced_select(
        candidates,
        args.select,
        random_seed=args.seed,
        max_sections_per_artist=args.max_sections_per_artist,
        max_sections_per_song=args.max_sections_per_song,
    )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    selected.to_csv(args.output_csv, index=False, encoding="utf-8-sig")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_repository": SOURCE_REPOSITORY,
        "source_revision": SOURCE_REVISION,
        "source_notice": SOURCE_NOTICE,
        "audit": audit,
        "selected_rows": len(selected),
        "selected_songs": int(selected["corpus_song_id"].nunique()),
        "selected_artists": int(selected["artist"].nunique()),
        "maximum_rows_for_one_artist": int(selected["artist"].value_counts().max()),
        "maximum_rows_for_one_song": int(
            selected["corpus_song_id"].value_counts().max()
        ),
        "character_count_summary": selected["character_count"].describe().to_dict(),
        "output_sha256": hashlib.sha256(args.output_csv.read_bytes()).hexdigest(),
    }
    args.output_csv.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
