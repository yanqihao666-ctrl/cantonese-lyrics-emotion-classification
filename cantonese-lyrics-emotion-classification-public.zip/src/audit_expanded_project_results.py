"""Final completeness audit for the expanded-corpus project artifacts."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from src.error_analysis import is_sensitive_text_column


def audit(root: Path) -> dict[str, object]:
    dataset = pd.read_csv(
        root / "data/research_only/expanded_6000_consensus_final.csv",
        low_memory=False,
    )
    diagnostics = json.loads(
        (root / "data/research_only/consensus_final_6000_cv_manifest.diagnostics.json")
        .read_text(encoding="utf-8")
    )
    transformer_root = root / "results/consensus_final_6000/transformer_matrix"
    transformer_jobs = json.loads(
        (transformer_root / "matrix.json").read_text(encoding="utf-8")
    )["jobs"]
    transformer_metrics = pd.read_csv(transformer_root / "all_metrics.csv")
    fixed_root = root / "results/consensus_final_fixed_size"
    fixed_jobs = json.loads(
        (fixed_root / "transformer_matrix.json").read_text(encoding="utf-8")
    )
    fixed_metrics = pd.read_csv(fixed_root / "transformer_all_metrics.csv")
    primary = pd.read_csv(
        root / "results/consensus_final_6000/analysis/primary_test_predictions.csv",
        low_memory=False,
    )
    robustness = json.loads(
        (root / "results/consensus_final_6000/silver_label_robustness/robustness_audit.json")
        .read_text(encoding="utf-8")
    )
    error_queue_columns = pd.read_csv(
        root / "results/consensus_final_6000/error_analysis/qualitative_review_queue.csv",
        nrows=0,
    ).columns
    coverage = primary.groupby("model_key").size().to_dict()
    partition_coverage = primary.groupby("model_key")[["partition_seed", "outer_fold"]].apply(
        lambda values: len(set(values.itertuples(index=False, name=None)))
    ).to_dict()
    checks = {
        "dataset_has_6000_rows": len(dataset) == 6000,
        "dataset_case_ids_unique": not dataset["case_id"].duplicated().any(),
        "dataset_lyrics_hashes_unique": not dataset["normalized_lyric_sha256"].duplicated().any(),
        "dataset_has_four_labels": set(dataset["emotion"])
        == {"joy", "sadness", "anger", "calmness"},
        "dataset_not_marked_human_gold": not bool(dataset["formal_evaluation_eligible"].any()),
        "main_cv_has_15_partitions": len(diagnostics["partitions"]) == 15,
        "main_cv_has_no_artist_leakage": all(
            not part["group_overlap"] for part in diagnostics["partitions"]
        ),
        "main_cv_has_no_song_leakage": all(
            not part["parent_song_overlap"] for part in diagnostics["partitions"]
        ),
        "transformer_60_jobs_completed": len(transformer_jobs) == 60
        and all(job["status"] == "completed" for job in transformer_jobs),
        "transformer_60_metric_artifacts": len(list((transformer_root / "runs").rglob("metrics.json")))
        == 60,
        "transformer_120_split_metric_rows": len(transformer_metrics) == 120,
        "fixed_transformer_30_jobs_completed": len(fixed_jobs) == 30
        and all(job["status"] == "completed" for job in fixed_jobs),
        "fixed_transformer_60_split_metric_rows": len(fixed_metrics) == 60,
        "primary_has_three_models": len(coverage) == 3,
        "primary_models_have_equal_coverage": len(set(coverage.values())) == 1,
        "primary_models_have_15_partitions": set(partition_coverage.values()) == {15},
        "primary_predictions_exclude_lyrics": not any(
            is_sensitive_text_column(column) for column in primary.columns
        ),
        "error_queue_excludes_lyric_text": not any(
            is_sensitive_text_column(column) for column in error_queue_columns
        ),
        "robustness_has_all_models_and_partitions": bool(
            robustness["all_models_all_partitions"]
        ),
        "robustness_does_not_claim_human_gold": not bool(
            robustness["human_gold_claimed"]
        ),
    }
    return {
        "passed": all(checks.values()),
        "checks": checks,
        "dataset": {
            "rows": len(dataset),
            "songs": int(dataset["corpus_song_id"].nunique()),
            "artists": int(dataset["artist"].nunique()),
            "labels": dataset["emotion"].value_counts().to_dict(),
        },
        "primary_prediction_rows_by_model": {
            str(key): int(value) for key, value in coverage.items()
        },
        "primary_partition_coverage": {
            str(key): int(value) for key, value in partition_coverage.items()
        },
        "evaluation_warning": "AI-assisted development labels; not independent human gold.",
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()
    payload = audit(args.project_root.resolve())
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    if not payload["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
