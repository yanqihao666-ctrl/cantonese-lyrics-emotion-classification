"""Create auditable zero-shot candidate labels for annotation sampling.

The output is candidate metadata only. It must never be treated as human gold.
"""

from __future__ import annotations

import argparse
import json
from collections import Counter
from pathlib import Path

import pandas as pd
import torch
from transformers import pipeline


MODEL_DEFAULT = "MoritzLaurer/mDeBERTa-v3-base-mnli-xnli"
MODEL_REVISION_DEFAULT = "8adb042d524ecd5c26d3e3ba0e3fbcf7e2d0864c"
LABEL_TEXT = {
    "joy": "喜悅、興奮、希望或慶祝",
    "sadness": "悲傷、孤獨、失落、後悔或痛苦",
    "anger": "憤怒、怨恨、指責、反抗或敵意",
    "calmness": "平靜、安慰、接受、溫柔或滿足",
}
TEXT_TO_LABEL = {value: key for key, value in LABEL_TEXT.items()}
HYPOTHESIS_TEMPLATES = [
    "這段歌詞主要表達{}。",
    "這段歌詞中敘事聲音的主導情緒是{}。",
    "只根據所提供的歌詞段落判斷，最強的情緒是{}。",
]


def consensus_from_rankings(rankings: list[dict[str, float]]) -> tuple[str | None, float, bool]:
    winners = [max(scores, key=scores.get) for scores in rankings if scores]
    if not winners:
        return None, 0.0, False
    counts = Counter(winners)
    label, votes = counts.most_common(1)[0]
    tied = list(counts.values()).count(votes) > 1
    return (None if tied else label), votes / len(HYPOTHESIS_TEMPLATES), tied


def label_zero_shot(
    frame: pd.DataFrame,
    model_name: str = MODEL_DEFAULT,
    model_revision: str | None = MODEL_REVISION_DEFAULT,
    text_column: str = "lyrics",
    batch_size: int = 8,
    checkpoint_dir: Path | None = None,
) -> pd.DataFrame:
    if text_column not in frame.columns:
        raise ValueError(f"Missing text column: {text_column}")
    device = 0 if torch.cuda.is_available() else -1
    classifier = pipeline(
        "zero-shot-classification",
        model=model_name,
        revision=model_revision,
        device=device,
        local_files_only=True,
    )
    texts = frame[text_column].astype(str).tolist()
    checkpoint_dir = checkpoint_dir or Path(".zero_shot_checkpoints")
    checkpoint_dir.mkdir(parents=True, exist_ok=True)
    per_template: list[list[dict[str, float]]] = []
    candidate_texts = list(LABEL_TEXT.values())

    for template_index, template in enumerate(HYPOTHESIS_TEMPLATES):
        checkpoint_path = checkpoint_dir / f"template_{template_index}.jsonl"
        rankings: list[dict[str, float]] = []
        if checkpoint_path.exists():
            for line in checkpoint_path.read_text(encoding="utf-8").splitlines():
                if line.strip():
                    rankings.append(json.loads(line)["scores"])
        if len(rankings) > len(texts):
            raise ValueError(f"Checkpoint has more rows than input: {checkpoint_path}")
        for start in range(len(rankings), len(texts), batch_size):
            batch_texts = texts[start : start + batch_size]
            outputs = classifier(
                batch_texts,
                candidate_labels=candidate_texts,
                hypothesis_template=template,
                multi_label=False,
                batch_size=batch_size,
                truncation=True,
            )
            if isinstance(outputs, dict):
                outputs = [outputs]
            with checkpoint_path.open("a", encoding="utf-8") as checkpoint:
                for offset, output in enumerate(outputs):
                    scores = {
                        TEXT_TO_LABEL[label]: float(score)
                        for label, score in zip(output["labels"], output["scores"])
                    }
                    rankings.append(scores)
                    checkpoint.write(
                        json.dumps({"row_index": start + offset, "scores": scores}, ensure_ascii=False) + "\n"
                    )
                    checkpoint.flush()
            print(
                f"template {template_index + 1}/{len(HYPOTHESIS_TEMPLATES)}: "
                f"{len(rankings)}/{len(texts)} rows checkpointed",
                flush=True,
            )
        per_template.append(rankings)

    safe_columns = [
        column
        for column in [
            "case_id",
            "corpus_song_id",
            "section_type",
            "section_index",
            "title",
            "artist",
            "release_year",
            "source_sha256",
        ]
        if column in frame.columns
    ]
    result = frame[safe_columns].copy()
    labels, agreements, ties, margins, evidence = [], [], [], [], []
    for row_index in range(len(frame)):
        rankings = [template_results[row_index] for template_results in per_template]
        label, agreement, tied = consensus_from_rankings(rankings)
        winner_margins = []
        for scores in rankings:
            ordered = sorted(scores.values(), reverse=True)
            winner_margins.append(ordered[0] - ordered[1])
        labels.append(label)
        agreements.append(agreement)
        ties.append(tied)
        margins.append(sum(winner_margins) / len(winner_margins))
        evidence.append(json.dumps(rankings, ensure_ascii=False, sort_keys=True))
    result["candidate_label"] = labels
    result["prompt_agreement"] = agreements
    result["candidate_tied"] = ties
    result["mean_top_two_margin"] = margins
    result["candidate_scores_json"] = evidence
    result["candidate_method"] = (
        f"zero-shot NLI; three Chinese hypothesis templates; "
        f"{model_name}@{model_revision or 'default'}"
    )
    result["candidate_model_revision"] = model_revision
    result["label_quality"] = "candidate"
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default=MODEL_DEFAULT)
    parser.add_argument("--model-revision", default=MODEL_REVISION_DEFAULT)
    parser.add_argument("--text-column", default="lyrics")
    parser.add_argument("--batch-size", type=int, default=8)
    args = parser.parse_args()
    frame = pd.read_csv(args.input, low_memory=False)
    checkpoint_dir = args.output.parent / f"{args.output.stem}_checkpoints"
    result = label_zero_shot(
        frame,
        args.model,
        args.model_revision,
        args.text_column,
        args.batch_size,
        checkpoint_dir=checkpoint_dir,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(result["candidate_label"].value_counts(dropna=False).to_string())
    print(f"Saved {len(result)} candidate labels to {args.output}")


if __name__ == "__main__":
    main()
