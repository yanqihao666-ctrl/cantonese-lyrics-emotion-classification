"""Apply auditable, evidence-based taxonomy-v2 corrections to the frozen V1 data."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


VALID_LABELS = {"joy", "sadness", "anger", "calmness"}
REQUIRED_OVERRIDE_COLUMNS = {
    "case_id",
    "expected_v1_label",
    "v2_label",
    "confidence",
    "evidence",
    "rationale",
    "reviewer",
    "review_stage",
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_v2(source: pd.DataFrame, overrides: pd.DataFrame) -> pd.DataFrame:
    if "case_id" not in source or "emotion" not in source:
        raise ValueError("Source must contain case_id and emotion columns")
    if source["case_id"].duplicated().any():
        raise ValueError("Source case_id values must be unique")
    missing = REQUIRED_OVERRIDE_COLUMNS.difference(overrides.columns)
    if missing:
        raise ValueError(f"Override table is missing columns: {sorted(missing)}")
    if overrides["case_id"].duplicated().any():
        raise ValueError("Override case_id values must be unique")
    if not set(overrides["v2_label"]).issubset(VALID_LABELS):
        raise ValueError("Override table contains an invalid v2_label")
    if not overrides["confidence"].between(1, 5).all():
        raise ValueError("Override confidence must be between 1 and 5")

    missing_ids = sorted(set(overrides["case_id"]) - set(source["case_id"]))
    if missing_ids:
        raise ValueError(f"Override IDs absent from source: {missing_ids}")
    current = source.set_index("case_id")["emotion"]
    expected = overrides.set_index("case_id")["expected_v1_label"]
    mismatched = current.reindex(expected.index).ne(expected)
    if mismatched.any():
        ids = mismatched[mismatched].index.tolist()
        raise ValueError(f"V1 labels differ from audited expectations: {ids}")
    if overrides["expected_v1_label"].eq(overrides["v2_label"]).any():
        raise ValueError("Every override must actually change the V1 label")

    clean = source.copy()
    clean["taxonomy_version"] = "v2-four-quadrant-working"
    clean["v2_previous_emotion"] = clean["emotion"]
    clean["v2_label_changed"] = False
    clean["v2_review_confidence"] = pd.NA
    clean["v2_review_evidence"] = ""
    clean["v2_review_rationale"] = ""
    clean["v2_reviewer"] = ""
    clean["v2_review_stage"] = ""

    indexed = clean.set_index("case_id")
    audited = overrides.set_index("case_id")
    for case_id, row in audited.iterrows():
        indexed.at[case_id, "emotion"] = row["v2_label"]
        indexed.at[case_id, "v2_label_changed"] = True
        indexed.at[case_id, "v2_review_confidence"] = int(row["confidence"])
        indexed.at[case_id, "v2_review_evidence"] = row["evidence"]
        indexed.at[case_id, "v2_review_rationale"] = row["rationale"]
        indexed.at[case_id, "v2_reviewer"] = row["reviewer"]
        indexed.at[case_id, "v2_review_stage"] = row["review_stage"]
    return indexed.reset_index()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("overrides", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    source = pd.read_csv(args.source)
    overrides = pd.read_csv(args.overrides)
    output = build_v2(source, overrides)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    output.to_csv(args.output, index=False, encoding="utf-8-sig")

    before = source["emotion"].value_counts().sort_index().to_dict()
    after = output["emotion"].value_counts().sort_index().to_dict()
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "taxonomy": "docs/emotion_taxonomy_v2.md",
        "status": "AI-assisted development labels; not human gold",
        "source_path": str(args.source),
        "source_sha256": sha256(args.source),
        "override_path": str(args.overrides),
        "override_sha256": sha256(args.overrides),
        "rows": len(output),
        "changed_rows": int(output["v2_label_changed"].sum()),
        "class_counts_before": before,
        "class_counts_after": after,
        "unique_songs": int(output["corpus_song_id"].nunique()),
        "unique_artists": int(output["artist"].nunique()),
        "all_sources_cc_by_4": bool(output["source_license"].eq("CC BY 4.0").all()),
        "synthetic_lyrics_added": 0,
        "new_unlicensed_sources_added": 0,
    }
    args.output.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
