"""Create paired 680-vs-6,000 partitions with identical validation/test rows."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd

from src.make_cv_manifest import create_repeated_group_manifest


def build_paired_partitions(
    frame: pd.DataFrame,
    output_dir: Path,
    seeds: list[int] | None = None,
    folds: int = 5,
) -> dict:
    seeds = seeds or [13, 42, 97]
    original = frame.loc[frame["source_cohort"].eq("original_680")].copy()
    expansion = frame.loc[frame["source_cohort"].eq("github_expansion_5320")].copy()
    if len(original) != 680 or len(expansion) != 5320:
        raise ValueError("Expected original_680=680 and github_expansion_5320=5,320")
    manifest, diagnostics = create_repeated_group_manifest(
        original,
        id_column="case_id",
        label_column="emotion",
        group_column="artist",
        seeds=seeds,
        outer_folds=folds,
        inner_folds=5,
    )
    output_dir.mkdir(parents=True, exist_ok=True)
    records = []
    for seed in seeds:
        for fold in range(1, folds + 1):
            roles = manifest.loc[
                manifest["seed"].eq(seed) & manifest["outer_fold"].eq(fold),
                ["case_id", "split"],
            ]
            small = original.merge(roles, on="case_id", validate="one_to_one")
            held_out_artists = set(
                small.loc[small["split"].isin(["validation", "test"]), "artist"]
            )
            eligible_expansion = expansion.loc[
                ~expansion["artist"].isin(held_out_artists)
            ].copy()
            eligible_expansion["split"] = "train"
            large = pd.concat([small, eligible_expansion], ignore_index=True)
            for part in [small, large]:
                part["partition_seed"] = seed
                part["outer_fold"] = fold
            small_path = output_dir / f"seed_{seed}_fold_{fold}__small_680.csv"
            large_path = output_dir / f"seed_{seed}_fold_{fold}__expanded_train.csv"
            small.to_csv(small_path, index=False, encoding="utf-8-sig")
            large.to_csv(large_path, index=False, encoding="utf-8-sig")

            small_test = set(small.loc[small["split"].eq("test"), "case_id"])
            large_test = set(large.loc[large["split"].eq("test"), "case_id"])
            small_val = set(small.loc[small["split"].eq("validation"), "case_id"])
            large_val = set(large.loc[large["split"].eq("validation"), "case_id"])
            train_artists = set(large.loc[large["split"].eq("train"), "artist"])
            held_artists = set(large.loc[~large["split"].eq("train"), "artist"])
            if small_test != large_test or small_val != large_val:
                raise AssertionError("Paired validation/test cases differ")
            if train_artists & held_artists:
                raise AssertionError("Artist leakage in expanded training partition")
            records.append(
                {
                    "seed": seed,
                    "outer_fold": fold,
                    "small_train_rows": int(small["split"].eq("train").sum()),
                    "expanded_train_rows": int(large["split"].eq("train").sum()),
                    "validation_rows": len(small_val),
                    "test_rows": len(small_test),
                    "excluded_expansion_rows_due_to_artist_overlap": int(
                        len(expansion) - len(eligible_expansion)
                    ),
                    "small_path": str(small_path.resolve()),
                    "large_path": str(large_path.resolve()),
                    "small_sha256": hashlib.sha256(small_path.read_bytes()).hexdigest(),
                    "large_sha256": hashlib.sha256(large_path.read_bytes()).hexdigest(),
                }
            )
    report = {
        "comparison": "paired fixed validation/test; only training data size changes",
        "partitions": records,
        "manifest_diagnostics": {
            key: value for key, value in diagnostics.items() if key != "partitions"
        },
    }
    (output_dir / "paired_partition_audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    return report


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.input_csv, low_memory=False)
    report = build_paired_partitions(frame, args.output_dir)
    print(
        json.dumps(
            {
                "partitions": len(report["partitions"]),
                "small_train_mean": sum(x["small_train_rows"] for x in report["partitions"])
                / len(report["partitions"]),
                "expanded_train_mean": sum(
                    x["expanded_train_rows"] for x in report["partitions"]
                )
                / len(report["partitions"]),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
