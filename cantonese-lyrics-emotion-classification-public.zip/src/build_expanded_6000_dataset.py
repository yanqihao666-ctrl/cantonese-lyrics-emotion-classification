"""Combine the original 680 sections with 5,320 research-only sections."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
from opencc import OpenCC


_KEY_FILTER = re.compile(r"[^\u3400-\u9fffA-Za-z0-9]+")


def _sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _key(value: str) -> str:
    return _KEY_FILTER.sub("", unicodedata.normalize("NFKC", value)).casefold()


def build_expanded_frame(original: pd.DataFrame, expansion: pd.DataFrame) -> pd.DataFrame:
    if len(original) != 680:
        raise ValueError(f"Expected 680 original rows, found {len(original)}")
    if len(expansion) != 5320:
        raise ValueError(f"Expected 5,320 expansion rows, found {len(expansion)}")
    required_original = {"case_id", "corpus_song_id", "lyrics", "title", "artist", "emotion"}
    required_expansion = {"case_id", "corpus_song_id", "lyrics", "title", "artist"}
    if missing := required_original - set(original):
        raise ValueError(f"Original data missing columns: {sorted(missing)}")
    if missing := required_expansion - set(expansion):
        raise ValueError(f"Expansion data missing columns: {sorted(missing)}")

    converter = OpenCC("t2s")
    old = original.copy()
    old["source_cohort"] = "original_680"
    old["historical_emotion"] = old["emotion"]
    old["historical_label_available"] = True
    old["research_only"] = False
    old["redistribution_permitted"] = True

    new = expansion.copy()
    new["source_cohort"] = "github_expansion_5320"
    new["historical_emotion"] = pd.NA
    new["historical_label_available"] = False
    new["emotion"] = pd.NA

    common = sorted(set(old.columns) | set(new.columns))
    old = old.reindex(columns=common)
    new = new.reindex(columns=common)
    combined = pd.concat([old, new], ignore_index=True)

    combined["lyrics_original"] = combined["lyrics"].astype(str)
    combined["title_original"] = combined["title"].astype(str)
    combined["artist_original"] = combined["artist"].astype(str)
    combined["lyrics"] = combined["lyrics_original"].map(converter.convert)
    combined["title"] = combined["title_original"].map(converter.convert)
    combined["artist"] = combined["artist_original"].map(converter.convert)
    combined["orthography_for_modelling"] = "OpenCC t2s"
    combined["normalized_lyric_sha256"] = combined["lyrics"].map(
        lambda value: hashlib.sha256(_key(value).encode("utf-8")).hexdigest()
    )
    combined["character_count"] = combined["lyrics"].map(
        lambda value: len(_key(value))
    )
    combined["expanded_ai_label"] = pd.NA
    combined["emotion"] = pd.NA
    combined["label_status"] = "awaiting_uniform_expanded_ai_annotation"
    combined["development_only"] = True
    combined["formal_evaluation_eligible"] = False

    if combined["case_id"].duplicated().any():
        raise ValueError("case_id values are not unique")
    if combined["normalized_lyric_sha256"].duplicated().any():
        duplicates = int(combined["normalized_lyric_sha256"].duplicated().sum())
        raise ValueError(f"Found {duplicates} normalized duplicate lyric sections")
    if len(combined) != 6000:
        raise AssertionError("Combined dataset does not contain exactly 6,000 rows")
    return combined.sort_values(["source_cohort", "case_id"], kind="stable").reset_index(drop=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_csv", type=Path)
    parser.add_argument("expansion_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    args = parser.parse_args()

    frame = build_expanded_frame(
        pd.read_csv(args.original_csv), pd.read_csv(args.expansion_csv)
    )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output_csv, index=False, encoding="utf-8-sig")
    cohort = frame.groupby("source_cohort").agg(
        rows=("case_id", "size"),
        songs=("corpus_song_id", "nunique"),
        artists=("artist", "nunique"),
        mean_characters=("character_count", "mean"),
    )
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(frame),
        "songs": int(frame["corpus_song_id"].nunique()),
        "artists_after_t2s_normalization": int(frame["artist"].nunique()),
        "duplicate_case_ids": int(frame["case_id"].duplicated().sum()),
        "duplicate_normalized_lyrics": int(
            frame["normalized_lyric_sha256"].duplicated().sum()
        ),
        "cohort_summary": cohort.to_dict(orient="index"),
        "uniform_label_status": "pending",
        "original_sha256": _sha256(args.original_csv),
        "expansion_sha256": _sha256(args.expansion_csv),
        "output_sha256": _sha256(args.output_csv),
    }
    args.output_csv.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
