"""Import MIR-MLPop Cantonese annotations for pipeline validation.

MIR-MLPop is not emotion-labelled and must not be used as the main supervised
dataset. The importer reconstructs lyric text from aligned character records so
that preprocessing and tokenizer coverage can be audited.
"""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def reconstruct_lyrics(aligned_lyrics: list[list[object]]) -> str:
    """Join the annotated graphemes in temporal order."""
    ordered = sorted(aligned_lyrics, key=lambda item: float(item[0]))
    return "".join(str(item[2]) for item in ordered if len(item) >= 3).strip()


def import_annotations(source: str | Path) -> pd.DataFrame:
    with Path(source).open(encoding="utf-8") as handle:
        records = json.load(handle)

    rows = []
    for record in records:
        song_id = str(record["song_id"])
        rows.append(
            {
                "external_id": f"mirmlpop-yue-{int(song_id):03d}",
                "lyrics": reconstruct_lyrics(record["aligned_lyrics"]),
                "source_url": record["youtube_link"],
                "original_split": record["data_split"],
                "source_dataset": "MIR-MLPop yue 240223",
                "label_quality": "unlabelled",
            }
        )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    frame = import_annotations(args.source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"Imported {len(frame)} unlabelled Cantonese songs to {args.output}")


if __name__ == "__main__":
    main()
