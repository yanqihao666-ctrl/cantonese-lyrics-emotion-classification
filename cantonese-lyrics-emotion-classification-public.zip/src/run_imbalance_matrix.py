"""Run the predeclared V2 imbalance-treatment matrix with resumable evidence."""

from __future__ import annotations

import argparse
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from src.run_experiment_matrix import discover_partitions, validate_partition_grid


MACBERT = (
    "hfl/chinese-macbert-base",
    "a986e004d2a7f2a1c2f5a3edef4e20604a974ed1",
)
CLASSICAL_STRATEGIES = [
    "baseline",
    "class_weight",
    "random_oversampling",
    "smote",
    "moderate_undersampling",
]
TRANSFORMER_STRATEGIES = ["baseline", "balanced_loss", "balanced_sampler"]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def transformer_run_name(model: str, seed: int, fold: int, strategy: str) -> str:
    name = (
        f"{model.replace('/', '__')}__trainseed_{seed}"
        f"__partitionseed_{seed}__fold_{fold}"
    )
    if strategy == "balanced_loss":
        name += "__classweight_balanced"
    elif strategy == "balanced_sampler":
        name += "__sampler_balanced"
    return name


def build_jobs(partitions, output_root: Path, families: list[str]) -> list[dict]:
    jobs: list[dict] = []
    python = str(Path(sys.executable).resolve())
    for partition in partitions:
        seed, fold = partition.partition_seed, partition.outer_fold
        if "classical" in families:
            output = output_root / "classical" / f"seed_{seed}_fold_{fold}"
            jobs.append(
                {
                    "job_id": f"classical__seed_{seed}__fold_{fold}",
                    "family": "classical",
                    "strategy": "five_strategy_matrix",
                    "seed": seed,
                    "fold": fold,
                    "input": partition.path,
                    "input_sha256": partition.input_sha256,
                    "command": [
                        python,
                        "-m",
                        "src.classical_experiment",
                        partition.path,
                        "--fixed-split",
                        "--seeds",
                        str(seed),
                        "--feature-sets",
                        "character_tfidf",
                        "--models",
                        "linear_svm",
                        "--imbalance-strategies",
                        *CLASSICAL_STRATEGIES,
                        "--output-dir",
                        str(output.resolve()),
                    ],
                    "expected": str((output / "run_metadata.json").resolve()),
                    "status": "pending",
                }
            )
        if "transformer" in families:
            model, revision = MACBERT
            transformer_root = output_root / "transformer"
            for strategy in TRANSFORMER_STRATEGIES:
                run_name = transformer_run_name(model, seed, fold, strategy)
                command = [
                    python,
                    "-m",
                    "src.transformer_experiment",
                    partition.path,
                    "--model",
                    model,
                    "--model-revision",
                    revision,
                    "--seed",
                    str(seed),
                    "--output-dir",
                    str(transformer_root.resolve()),
                    "--discard-model-artifacts",
                ]
                if strategy == "balanced_loss":
                    command.extend(["--class-weighting", "balanced"])
                elif strategy == "balanced_sampler":
                    command.extend(["--sampling-strategy", "balanced"])
                jobs.append(
                    {
                        "job_id": f"macbert__{strategy}__seed_{seed}__fold_{fold}",
                        "family": "transformer",
                        "strategy": strategy,
                        "seed": seed,
                        "fold": fold,
                        "input": partition.path,
                        "input_sha256": partition.input_sha256,
                        "command": command,
                        "expected": str((transformer_root / run_name / "run_metadata.json").resolve()),
                        "status": "pending",
                    }
                )
    return jobs


def metadata_matches(job: dict) -> bool:
    path = Path(job["expected"])
    if not path.exists():
        return False
    metadata = json.loads(path.read_text(encoding="utf-8"))
    return (
        metadata.get("input_sha256") == job["input_sha256"]
        and metadata.get("partition_seed") == job["seed"]
        and metadata.get("outer_fold") == job["fold"]
    )


def write_manifest(path: Path, jobs: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(
            {"updated_at_utc": utc_now(), "job_count": len(jobs), "jobs": jobs},
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )


def execute(jobs: list[dict], manifest: Path, workdir: Path, force: bool) -> None:
    logs = manifest.parent / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    for job in jobs:
        if not force and metadata_matches(job):
            job["status"] = "skipped_existing"
            write_manifest(manifest, jobs)
            continue
        job["status"] = "running"
        job["started_at_utc"] = utc_now()
        write_manifest(manifest, jobs)
        stdout = logs / f"{job['job_id']}.stdout.log"
        stderr = logs / f"{job['job_id']}.stderr.log"
        with stdout.open("w", encoding="utf-8") as out, stderr.open(
            "w", encoding="utf-8"
        ) as err:
            completed = subprocess.run(
                job["command"], cwd=workdir, stdout=out, stderr=err, check=False
            )
        job["return_code"] = int(completed.returncode)
        job["completed_at_utc"] = utc_now()
        job["status"] = (
            "completed"
            if completed.returncode == 0 and Path(job["expected"]).exists()
            else "failed"
        )
        write_manifest(manifest, jobs)
        if job["status"] == "failed":
            raise RuntimeError(f"{job['job_id']} failed; inspect {stderr}")


def collect_classical(output_root: Path) -> pd.DataFrame:
    parts = []
    for path in sorted((output_root / "classical").glob("seed_*_fold_*/metrics.csv")):
        frame = pd.read_csv(path)
        parts.append(frame.assign(source_path=str(path)))
    if not parts:
        return pd.DataFrame()
    return pd.concat(parts, ignore_index=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("partitions_dir", type=Path)
    parser.add_argument("--output-root", type=Path, default=Path("results/imbalance_v2"))
    parser.add_argument(
        "--families",
        nargs="+",
        choices=["classical", "transformer"],
        default=["classical", "transformer"],
    )
    parser.add_argument("--allow-partial-grid", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    partitions = discover_partitions(args.partitions_dir)
    if not args.allow_partial_grid:
        validate_partition_grid(partitions)
    output_root = args.output_root.resolve()
    jobs = build_jobs(partitions, output_root, args.families)
    manifest = output_root / "imbalance_matrix.json"
    write_manifest(manifest, jobs)
    print(json.dumps({"partitions": len(partitions), "jobs": len(jobs)}, indent=2))
    if not args.dry_run:
        execute(jobs, manifest, Path.cwd(), args.force)
        classical = collect_classical(output_root)
        if not classical.empty:
            classical.to_csv(
                output_root / "classical_all_metrics.csv",
                index=False,
                encoding="utf-8-sig",
            )


if __name__ == "__main__":
    main()
