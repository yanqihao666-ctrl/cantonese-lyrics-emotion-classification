"""Uniformly label all 6,000 sections for development experiments.

This creates disclosed AI-assisted labels, never human gold labels. Two
deterministic prompts use reversed code orders; disagreements receive a third
adjudication pass. Checkpoints make the GPU job resumable.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


LABELS = ("joy", "sadness", "anger", "calmness")
MODEL_DEFAULT = "Qwen/Qwen2.5-3B-Instruct"
MODEL_REVISION_DEFAULT = "aa8e72537993ba99e69dfaafa59ed015b17504d1"
_CODE = re.compile(r"(?<!\d)([1-4])(?!\d)")
_LABEL = re.compile(r"\b(joy|sadness|anger|calmness)\b", flags=re.IGNORECASE)


def parse_code(text: object, mapping: dict[int, str]) -> str | None:
    match = _CODE.search(str(text or ""))
    return mapping.get(int(match.group(1))) if match else None


def parse_label(text: object) -> str | None:
    match = _LABEL.search(str(text or ""))
    return match.group(1).casefold() if match else None


def resolve_decisions(
    pass_a: pd.Series, pass_b: pd.Series, adjudicated: pd.Series
) -> pd.DataFrame:
    rows = []
    for a, b, final in zip(pass_a, pass_b, adjudicated):
        a = a if isinstance(a, str) and a in LABELS else None
        b = b if isinstance(b, str) and b in LABELS else None
        final = final if isinstance(final, str) and final in LABELS else None
        agreement = bool(a is not None and b is not None and a == b)
        label = a if agreement else (final or a or b)
        if label not in LABELS:
            raise ValueError("At least one item has no valid four-class decision")
        rows.append(
            {
                "expanded_ai_label": label,
                "ai_prompt_agreement": agreement,
                "ai_adjudication_used": not agreement,
                "ai_confidence_1_to_5": 4 if agreement else 3,
                "needs_human_review": not agreement,
            }
        )
    return pd.DataFrame(rows)


def _prompt(lyrics: str, pass_name: str, candidates: tuple[str, str] | None = None) -> str:
    definitions_a = (
        "joy 是积极且较活跃的喜悦、希望、庆祝或热烈爱意；"
        "sadness 是失落、孤独、遗憾、离别或痛苦思念；"
        "anger 是明确的愤怒、怨恨、指责、抗议或对抗；"
        "calmness 是平和、安慰、温柔、释然、满足或宁静反思。"
    )
    definitions_b = (
        "calmness 是平和、安慰、温柔、释然、满足或宁静反思；"
        "anger 是明确的愤怒、怨恨、指责、抗议或对抗；"
        "sadness 是失落、孤独、遗憾、离别或痛苦思念；"
        "joy 是积极且较活跃的喜悦、希望、庆祝或热烈爱意。"
    )
    rules = (
        "判断歌词片段中叙述者最强烈表达的主要情绪。只能四选一。"
        + (definitions_b if pass_name == "b" else definitions_a)
        + "出现‘爱’不自动等于 joy；痛苦思念优先 sadness；"
        "只有明确指责或对抗强于悲伤时才选 anger。"
    )
    if pass_name == "a":
        instruction = "直接输出对应的英文标签词。"
    elif pass_name == "b":
        instruction = "直接输出对应的英文标签词。"
    else:
        instruction = "最终复核，直接输出对应的英文标签词。"
        if candidates:
            instruction += f"前两次候选为 {candidates[0]} 和 {candidates[1]}，请重新依据文本决定。"
    return (
        f"{rules}\n{instruction}\n"
        "只能输出 joy、sadness、anger、calmness 之一，不要数字，不要解释。"
        f"\n歌词片段：\n{lyrics}"
    )


def _load_model(model_name: str, revision: str):
    tokenizer = AutoTokenizer.from_pretrained(
        model_name, revision=revision, local_files_only=True
    )
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        revision=revision,
        local_files_only=True,
        dtype=dtype,
        low_cpu_mem_usage=True,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()
    return tokenizer, model, device


def _generate(tokenizer, model, device, prompts: list[str]) -> list[str]:
    rendered = [
        tokenizer.apply_chat_template(
            [
                {
                    "role": "system",
                    "content": "你是严谨的粤语歌词情绪标注员，严格按标签定义判断。",
                },
                {"role": "user", "content": prompt},
            ],
            tokenize=False,
            add_generation_prompt=True,
        )
        for prompt in prompts
    ]
    inputs = tokenizer(
        rendered,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=384,
    ).to(device)
    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=8,
            do_sample=False,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    prompt_length = inputs["input_ids"].shape[1]
    return [
        tokenizer.decode(output[prompt_length:], skip_special_tokens=True).strip()
        for output in outputs
    ]


def _run_pass(
    frame: pd.DataFrame,
    pass_name: str,
    checkpoint: Path,
    tokenizer,
    model,
    device,
    batch_size: int,
    candidate_columns: tuple[str, str] | None = None,
) -> pd.DataFrame:
    existing = pd.read_csv(checkpoint) if checkpoint.exists() else pd.DataFrame()
    done = set(existing.get("case_id", pd.Series(dtype=str)).astype(str))
    rows = existing.to_dict(orient="records")
    pending = frame.loc[~frame["case_id"].astype(str).isin(done)]
    for start in range(0, len(pending), batch_size):
        batch = pending.iloc[start : start + batch_size]
        prompts = []
        for _, row in batch.iterrows():
            candidates = None
            if candidate_columns:
                candidates = (
                    str(row[candidate_columns[0]]),
                    str(row[candidate_columns[1]]),
                )
            prompts.append(_prompt(str(row["lyrics"]), pass_name, candidates))
        raw_outputs = _generate(tokenizer, model, device, prompts)
        for (_, source), raw in zip(batch.iterrows(), raw_outputs):
            parsed = parse_label(raw)
            rows.append(
                {
                    "case_id": source["case_id"],
                    f"pass_{pass_name}_label": parsed,
                    f"pass_{pass_name}_raw": raw[:80],
                    f"pass_{pass_name}_parse_ok": parsed is not None,
                }
            )
        checkpoint.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).to_csv(checkpoint, index=False, encoding="utf-8-sig")
        print(
            f"pass {pass_name}: {len(rows)}/{len(frame)}",
            flush=True,
        )
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    parser.add_argument("--checkpoint-dir", type=Path, required=True)
    parser.add_argument("--model", default=MODEL_DEFAULT)
    parser.add_argument("--revision", default=MODEL_REVISION_DEFAULT)
    parser.add_argument("--batch-size", type=int, default=16)
    args = parser.parse_args()

    frame = pd.read_csv(args.input_csv)
    if len(frame) != 6000 or frame["case_id"].duplicated().any():
        raise ValueError("Expected exactly 6,000 unique cases")
    torch.manual_seed(42)
    tokenizer, model, device = _load_model(args.model, args.revision)
    args.checkpoint_dir.mkdir(parents=True, exist_ok=True)

    pass_a = _run_pass(
        frame,
        "a",
        args.checkpoint_dir / "pass_a.csv",
        tokenizer,
        model,
        device,
        args.batch_size,
    )
    pass_b = _run_pass(
        frame,
        "b",
        args.checkpoint_dir / "pass_b.csv",
        tokenizer,
        model,
        device,
        args.batch_size,
    )
    merged = frame.merge(pass_a, on="case_id", validate="one_to_one").merge(
        pass_b, on="case_id", validate="one_to_one"
    )
    disagreement = merged.loc[
        merged["pass_a_label"].isna()
        | merged["pass_b_label"].isna()
        | merged["pass_a_label"].ne(merged["pass_b_label"])
    ].copy()
    adjudicated = _run_pass(
        disagreement,
        "adjudication",
        args.checkpoint_dir / "adjudication.csv",
        tokenizer,
        model,
        device,
        args.batch_size,
        candidate_columns=("pass_a_label", "pass_b_label"),
    )
    merged = merged.merge(adjudicated, on="case_id", how="left", validate="one_to_one")
    decisions = resolve_decisions(
        merged["pass_a_label"],
        merged["pass_b_label"],
        merged.get("pass_adjudication_label", pd.Series(index=merged.index, dtype=object)),
    )
    for column in decisions:
        merged[column] = decisions[column].values
    merged["emotion"] = merged["expanded_ai_label"]
    merged["label_status"] = "uniform_ai_assisted_development_label"
    merged["development_label_source"] = "qwen_two_prompt_plus_adjudication"
    merged["development_only"] = True
    merged["formal_evaluation_eligible"] = False
    merged["annotator_type"] = "AI research-assisted annotation"
    merged["model_name"] = args.model
    merged["model_revision"] = args.revision
    merged["annotated_at_utc"] = datetime.now(timezone.utc).isoformat()
    merged["historical_label_agreement"] = (
        merged["historical_emotion"].isna()
        | merged["historical_emotion"].eq(merged["emotion"])
    )

    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(args.output_csv, index=False, encoding="utf-8-sig")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(merged),
        "label_counts": merged["emotion"].value_counts().to_dict(),
        "prompt_agreement_rate": float(merged["ai_prompt_agreement"].mean()),
        "needs_human_review": int(merged["needs_human_review"].sum()),
        "historical_680_agreement_rate": float(
            merged.loc[merged["source_cohort"].eq("original_680"), "historical_label_agreement"].mean()
        ),
        "model_name": args.model,
        "model_revision": args.revision,
        "device": str(device),
        "formal_evaluation_eligible": False,
        "warning": "AI-assisted development labels; not human gold.",
        "input_sha256": hashlib.sha256(args.input_csv.read_bytes()).hexdigest(),
        "output_sha256": hashlib.sha256(args.output_csv.read_bytes()).hexdigest(),
    }
    args.output_csv.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
