"""Quality and provenance audit for the 6,000-row development dataset."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import pandas as pd
from sklearn.metrics import cohen_kappa_score, confusion_matrix


LABELS = ["joy", "sadness", "anger", "calmness"]


def _as_boolean(series: pd.Series) -> pd.Series:
    """Read booleans consistently after mixed-schema CSV concatenation."""
    return series.map(
        lambda value: str(value).strip().lower() in {"true", "1", "yes"}
        if pd.notna(value)
        else False
    )


def _vote_columns(frame: pd.DataFrame) -> list[str]:
    # The frozen consensus builder gives the three final evidence streams
    # unambiguous names. Earlier input files may also remain as provenance
    # columns, so prefer these final names whenever they are available.
    consensus = ["generation_label", "score_label", "nli_label"]
    research_assisted = ["qwen_direct_vote", "qwen_strict_vote", "nli_vote"]
    legacy = ["pass_a_label", "pass_b_label"]
    if set(consensus).issubset(frame.columns):
        return consensus
    if set(research_assisted).issubset(frame.columns):
        return research_assisted
    if set(legacy).issubset(frame.columns):
        return legacy
    raise ValueError(
        "Missing label-evidence columns: expected either "
        f"{consensus}, {research_assisted}, or {legacy}"
    )


def audit(
    frame: pd.DataFrame,
) -> tuple[dict, pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    required = {
        "case_id",
        "corpus_song_id",
        "artist",
        "lyrics",
        "emotion",
        "source_cohort",
        "needs_human_review",
        "normalized_lyric_sha256",
    }
    if missing := required - set(frame):
        raise ValueError(f"Missing columns: {sorted(missing)}")
    invalid = sorted(set(frame["emotion"].dropna()) - set(LABELS))
    if invalid or frame["emotion"].isna().any():
        raise ValueError(f"Invalid or missing final labels: {invalid}")

    votes = _vote_columns(frame)
    review = _as_boolean(frame["needs_human_review"])
    valid_votes = frame[votes].isin(LABELS)
    full_coverage = valid_votes.all(axis=1)
    full_agreement = frame[votes].nunique(axis=1, dropna=True).eq(1) & full_coverage
    frame = frame.assign(
        _method_vote_coverage=full_coverage,
        _method_full_agreement=full_agreement.where(full_coverage),
        _review=review,
    )

    per_class = (
        frame.groupby("emotion")
        .agg(
            rows=("case_id", "size"),
            songs=("corpus_song_id", "nunique"),
            artists=("artist", "nunique"),
            method_vote_coverage_rate=("_method_vote_coverage", "mean"),
            method_full_agreement_rate=("_method_full_agreement", "mean"),
            review_rows=("_review", "sum"),
            mean_characters=("character_count", "mean"),
        )
        .reindex(LABELS)
        .reset_index()
    )
    cohort = (
        frame.groupby(["source_cohort", "emotion"])
        .agg(rows=("case_id", "size"), songs=("corpus_song_id", "nunique"))
        .reset_index()
    )
    first_vote, second_vote = votes[:2]
    valid_pair = frame[first_vote].isin(LABELS) & frame[second_vote].isin(LABELS)
    pair = frame.loc[valid_pair]
    matrix = confusion_matrix(pair[first_vote], pair[second_vote], labels=LABELS)
    confusion = pd.DataFrame(matrix, index=LABELS, columns=LABELS)
    pairwise_kappa = {}
    for index, left in enumerate(votes):
        for right in votes[index + 1 :]:
            valid = frame[left].isin(LABELS) & frame[right].isin(LABELS)
            subset = frame.loc[valid]
            key = f"{left}__vs__{right}"
            pairwise_kappa[key] = (
                float(cohen_kappa_score(subset[left], subset[right], labels=LABELS))
                if len(subset)
                else None
            )
    report = {
        "rows": len(frame),
        "songs": int(frame["corpus_song_id"].nunique()),
        "artists": int(frame["artist"].nunique()),
        "case_id_duplicates": int(frame["case_id"].duplicated().sum()),
        "normalized_lyric_duplicates": int(
            frame["normalized_lyric_sha256"].duplicated().sum()
        ),
        "missing_final_labels": int(frame["emotion"].isna().sum()),
        "final_label_counts": {
            str(key): int(value) for key, value in frame["emotion"].value_counts().items()
        },
        "source_cohort_counts": {
            str(key): int(value)
            for key, value in frame["source_cohort"].value_counts().items()
        },
        "consensus_method_counts": (
            {
                str(key): int(value)
                for key, value in frame["consensus_method"].value_counts().items()
            }
            if "consensus_method" in frame.columns
            else None
        ),
        "vote_columns": votes,
        "invalid_or_missing_votes": {
            column: int((~frame[column].isin(LABELS)).sum()) for column in votes
        },
        "method_vote_coverage_rows": int(full_coverage.sum()),
        "method_full_agreement_rows": int(full_agreement.sum()),
        "method_full_agreement_rate_on_covered_rows": (
            float(full_agreement[full_coverage].mean()) if full_coverage.any() else None
        ),
        "pairwise_cohen_kappa": pairwise_kappa,
        "first_pair_confusion": [first_vote, second_vote],
        "review_rows": int(review.sum()),
        "minimum_class_rows": int(frame["emotion"].value_counts().min()),
        "maximum_artist_rows": int(frame["artist"].value_counts().max()),
        "maximum_song_rows": int(frame["corpus_song_id"].value_counts().max()),
        "formal_evaluation_eligible": False,
        "warning": "AI-assisted development labels; not independent human gold.",
    }
    return report, per_class, cohort, confusion


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input_csv", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    frame = pd.read_csv(args.input_csv, low_memory=False)
    report, per_class, cohort, confusion = audit(frame)
    report["input_sha256"] = hashlib.sha256(args.input_csv.read_bytes()).hexdigest()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    per_class.to_csv(args.output_dir / "per_class_quality.csv", index=False)
    cohort.to_csv(args.output_dir / "cohort_class_counts.csv", index=False)
    confusion.to_csv(args.output_dir / "first_pair_confusion_matrix.csv")
    (args.output_dir / "audit.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
