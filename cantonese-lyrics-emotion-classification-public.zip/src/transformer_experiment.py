"""Fine-tune one Transformer checkpoint on fixed, leakage-audited splits."""

from __future__ import annotations

import argparse
import hashlib
import json
import math
import platform
import shutil
import time
from pathlib import Path

import accelerate
import datasets
import numpy as np
import pandas as pd
import torch
import transformers
from datasets import Dataset
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_recall_fscore_support,
)
from torch.utils.data import WeightedRandomSampler
from transformers import (
    AutoModelForSequenceClassification,
    AutoTokenizer,
    DataCollatorWithPadding,
    EarlyStoppingCallback,
    EvalPrediction,
    Trainer,
    TrainingArguments,
    set_seed,
)


LABELS = ["joy", "sadness", "anger", "calmness"]
LABEL_TO_ID = {label: index for index, label in enumerate(LABELS)}
ID_TO_LABEL = {index: label for label, index in LABEL_TO_ID.items()}


def checkpoint_directory(output_dir: Path, run_name: str) -> Path:
    """Keep temporary Trainer checkpoints short enough for Windows paths."""
    run_token = hashlib.sha256(run_name.encode("utf-8")).hexdigest()[:16]
    return output_dir / "_trainer_checkpoints" / run_token


def compute_balanced_class_weights(labels: pd.Series) -> list[float]:
    """Return inverse-frequency weights in the fixed model label order."""
    counts = labels.value_counts().reindex(LABELS, fill_value=0)
    if (counts <= 0).any():
        missing = counts.index[counts <= 0].tolist()
        raise ValueError(f"Cannot compute balanced weights with missing classes: {missing}")
    total = float(counts.sum())
    return [total / (len(LABELS) * float(counts[label])) for label in LABELS]


def compute_balanced_sample_weights(labels: pd.Series) -> list[float]:
    """Return inverse-frequency sample weights without changing epoch length."""

    class_weights = dict(zip(LABELS, compute_balanced_class_weights(labels)))
    return [float(class_weights[str(label)]) for label in labels]


class ClassWeightedTrainer(Trainer):
    """Trainer with an optional auditable weighted cross-entropy objective."""

    def __init__(
        self,
        *args,
        class_weights: list[float] | None = None,
        sample_weights: list[float] | None = None,
        sampler_seed: int = 42,
        **kwargs,
    ):
        super().__init__(*args, **kwargs)
        self.class_weights = (
            torch.tensor(class_weights, dtype=torch.float32)
            if class_weights is not None
            else None
        )
        self.sample_weights = sample_weights
        self.sampler_seed = sampler_seed

    def _get_train_sampler(self, train_dataset=None):
        if self.sample_weights is None:
            return super()._get_train_sampler(train_dataset)
        generator = torch.Generator()
        generator.manual_seed(self.sampler_seed)
        return WeightedRandomSampler(
            weights=torch.tensor(self.sample_weights, dtype=torch.double),
            num_samples=len(self.sample_weights),
            replacement=True,
            generator=generator,
        )

    def compute_loss(
        self,
        model,
        inputs,
        return_outputs: bool = False,
        num_items_in_batch=None,
    ):
        if self.class_weights is None:
            return super().compute_loss(
                model,
                inputs,
                return_outputs=return_outputs,
                num_items_in_batch=num_items_in_batch,
            )
        labels = inputs["labels"]
        model_inputs = {key: value for key, value in inputs.items() if key != "labels"}
        outputs = model(**model_inputs)
        weights = self.class_weights.to(outputs.logits.device)
        loss = torch.nn.functional.cross_entropy(outputs.logits, labels, weight=weights)
        return (loss, outputs) if return_outputs else loss


def compute_metrics(prediction: EvalPrediction) -> dict[str, float]:
    predicted = np.argmax(prediction.predictions, axis=-1)
    truth = prediction.label_ids
    precision, recall, class_f1, _ = precision_recall_fscore_support(
        truth, predicted, labels=list(range(len(LABELS))), zero_division=0
    )
    metrics: dict[str, float] = {
        "accuracy": float(accuracy_score(truth, predicted)),
        "macro_f1": float(f1_score(truth, predicted, labels=list(range(len(LABELS))), average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(truth, predicted, labels=list(range(len(LABELS))), average="weighted", zero_division=0)),
        "balanced_accuracy": float(balanced_accuracy_score(truth, predicted)),
    }
    for index, label in enumerate(LABELS):
        metrics[f"{label}_precision"] = float(precision[index])
        metrics[f"{label}_recall"] = float(recall[index])
        metrics[f"{label}_f1"] = float(class_f1[index])
    return metrics


def validate_fixed_splits(
    frame: pd.DataFrame,
    text_column: str = "lyrics",
    label_column: str = "emotion",
    group_column: str = "artist",
) -> pd.DataFrame:
    required = {text_column, label_column, "split"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    clean = frame.dropna(subset=list(required)).copy()
    clean[label_column] = clean[label_column].astype(str).str.strip().str.lower()
    if set(clean[label_column]) - set(LABELS):
        raise ValueError("Labels must use the documented four-class taxonomy")
    if set(clean["split"]) != {"train", "validation", "test"}:
        raise ValueError("split must contain train, validation and test")
    for split_name in ["train", "validation", "test"]:
        missing_labels = set(LABELS) - set(clean.loc[clean["split"] == split_name, label_column])
        if missing_labels:
            raise ValueError(f"{split_name} is missing labels: {sorted(missing_labels)}")
    if group_column in clean.columns:
        overlap = clean.groupby(group_column)["split"].nunique()
        if overlap.gt(1).any():
            raise ValueError("Group leakage detected across fixed splits")
    if "corpus_song_id" in clean.columns:
        parent_overlap = clean.groupby("corpus_song_id")["split"].nunique()
        if parent_overlap.gt(1).any():
            raise ValueError("Parent-song leakage detected across fixed splits")
    return clean


def head_tail_tokenise(tokenizer, text: str, max_length: int) -> dict[str, list[int]]:
    """Keep both lyric opening and ending when an input exceeds the model limit."""

    full = tokenizer(
        str(text),
        add_special_tokens=True,
        truncation=False,
        return_special_tokens_mask=True,
    )
    input_ids = full["input_ids"]
    if len(input_ids) <= max_length:
        return {
            key: value
            for key, value in full.items()
            if key in getattr(tokenizer, "model_input_names", ["input_ids", "attention_mask"])
        }

    special_mask = full["special_tokens_mask"]
    content_positions = [
        position for position, is_special in enumerate(special_mask) if not is_special
    ]
    if not content_positions:
        raise ValueError("Tokenizer produced no content tokens")
    prefix_positions = list(range(content_positions[0]))
    suffix_positions = list(range(content_positions[-1] + 1, len(input_ids)))
    available = max_length - len(prefix_positions) - len(suffix_positions)
    if available < 2:
        raise ValueError("max_length leaves no room for lyric tokens")
    head_length = (available + 1) // 2
    tail_length = available - head_length
    selected_positions = (
        prefix_positions
        + content_positions[:head_length]
        + content_positions[-tail_length:]
        + suffix_positions
    )
    encoded: dict[str, list[int]] = {}
    for key in getattr(tokenizer, "model_input_names", ["input_ids", "attention_mask"]):
        if key in full:
            encoded[key] = [full[key][position] for position in selected_positions]
    if "attention_mask" not in encoded:
        encoded["attention_mask"] = [1] * len(encoded["input_ids"])
    return encoded


def _to_dataset(
    frame: pd.DataFrame,
    tokenizer,
    text_column: str,
    label_column: str,
    max_length: int,
    truncation_strategy: str,
) -> Dataset:
    dataset_frame = frame[[text_column, label_column]].rename(columns={label_column: "label"}).copy()
    dataset_frame["label"] = dataset_frame["label"].map(LABEL_TO_ID)
    dataset = Dataset.from_pandas(dataset_frame, preserve_index=False)

    def tokenise(batch):
        if truncation_strategy == "right":
            return tokenizer(batch[text_column], truncation=True, max_length=max_length)
        if truncation_strategy == "head_tail":
            encoded = [
                head_tail_tokenise(tokenizer, text, max_length)
                for text in batch[text_column]
            ]
            keys = encoded[0].keys()
            return {key: [item[key] for item in encoded] for key in keys}
        raise ValueError(f"Unknown truncation strategy: {truncation_strategy}")

    return dataset.map(tokenise, batched=True, remove_columns=[text_column])


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def fixed_partition_identity(frame: pd.DataFrame) -> tuple[int | None, int | None]:
    """Return the shared partition identity and reject mixed input files."""

    values: list[int | None] = []
    for column in ["partition_seed", "outer_fold"]:
        if column not in frame.columns:
            values.append(None)
            continue
        unique = frame[column].dropna().unique()
        if len(unique) != 1:
            raise ValueError(f"{column} must contain exactly one value per fixed input file")
        values.append(int(unique[0]))
    return values[0], values[1]


def learning_curve_identity(frame: pd.DataFrame) -> float | None:
    if "learning_curve_fraction" not in frame.columns:
        return None
    unique = frame["learning_curve_fraction"].dropna().unique()
    if len(unique) != 1 or not 0 < float(unique[0]) <= 1:
        raise ValueError("learning_curve_fraction must contain one value in (0, 1]")
    return float(unique[0])


def fraction_slug(fraction: float) -> str:
    return f"{int(round(fraction * 100)):03d}"


def compute_warmup_steps(
    training_examples: int,
    batch_size: int,
    gradient_accumulation_steps: int,
    epochs: int,
    warmup_ratio: float = 0.1,
) -> int:
    """Convert a predeclared warm-up ratio to explicit optimiser steps."""

    if min(training_examples, batch_size, gradient_accumulation_steps, epochs) < 1:
        raise ValueError("Training size, batch size, accumulation and epochs must be positive")
    batches_per_epoch = math.ceil(training_examples / batch_size)
    optimiser_steps_per_epoch = math.ceil(batches_per_epoch / gradient_accumulation_steps)
    total_steps = optimiser_steps_per_epoch * epochs
    return max(1, math.ceil(total_steps * warmup_ratio))


def rename_validation_metrics(metrics: dict[str, float]) -> dict[str, float]:
    """Expose post-training validation metrics without retriggering prefix bugs."""

    renamed: dict[str, float] = {}
    for key, value in metrics.items():
        if key.startswith("eval_"):
            renamed[f"validation_{key.removeprefix('eval_')}"] = value
        else:
            renamed[f"validation_{key}"] = value
    return renamed


def run_training(
    input_path: Path,
    output_dir: Path,
    model_name: str,
    model_revision: str | None = None,
    seed: int = 42,
    text_column: str = "lyrics",
    label_column: str = "emotion",
    group_column: str = "artist",
    max_length: int = 512,
    truncation_strategy: str = "head_tail",
    epochs: int = 5,
    learning_rate: float = 2e-5,
    batch_size: int = 4,
    gradient_accumulation_steps: int = 4,
    class_weighting: str = "none",
    sampling_strategy: str = "none",
    retain_model_artifacts: bool = True,
) -> dict[str, object]:
    set_seed(seed)
    frame = validate_fixed_splits(pd.read_csv(input_path), text_column, label_column, group_column)
    partition_seed, outer_fold = fixed_partition_identity(frame)
    learning_curve_fraction = learning_curve_identity(frame)
    tokenizer = AutoTokenizer.from_pretrained(
        model_name,
        revision=model_revision,
        use_fast=True,
    )
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        revision=model_revision,
        num_labels=len(LABELS),
        id2label=ID_TO_LABEL,
        label2id=LABEL_TO_ID,
    )
    split_frames = {name: frame.loc[frame["split"] == name].copy() for name in ["train", "validation", "test"]}
    split_datasets = {
        name: _to_dataset(
            part,
            tokenizer,
            text_column,
            label_column,
            max_length,
            truncation_strategy,
        )
        for name, part in split_frames.items()
    }
    run_name = f"{model_name.replace('/', '__')}__trainseed_{seed}"
    if partition_seed is not None:
        run_name += f"__partitionseed_{partition_seed}"
    if outer_fold is not None:
        run_name += f"__fold_{outer_fold}"
    if learning_curve_fraction is not None:
        run_name += f"__fraction_{fraction_slug(learning_curve_fraction)}"
    if class_weighting not in {"none", "balanced"}:
        raise ValueError("class_weighting must be 'none' or 'balanced'")
    if sampling_strategy not in {"none", "balanced"}:
        raise ValueError("sampling_strategy must be 'none' or 'balanced'")
    if class_weighting == "balanced" and sampling_strategy == "balanced":
        raise ValueError("Use either balanced loss or balanced sampling, not both")
    if class_weighting == "balanced":
        run_name += "__classweight_balanced"
    if sampling_strategy == "balanced":
        run_name += "__sampler_balanced"
    run_dir = output_dir / run_name
    checkpoint_dir = checkpoint_directory(output_dir, run_name)
    run_dir.mkdir(parents=True, exist_ok=True)
    use_cuda = torch.cuda.is_available()
    warmup_steps = compute_warmup_steps(
        len(split_frames["train"]),
        batch_size,
        gradient_accumulation_steps,
        epochs,
    )
    arguments = TrainingArguments(
        output_dir=str(checkpoint_dir),
        per_device_train_batch_size=batch_size,
        per_device_eval_batch_size=max(batch_size, 8),
        gradient_accumulation_steps=gradient_accumulation_steps,
        num_train_epochs=epochs,
        learning_rate=learning_rate,
        weight_decay=0.01,
        warmup_steps=warmup_steps,
        eval_strategy="epoch",
        save_strategy="epoch",
        logging_strategy="epoch",
        load_best_model_at_end=True,
        metric_for_best_model="macro_f1",
        greater_is_better=True,
        save_total_limit=2,
        seed=seed,
        data_seed=seed,
        fp16=use_cuda,
        report_to="none",
        use_cpu=not use_cuda,
    )
    class_weights = (
        compute_balanced_class_weights(split_frames["train"][label_column])
        if class_weighting == "balanced"
        else None
    )
    sample_weights = (
        compute_balanced_sample_weights(split_frames["train"][label_column])
        if sampling_strategy == "balanced"
        else None
    )
    trainer = ClassWeightedTrainer(
        model=model,
        args=arguments,
        train_dataset=split_datasets["train"],
        eval_dataset=split_datasets["validation"],
        processing_class=tokenizer,
        data_collator=DataCollatorWithPadding(tokenizer),
        compute_metrics=compute_metrics,
        callbacks=[EarlyStoppingCallback(early_stopping_patience=2)],
        class_weights=class_weights,
        sample_weights=sample_weights,
        sampler_seed=seed,
    )
    started = time.perf_counter()
    train_result = trainer.train()
    training_seconds = time.perf_counter() - started
    validation_metrics_raw = trainer.evaluate(
        split_datasets["validation"],
        metric_key_prefix="eval",
    )
    validation_metrics = rename_validation_metrics(validation_metrics_raw)
    test_result = trainer.predict(split_datasets["test"], metric_key_prefix="test")
    predicted_ids = np.argmax(test_result.predictions, axis=-1)
    test_predictions = split_frames["test"].copy()
    test_predictions["model_key"] = f"transformer::{model_name}"
    if class_weighting == "balanced":
        test_predictions["model_key"] += "::balanced_loss"
    if sampling_strategy == "balanced":
        test_predictions["model_key"] += "::balanced_sampler"
    test_predictions["evaluation_split"] = "test"
    test_predictions["true_label"] = test_predictions[label_column]
    test_predictions["predicted_label"] = [ID_TO_LABEL[int(value)] for value in predicted_ids]
    test_predictions["correct"] = test_predictions["true_label"] == test_predictions["predicted_label"]
    test_predictions["training_rows"] = len(split_frames["train"])
    test_predictions["training_songs"] = (
        int(split_frames["train"]["corpus_song_id"].nunique())
        if "corpus_song_id" in split_frames["train"].columns
        else None
    )
    test_predictions["training_groups"] = (
        int(split_frames["train"][group_column].nunique())
        if group_column in split_frames["train"].columns
        else None
    )
    safe_columns = [
        column
        for column in [
            "case_id",
            "corpus_song_id",
            "section_type",
            "section_index",
            "occurrence_count",
            "title",
            "artist",
            "release_year",
            "partition_seed",
            "outer_fold",
            "learning_curve_fraction",
            "model_key",
            "evaluation_split",
            "true_label",
            "predicted_label",
            "correct",
            "training_rows",
            "training_songs",
            "training_groups",
        ]
        if column in test_predictions.columns
    ]
    test_predictions[safe_columns].to_csv(run_dir / "test_predictions.csv", index=False, encoding="utf-8-sig")

    metrics = {
        "validation": {key: float(value) for key, value in validation_metrics.items() if isinstance(value, (int, float))},
        "test": {key: float(value) for key, value in test_result.metrics.items() if isinstance(value, (int, float))},
        "train": {key: float(value) for key, value in train_result.metrics.items() if isinstance(value, (int, float))},
        "training_seconds_wall_clock": training_seconds,
    }
    (run_dir / "metrics.json").write_text(json.dumps(metrics, ensure_ascii=False, indent=2), encoding="utf-8")
    metadata: dict[str, object] = {
        "model": model_name,
        "model_revision": model_revision,
        "seed": seed,
        "partition_seed": partition_seed,
        "outer_fold": outer_fold,
        "learning_curve_fraction": learning_curve_fraction,
        "input_sha256": file_sha256(input_path),
        "split_sizes": {name: len(part) for name, part in split_frames.items()},
        "training_songs": (
            int(split_frames["train"]["corpus_song_id"].nunique())
            if "corpus_song_id" in split_frames["train"].columns
            else None
        ),
        "training_groups": (
            int(split_frames["train"][group_column].nunique())
            if group_column in split_frames["train"].columns
            else None
        ),
        "class_counts": {
            name: part[label_column].value_counts().reindex(LABELS, fill_value=0).to_dict()
            for name, part in split_frames.items()
        },
        "max_length": max_length,
        "truncation_strategy": truncation_strategy,
        "epochs_requested": epochs,
        "learning_rate": learning_rate,
        "warmup_steps": warmup_steps,
        "batch_size": batch_size,
        "gradient_accumulation_steps": gradient_accumulation_steps,
        "class_weighting": class_weighting,
        "class_weights": class_weights,
        "sampling_strategy": sampling_strategy,
        "sample_weighting": "inverse_frequency" if sample_weights is not None else None,
        "sampling_scope": "training split only",
        "model_artifacts_retained": retain_model_artifacts,
        "device": torch.cuda.get_device_name(0) if use_cuda else "cpu",
        "cuda_available": use_cuda,
        "torch": torch.__version__,
        "transformers": transformers.__version__,
        "datasets": datasets.__version__,
        "accelerate": accelerate.__version__,
        "python": platform.python_version(),
        "case_id_column": "case_id"
        if "case_id" in split_frames["test"].columns
        else "corpus_song_id",
        "cluster_unit": "corpus_song_id"
        if "corpus_song_id" in split_frames["test"].columns
        else None,
    }
    (run_dir / "run_metadata.json").write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8")
    if retain_model_artifacts:
        tokenizer.save_pretrained(run_dir / "best_model")
        trainer.save_model(run_dir / "best_model")
    elif checkpoint_dir.exists():
        # Learning-curve runs only need predictions, metrics and metadata. The
        # recorded base revision, input hash and hyperparameters are sufficient
        # to reproduce the fine-tuned weights, which otherwise consume hundreds
        # of gigabytes across the experiment matrix.
        shutil.rmtree(checkpoint_dir)
    return {"run_dir": str(run_dir), "metrics": metrics, "metadata": metadata}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/transformer"))
    parser.add_argument("--model", required=True)
    parser.add_argument("--model-revision")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--text-column", default="lyrics")
    parser.add_argument("--label-column", default="emotion")
    parser.add_argument("--group-column", default="artist")
    parser.add_argument("--max-length", type=int, default=512)
    parser.add_argument(
        "--truncation-strategy",
        choices=["head_tail", "right"],
        default="head_tail",
    )
    parser.add_argument("--epochs", type=int, default=5)
    parser.add_argument("--learning-rate", type=float, default=2e-5)
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--gradient-accumulation-steps", type=int, default=4)
    parser.add_argument(
        "--class-weighting",
        choices=["none", "balanced"],
        default="none",
        help="Optional inverse-frequency loss weighting for sensitivity analysis",
    )
    parser.add_argument(
        "--sampling-strategy",
        choices=["none", "balanced"],
        default="none",
        help="Optional inverse-frequency WeightedRandomSampler for the training split",
    )
    parser.add_argument(
        "--discard-model-artifacts",
        action="store_true",
        help="Keep predictions, metrics and metadata but remove reproducible weights",
    )
    args = parser.parse_args()
    result = run_training(
        args.input,
        args.output_dir,
        args.model,
        model_revision=args.model_revision,
        seed=args.seed,
        text_column=args.text_column,
        label_column=args.label_column,
        group_column=args.group_column,
        max_length=args.max_length,
        truncation_strategy=args.truncation_strategy,
        epochs=args.epochs,
        learning_rate=args.learning_rate,
        batch_size=args.batch_size,
        gradient_accumulation_steps=args.gradient_accumulation_steps,
        class_weighting=args.class_weighting,
        sampling_strategy=args.sampling_strategy,
        retain_model_artifacts=not args.discard_model_artifacts,
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
