"""Run paired data-size experiments on identical validation/test cases."""

from __future__ import annotations

import argparse
import json
import re
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


PATTERN = re.compile(r"seed_(\d+)_fold_(\d+)__(small_680|expanded_train)\.csv$")
MACBERT = "hfl/chinese-macbert-base"
MACBERT_REVISION = "a986e004d2a7f2a1c2f5a3edef4e20604a974ed1"


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def discover(partitions_dir: Path) -> list[dict]:
    items = []
    for path in sorted(partitions_dir.glob("*.csv")):
        match = PATTERN.match(path.name)
        if match:
            items.append(
                {
                    "path": path.resolve(),
                    "seed": int(match.group(1)),
                    "fold": int(match.group(2)),
                    "cohort": match.group(3),
                }
            )
    if len(items) != 30:
        raise ValueError(f"Expected 30 paired files, found {len(items)}")
    return items


def jobs(items: list[dict], output_root: Path, family: str) -> list[dict]:
    result = []
    python = str(Path(sys.executable).resolve())
    for item in items:
        base = output_root / family / item["cohort"]
        if family == "classical":
            run_dir = base / f"seed_{item['seed']}_fold_{item['fold']}"
            command = [
                python,
                "-m",
                "src.classical_experiment",
                str(item["path"]),
                "--fixed-split",
                "--seeds",
                str(item["seed"]),
                "--feature-sets",
                "character_tfidf",
                "--models",
                "linear_svm",
                "--imbalance-strategies",
                "baseline",
                "moderate_undersampling",
                "--output-dir",
                str(run_dir.resolve()),
            ]
            expected = run_dir / "run_metadata.json"
        else:
            name = (
                f"hfl__chinese-macbert-base__trainseed_{item['seed']}"
                f"__partitionseed_{item['seed']}__fold_{item['fold']}"
            )
            run_dir = base / name
            command = [
                python,
                "-m",
                "src.transformer_experiment",
                str(item["path"]),
                "--model",
                MACBERT,
                "--model-revision",
                MACBERT_REVISION,
                "--seed",
                str(item["seed"]),
                "--max-length",
                "128",
                "--epochs",
                "3",
                "--batch-size",
                "8",
                "--gradient-accumulation-steps",
                "2",
                "--discard-model-artifacts",
                "--output-dir",
                str(base.resolve()),
            ]
            expected = run_dir / "run_metadata.json"
        result.append(
            {
                **item,
                "path": str(item["path"]),
                "family": family,
                "command": command,
                "run_dir": str(run_dir.resolve()),
                "expected": str(expected.resolve()),
                "status": "pending",
            }
        )
    return result


def collect_classical(all_jobs: list[dict]) -> pd.DataFrame:
    frames = []
    for job in all_jobs:
        path = Path(job["run_dir"]) / "metrics.csv"
        if path.exists():
            frames.append(
                pd.read_csv(path).assign(
                    training_cohort=job["cohort"], outer_fold=job["fold"]
                )
            )
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()


def collect_transformer(all_jobs: list[dict]) -> pd.DataFrame:
    rows = []
    for job in all_jobs:
        path = Path(job["run_dir"]) / "metrics.json"
        if not path.exists():
            continue
        payload = json.loads(path.read_text(encoding="utf-8"))
        for split in ["validation", "test"]:
            prefix = f"{split}_"
            row = {
                "training_cohort": job["cohort"],
                "seed": job["seed"],
                "outer_fold": job["fold"],
                "evaluation_split": split,
                "training_seconds": payload["training_seconds_wall_clock"],
            }
            row.update(
                {
                    key.removeprefix(prefix): value
                    for key, value in payload[split].items()
                    if key.startswith(prefix)
                }
            )
            rows.append(row)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("partitions_dir", type=Path)
    parser.add_argument("--output-root", type=Path, required=True)
    parser.add_argument("--family", choices=["classical", "transformer"], required=True)
    args = parser.parse_args()
    output_root = args.output_root.resolve()
    all_jobs = jobs(discover(args.partitions_dir), output_root, args.family)
    manifest_path = output_root / f"{args.family}_matrix.json"
    logs = output_root / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    for job in all_jobs:
        if Path(job["expected"]).exists():
            job["status"] = "skipped_existing"
            continue
        job["status"] = "running"
        job["started_at_utc"] = now()
        manifest_path.write_text(json.dumps(all_jobs, indent=2), encoding="utf-8")
        logbase = f"{args.family}__{job['cohort']}__seed_{job['seed']}__fold_{job['fold']}"
        with (logs / f"{logbase}.stdout.log").open("w", encoding="utf-8") as out, (
            logs / f"{logbase}.stderr.log"
        ).open("w", encoding="utf-8") as err:
            completed = subprocess.run(job["command"], cwd=Path.cwd(), stdout=out, stderr=err)
        job["return_code"] = completed.returncode
        job["completed_at_utc"] = now()
        job["status"] = (
            "completed"
            if completed.returncode == 0 and Path(job["expected"]).exists()
            else "failed"
        )
        manifest_path.write_text(json.dumps(all_jobs, indent=2), encoding="utf-8")
        if job["status"] == "failed":
            raise RuntimeError(f"Failed: {logbase}")
    result = (
        collect_classical(all_jobs)
        if args.family == "classical"
        else collect_transformer(all_jobs)
    )
    result.to_csv(output_root / f"{args.family}_all_metrics.csv", index=False)


if __name__ == "__main__":
    main()
