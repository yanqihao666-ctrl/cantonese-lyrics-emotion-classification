"""Materialise and execute the predeclared RQ3 learning-curve matrix."""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from src.make_learning_curve_subsets import (
    DEFAULT_FRACTIONS,
    materialise_learning_curve_subsets,
    select_nested_training_groups,
)
from src.run_experiment_matrix import (
    PRIMARY_TRANSFORMERS,
    ExperimentJob,
    Partition,
    _transformer_run_name,
    execute_jobs,
    file_sha256,
    write_matrix_manifest,
)


LEARNING_CURVE_SEED = 42
LEARNING_CURVE_FOLDS = [1, 2, 3, 4, 5]


def discover_base_partitions(
    partitions_dir: Path,
    partition_seed: int = LEARNING_CURVE_SEED,
) -> list[Path]:
    selected: list[tuple[int, Path]] = []
    for path in sorted(partitions_dir.glob("*.csv")):
        frame = pd.read_csv(path, usecols=lambda column: column in {"partition_seed", "outer_fold"})
        if set(frame.columns) != {"partition_seed", "outer_fold"}:
            continue
        seeds = frame["partition_seed"].dropna().unique()
        folds = frame["outer_fold"].dropna().unique()
        if len(seeds) == 1 and len(folds) == 1 and int(seeds[0]) == partition_seed:
            selected.append((int(folds[0]), path))
    if not selected:
        raise ValueError(
            f"No seed-{partition_seed} fixed partitions found in {partitions_dir}"
        )
    identities = [fold for fold, _ in selected]
    if len(identities) != len(set(identities)):
        raise ValueError("Duplicate learning-curve outer folds")
    return [path for _, path in sorted(selected)]


def materialise_learning_matrix(
    base_paths: list[Path],
    subsets_root: Path,
    fractions: list[float] | None = None,
    selection_seed: int = LEARNING_CURVE_SEED,
) -> list[Partition]:
    fractions = fractions or DEFAULT_FRACTIONS
    subset_partitions: list[Partition] = []
    for base_path in base_paths:
        frame = pd.read_csv(base_path)
        partition_seeds = frame["partition_seed"].dropna().unique()
        outer_folds = frame["outer_fold"].dropna().unique()
        if len(partition_seeds) != 1 or len(outer_folds) != 1:
            raise ValueError(f"{base_path} has mixed partition identity")
        partition_seed = int(partition_seeds[0])
        outer_fold = int(outer_folds[0])
        selections, metadata = select_nested_training_groups(
            frame,
            fractions=fractions,
            seed=selection_seed,
        )
        materialised = materialise_learning_curve_subsets(frame, selections)
        output_dir = subsets_root / f"seed_{partition_seed}_fold_{outer_fold}"
        output_dir.mkdir(parents=True, exist_ok=True)
        metadata.update(
            {
                "partition_seed": partition_seed,
                "outer_fold": outer_fold,
                "base_partition_path": str(base_path.resolve()),
                "base_partition_sha256": file_sha256(base_path),
            }
        )
        for fraction, subset in materialised.items():
            fraction_slug = int(round(fraction * 100))
            subset_path = output_dir / f"train_fraction_{fraction_slug:03d}.csv"
            subset.to_csv(subset_path, index=False, encoding="utf-8-sig")
            train = subset.loc[subset["split"] == "train"]
            subset_partitions.append(
                Partition(
                    path=str(subset_path.resolve()),
                    partition_seed=partition_seed,
                    outer_fold=outer_fold,
                    input_sha256=file_sha256(subset_path),
                    rows=len(subset),
                    learning_curve_fraction=float(fraction),
                    training_rows=len(train),
                    training_groups=int(train["artist"].nunique()),
                )
            )
        (output_dir / "learning_curve_metadata.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2),
            encoding="utf-8",
        )
    return sorted(
        subset_partitions,
        key=lambda item: (
            item.partition_seed,
            item.outer_fold,
            item.learning_curve_fraction or 0,
        ),
    )


def validate_learning_grid(
    subsets: list[Partition],
    fractions: list[float] | None = None,
) -> None:
    fractions = fractions or DEFAULT_FRACTIONS
    expected = {
        (LEARNING_CURVE_SEED, fold, fraction)
        for fold in LEARNING_CURVE_FOLDS
        for fraction in fractions
    }
    observed = {
        (item.partition_seed, item.outer_fold, item.learning_curve_fraction)
        for item in subsets
    }
    missing = sorted(expected.difference(observed))
    extra = sorted(observed.difference(expected))
    if missing or extra:
        raise ValueError(f"Learning-curve grid mismatch; missing={missing}, extra={extra}")


def validate_nested_subsets(subsets: list[Partition]) -> None:
    grouped: dict[tuple[int, int], list[Partition]] = {}
    for subset in subsets:
        grouped.setdefault((subset.partition_seed, subset.outer_fold), []).append(subset)
    for identity, items in grouped.items():
        previous_train_ids: set[str] = set()
        reference_evaluation_ids: set[str] | None = None
        for item in sorted(items, key=lambda value: value.learning_curve_fraction or 0):
            frame = pd.read_csv(item.path)
            id_column = "case_id" if "case_id" in frame.columns else "corpus_song_id"
            train_ids = set(
                frame.loc[frame["split"] == "train", id_column].astype(str)
            )
            evaluation_ids = set(
                frame.loc[frame["split"] != "train", id_column].astype(str)
            )
            if not previous_train_ids.issubset(train_ids):
                raise ValueError(f"Training subsets are not nested for {identity}")
            if reference_evaluation_ids is None:
                reference_evaluation_ids = evaluation_ids
            elif evaluation_ids != reference_evaluation_ids:
                raise ValueError(f"Evaluation cases changed across fractions for {identity}")
            previous_train_ids = train_ids


def build_learning_jobs(
    subsets: list[Partition],
    output_root: Path,
    python_executable: Path,
    families: list[str],
) -> list[ExperimentJob]:
    invalid = sorted(set(families).difference({"classical", "transformer"}))
    if invalid:
        raise ValueError(f"Unknown learning-curve families: {invalid}")
    output_root = output_root.resolve()
    logs_dir = output_root / "logs"
    jobs: list[ExperimentJob] = []
    for subset in subsets:
        seed = subset.partition_seed
        fold = subset.outer_fold
        fraction = subset.learning_curve_fraction
        if fraction is None:
            raise ValueError("Learning subset is missing its fraction")
        fraction_slug = int(round(fraction * 100))
        if "classical" in families:
            job_id = f"classical_svm__seed_{seed}__fold_{fold}__fraction_{fraction_slug:03d}"
            output_dir = (
                output_root
                / "classical"
                / f"seed_{seed}_fold_{fold}_fraction_{fraction_slug:03d}"
            )
            jobs.append(
                ExperimentJob(
                    job_id=job_id,
                    family="classical",
                    model_key="classical::character_tfidf::linear_svm",
                    partition_seed=seed,
                    outer_fold=fold,
                    input_path=subset.path,
                    input_sha256=subset.input_sha256,
                    command=[
                        str(python_executable),
                        "-m",
                        "src.classical_experiment",
                        subset.path,
                        "--fixed-split",
                        "--seeds",
                        str(seed),
                        "--feature-sets",
                        "character_tfidf",
                        "--models",
                        "linear_svm",
                        "--id-column",
                        "case_id",
                        "--output-dir",
                        str(output_dir),
                    ],
                    expected_metadata=str(output_dir / "run_metadata.json"),
                    stdout_log=str(logs_dir / f"{job_id}.stdout.log"),
                    stderr_log=str(logs_dir / f"{job_id}.stderr.log"),
                    learning_curve_fraction=fraction,
                )
            )
        if "transformer" in families:
            for model_name, revision in PRIMARY_TRANSFORMERS:
                model_slug = model_name.replace("/", "__")
                job_id = (
                    f"{model_slug}__seed_{seed}__fold_{fold}"
                    f"__fraction_{fraction_slug:03d}"
                )
                transformer_root = output_root / "transformer"
                run_name = _transformer_run_name(
                    model_name,
                    seed,
                    fold,
                    learning_curve_fraction=fraction,
                )
                jobs.append(
                    ExperimentJob(
                        job_id=job_id,
                        family="transformer",
                        model_key=f"transformer::{model_name}",
                        partition_seed=seed,
                        outer_fold=fold,
                        input_path=subset.path,
                        input_sha256=subset.input_sha256,
                        command=[
                            str(python_executable),
                            "-m",
                            "src.transformer_experiment",
                            subset.path,
                            "--model",
                            model_name,
                            "--model-revision",
                            revision,
                            "--seed",
                            str(seed),
                            "--output-dir",
                            str(transformer_root),
                            "--discard-model-artifacts",
                        ],
                        expected_metadata=str(
                            transformer_root / run_name / "run_metadata.json"
                        ),
                        stdout_log=str(logs_dir / f"{job_id}.stdout.log"),
                        stderr_log=str(logs_dir / f"{job_id}.stderr.log"),
                        learning_curve_fraction=fraction,
                    )
                )
    if len({job.job_id for job in jobs}) != len(jobs):
        raise AssertionError("Duplicate learning-curve job IDs")
    if len({job.expected_metadata for job in jobs}) != len(jobs):
        raise AssertionError("Colliding learning-curve outputs")
    return jobs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("partitions_dir", type=Path)
    parser.add_argument(
        "--subsets-root",
        type=Path,
        default=Path("data/processed/learning_curves"),
    )
    parser.add_argument(
        "--output-root",
        type=Path,
        default=Path("results/formal/learning_curves"),
    )
    parser.add_argument(
        "--families",
        nargs="+",
        choices=["classical", "transformer"],
        default=["classical", "transformer"],
    )
    parser.add_argument("--fractions", nargs="+", type=float, default=DEFAULT_FRACTIONS)
    parser.add_argument(
        "--partition-seed",
        type=int,
        default=LEARNING_CURVE_SEED,
        help="Formal protocol uses 42; override only for synthetic diagnostics",
    )
    parser.add_argument("--allow-partial-grid", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    base_paths = discover_base_partitions(
        args.partitions_dir,
        partition_seed=args.partition_seed,
    )
    subsets = materialise_learning_matrix(
        base_paths,
        subsets_root=args.subsets_root,
        fractions=args.fractions,
        selection_seed=args.partition_seed,
    )
    validate_nested_subsets(subsets)
    if not args.allow_partial_grid:
        validate_learning_grid(subsets, fractions=args.fractions)
    jobs = build_learning_jobs(
        subsets,
        output_root=args.output_root,
        python_executable=Path(sys.executable).resolve(),
        families=args.families,
    )
    manifest_path = args.output_root / "learning_curve_matrix.json"
    write_matrix_manifest(manifest_path, subsets, jobs)
    print(
        json.dumps(
            {
                "base_partitions": len(base_paths),
                "subsets": len(subsets),
                "jobs": len(jobs),
                "manifest": str(manifest_path),
                "dry_run": args.dry_run,
            },
            indent=2,
        )
    )
    if not args.dry_run:
        execute_jobs(
            jobs,
            subsets,
            manifest_path=manifest_path,
            workdir=Path.cwd(),
            force=args.force,
        )


if __name__ == "__main__":
    main()
