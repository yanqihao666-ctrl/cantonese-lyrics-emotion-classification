"""Validate, aggregate and plot the predeclared RQ3 learning curves."""

from __future__ import annotations

import argparse
import json
from datetime import datetime, timezone
from pathlib import Path

import matplotlib
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score

matplotlib.use("Agg")
import matplotlib.pyplot as plt  # noqa: E402

from src.statistical_analysis import LABELS, file_sha256


PREDICTION_FILENAMES = {"predictions.csv", "test_predictions.csv"}
CASE_COLUMNS = ["case_id", "partition_seed", "outer_fold"]


def display_model_name(model_key: str) -> str:
    names = {
        "classical::character_tfidf::linear_svm": "Character TF-IDF + Linear SVM",
        "transformer::FacebookAI/xlm-roberta-base": "XLM-RoBERTa-base",
        "transformer::hfl/chinese-macbert-base": "Chinese MacBERT-base",
    }
    return names.get(model_key, model_key)


def discover_learning_predictions(inputs: list[Path]) -> list[Path]:
    discovered: set[Path] = set()
    for input_path in inputs:
        if input_path.is_file():
            discovered.add(input_path.resolve())
        elif input_path.is_dir():
            for path in input_path.rglob("*.csv"):
                if path.name in PREDICTION_FILENAMES:
                    discovered.add(path.resolve())
        else:
            raise FileNotFoundError(input_path)
    if not discovered:
        raise ValueError("No learning-curve prediction files found")
    return sorted(discovered)


def collect_learning_predictions(paths: list[Path]) -> pd.DataFrame:
    parts: list[pd.DataFrame] = []
    for path in paths:
        frame = pd.read_csv(path)
        if "case_id" not in frame.columns and "corpus_song_id" in frame.columns:
            frame["case_id"] = frame["corpus_song_id"]
        if "evaluation_split" in frame.columns:
            frame = frame.loc[frame["evaluation_split"] == "test"].copy()
        if frame.empty:
            continue
        if "training_songs" not in frame.columns:
            frame["training_songs"] = frame["training_rows"]
        required = {
            *CASE_COLUMNS,
            "model_key",
            "true_label",
            "predicted_label",
            "learning_curve_fraction",
            "training_rows",
            "training_songs",
            "training_groups",
        }
        missing = sorted(required.difference(frame.columns))
        if missing:
            raise ValueError(f"{path} is missing learning-curve columns: {missing}")
        frame["source_prediction_file"] = str(path)
        parts.append(frame)
    if not parts:
        raise ValueError("Learning-curve files contained no test rows")
    combined = pd.concat(parts, ignore_index=True, sort=False)
    return validate_learning_predictions(combined)


def validate_learning_predictions(predictions: pd.DataFrame) -> pd.DataFrame:
    predictions = predictions.copy()
    if "case_id" not in predictions.columns and "corpus_song_id" in predictions.columns:
        predictions["case_id"] = predictions["corpus_song_id"]
    if "training_songs" not in predictions.columns and "training_rows" in predictions.columns:
        predictions["training_songs"] = predictions["training_rows"]
    required = {
        *CASE_COLUMNS,
        "model_key",
        "true_label",
        "predicted_label",
        "learning_curve_fraction",
        "training_rows",
        "training_songs",
        "training_groups",
    }
    missing = sorted(required.difference(predictions.columns))
    if missing:
        raise ValueError(f"Missing learning-curve columns: {missing}")
    clean = predictions.copy()
    if clean[list(required)].isna().any().any():
        raise ValueError("Learning-curve prediction identities cannot be missing")
    for column in ["true_label", "predicted_label"]:
        clean[column] = clean[column].astype(str).str.strip().str.lower()
        invalid = sorted(set(clean[column]).difference(LABELS))
        if invalid:
            raise ValueError(f"Invalid {column} values: {invalid}")
    clean["learning_curve_fraction"] = pd.to_numeric(
        clean["learning_curve_fraction"],
        errors="coerce",
    )
    if (
        clean["learning_curve_fraction"].isna().any()
        or not clean["learning_curve_fraction"].between(0, 1, inclusive="right").all()
        or clean["learning_curve_fraction"].eq(0).any()
    ):
        raise ValueError("Learning-curve fractions must lie in (0, 1]")
    for column in ["training_rows", "training_songs", "training_groups"]:
        clean[column] = pd.to_numeric(clean[column], errors="coerce")
        if clean[column].isna().any() or clean[column].le(0).any():
            raise ValueError(f"{column} must be positive")

    key_columns = [
        *CASE_COLUMNS,
        "model_key",
        "learning_curve_fraction",
    ]
    if clean.duplicated(key_columns).any():
        raise ValueError("Each model/fraction must have one prediction per case")
    truth_counts = clean.groupby(
        [*CASE_COLUMNS, "learning_curve_fraction"]
    )["true_label"].nunique()
    if truth_counts.gt(1).any():
        raise ValueError("True labels disagree across learning-curve models")

    models = sorted(clean["model_key"].unique())
    fractions = sorted(clean["learning_curve_fraction"].unique())
    reference_cases: set[tuple[object, ...]] | None = None
    for model_key in models:
        for fraction in fractions:
            part = clean.loc[
                (clean["model_key"] == model_key)
                & (clean["learning_curve_fraction"] == fraction)
            ]
            cases = set(map(tuple, part[CASE_COLUMNS].to_numpy()))
            if reference_cases is None:
                reference_cases = cases
            elif cases != reference_cases:
                raise ValueError(
                    f"Learning models/fractions do not cover identical cases: "
                    f"{model_key} at {fraction}"
                )

    training_identity = [
        "partition_seed",
        "outer_fold",
        "learning_curve_fraction",
    ]
    training_counts = clean.groupby(training_identity)[
        ["training_rows", "training_songs", "training_groups"]
    ].nunique()
    if training_counts.gt(1).any().any():
        raise ValueError("Models disagree on achieved learning-curve training size")
    achieved = (
        clean[training_identity + ["training_rows", "training_songs", "training_groups"]]
        .drop_duplicates()
        .sort_values(training_identity)
    )
    for _, partition in achieved.groupby(["partition_seed", "outer_fold"]):
        ordered = partition.sort_values("learning_curve_fraction")
        if not ordered["training_rows"].is_monotonic_increasing:
            raise ValueError("Training rows must increase with learning-curve fraction")
        if not ordered["training_songs"].is_monotonic_increasing:
            raise ValueError("Training source songs must increase with learning-curve fraction")
        if not ordered["training_groups"].is_monotonic_increasing:
            raise ValueError("Training groups must increase with learning-curve fraction")
    return clean


def learning_curve_metrics(
    predictions: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    clean = validate_learning_predictions(predictions)
    rows: list[dict[str, object]] = []
    for keys, part in clean.groupby(
        ["model_key", "learning_curve_fraction", "partition_seed", "outer_fold"]
    ):
        model_key, fraction, partition_seed, outer_fold = keys
        rows.append(
            {
                "model_key": model_key,
                "learning_curve_fraction": float(fraction),
                "partition_seed": int(partition_seed),
                "outer_fold": int(outer_fold),
                "training_rows": int(part["training_rows"].iloc[0]),
                "training_songs": int(part["training_songs"].iloc[0]),
                "training_groups": int(part["training_groups"].iloc[0]),
                "test_rows": len(part),
                "macro_f1": f1_score(
                    part["true_label"],
                    part["predicted_label"],
                    labels=LABELS,
                    average="macro",
                    zero_division=0,
                ),
                "weighted_f1": f1_score(
                    part["true_label"],
                    part["predicted_label"],
                    labels=LABELS,
                    average="weighted",
                    zero_division=0,
                ),
                "accuracy": accuracy_score(
                    part["true_label"],
                    part["predicted_label"],
                ),
            }
        )
    partition_metrics = pd.DataFrame(rows).sort_values(
        ["model_key", "learning_curve_fraction", "partition_seed", "outer_fold"]
    )
    summary = (
        partition_metrics.groupby(
            ["model_key", "learning_curve_fraction"],
            as_index=False,
        )
        .agg(
            macro_f1_mean=("macro_f1", "mean"),
            macro_f1_std=("macro_f1", "std"),
            weighted_f1_mean=("weighted_f1", "mean"),
            accuracy_mean=("accuracy", "mean"),
            partitions=("outer_fold", "count"),
            training_rows_mean=("training_rows", "mean"),
            training_rows_min=("training_rows", "min"),
            training_rows_max=("training_rows", "max"),
            training_songs_mean=("training_songs", "mean"),
            training_songs_min=("training_songs", "min"),
            training_songs_max=("training_songs", "max"),
            training_groups_mean=("training_groups", "mean"),
            training_groups_min=("training_groups", "min"),
            training_groups_max=("training_groups", "max"),
        )
        .sort_values(["model_key", "learning_curve_fraction"])
    )
    return partition_metrics, summary


def plot_learning_curves(
    partition_metrics: pd.DataFrame,
    summary: pd.DataFrame,
    output_path: Path,
) -> None:
    output_path.parent.mkdir(parents=True, exist_ok=True)
    figure, axis = plt.subplots(figsize=(8.5, 5.2))
    colors = plt.get_cmap("tab10")
    for index, model_key in enumerate(sorted(summary["model_key"].unique())):
        model_summary = summary.loc[summary["model_key"] == model_key]
        model_points = partition_metrics.loc[
            partition_metrics["model_key"] == model_key
        ]
        color = colors(index)
        axis.scatter(
            model_points["learning_curve_fraction"] * 100,
            model_points["macro_f1"],
            color=color,
            alpha=0.35,
            s=24,
        )
        axis.plot(
            model_summary["learning_curve_fraction"] * 100,
            model_summary["macro_f1_mean"],
            color=color,
            marker="o",
            linewidth=2,
            label=display_model_name(model_key),
        )
    axis.set_xlabel("Nominal fraction of training sections, sampled by artist (%)")
    axis.set_ylabel("Test macro-F1")
    axis.set_ylim(-0.02, 1.02)
    axis.set_xticks(
        sorted(summary["learning_curve_fraction"].unique() * 100)
    )
    axis.grid(axis="y", alpha=0.25)
    axis.legend(fontsize=8, frameon=False)
    figure.tight_layout()
    figure.savefig(output_path, dpi=200)
    plt.close(figure)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/formal/learning_curve_analysis"),
    )
    args = parser.parse_args()

    paths = discover_learning_predictions(args.inputs)
    predictions = collect_learning_predictions(paths)
    partition_metrics, summary = learning_curve_metrics(predictions)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    combined_path = args.output_dir / "learning_curve_predictions.csv"
    predictions.to_csv(combined_path, index=False, encoding="utf-8-sig")
    partition_metrics.to_csv(
        args.output_dir / "learning_curve_partition_metrics.csv",
        index=False,
        encoding="utf-8-sig",
    )
    summary.to_csv(
        args.output_dir / "learning_curve_summary.csv",
        index=False,
        encoding="utf-8-sig",
    )
    plot_learning_curves(
        partition_metrics,
        summary,
        args.output_dir / "learning_curve_macro_f1.png",
    )
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_files": [
            {"path": str(path), "sha256": file_sha256(path)}
            for path in paths
        ],
        "models": sorted(predictions["model_key"].unique()),
        "fractions": sorted(
            float(value)
            for value in predictions["learning_curve_fraction"].unique()
        ),
        "partition_identities": (
            predictions[["partition_seed", "outer_fold"]]
            .drop_duplicates()
            .sort_values(["partition_seed", "outer_fold"])
            .to_dict("records")
        ),
        "uncertainty_display": "individual partition points plus mean line",
        "inferential_claims": False,
        "combined_predictions_sha256": file_sha256(combined_path),
    }
    (args.output_dir / "learning_curve_analysis_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "models": len(metadata["models"]),
                "fractions": len(metadata["fractions"]),
                "partitions": len(metadata["partition_identities"]),
                "output_dir": str(args.output_dir),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
