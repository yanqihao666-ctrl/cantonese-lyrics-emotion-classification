"""Audit completeness and traceability of the V2 imbalance results."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("root", type=Path)
    args = parser.parse_args()
    root = args.root
    checks: dict[str, bool] = {}

    classical = pd.read_csv(root / "classical_all_metrics.csv")
    checks["classical_150_validation_test_rows"] = len(classical) == 150
    checks["classical_75_test_rows"] = int(classical["evaluation_split"].eq("test").sum()) == 75
    checks["classical_all_finite_primary_metrics"] = bool(
        classical[["macro_f1", "balanced_accuracy", "accuracy"]].notna().all().all()
    )

    manifest = json.loads((root / "imbalance_matrix.json").read_text(encoding="utf-8"))
    jobs = manifest["jobs"]
    checks["transformer_45_completed_jobs"] = (
        len(jobs) == 45 and all(job["status"] == "completed" for job in jobs)
    )
    metadata_paths = sorted((root / "transformer").glob("*/run_metadata.json"))
    checks["transformer_45_metadata_files"] = len(metadata_paths) == 45
    prediction_lengths_ok = True
    no_retained_models = True
    unique_partitions = set()
    strategy_counts = {"baseline": 0, "balanced_loss": 0, "balanced_sampler": 0}
    for path in metadata_paths:
        metadata = json.loads(path.read_text(encoding="utf-8"))
        predictions = pd.read_csv(path.parent / "test_predictions.csv")
        prediction_lengths_ok &= len(predictions) == int(metadata["split_sizes"]["test"])
        no_retained_models &= metadata["model_artifacts_retained"] is False
        if metadata.get("class_weighting") == "balanced":
            strategy = "balanced_loss"
        elif metadata.get("sampling_strategy") == "balanced":
            strategy = "balanced_sampler"
        else:
            strategy = "baseline"
        strategy_counts[strategy] += 1
        unique_partitions.add((strategy, metadata["partition_seed"], metadata["outer_fold"]))
    checks["transformer_prediction_lengths_match_test_splits"] = prediction_lengths_ok
    checks["transformer_no_model_artifacts_retained"] = no_retained_models
    checks["transformer_15_runs_per_strategy"] = all(value == 15 for value in strategy_counts.values())
    checks["transformer_45_unique_strategy_partitions"] = len(unique_partitions) == 45
    checks["no_temporary_checkpoint_directory"] = not (root / "transformer" / "_trainer_checkpoints").exists()

    payload = {
        "passed": all(checks.values()),
        "checks": checks,
        "classical_test_results": 75,
        "transformer_test_results": 45,
        "transformer_strategy_counts": strategy_counts,
    }
    (root / "imbalance_results_audit.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))
    if not payload["passed"]:
        raise SystemExit(1)


if __name__ == "__main__":
    main()
