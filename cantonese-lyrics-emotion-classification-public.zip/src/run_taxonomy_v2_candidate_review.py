"""Run a second, frozen-model review of v2 minority-class candidates."""

from __future__ import annotations

import argparse
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


LABELS = {"joy", "sadness", "anger", "calmness"}


def parse_json(text: str) -> dict[str, object]:
    match = re.search(r"\{.*\}", text.replace("```json", "").replace("```", ""), re.S)
    if not match:
        return {}
    try:
        value = json.loads(match.group(0))
    except json.JSONDecodeError:
        return {}
    return value if isinstance(value, dict) else {}


def prompt(row: pd.Series) -> str:
    return f"""Classify the dominant perceived emotion in this Cantonese lyric section.

Use exactly one label from this four-quadrant taxonomy:
- joy: positive, high arousal; excitement, celebration, energetic hope or triumph.
- calmness: positive, low arousal; tenderness, reassurance, peace, acceptance, gentle affection or contentment. It is not a neutral fallback.
- anger: negative, high arousal; anger, resentment, confrontation, protest, jealousy, fear, anxiety, pressure or emotional agitation. Negative subject matter alone is insufficient.
- sadness: negative, low arousal; grief, loss, loneliness, regret, despair or resignation.

Judge the section text first. Song context may resolve references but must not override the local wording. Do not choose a label to balance the dataset.

Song: {row['title']} — {row['artist']}
Context theme: {row.get('theme', '')}
Emotional arc: {row.get('emotional_arc', '')}
Section: {row['lyrics']}
Previous development label: {row['emotion']} (weak evidence only)

Return JSON only:
{{"label":"joy|sadness|anger|calmness","confidence":1,"mixed":false,"alternative_label":"","rationale":"Briefly cite the textual evidence and explain arousal."}}
Confidence must be an integer from 1 to 5."""


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default="Qwen/Qwen2.5-3B-Instruct")
    parser.add_argument("--revision", required=True)
    parser.add_argument("--batch-size", type=int, default=2)
    args = parser.parse_args()

    frame = pd.read_csv(args.input)
    existing: dict[str, dict[str, object]] = {}
    if args.output.exists():
        prior = pd.read_csv(args.output)
        existing = {str(row["case_id"]): row.to_dict() for _, row in prior.iterrows()}

    tokenizer = AutoTokenizer.from_pretrained(args.model, revision=args.revision)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    model = AutoModelForCausalLM.from_pretrained(
        args.model,
        revision=args.revision,
        dtype=torch.float16 if torch.cuda.is_available() else torch.float32,
        low_cpu_mem_usage=True,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device).eval()
    rows = list(existing.values())
    pending = frame.loc[~frame["case_id"].astype(str).isin(existing)].copy()

    args.output.parent.mkdir(parents=True, exist_ok=True)
    for start in range(0, len(pending), args.batch_size):
        batch = pending.iloc[start : start + args.batch_size]
        rendered = [
            tokenizer.apply_chat_template(
                [
                    {"role": "system", "content": "You are a rigorous Cantonese lyric emotion annotator. Output valid JSON only."},
                    {"role": "user", "content": prompt(row)},
                ],
                tokenize=False,
                add_generation_prompt=True,
            )
            for _, row in batch.iterrows()
        ]
        inputs = tokenizer(rendered, return_tensors="pt", padding=True, truncation=True, max_length=1536).to(device)
        with torch.inference_mode():
            outputs = model.generate(
                **inputs,
                max_new_tokens=150,
                do_sample=False,
                repetition_penalty=1.05,
                pad_token_id=tokenizer.pad_token_id,
                eos_token_id=tokenizer.eos_token_id,
            )
        prompt_length = inputs["input_ids"].shape[1]
        decoded = [
            tokenizer.decode(value[prompt_length:], skip_special_tokens=True).strip()
            for value in outputs
        ]
        for (_, source), raw in zip(batch.iterrows(), decoded):
            parsed = parse_json(raw)
            label = str(parsed.get("label", "")).strip().lower()
            alternative = str(parsed.get("alternative_label", "")).strip().lower()
            try:
                confidence = max(1, min(5, int(parsed.get("confidence", 1))))
            except (TypeError, ValueError):
                confidence = 1
            rows.append(
                {
                    "case_id": source["case_id"],
                    "v2_model_label": label if label in LABELS else "",
                    "v2_model_confidence": confidence,
                    "v2_model_mixed": bool(parsed.get("mixed", False)),
                    "v2_model_alternative_label": alternative if alternative in LABELS else "",
                    "v2_model_rationale": str(parsed.get("rationale", raw))[:500],
                    "v2_model_parse_ok": label in LABELS,
                    "v2_model_name": args.model,
                    "v2_model_revision": args.revision,
                    "v2_model_reviewed_at_utc": datetime.now(timezone.utc).isoformat(),
                }
            )
        pd.DataFrame(rows).sort_values("case_id").to_csv(args.output, index=False, encoding="utf-8-sig")
        print(f"reviewed={len(rows)}/{len(frame)}", flush=True)


if __name__ == "__main__":
    main()
