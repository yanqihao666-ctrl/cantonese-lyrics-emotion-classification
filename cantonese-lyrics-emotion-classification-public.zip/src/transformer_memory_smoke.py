"""Run a full-length Transformer forward/backward pass on the real GPU."""

from __future__ import annotations

import argparse
import json
import platform
import time
from pathlib import Path

import torch
import transformers
from transformers import AutoModelForSequenceClassification


def validate_dimensions(batch_size: int, sequence_length: int, num_labels: int) -> None:
    if min(batch_size, sequence_length, num_labels) < 1:
        raise ValueError("Batch size, sequence length and label count must be positive")


def run_memory_smoke(
    model_name: str,
    model_revision: str | None,
    batch_size: int = 4,
    sequence_length: int = 512,
    num_labels: int = 4,
) -> dict[str, object]:
    """Measure whether the declared full-length training shape fits in GPU memory."""

    validate_dimensions(batch_size, sequence_length, num_labels)
    if not torch.cuda.is_available():
        raise RuntimeError("CUDA is required for the Transformer memory smoke test")
    torch.manual_seed(42)
    torch.cuda.manual_seed_all(42)
    torch.cuda.set_device(0)
    device = torch.device("cuda:0")
    model = AutoModelForSequenceClassification.from_pretrained(
        model_name,
        revision=model_revision,
        num_labels=num_labels,
    ).to(device)
    model.train()
    total_parameters = sum(parameter.numel() for parameter in model.parameters())
    trainable_parameters = sum(
        parameter.numel() for parameter in model.parameters() if parameter.requires_grad
    )
    torch.cuda.reset_peak_memory_stats()
    vocabulary_size = int(model.config.vocab_size)
    input_ids = torch.randint(
        low=0,
        high=vocabulary_size,
        size=(batch_size, sequence_length),
        device=device,
    )
    attention_mask = torch.ones_like(input_ids)
    labels = torch.arange(batch_size, device=device) % num_labels

    torch.cuda.synchronize()
    started = time.perf_counter()
    with torch.autocast(device_type="cuda", dtype=torch.float16):
        output = model(
            input_ids=input_ids,
            attention_mask=attention_mask,
            labels=labels,
        )
        loss = output.loss
    loss.backward()
    torch.cuda.synchronize()
    elapsed = time.perf_counter() - started
    result: dict[str, object] = {
        "model": model_name,
        "model_revision": model_revision,
        "batch_size": batch_size,
        "sequence_length": sequence_length,
        "num_labels": num_labels,
        "total_parameters": total_parameters,
        "trainable_parameters": trainable_parameters,
        "mixed_precision": "float16",
        "loss": float(loss.detach().cpu()),
        "loss_finite": bool(torch.isfinite(loss).item()),
        "forward_backward_seconds": elapsed,
        "peak_allocated_memory_bytes": int(torch.cuda.max_memory_allocated()),
        "peak_reserved_memory_bytes": int(torch.cuda.max_memory_reserved()),
        "device": torch.cuda.get_device_name(0),
        "torch": torch.__version__,
        "torch_cuda_runtime": torch.version.cuda,
        "transformers": transformers.__version__,
        "python": platform.python_version(),
    }
    if not result["loss_finite"]:
        raise RuntimeError("Full-length Transformer smoke loss is not finite")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--model", required=True)
    parser.add_argument("--model-revision")
    parser.add_argument("--batch-size", type=int, default=4)
    parser.add_argument("--sequence-length", type=int, default=512)
    parser.add_argument("--num-labels", type=int, default=4)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/environment/transformer_memory_smoke.json"),
    )
    args = parser.parse_args()
    result = run_memory_smoke(
        model_name=args.model,
        model_revision=args.model_revision,
        batch_size=args.batch_size,
        sequence_length=args.sequence_length,
        num_labels=args.num_labels,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
