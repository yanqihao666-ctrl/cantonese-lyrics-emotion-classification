"""Validate independent annotations and calculate inter-annotator agreement."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.metrics import cohen_kappa_score, confusion_matrix

from src.tabular_io import read_annotation_file


LABELS = ["joy", "sadness", "anger", "calmness"]
FLAG_COLUMNS = ["mixed", "uncertain", "non_cantonese", "insufficient_text", "translation_required"]
ADJUDICATION_DECISION_COLUMNS = [
    "adjudicated_label",
    "include_in_gold",
    "exclusion_reason",
    "adjudicator_rationale",
    "adjudicator_code",
    "adjudication_date",
]


def _normalise_boolean(series: pd.Series) -> pd.Series:
    mapping = {
        "true": True,
        "false": False,
        "1": True,
        "0": False,
        "yes": True,
        "no": False,
        "y": True,
        "n": False,
        "": False,
    }
    converted = series.fillna("").astype(str).str.strip().str.lower().map(mapping)
    if converted.isna().any():
        invalid = sorted(series[converted.isna()].astype(str).unique())
        raise ValueError(f"Invalid boolean values: {invalid}")
    return converted.astype(bool)


def validate_annotations(frame: pd.DataFrame, name: str) -> pd.DataFrame:
    required = {"annotation_id", "human_label", "confidence_1_to_5", *FLAG_COLUMNS}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"{name}: missing columns {missing}")
    if frame["annotation_id"].isna().any() or frame["annotation_id"].duplicated().any():
        raise ValueError(f"{name}: annotation_id must be present and unique")

    clean = frame.copy()
    clean["human_label"] = clean["human_label"].astype(str).str.strip().str.lower()
    invalid_labels = sorted(set(clean["human_label"]).difference(LABELS))
    if invalid_labels:
        raise ValueError(f"{name}: invalid or blank human labels {invalid_labels}")
    clean["confidence_1_to_5"] = pd.to_numeric(clean["confidence_1_to_5"], errors="coerce")
    if (
        clean["confidence_1_to_5"].isna().any()
        or not clean["confidence_1_to_5"].between(1, 5).all()
        or not clean["confidence_1_to_5"].mod(1).eq(0).all()
    ):
        raise ValueError(f"{name}: confidence must be an integer from 1 to 5")
    for column in FLAG_COLUMNS:
        clean[column] = _normalise_boolean(clean[column])
    return clean


def calculate_agreement(
    annotator_a: pd.DataFrame, annotator_b: pd.DataFrame
) -> tuple[dict[str, object], pd.DataFrame, pd.DataFrame]:
    a = validate_annotations(annotator_a, "annotator_a")
    b = validate_annotations(annotator_b, "annotator_b")
    if set(a["annotation_id"]) != set(b["annotation_id"]):
        missing_a = sorted(set(b["annotation_id"]) - set(a["annotation_id"]))
        missing_b = sorted(set(a["annotation_id"]) - set(b["annotation_id"]))
        raise ValueError(f"Annotation IDs differ; missing from A={missing_a}, missing from B={missing_b}")

    keep_a = ["annotation_id", "human_label", "confidence_1_to_5", *FLAG_COLUMNS, "rationale"]
    keep_b = ["annotation_id", "human_label", "confidence_1_to_5", *FLAG_COLUMNS, "rationale"]
    merged = a[[column for column in keep_a if column in a.columns]].merge(
        b[[column for column in keep_b if column in b.columns]],
        on="annotation_id",
        suffixes=("_a", "_b"),
        validate="one_to_one",
    )
    merged["label_agreement"] = merged["human_label_a"] == merged["human_label_b"]
    merged["requires_adjudication"] = ~merged["label_agreement"]
    low_confidence = (
        merged["confidence_1_to_5_a"].le(2)
        | merged["confidence_1_to_5_b"].le(2)
    )
    merged["requires_adjudication"] |= low_confidence
    for column in FLAG_COLUMNS:
        merged["requires_adjudication"] |= merged[f"{column}_a"] | merged[f"{column}_b"]
    reasons: list[str] = []
    for row in merged.itertuples(index=False):
        row_reasons: list[str] = []
        if not row.label_agreement:
            row_reasons.append("label_disagreement")
        if row.confidence_1_to_5_a <= 2 or row.confidence_1_to_5_b <= 2:
            row_reasons.append("low_confidence")
        for column in FLAG_COLUMNS:
            if getattr(row, f"{column}_a") or getattr(row, f"{column}_b"):
                row_reasons.append(f"flag:{column}")
        reasons.append(";".join(row_reasons))
    merged["adjudication_reasons"] = reasons

    confusion = pd.DataFrame(
        confusion_matrix(merged["human_label_a"], merged["human_label_b"], labels=LABELS),
        index=[f"a_{label}" for label in LABELS],
        columns=[f"b_{label}" for label in LABELS],
    )
    summary: dict[str, object] = {
        "items": int(len(merged)),
        "raw_label_agreement": float(merged["label_agreement"].mean()),
        "cohen_kappa": float(cohen_kappa_score(merged["human_label_a"], merged["human_label_b"], labels=LABELS)),
        "adjudication_items": int(merged["requires_adjudication"].sum()),
        "low_confidence_items": int(low_confidence.sum()),
        "flagged_items": int(
            merged[
                [
                    f"{column}_{annotator}"
                    for column in FLAG_COLUMNS
                    for annotator in ["a", "b"]
                ]
            ]
            .any(axis=1)
            .sum()
        ),
        "mean_confidence_a": float(merged["confidence_1_to_5_a"].mean()),
        "mean_confidence_b": float(merged["confidence_1_to_5_b"].mean()),
        "label_distribution_a": merged["human_label_a"].value_counts().reindex(LABELS, fill_value=0).to_dict(),
        "label_distribution_b": merged["human_label_b"].value_counts().reindex(LABELS, fill_value=0).to_dict(),
    }

    adjudication = merged.loc[merged["requires_adjudication"]].copy()
    for column in ADJUDICATION_DECISION_COLUMNS:
        adjudication[column] = ""
    return summary, confusion, adjudication


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("annotator_a", type=Path)
    parser.add_argument("annotator_b", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/annotation_agreement"))
    args = parser.parse_args()
    summary, confusion, adjudication = calculate_agreement(
        read_annotation_file(args.annotator_a),
        read_annotation_file(args.annotator_b),
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "agreement_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    confusion.to_csv(args.output_dir / "label_confusion.csv", encoding="utf-8-sig")
    adjudication.to_csv(args.output_dir / "adjudication_required.csv", index=False, encoding="utf-8-sig")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
