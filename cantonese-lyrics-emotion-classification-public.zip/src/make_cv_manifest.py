"""Build repeated, artist-exclusive train/validation/test evaluation manifests."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from sklearn.model_selection import StratifiedGroupKFold


DEFAULT_SEEDS = [13, 42, 97]
SPLIT_ORDER = ["train", "validation", "test"]


def _validate_input(
    frame: pd.DataFrame,
    id_column: str,
    label_column: str,
    group_column: str,
    outer_folds: int,
) -> pd.DataFrame:
    required = {id_column, label_column, group_column}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if outer_folds < 3:
        raise ValueError("outer_folds must be at least three")
    if frame[list(required)].isna().any().any():
        raise ValueError("IDs, labels and groups cannot be missing")
    if frame[id_column].duplicated().any():
        raise ValueError(f"{id_column} must be unique")

    clean = frame.copy()
    if "corpus_song_id" in clean.columns:
        parent_group_counts = clean.groupby("corpus_song_id")[group_column].nunique()
        if parent_group_counts.gt(1).any():
            raise ValueError("Each parent song must map to exactly one artist group")
    clean[label_column] = clean[label_column].astype(str).str.strip().str.lower()
    labels = sorted(clean[label_column].unique())
    if len(labels) < 2:
        raise ValueError("At least two labels are required")
    groups_per_label = (
        clean[[label_column, group_column]]
        .drop_duplicates()
        .groupby(label_column)[group_column]
        .nunique()
    )
    insufficient = groups_per_label[groups_per_label < outer_folds]
    if not insufficient.empty:
        details = ", ".join(f"{label}={count}" for label, count in insufficient.items())
        raise ValueError(
            "Every label needs at least outer_folds distinct groups for "
            f"artist-exclusive evaluation; insufficient: {details}"
        )
    return clean


def _partition_diagnostics(
    frame: pd.DataFrame,
    roles: pd.Series,
    label_column: str,
    group_column: str,
) -> dict[str, object]:
    labels = sorted(frame[label_column].unique())
    role_frame = frame.assign(_split=roles)
    group_overlap = role_frame.groupby(group_column)["_split"].nunique().gt(1).any()
    parent_song_overlap = (
        role_frame.groupby("corpus_song_id")["_split"].nunique().gt(1).any()
        if "corpus_song_id" in role_frame.columns
        else False
    )
    return {
        "rows_per_split": roles.value_counts().reindex(SPLIT_ORDER, fill_value=0).to_dict(),
        "groups_per_split": (
            role_frame.groupby("_split")[group_column]
            .nunique()
            .reindex(SPLIT_ORDER, fill_value=0)
            .to_dict()
        ),
        "class_counts": (
            pd.crosstab(roles, frame[label_column])
            .reindex(index=SPLIT_ORDER, columns=labels, fill_value=0)
            .to_dict(orient="index")
        ),
        "group_overlap": bool(group_overlap),
        "parent_song_overlap": bool(parent_song_overlap),
        "source_songs_per_split": (
            role_frame.groupby("_split")["corpus_song_id"]
            .nunique()
            .reindex(SPLIT_ORDER, fill_value=0)
            .to_dict()
            if "corpus_song_id" in role_frame.columns
            else None
        ),
    }


def _select_validation_indices(
    development: pd.DataFrame,
    label_column: str,
    group_column: str,
    inner_folds: int,
    seed: int,
) -> list[int]:
    labels = sorted(development[label_column].unique())
    minimum_class = int(development[label_column].value_counts().min())
    n_splits = min(inner_folds, minimum_class, development[group_column].nunique())
    if n_splits < 2:
        raise ValueError("Development partition is too small for a validation split")

    splitter = StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed)
    target_size = len(development) / n_splits
    target_proportions = development[label_column].value_counts(normalize=True).reindex(labels)
    candidates: list[tuple[float, list[int]]] = []
    for train_positions, validation_positions in splitter.split(
        development,
        development[label_column],
        development[group_column],
    ):
        train_labels = set(development.iloc[train_positions][label_column])
        validation = development.iloc[validation_positions]
        validation_labels = set(validation[label_column])
        if train_labels != set(labels) or validation_labels != set(labels):
            continue
        size_error = abs(len(validation) - target_size) / max(target_size, 1.0)
        proportions = validation[label_column].value_counts(normalize=True).reindex(labels, fill_value=0)
        class_error = float((proportions - target_proportions).abs().mean())
        candidates.append((size_error + 2.0 * class_error, validation.index.tolist()))

    if not candidates:
        raise ValueError(
            "Could not create a validation partition containing every label; "
            "increase the corpus or reduce the number of folds"
        )
    candidates.sort(key=lambda item: item[0])
    return candidates[0][1]


def create_repeated_group_manifest(
    frame: pd.DataFrame,
    id_column: str = "corpus_song_id",
    label_column: str = "emotion",
    group_column: str = "artist",
    seeds: list[int] | None = None,
    outer_folds: int = 5,
    inner_folds: int = 5,
) -> tuple[pd.DataFrame, dict[str, object]]:
    """Create long-form split assignments shared by all model families.

    For every repeat and outer fold, the outer test groups are fixed first.
    A validation fold is then selected only from the remaining development
    groups. Consequently, an artist cannot occur in more than one role.
    """

    clean = _validate_input(frame, id_column, label_column, group_column, outer_folds)
    seeds = seeds or DEFAULT_SEEDS
    labels = sorted(clean[label_column].unique())
    manifest_parts: list[pd.DataFrame] = []
    partition_reports: list[dict[str, object]] = []

    for repeat_index, seed in enumerate(seeds, start=1):
        outer_splitter = StratifiedGroupKFold(
            n_splits=outer_folds,
            shuffle=True,
            random_state=seed,
        )
        outer_splits = list(
            outer_splitter.split(clean, clean[label_column], clean[group_column])
        )
        for outer_fold, (development_positions, test_positions) in enumerate(
            outer_splits,
            start=1,
        ):
            development = clean.iloc[development_positions]
            test_indices = clean.iloc[test_positions].index.tolist()
            validation_indices = _select_validation_indices(
                development,
                label_column=label_column,
                group_column=group_column,
                inner_folds=inner_folds,
                seed=seed + outer_fold * 1_003,
            )

            roles = pd.Series("train", index=clean.index, dtype="object")
            roles.loc[validation_indices] = "validation"
            roles.loc[test_indices] = "test"
            report = _partition_diagnostics(clean, roles, label_column, group_column)
            if report["group_overlap"] or report["parent_song_overlap"]:
                raise AssertionError("Group leakage detected while constructing manifest")
            if any(
                report["class_counts"][split_name][label] == 0
                for split_name in SPLIT_ORDER
                for label in labels
            ):
                raise ValueError("A generated train/validation/test partition is missing a label")

            part = pd.DataFrame(
                {
                    id_column: clean[id_column],
                    "repeat": repeat_index,
                    "seed": seed,
                    "outer_fold": outer_fold,
                    "split": roles,
                }
            )
            manifest_parts.append(part)
            partition_reports.append(
                {
                    "repeat": repeat_index,
                    "seed": seed,
                    "outer_fold": outer_fold,
                    **report,
                }
            )

    manifest = pd.concat(manifest_parts, ignore_index=True)
    diagnostics: dict[str, object] = {
        "observations": len(clean),
        "labels": labels,
        "groups": int(clean[group_column].nunique()),
        "id_column": id_column,
        "label_column": label_column,
        "group_column": group_column,
        "seeds": seeds,
        "outer_folds": outer_folds,
        "inner_folds": inner_folds,
        "partitions": partition_reports,
    }
    return manifest, diagnostics


def materialise_partition(
    frame: pd.DataFrame,
    manifest: pd.DataFrame,
    seed: int,
    outer_fold: int,
    id_column: str = "corpus_song_id",
) -> pd.DataFrame:
    """Attach one manifest partition to a labelled dataset."""

    required = {id_column, "seed", "outer_fold", "split"}
    missing = sorted(required.difference(manifest.columns))
    if missing:
        raise ValueError(f"Manifest is missing columns: {missing}")
    selected = manifest.loc[
        (manifest["seed"] == seed) & (manifest["outer_fold"] == outer_fold),
        [id_column, "split"],
    ]
    if selected.empty:
        raise ValueError(f"No manifest partition for seed={seed}, outer_fold={outer_fold}")
    if selected[id_column].duplicated().any():
        raise ValueError("Selected manifest partition contains duplicate IDs")
    merged = frame.merge(selected, on=id_column, how="left", validate="one_to_one")
    if merged["split"].isna().any():
        raise ValueError("Manifest does not cover every input observation")
    merged["partition_seed"] = seed
    merged["outer_fold"] = outer_fold
    return merged


def write_materialised_partitions(
    frame: pd.DataFrame,
    manifest: pd.DataFrame,
    output_dir: Path,
    id_column: str = "corpus_song_id",
) -> list[Path]:
    """Write one labelled input file per shared evaluation partition."""

    output_dir.mkdir(parents=True, exist_ok=True)
    paths: list[Path] = []
    partitions = (
        manifest[["seed", "outer_fold"]]
        .drop_duplicates()
        .sort_values(["seed", "outer_fold"])
        .itertuples(index=False)
    )
    for partition in partitions:
        materialised = materialise_partition(
            frame,
            manifest,
            seed=int(partition.seed),
            outer_fold=int(partition.outer_fold),
            id_column=id_column,
        )
        path = output_dir / f"seed_{partition.seed}_fold_{partition.outer_fold}.csv"
        materialised.to_csv(path, index=False, encoding="utf-8-sig")
        paths.append(path)
    return paths


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--id-column", default="case_id")
    parser.add_argument("--label-column", default="emotion")
    parser.add_argument("--group-column", default="artist")
    parser.add_argument("--seeds", nargs="+", type=int, default=DEFAULT_SEEDS)
    parser.add_argument("--outer-folds", type=int, default=5)
    parser.add_argument("--inner-folds", type=int, default=5)
    parser.add_argument(
        "--materialised-dir",
        type=Path,
        help="Optionally write one full labelled CSV per seed/fold partition",
    )
    args = parser.parse_args()

    frame = pd.read_csv(args.input)
    manifest, diagnostics = create_repeated_group_manifest(
        frame,
        id_column=args.id_column,
        label_column=args.label_column,
        group_column=args.group_column,
        seeds=args.seeds,
        outer_folds=args.outer_folds,
        inner_folds=args.inner_folds,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    manifest.to_csv(args.output, index=False, encoding="utf-8-sig")
    args.output.with_suffix(".diagnostics.json").write_text(
        json.dumps(diagnostics, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    if args.materialised_dir:
        written = write_materialised_partitions(
            frame,
            manifest,
            args.materialised_dir,
            id_column=args.id_column,
        )
        print(f"Wrote {len(written)} shared model-input partitions to {args.materialised_dir}")
    print(json.dumps({key: value for key, value in diagnostics.items() if key != "partitions"}, indent=2))


if __name__ == "__main__":
    main()
