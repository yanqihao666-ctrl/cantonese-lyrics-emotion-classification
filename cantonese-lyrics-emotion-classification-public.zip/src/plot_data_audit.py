"""Create publication-ready figures from the safe corpus-audit table."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import pandas as pd


BLUE = "#1F4E79"
ORANGE = "#E07A2D"
GRID = "#D9E2F3"


def _style_axis(axis) -> None:
    axis.spines["top"].set_visible(False)
    axis.spines["right"].set_visible(False)
    axis.grid(axis="y", color=GRID, linewidth=0.8, alpha=0.8)
    axis.set_axisbelow(True)


def create_audit_figures(frame: pd.DataFrame, output_dir: Path) -> list[Path]:
    required = {"release_year", "artist", "observed_character_count"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing audit columns: {missing}")
    output_dir.mkdir(parents=True, exist_ok=True)
    plt.rcParams.update(
        {
            "font.family": ["Microsoft YaHei", "DejaVu Sans"],
            "font.size": 10,
            "axes.titlesize": 13,
            "axes.labelsize": 11,
            "figure.facecolor": "white",
            "axes.facecolor": "white",
        }
    )
    outputs: list[Path] = []

    source_songs = (
        frame.drop_duplicates("corpus_song_id")
        if "corpus_song_id" in frame.columns
        else frame
    )
    yearly = source_songs["release_year"].value_counts().sort_index()
    fig, axis = plt.subplots(figsize=(8.2, 4.4))
    axis.bar(yearly.index.astype(str), yearly.values, color=BLUE, width=0.72)
    axis.set_title("Pilot corpus coverage by release year", loc="left", fontweight="bold")
    axis.set_xlabel("Release year")
    axis.set_ylabel("Number of songs")
    axis.tick_params(axis="x", rotation=55)
    axis.text(
        0,
        -0.31,
        f"n = {len(source_songs)} source songs; source: Cantopop Corpus Project (CC BY 4.0)",
        transform=axis.transAxes,
        color="#666666",
        fontsize=8.5,
    )
    _style_axis(axis)
    fig.tight_layout()
    path = output_dir / "year_coverage.png"
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    outputs.append(path)

    artists = source_songs["artist"].value_counts().head(10).sort_values()
    fig, axis = plt.subplots(figsize=(8.2, 4.8))
    axis.barh(artists.index, artists.values, color=ORANGE)
    axis.set_title("Most represented artists by source songs", loc="left", fontweight="bold")
    axis.set_xlabel("Number of source songs")
    axis.set_ylabel("")
    for index, value in enumerate(artists.values):
        axis.text(value + 0.12, index, str(value), va="center", fontsize=9)
    axis.text(
        0,
        -0.17,
        "Artist concentration motivates group-exclusive splitting and overlap reporting.",
        transform=axis.transAxes,
        color="#666666",
        fontsize=8.5,
    )
    _style_axis(axis)
    fig.tight_layout()
    path = output_dir / "artist_concentration.png"
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    outputs.append(path)

    fig, axis = plt.subplots(figsize=(8.2, 4.4))
    axis.hist(frame["observed_character_count"], bins=12, color=BLUE, edgecolor="white")
    median = float(frame["observed_character_count"].median())
    axis.axvline(median, color=ORANGE, linestyle="--", linewidth=2, label=f"Median = {median:.0f}")
    axis.set_title("Distribution of lyric-section length", loc="left", fontweight="bold")
    axis.set_xlabel("Normalised Chinese-character count per lyric section")
    axis.set_ylabel("Number of sections")
    axis.legend(frameon=False)
    _style_axis(axis)
    fig.tight_layout()
    path = output_dir / "lyric_length_distribution.png"
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    outputs.append(path)
    return outputs


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/data_audit/figures"))
    args = parser.parse_args()
    outputs = create_audit_figures(pd.read_csv(args.input), args.output_dir)
    for output in outputs:
        print(output)


if __name__ == "__main__":
    main()
