"""Create a model-ready development dataset from disclosed AI pre-annotations."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


LABELS = {"joy", "sadness", "anger", "calmness"}


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def build_development_frame(frame: pd.DataFrame) -> pd.DataFrame:
    required = {
        "case_id",
        "corpus_song_id",
        "lyrics",
        "artist",
        "ai_label",
        "formal_evaluation_eligible",
    }
    missing = required - set(frame.columns)
    if missing:
        raise ValueError(f"Missing required columns: {sorted(missing)}")
    if frame["case_id"].duplicated().any():
        raise ValueError("case_id must be unique")
    labels = set(frame["ai_label"].dropna().astype(str).str.strip().str.lower())
    if labels != LABELS or frame["ai_label"].isna().any():
        raise ValueError(f"Expected all four non-null labels, found {sorted(labels)}")
    if frame["formal_evaluation_eligible"].astype(bool).any():
        raise ValueError("AI pre-annotations must not be marked formal-evaluation eligible")

    result = frame.copy()
    result["emotion"] = result["ai_label"].astype(str).str.strip().str.lower()
    result["development_label_source"] = "research_assisted_ai_preannotation"
    result["development_only"] = True
    result["formal_evaluation_eligible"] = False
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()

    source = pd.read_csv(args.input)
    if len(source) != 680:
        raise ValueError(f"Expected 680 section rows, found {len(source)}")
    result = build_development_frame(source)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False, encoding="utf-8-sig")

    group_summary = (
        result.groupby("emotion")
        .agg(
            rows=("case_id", "size"),
            songs=("corpus_song_id", "nunique"),
            artists=("artist", "nunique"),
        )
        .to_dict(orient="index")
    )
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(result),
        "songs": int(result["corpus_song_id"].nunique()),
        "artists": int(result["artist"].nunique()),
        "class_group_summary": group_summary,
        "input_sha256": file_sha256(args.input),
        "output_sha256": file_sha256(args.output),
        "formal_evaluation_eligible": False,
        "warning": (
            "AI pre-annotation development dataset only. Metrics produced from "
            "this target are pipeline-development evidence, not dissertation "
            "test results against human gold."
        ),
    }
    args.output.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
