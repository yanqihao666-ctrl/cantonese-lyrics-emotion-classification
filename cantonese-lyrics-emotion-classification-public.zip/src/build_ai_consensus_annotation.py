"""Combine three disclosed AI judgements into an auditable pre-annotation.

No single system is treated as authoritative. A label receives higher
confidence only when independent prompting/model views agree.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


LABELS = ["joy", "sadness", "anger", "calmness"]


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _valid_label(value: object) -> str | None:
    text = str(value or "").strip().lower()
    return text if text in LABELS else None


def consensus_decision(row: pd.Series) -> dict[str, object]:
    systems = {
        "nli": _valid_label(row.get("nli_candidate_label")),
        "qwen_direct": _valid_label(row.get("direct_label")),
        "qwen_strict": _valid_label(row.get("adjudicated_label")),
    }
    valid = [label for label in systems.values() if label is not None]
    counts = Counter(valid)
    top_label, top_votes = counts.most_common(1)[0]
    tied_top = sum(count == top_votes for count in counts.values()) > 1

    if top_votes >= 2 and not tied_top:
        label = top_label
        method = "three_way_unanimous" if top_votes == 3 else "two_of_three_majority"
    else:
        nli_label = systems["nli"]
        if nli_label is not None:
            label = nli_label
            method = "no_majority_nli_tiebreak"
        else:
            score_columns = {label: float(row[f"nli_{label}_score"]) for label in LABELS}
            label = max(score_columns, key=score_columns.get)
            method = "no_majority_nli_score_tiebreak"
        top_votes = 1

    matched_generators = [
        name for name in ["qwen_direct", "qwen_strict"] if systems[name] == label
    ]
    generator_confidences: list[int] = []
    if "qwen_direct" in matched_generators:
        generator_confidences.append(int(row.get("direct_confidence", 2)))
    if "qwen_strict" in matched_generators:
        generator_confidences.append(int(row.get("adjudicated_confidence", 2)))
    min_generator_confidence = min(generator_confidences) if generator_confidences else 2
    any_mixed = bool(row.get("direct_mixed", False)) or bool(
        row.get("adjudicated_mixed", False)
    )
    any_uncertain = bool(row.get("direct_uncertain", False)) or bool(
        row.get("adjudicated_uncertain", False)
    )

    if method == "three_way_unanimous" and min_generator_confidence >= 4:
        confidence = 5 if not any_mixed and not any_uncertain else 4
    elif method == "two_of_three_majority":
        confidence = 4 if min_generator_confidence >= 4 and not any_uncertain else 3
    else:
        confidence = 2

    strict_rationale = str(row.get("adjudicated_rationale") or "").strip()
    direct_rationale = str(row.get("direct_rationale") or "").strip()
    if systems["qwen_strict"] == label and strict_rationale:
        rationale = strict_rationale
    elif systems["qwen_direct"] == label and direct_rationale:
        rationale = direct_rationale
    else:
        rationale = (
            f"三路AI判断未形成多数，暂以NLI候选{label}保留；"
            "该条必须由粤语标注者根据段落文字复核。"
        )

    strong_consensus = method == "three_way_unanimous" and confidence >= 4
    needs_review = (
        not strong_consensus
        or any_mixed
        or any_uncertain
        or bool(row.get("direct_non_cantonese", False))
        or bool(row.get("direct_insufficient_text", False))
        or confidence <= 3
    )
    return {
        "ai_label": label,
        "ai_confidence_1_to_5": confidence,
        "consensus_method": method,
        "consensus_vote_count": top_votes,
        "nli_vote": systems["nli"],
        "qwen_direct_vote": systems["qwen_direct"],
        "qwen_strict_vote": systems["qwen_strict"],
        "mixed": any_mixed,
        "uncertain": any_uncertain or method.startswith("no_majority"),
        "rationale": rationale[:420],
        "needs_human_review": needs_review,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    args = parser.parse_args()

    frame = pd.read_csv(args.input)
    if len(frame) != 680 or frame["case_id"].duplicated().any():
        raise ValueError("Expected exactly 680 unique cases")
    decisions = pd.DataFrame(
        [consensus_decision(row) for _, row in frame.iterrows()],
        index=frame.index,
    )
    columns_to_replace = [column for column in decisions.columns if column in frame.columns]
    result = pd.concat(
        [frame.drop(columns=columns_to_replace), decisions],
        axis=1,
    )
    result["annotator_type"] = "AI three-view research-assisted pre-annotation"
    result["label_status"] = "ai_consensus_development_only"
    result["formal_evaluation_eligible"] = False
    result["consensus_created_at_utc"] = datetime.now(timezone.utc).isoformat()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False, encoding="utf-8-sig")

    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(result),
        "songs": int(result["corpus_song_id"].nunique()),
        "label_counts": result["ai_label"].value_counts().to_dict(),
        "consensus_methods": result["consensus_method"].value_counts().to_dict(),
        "confidence_counts": result["ai_confidence_1_to_5"].value_counts().sort_index().to_dict(),
        "needs_human_review": int(result["needs_human_review"].sum()),
        "input_sha256": _sha256(args.input),
        "output_sha256": _sha256(args.output),
        "formal_evaluation_eligible": False,
        "warning": (
            "AI consensus pre-annotation only. Disagreement is retained as a review "
            "signal; this file is not human gold."
        ),
    }
    args.output.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
