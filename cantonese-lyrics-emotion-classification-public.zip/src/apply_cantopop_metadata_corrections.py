"""Apply the documented Cantopop metadata corrections to derived CSV files."""

from __future__ import annotations

import argparse
from pathlib import Path

import pandas as pd

from src.import_cantopop_lyrics import apply_known_metadata_corrections


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    corrected = apply_known_metadata_corrections(frame)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    corrected.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(
        f"Corrected {int(corrected['metadata_correction_applied'].sum())} rows "
        f"across {corrected.loc[corrected['metadata_correction_applied'], 'corpus_song_id'].nunique()} songs"
    )


if __name__ == "__main__":
    main()
