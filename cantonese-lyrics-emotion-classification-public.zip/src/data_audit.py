"""Generate reproducible quality and leakage audits for the lyric corpus."""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import unicodedata
from collections import Counter
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics.pairwise import cosine_similarity


def normalise_lyrics(text: str) -> str:
    """Normalise text for duplicate detection without changing model input."""
    text = unicodedata.normalize("NFKC", str(text)).lower()
    return re.sub(r"[^\w\u3400-\u9fff]+", "", text)


def cjk_fraction(text: str) -> float:
    chars = [char for char in str(text) if not char.isspace()]
    if not chars:
        return 0.0
    cjk = sum("\u3400" <= char <= "\u9fff" for char in chars)
    return cjk / len(chars)


class UnionFind:
    def __init__(self, size: int) -> None:
        self.parent = list(range(size))

    def find(self, item: int) -> int:
        while self.parent[item] != item:
            self.parent[item] = self.parent[self.parent[item]]
            item = self.parent[item]
        return item

    def union(self, left: int, right: int) -> None:
        left_root, right_root = self.find(left), self.find(right)
        if left_root != right_root:
            self.parent[right_root] = left_root


def audit_corpus(
    frame: pd.DataFrame, near_duplicate_threshold: float = 0.88
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    frame = frame.copy()
    if "case_id" not in frame.columns and "corpus_song_id" in frame.columns:
        frame["case_id"] = frame["corpus_song_id"]
    required = {
        "case_id",
        "corpus_song_id",
        "title",
        "artist",
        "release_year",
        "lyrics",
        "jyutping",
    }
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")

    audited = frame.copy()
    audited["normalised_lyrics"] = audited["lyrics"].map(normalise_lyrics)
    audited["normalised_sha256"] = audited["normalised_lyrics"].map(
        lambda value: hashlib.sha256(value.encode("utf-8")).hexdigest()
    )
    audited["observed_character_count"] = audited["normalised_lyrics"].str.len()
    audited["unique_character_count"] = audited["normalised_lyrics"].map(lambda value: len(set(value)))
    audited["type_token_ratio"] = (
        audited["unique_character_count"] / audited["observed_character_count"].replace(0, np.nan)
    )
    audited["cjk_fraction"] = audited["lyrics"].map(cjk_fraction)
    audited["jyutping_token_count"] = audited["jyutping"].astype(str).str.split().str.len()
    audited["exact_duplicate"] = audited["normalised_sha256"].duplicated(keep=False)

    vectorizer = TfidfVectorizer(analyzer="char", ngram_range=(3, 5), min_df=1, sublinear_tf=True)
    matrix = vectorizer.fit_transform(audited["normalised_lyrics"])
    similarities = cosine_similarity(matrix)

    union_find = UnionFind(len(audited))
    pairs: list[dict[str, object]] = []
    for left in range(len(audited)):
        for right in range(left + 1, len(audited)):
            score = float(similarities[left, right])
            if score >= near_duplicate_threshold:
                union_find.union(left, right)
                pairs.append(
                    {
                        "case_id_a": audited.iloc[left]["case_id"],
                        "song_id_a": audited.iloc[left]["corpus_song_id"],
                        "title_a": audited.iloc[left]["title"],
                        "case_id_b": audited.iloc[right]["case_id"],
                        "song_id_b": audited.iloc[right]["corpus_song_id"],
                        "title_b": audited.iloc[right]["title"],
                        "cosine_similarity": round(score, 6),
                    }
                )

    roots = [union_find.find(index) for index in range(len(audited))]
    root_counts = Counter(roots)
    grouped_roots = {root: f"dup_{number:03d}" for number, root in enumerate(
        sorted(root for root, count in root_counts.items() if count > 1), start=1
    )}
    audited["duplicate_group"] = [grouped_roots.get(root, "") for root in roots]

    artist_counts = audited["artist"].value_counts()
    cross_song_pairs = sum(
        pair["song_id_a"] != pair["song_id_b"] for pair in pairs
    )
    summary: dict[str, object] = {
        "sections": int(len(audited)),
        "source_songs": int(audited["corpus_song_id"].nunique()),
        "artists": int(audited["artist"].nunique()),
        "years_min": int(audited["release_year"].min()),
        "years_max": int(audited["release_year"].max()),
        "missing_lyrics": int(audited["lyrics"].isna().sum()),
        "missing_jyutping": int(audited["jyutping"].isna().sum()),
        "characters_median": float(audited["observed_character_count"].median()),
        "characters_min": int(audited["observed_character_count"].min()),
        "characters_max": int(audited["observed_character_count"].max()),
        "cjk_fraction_median": float(audited["cjk_fraction"].median()),
        "exact_duplicate_rows": int(audited["exact_duplicate"].sum()),
        "near_duplicate_pairs": int(len(pairs)),
        "within_song_near_duplicate_pairs": int(len(pairs) - cross_song_pairs),
        "cross_song_near_duplicate_pairs": int(cross_song_pairs),
        "near_duplicate_threshold": near_duplicate_threshold,
        "largest_artist_count": int(artist_counts.iloc[0]),
        "largest_artist": str(artist_counts.index[0]),
        "top_two_artist_share": float(artist_counts.iloc[:2].sum() / len(audited)),
        "source_licences": sorted(audited.get("source_license", pd.Series(dtype=str)).dropna().unique().tolist()),
    }
    return audited, pd.DataFrame(pairs), summary


def write_markdown(summary: dict[str, object], path: Path) -> None:
    text = f"""# Corpus quality audit

This report is generated from the local corpus and contains derived statistics only.

## Coverage

- Lyric sections: {summary['sections']}
- Source songs: {summary['source_songs']}
- Artists: {summary['artists']}
- Release years: {summary['years_min']}–{summary['years_max']}
- Missing lyric texts: {summary['missing_lyrics']}
- Missing Jyutping transcriptions: {summary['missing_jyutping']}
- Source licence(s): {', '.join(summary['source_licences'])}

## Text characteristics

- Normalised character count: median {summary['characters_median']:.0f}, range {summary['characters_min']}–{summary['characters_max']}
- Median CJK-character fraction: {summary['cjk_fraction_median']:.3f}

## Leakage risks

- Exact duplicate rows: {summary['exact_duplicate_rows']}
- Near-duplicate pairs at cosine similarity ≥ {summary['near_duplicate_threshold']:.2f}: {summary['near_duplicate_pairs']}
- Within-song near-duplicate pairs: {summary['within_song_near_duplicate_pairs']}
- Cross-song near-duplicate pairs: {summary['cross_song_near_duplicate_pairs']}
- Largest artist: {summary['largest_artist']} ({summary['largest_artist_count']} sections)
- Top-two artist share: {summary['top_two_artist_share']:.1%}

## Interpretation

Each section is a modelling case. All sections from the same song must remain in one partition, and partitions must also be checked for artist overlap. Any detected duplicate group must remain inside one partition. These statistics do not assess emotion-label validity; that requires independent annotation.
"""
    path.write_text(text, encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/data_audit"))
    parser.add_argument("--near-duplicate-threshold", type=float, default=0.88)
    args = parser.parse_args()

    frame = pd.read_csv(args.input)
    audited, pairs, summary = audit_corpus(frame, args.near_duplicate_threshold)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    # The tracked audit artifact must not redistribute licensed lyric text or
    # phonetic transcription. Hashes and derived measurements are sufficient
    # to reproduce leakage decisions against a locally acquired corpus.
    audited.drop(
        columns=[
            "normalised_lyrics",
            "lyrics",
            "jyutping",
            "jyutping_search",
            "jyutping_diacritics",
        ],
        errors="ignore",
    ).to_csv(
        args.output_dir / "corpus_audit_rows.csv", index=False, encoding="utf-8-sig"
    )
    pairs.to_csv(args.output_dir / "near_duplicate_pairs.csv", index=False, encoding="utf-8-sig")
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    write_markdown(summary, args.output_dir / "report.md")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
