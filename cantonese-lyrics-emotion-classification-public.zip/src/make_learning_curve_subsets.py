"""Create nested, artist-grouped training subsets for learning curves."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


DEFAULT_FRACTIONS = [0.25, 0.5, 0.75, 1.0]


def _validate(
    frame: pd.DataFrame,
    label_column: str,
    group_column: str,
    split_column: str,
    fractions: list[float],
) -> pd.DataFrame:
    required = {label_column, group_column, split_column}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if set(frame[split_column]) != {"train", "validation", "test"}:
        raise ValueError("Input must contain train, validation and test roles")
    if not fractions or fractions[-1] != 1.0:
        raise ValueError("Fractions must end with 1.0")
    if fractions != sorted(set(fractions)) or fractions[0] <= 0 or fractions[-1] > 1:
        raise ValueError("Fractions must be unique, increasing and within (0, 1]")
    if frame[list(required)].isna().any().any():
        raise ValueError("Labels, groups and split roles cannot be missing")
    overlap = frame.groupby(group_column)[split_column].nunique()
    if overlap.gt(1).any():
        raise ValueError("Group leakage already exists in the input partition")
    labels = set(frame[label_column].unique())
    for role in ["train", "validation", "test"]:
        if set(frame.loc[frame[split_column] == role, label_column]) != labels:
            raise ValueError(f"{role} must contain every label")
    return frame.copy()


def select_nested_training_groups(
    frame: pd.DataFrame,
    fractions: list[float] | None = None,
    label_column: str = "emotion",
    group_column: str = "artist",
    split_column: str = "split",
    seed: int = 42,
    trials: int = 2_000,
) -> tuple[dict[float, list[str]], dict[str, object]]:
    """Choose one group ordering whose prefixes fit every requested fraction."""

    fractions = fractions or DEFAULT_FRACTIONS
    clean = _validate(frame, label_column, group_column, split_column, fractions)
    train = clean.loc[clean[split_column] == "train"].copy()
    labels = sorted(train[label_column].unique())
    groups = sorted(train[group_column].astype(str).unique())
    if len(groups) < len(labels):
        raise ValueError("Too few training groups for class-complete subsets")
    target_proportions = train[label_column].value_counts(normalize=True).reindex(labels)
    rng = np.random.default_rng(seed)
    best_score = float("inf")
    best_selections: dict[float, list[str]] | None = None

    for trial_index in range(max(1, trials)):
        order = groups if trial_index == 0 else list(rng.permutation(groups))
        prefixes: list[tuple[list[str], pd.DataFrame]] = []
        for end in range(1, len(order) + 1):
            selected = order[:end]
            subset = train.loc[train[group_column].astype(str).isin(selected)]
            if set(subset[label_column]) == set(labels):
                prefixes.append((selected.copy(), subset))
        if not prefixes:
            continue

        selections: dict[float, list[str]] = {}
        total_score = 0.0
        previous_count = 0
        valid = True
        for fraction in fractions:
            if fraction == 1.0:
                selected, subset = groups.copy(), train
            else:
                target_rows = len(train) * fraction
                candidates = [
                    (selected, subset)
                    for selected, subset in prefixes
                    if len(selected) >= previous_count
                ]
                if not candidates:
                    valid = False
                    break
                selected, subset = min(
                    candidates,
                    key=lambda item: (
                        abs(len(item[1]) - target_rows),
                        len(item[0]),
                    ),
                )
                size_error = abs(len(subset) - target_rows) / max(target_rows, 1)
                proportions = (
                    subset[label_column]
                    .value_counts(normalize=True)
                    .reindex(labels, fill_value=0)
                )
                class_error = float((proportions - target_proportions).abs().mean())
                total_score += size_error + 2.0 * class_error
            selections[fraction] = sorted(selected)
            previous_count = len(selected)
        if valid and total_score < best_score:
            best_score = total_score
            best_selections = selections

    if best_selections is None:
        raise ValueError("Could not construct class-complete nested training subsets")

    reports: list[dict[str, object]] = []
    for fraction, selected_groups in best_selections.items():
        subset = train.loc[train[group_column].astype(str).isin(selected_groups)]
        reports.append(
            {
                "fraction": fraction,
                "training_rows": len(subset),
                "training_source_songs": int(subset["corpus_song_id"].nunique())
                if "corpus_song_id" in subset.columns
                else None,
                "target_training_rows": len(train) * fraction,
                "training_groups": len(selected_groups),
                "class_counts": subset[label_column]
                .value_counts()
                .reindex(labels, fill_value=0)
                .to_dict(),
                "selected_groups": selected_groups,
            }
        )
    metadata: dict[str, object] = {
        "seed": seed,
        "trials": trials,
        "fractions": fractions,
        "full_training_rows": len(train),
        "full_training_source_songs": int(train["corpus_song_id"].nunique())
        if "corpus_song_id" in train.columns
        else None,
        "full_training_groups": len(groups),
        "selection_score": best_score,
        "subsets": reports,
    }
    return best_selections, metadata


def materialise_learning_curve_subsets(
    frame: pd.DataFrame,
    selections: dict[float, list[str]],
    group_column: str = "artist",
    split_column: str = "split",
) -> dict[float, pd.DataFrame]:
    """Keep validation/test fixed while reducing only the training artists."""

    non_train = frame.loc[frame[split_column] != "train"].copy()
    materialised: dict[float, pd.DataFrame] = {}
    for fraction, selected_groups in selections.items():
        train_subset = frame.loc[
            (frame[split_column] == "train")
            & frame[group_column].astype(str).isin(selected_groups)
        ].copy()
        subset = pd.concat([train_subset, non_train], ignore_index=True)
        subset["learning_curve_fraction"] = fraction
        materialised[fraction] = subset
    return materialised


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--fractions", nargs="+", type=float, default=DEFAULT_FRACTIONS)
    parser.add_argument("--label-column", default="emotion")
    parser.add_argument("--group-column", default="artist")
    parser.add_argument("--split-column", default="split")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--trials", type=int, default=2_000)
    args = parser.parse_args()

    frame = pd.read_csv(args.input)
    selections, metadata = select_nested_training_groups(
        frame,
        fractions=args.fractions,
        label_column=args.label_column,
        group_column=args.group_column,
        split_column=args.split_column,
        seed=args.seed,
        trials=args.trials,
    )
    subsets = materialise_learning_curve_subsets(
        frame,
        selections,
        group_column=args.group_column,
        split_column=args.split_column,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    for fraction, subset in subsets.items():
        percentage = int(round(fraction * 100))
        subset.to_csv(
            args.output_dir / f"train_fraction_{percentage:03d}.csv",
            index=False,
            encoding="utf-8-sig",
        )
    (args.output_dir / "learning_curve_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
