"""Validate the dissertation claim-to-artifact evidence register."""

from __future__ import annotations

import argparse
import csv
import json
from collections import Counter
from pathlib import Path


REQUIRED_COLUMNS = {
    "evidence_id",
    "chapter",
    "claim_or_output",
    "status",
    "authoritative_artifact",
    "entry_condition",
    "allowed_use",
}
ALLOWED_STATUSES = {"verified", "blocked"}


class DissertationEvidenceError(ValueError):
    """Raised when dissertation evidence is missing or unsafe."""


def _artifact_paths(value: str) -> list[str]:
    return [item.strip() for item in value.split(";") if item.strip()]


def audit_dissertation_evidence(
    register_path: Path, project_root: Path
) -> dict[str, object]:
    with register_path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = REQUIRED_COLUMNS.difference(reader.fieldnames or ())
        if missing:
            raise DissertationEvidenceError(
                f"Evidence register is missing columns: {sorted(missing)}"
            )

        rows = list(reader)

    if not rows:
        raise DissertationEvidenceError("Evidence register is empty")

    identifiers: set[str] = set()
    statuses: Counter[str] = Counter()
    chapters: set[str] = set()
    verified_artifacts: list[str] = []
    blocked_artifacts: list[str] = []

    for line_number, row in enumerate(rows, start=2):
        for column in REQUIRED_COLUMNS:
            if not (row.get(column) or "").strip():
                raise DissertationEvidenceError(
                    f"Evidence-register row {line_number} has an empty {column}"
                )

        evidence_id = row["evidence_id"].strip()
        if evidence_id in identifiers:
            raise DissertationEvidenceError(
                f"Duplicate evidence_id: {evidence_id}"
            )
        identifiers.add(evidence_id)

        status = row["status"].strip()
        if status not in ALLOWED_STATUSES:
            raise DissertationEvidenceError(
                f"Evidence {evidence_id} has invalid status {status!r}"
            )
        statuses[status] += 1

        chapter = row["chapter"].strip()
        if chapter not in {str(number) for number in range(1, 7)}:
            raise DissertationEvidenceError(
                f"Evidence {evidence_id} has invalid chapter {chapter!r}"
            )
        chapters.add(chapter)

        paths = _artifact_paths(row["authoritative_artifact"])
        if not paths:
            raise DissertationEvidenceError(
                f"Evidence {evidence_id} has no authoritative artifact"
            )
        for relative_path in paths:
            normalised = relative_path.replace("\\", "/").lower()
            if normalised.startswith("results/smoke/"):
                raise DissertationEvidenceError(
                    f"Evidence {evidence_id} points to prohibited smoke artifact "
                    f"{relative_path}"
                )
            if Path(relative_path).is_absolute():
                raise DissertationEvidenceError(
                    f"Evidence {evidence_id} must use a project-relative artifact path"
                )
            if status == "verified":
                artifact = project_root / relative_path
                if not artifact.exists():
                    raise DissertationEvidenceError(
                        f"Verified evidence {evidence_id} is missing artifact "
                        f"{relative_path}"
                    )
                verified_artifacts.append(relative_path)
            else:
                blocked_artifacts.append(relative_path)

    missing_chapters = {str(number) for number in range(1, 7)}.difference(chapters)
    if missing_chapters:
        raise DissertationEvidenceError(
            f"Evidence register does not cover chapters: {sorted(missing_chapters)}"
        )

    return {
        "status": "pass",
        "register_entries": len(rows),
        "status_counts": dict(sorted(statuses.items())),
        "chapters_covered": sorted(chapters),
        "verified_artifacts": verified_artifacts,
        "blocked_artifacts": blocked_artifacts,
        "smoke_artifacts_authorised": 0,
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--register",
        type=Path,
        default=Path("docs/dissertation_evidence_register.csv"),
    )
    parser.add_argument("--project-root", type=Path, default=Path("."))
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    report = audit_dissertation_evidence(
        args.register, args.project_root.resolve()
    )
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
