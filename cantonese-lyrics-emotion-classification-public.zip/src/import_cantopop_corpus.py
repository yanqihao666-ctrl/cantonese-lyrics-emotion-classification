"""Download the public Cantopop Corpus song-list metadata.

This importer stores bibliographic song metadata only. It does not download,
copy or redistribute copyrighted lyric text.
"""

from __future__ import annotations

import argparse
import json
from datetime import date
from pathlib import Path
from urllib.request import Request, urlopen

import pandas as pd


DEFAULT_ENDPOINT = (
    "https://script.google.com/macros/s/"
    "AKfycbxOja89FodUqmV1yI1SFz18UN2k6BLR4VyzFryZ0vRmh4tuZ9TsdpAcJuYmLi4yXA/exec"
)
SOURCE_PAGE = "https://cantopop.humdrum.org/song-list/"

COLUMN_MAP = {
    "ID ▼": "corpus_song_id",
    "Song Title ▼": "title",
    "Year ▼": "release_year",
    "Singer ▼": "artist",
    "Composer ▼": "composer",
    "Lyricist ▼": "lyricist",
    "Arranger ▼": "arranger",
    "Producer ▼": "producer",
    "VHV": "transcription_url",
}


def fetch_metadata(endpoint: str = DEFAULT_ENDPOINT) -> pd.DataFrame:
    request = Request(endpoint, headers={"User-Agent": "academic-research-importer/0.1"})
    with urlopen(request, timeout=30) as response:  # noqa: S310 - fixed documented endpoint
        records = json.loads(response.read())
    frame = pd.DataFrame(records).rename(columns=COLUMN_MAP)
    expected = set(COLUMN_MAP.values())
    missing = expected.difference(frame.columns)
    if missing:
        raise ValueError(f"Source schema changed; missing columns: {sorted(missing)}")
    frame = frame[list(COLUMN_MAP.values())].copy()
    frame["source_page"] = SOURCE_PAGE
    frame["access_date"] = date.today().isoformat()
    frame["emotion_label"] = pd.NA
    frame["label_status"] = "unlabelled"
    return frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    frame = fetch_metadata()
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"Saved {len(frame)} metadata-only records to {args.output}")


if __name__ == "__main__":
    main()
