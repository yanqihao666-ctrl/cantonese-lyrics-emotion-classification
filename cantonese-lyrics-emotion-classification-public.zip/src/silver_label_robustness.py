"""Robustness analysis for evaluation performed against silver labels.

This module does not turn AI-assisted labels into human gold.  It tests whether
the model-family ordering survives progressively stricter label-evidence
subsets and makes the remaining construct-validity limitation explicit.
"""

from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.metrics import accuracy_score, f1_score, recall_score

from src.statistical_analysis import add_holm_adjustment, validate_predictions


LABELS = ["joy", "sadness", "anger", "calmness"]
MODEL_NAMES = {
    "classical::validation_selected": "Classical ML",
    "transformer::FacebookAI/xlm-roberta-base": "XLM-R",
    "transformer::hfl/chinese-macbert-base": "Chinese MacBERT",
}
EVIDENCE_TIERS = {
    "retained_reviewed_original_v2_label": "original_reviewed",
    "unanimous_three_method_consensus": "unanimous_expansion",
    "two_of_three_method_consensus": "majority_expansion",
    "three_way_tie_generation_adjudication_tiebreak": "tie_break_expansion",
}


def attach_evidence(predictions: pd.DataFrame, dataset: pd.DataFrame) -> pd.DataFrame:
    required = {"case_id", "emotion", "source_cohort", "consensus_method"}
    missing = required.difference(dataset.columns)
    if missing:
        raise ValueError(f"Dataset lacks evidence columns: {sorted(missing)}")
    evidence = dataset[list(required)].copy()
    if evidence["case_id"].duplicated().any():
        raise ValueError("Dataset case_id must be unique")
    evidence["evidence_tier"] = evidence["consensus_method"].map(EVIDENCE_TIERS)
    if evidence["evidence_tier"].isna().any():
        unknown = sorted(evidence.loc[evidence["evidence_tier"].isna(), "consensus_method"].unique())
        raise ValueError(f"Unknown consensus methods: {unknown}")
    result = validate_predictions(predictions).merge(
        evidence,
        on="case_id",
        how="left",
        validate="many_to_one",
    )
    if result["evidence_tier"].isna().any():
        raise ValueError("Predictions contain case IDs absent from the dataset")
    if not result["true_label"].eq(result["emotion"]).all():
        raise ValueError("Saved prediction labels do not match the frozen dataset")
    return result


def subset_masks(frame: pd.DataFrame) -> dict[str, pd.Series]:
    tier = frame["evidence_tier"]
    return {
        "all_silver": pd.Series(True, index=frame.index),
        "exclude_tie_breaks": tier.ne("tie_break_expansion"),
        "original_plus_unanimous": tier.isin(["original_reviewed", "unanimous_expansion"]),
        "unanimous_expansion_only": tier.eq("unanimous_expansion"),
        "original_reviewed_only": tier.eq("original_reviewed"),
    }


def _metrics(group: pd.DataFrame) -> dict[str, float | int]:
    truth = group["true_label"]
    predicted = group["predicted_label"]
    return {
        "prediction_rows": int(len(group)),
        "unique_cases": int(group["case_id"].nunique()),
        "macro_f1": float(f1_score(truth, predicted, labels=LABELS, average="macro", zero_division=0)),
        "balanced_accuracy": float(
            recall_score(truth, predicted, labels=LABELS, average="macro", zero_division=0)
        ),
        "accuracy": float(accuracy_score(truth, predicted)),
    }


def partition_metrics(frame: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for subset, mask in subset_masks(frame).items():
        selected = frame.loc[mask]
        for (model, seed, fold), group in selected.groupby(
            ["model_key", "partition_seed", "outer_fold"], sort=True
        ):
            row: dict[str, object] = {
                "subset": subset,
                "model_key": model,
                "model": MODEL_NAMES.get(model, model),
                "partition_seed": int(seed),
                "outer_fold": int(fold),
            }
            row.update(_metrics(group))
            rows.append(row)
    result = pd.DataFrame(rows)
    expected = len(subset_masks(frame)) * frame["model_key"].nunique() * 15
    if len(result) != expected:
        raise ValueError(f"Expected {expected} subset/model/partition rows, found {len(result)}")
    return result


def summarise(metrics: pd.DataFrame) -> pd.DataFrame:
    summary = (
        metrics.groupby(["subset", "model_key", "model"], as_index=False)
        .agg(
            partitions=("macro_f1", "size"),
            unique_cases_min=("unique_cases", "min"),
            unique_cases_max=("unique_cases", "max"),
            macro_f1_mean=("macro_f1", "mean"),
            macro_f1_sd=("macro_f1", "std"),
            balanced_accuracy_mean=("balanced_accuracy", "mean"),
            accuracy_mean=("accuracy", "mean"),
        )
    )
    summary["rank_within_subset"] = summary.groupby("subset")["macro_f1_mean"].rank(
        method="min", ascending=False
    ).astype(int)
    return summary.sort_values(["subset", "rank_within_subset"])


def paired_model_tests(metrics: pd.DataFrame) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for subset, group in metrics.groupby("subset"):
        pivot = group.pivot(
            index=["partition_seed", "outer_fold"], columns="model", values="macro_f1"
        )
        for left, right in combinations(sorted(pivot.columns), 2):
            delta = pivot[right] - pivot[left]
            try:
                p_value = float(wilcoxon(pivot[right], pivot[left]).pvalue)
            except ValueError:
                p_value = 1.0
            rows.append(
                {
                    "subset": subset,
                    "left_model": left,
                    "right_model": right,
                    "mean_delta_right_minus_left": float(delta.mean()),
                    "right_wins": int(delta.gt(0).sum()),
                    "ties": int(delta.eq(0).sum()),
                    "left_wins": int(delta.lt(0).sum()),
                    "p_value_descriptive": p_value,
                }
            )
    output = []
    for _, family in pd.DataFrame(rows).groupby("subset", sort=False):
        adjusted = add_holm_adjustment(
            family, p_column="p_value_descriptive"
        )
        output.append(adjusted)
    return pd.concat(output, ignore_index=True)


def evidence_composition(dataset: pd.DataFrame) -> pd.DataFrame:
    frame = dataset.copy()
    frame["evidence_tier"] = frame["consensus_method"].map(EVIDENCE_TIERS)
    table = (
        frame.groupby(["evidence_tier", "emotion"], as_index=False)
        .agg(sections=("case_id", "size"), songs=("corpus_song_id", "nunique"))
    )
    totals = table.groupby("evidence_tier")["sections"].transform("sum")
    table["within_tier_proportion"] = table["sections"] / totals
    return table.sort_values(["evidence_tier", "emotion"])


def plot_summary(summary: pd.DataFrame, output: Path) -> None:
    subset_order = [
        "all_silver",
        "exclude_tie_breaks",
        "original_plus_unanimous",
        "unanimous_expansion_only",
        "original_reviewed_only",
    ]
    model_order = ["Classical ML", "XLM-R", "Chinese MacBERT"]
    colours = {"Classical ML": "#6C757D", "XLM-R": "#D28E2F", "Chinese MacBERT": "#345995"}
    fig, ax = plt.subplots(figsize=(10.5, 5.4))
    x = np.arange(len(subset_order))
    width = 0.24
    for offset, model in enumerate(model_order):
        part = summary.loc[summary["model"].eq(model)].set_index("subset").reindex(subset_order)
        ax.errorbar(
            x + (offset - 1) * width,
            part["macro_f1_mean"],
            yerr=part["macro_f1_sd"],
            fmt="o",
            capsize=3,
            color=colours[model],
            label=model,
        )
    ax.set_xticks(x, [value.replace("_", "\n") for value in subset_order])
    ax.set_ylabel("Macro-F1 (mean ± SD across 15 partitions)")
    ax.set_ylim(0, 1)
    ax.grid(axis="y", alpha=0.2)
    ax.legend(frameon=False)
    fig.tight_layout()
    fig.savefig(output, dpi=200)
    plt.close(fig)


def write_report(summary: pd.DataFrame, composition: pd.DataFrame, output: Path) -> None:
    ranking = summary.pivot(index="subset", columns="model", values="rank_within_subset")
    macbert_first = bool((ranking["Chinese MacBERT"] == 1).all())
    tie_count = int(
        composition.loc[composition["evidence_tier"].eq("tie_break_expansion"), "sections"].sum()
    )
    report_rows = summary[[
        "subset", "model", "macro_f1_mean", "macro_f1_sd", "rank_within_subset"
    ]]
    markdown_table = [
        "| Subset | Model | Macro-F1 mean | SD | Rank |",
        "|---|---|---:|---:|---:|",
    ]
    markdown_table.extend(
        f"| {row.subset} | {row.model} | {row.macro_f1_mean:.3f} | "
        f"{row.macro_f1_sd:.3f} | {row.rank_within_subset} |"
        for row in report_rows.itertuples(index=False)
    )
    lines = [
        "# Silver-label robustness report",
        "",
        "## Purpose",
        "",
        "This analysis tests whether the comparative result depends on the weakest AI-assisted labels. "
        "It does **not** validate the labels against human judgement and must not be described as human-gold evaluation.",
        "",
        "## Result",
        "",
        f"Chinese MacBERT ranked first in every declared evidence subset: **{str(macbert_first).lower()}**. "
        f"The weakest tier contains {tie_count} three-way-tie sections and is excluded in the first sensitivity check.",
        "",
        *markdown_table,
        "",
        "## Interpretation boundary",
        "",
        "Stable model ordering across these subsets strengthens the internal comparative conclusion. "
        "Higher performance on unanimous labels may partly reflect agreement between related pretrained language models "
        "rather than greater agreement with Cantonese-speaking humans. Therefore the evidence supports a comparison "
        "within this disclosed silver-labelled corpus, not a definitive estimate of real-world emotion accuracy.",
        "",
        "## Reporting rule",
        "",
        "Report the all-silver result as primary, the stricter subsets as sensitivity analyses, and the original-only "
        "subset as a small-cohort diagnostic. Do not select a preferred subset after viewing its test score.",
    ]
    output.write_text("\n".join(lines), encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("dataset", type=Path)
    parser.add_argument("predictions", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    args = parser.parse_args()
    dataset = pd.read_csv(args.dataset, low_memory=False)
    predictions = pd.read_csv(args.predictions, low_memory=False)
    enriched = attach_evidence(predictions, dataset)
    metrics = partition_metrics(enriched)
    summary = summarise(metrics)
    paired = paired_model_tests(metrics)
    composition = evidence_composition(dataset)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    metrics.to_csv(args.output_dir / "evidence_subset_partition_metrics.csv", index=False)
    summary.to_csv(args.output_dir / "evidence_subset_summary.csv", index=False)
    paired.to_csv(args.output_dir / "evidence_subset_paired_tests.csv", index=False)
    composition.to_csv(args.output_dir / "evidence_tier_class_composition.csv", index=False)
    plot_summary(summary, args.output_dir / "evidence_subset_robustness.png")
    write_report(summary, composition, args.output_dir / "SILVER_LABEL_ROBUSTNESS_REPORT.md")
    payload = {
        "dataset_rows": int(dataset["case_id"].nunique()),
        "prediction_rows": int(len(predictions)),
        "subsets": sorted(summary["subset"].unique()),
        "all_models_all_partitions": bool(summary["partitions"].eq(15).all()),
        "human_gold_claimed": False,
    }
    (args.output_dir / "robustness_audit.json").write_text(
        json.dumps(payload, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, indent=2))


if __name__ == "__main__":
    main()
