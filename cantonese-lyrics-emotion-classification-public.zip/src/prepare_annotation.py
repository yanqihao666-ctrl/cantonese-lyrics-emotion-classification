"""Create blinded, independently ordered human-annotation sheets."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path

import pandas as pd


ANNOTATION_COLUMNS = [
    "annotation_id",
    "lyrics",
    "jyutping",
    "human_label",
    "confidence_1_to_5",
    "mixed",
    "uncertain",
    "non_cantonese",
    "insufficient_text",
    "translation_required",
    "rationale",
]


def stable_annotation_id(song_id: str, salt: str) -> str:
    digest = hashlib.sha256(f"{salt}:{song_id}".encode("utf-8")).hexdigest()[:10].upper()
    return f"ANN-{digest}"


def prepare_annotation_files(
    frame: pd.DataFrame,
    output_dir: Path,
    annotators: int = 2,
    seed: int = 42,
    salt: str = "comp5200m-pilot",
) -> None:
    frame = frame.copy()
    if "case_id" not in frame.columns and "corpus_song_id" in frame.columns:
        frame["case_id"] = frame["corpus_song_id"]
    required = {"case_id", "corpus_song_id", "lyrics", "jyutping"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing required columns: {missing}")
    if frame["case_id"].isna().any() or frame["case_id"].duplicated().any():
        raise ValueError("case_id must be present and unique")

    output_dir.mkdir(parents=True, exist_ok=True)
    base = frame[["case_id", "corpus_song_id", "lyrics", "jyutping"]].copy()
    base["annotation_id"] = base["case_id"].map(
        lambda value: stable_annotation_id(str(value), salt)
    )

    optional_key_columns = [
        "section_index",
        "section_type",
        "source_section_types",
        "source_section_indices",
        "occurrence_count",
        "title",
        "artist",
        "release_year",
    ]
    key_columns = [
        "annotation_id",
        "case_id",
        "corpus_song_id",
        *[column for column in optional_key_columns if column in frame.columns],
    ]
    key = base[["annotation_id", "case_id", "corpus_song_id"]].merge(
        frame[["case_id", *[column for column in optional_key_columns if column in frame.columns]]],
        on="case_id",
        how="left",
        validate="one_to_one",
    )
    key[key_columns].to_csv(output_dir / "researcher_key.csv", index=False, encoding="utf-8-sig")

    for annotator in range(1, annotators + 1):
        sheet = base[["annotation_id", "lyrics", "jyutping"]].sample(
            frac=1, random_state=seed + annotator
        ).reset_index(drop=True)
        sheet["human_label"] = ""
        sheet["confidence_1_to_5"] = ""
        for flag in ["mixed", "uncertain", "non_cantonese", "insufficient_text", "translation_required"]:
            sheet[flag] = False
        sheet["rationale"] = ""
        sheet[ANNOTATION_COLUMNS].to_csv(
            output_dir / f"annotator_{annotator}_blind.csv", index=False, encoding="utf-8-sig"
        )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("data/annotation_pilot"))
    parser.add_argument("--annotators", type=int, default=2)
    parser.add_argument("--seed", type=int, default=42)
    args = parser.parse_args()
    prepare_annotation_files(pd.read_csv(args.input), args.output_dir, args.annotators, args.seed)
    print(f"Wrote {args.annotators} blinded sheets and one researcher key to {args.output_dir}")


if __name__ == "__main__":
    main()
