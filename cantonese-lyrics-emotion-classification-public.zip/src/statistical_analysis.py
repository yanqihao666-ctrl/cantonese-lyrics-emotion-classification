"""Aggregate shared-fold predictions and quantify uncertainty without inventing results."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score


LABELS = ["joy", "sadness", "anger", "calmness"]
KEY_COLUMNS = ["case_id", "partition_seed", "outer_fold"]


def _macro_f1_from_confusion(matrices: np.ndarray) -> np.ndarray:
    """Calculate fixed-label Macro-F1 from one or many confusion matrices."""
    values = np.asarray(matrices, dtype=np.float64)
    true_counts = values.sum(axis=-1)
    predicted_counts = values.sum(axis=-2)
    true_positive = np.diagonal(values, axis1=-2, axis2=-1)
    denominator = true_counts + predicted_counts
    per_class = np.divide(
        2.0 * true_positive,
        denominator,
        out=np.zeros_like(true_positive, dtype=np.float64),
        where=denominator != 0,
    )
    return per_class.mean(axis=-1)


def _cluster_confusions(
    frame: pd.DataFrame,
    *,
    cluster_column: str,
    truth_column: str,
    prediction_column: str,
    cluster_ids: np.ndarray,
) -> np.ndarray:
    """Represent every song cluster as a 4x4 confusion-count matrix."""
    label_index = {label: index for index, label in enumerate(LABELS)}
    cluster_index = {cluster_id: index for index, cluster_id in enumerate(cluster_ids)}
    matrices = np.zeros((len(cluster_ids), len(LABELS), len(LABELS)), dtype=np.int64)
    for cluster, truth, prediction in frame[
        [cluster_column, truth_column, prediction_column]
    ].itertuples(index=False, name=None):
        matrices[
            cluster_index[cluster], label_index[truth], label_index[prediction]
        ] += 1
    return matrices


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_predictions(
    predictions: pd.DataFrame,
    model_column: str = "model_key",
    id_column: str = "case_id",
) -> pd.DataFrame:
    predictions = predictions.copy()
    if id_column == "case_id" and id_column not in predictions.columns:
        if "corpus_song_id" in predictions.columns:
            predictions["case_id"] = predictions["corpus_song_id"]
    key_columns = [id_column, "partition_seed", "outer_fold"]
    required = set(key_columns + [model_column, "true_label", "predicted_label"])
    missing = sorted(required.difference(predictions.columns))
    if missing:
        raise ValueError(f"Missing prediction columns: {missing}")
    if predictions[list(required)].isna().any().any():
        raise ValueError("Prediction keys and labels cannot be missing")

    clean = predictions.copy()
    for column in ["true_label", "predicted_label"]:
        clean[column] = clean[column].astype(str).str.strip().str.lower()
        invalid = sorted(set(clean[column]).difference(LABELS))
        if invalid:
            raise ValueError(f"Invalid values in {column}: {invalid}")
    duplicate = clean.duplicated(key_columns + [model_column], keep=False)
    if duplicate.any():
        raise ValueError("Each model must have one prediction per case and partition")
    truth_counts = clean.groupby(key_columns)["true_label"].nunique()
    if truth_counts.gt(1).any():
        raise ValueError("True labels disagree between models for the same evaluation case")
    return clean


def select_analysis_models(
    predictions: pd.DataFrame,
    requested_models: list[str] | None,
    model_column: str = "model_key",
    id_column: str = "case_id",
) -> pd.DataFrame:
    """Restrict one predeclared multiplicity family before any statistics."""

    clean = validate_predictions(
        predictions,
        model_column=model_column,
        id_column=id_column,
    )
    if not requested_models:
        return clean
    if len(requested_models) != len(set(requested_models)):
        raise ValueError("Requested analysis models must be unique")
    observed = set(clean[model_column])
    missing = sorted(set(requested_models).difference(observed))
    if missing:
        raise ValueError(f"Requested models are absent: {missing}")
    return clean.loc[clean[model_column].isin(requested_models)].copy()


def partition_metrics(
    predictions: pd.DataFrame,
    model_column: str = "model_key",
) -> pd.DataFrame:
    clean = validate_predictions(predictions, model_column=model_column)
    rows: list[dict[str, object]] = []
    for keys, part in clean.groupby([model_column, "partition_seed", "outer_fold"]):
        model_key, partition_seed, outer_fold = keys
        rows.append(
            {
                model_column: model_key,
                "partition_seed": partition_seed,
                "outer_fold": outer_fold,
                "observations": len(part),
                "macro_f1": f1_score(
                    part["true_label"],
                    part["predicted_label"],
                    labels=LABELS,
                    average="macro",
                    zero_division=0,
                ),
                "weighted_f1": f1_score(
                    part["true_label"],
                    part["predicted_label"],
                    labels=LABELS,
                    average="weighted",
                    zero_division=0,
                ),
                "accuracy": accuracy_score(part["true_label"], part["predicted_label"]),
            }
        )
    return pd.DataFrame(rows).sort_values([model_column, "partition_seed", "outer_fold"])


def summarise_partition_metrics(
    metrics: pd.DataFrame,
    model_column: str = "model_key",
) -> pd.DataFrame:
    if metrics.empty:
        raise ValueError("Partition metrics cannot be empty")
    return (
        metrics.groupby(model_column, as_index=False)
        .agg(
            macro_f1_mean=("macro_f1", "mean"),
            macro_f1_std=("macro_f1", "std"),
            weighted_f1_mean=("weighted_f1", "mean"),
            weighted_f1_std=("weighted_f1", "std"),
            accuracy_mean=("accuracy", "mean"),
            accuracy_std=("accuracy", "std"),
            evaluated_partitions=("outer_fold", "count"),
        )
        .sort_values("macro_f1_mean", ascending=False)
    )


def cluster_bootstrap_macro_f1(
    predictions: pd.DataFrame,
    model_key: str,
    model_column: str = "model_key",
    id_column: str = "case_id",
    cluster_column: str = "corpus_song_id",
    n_bootstrap: int = 2_000,
    seed: int = 42,
) -> dict[str, object]:
    clean = validate_predictions(predictions, model_column=model_column, id_column=id_column)
    model_rows = clean.loc[clean[model_column] == model_key]
    if model_rows.empty:
        raise ValueError(f"Unknown model: {model_key}")
    if cluster_column not in model_rows.columns:
        if cluster_column == "corpus_song_id":
            model_rows = model_rows.copy()
            model_rows[cluster_column] = model_rows[id_column]
        else:
            raise ValueError(f"Missing cluster column: {cluster_column}")
    cluster_ids = model_rows[cluster_column].drop_duplicates().to_numpy()
    if len(cluster_ids) < 2:
        raise ValueError("At least two song clusters are required")
    if n_bootstrap < 100:
        raise ValueError("n_bootstrap must be at least 100")

    point = f1_score(
        model_rows["true_label"],
        model_rows["predicted_label"],
        labels=LABELS,
        average="macro",
        zero_division=0,
    )
    cluster_matrices = _cluster_confusions(
        model_rows,
        cluster_column=cluster_column,
        truth_column="true_label",
        prediction_column="predicted_label",
        cluster_ids=cluster_ids,
    ).reshape(len(cluster_ids), -1)
    rng = np.random.default_rng(seed)
    # Sampling cluster multiplicities is exactly the ordinary cluster
    # bootstrap, while summing 16 confusion counts avoids millions of
    # repeated DataFrame concatenations on the expanded corpus.
    multiplicities = rng.multinomial(
        len(cluster_ids),
        np.full(len(cluster_ids), 1.0 / len(cluster_ids)),
        size=n_bootstrap,
    )
    sampled_confusions = (multiplicities @ cluster_matrices).reshape(
        n_bootstrap, len(LABELS), len(LABELS)
    )
    bootstrap_values = _macro_f1_from_confusion(sampled_confusions)
    lower, upper = np.quantile(bootstrap_values, [0.025, 0.975])
    return {
        model_column: model_key,
        "macro_f1_pooled": float(point),
        "ci_95_lower": float(lower),
        "ci_95_upper": float(upper),
        "bootstrap_clusters": int(len(cluster_ids)),
        "bootstrap_iterations": n_bootstrap,
        "bootstrap_seed": seed,
    }


def paired_cluster_permutation_test(
    predictions: pd.DataFrame,
    model_a: str,
    model_b: str,
    model_column: str = "model_key",
    id_column: str = "case_id",
    cluster_column: str = "corpus_song_id",
    permutations: int = 5_000,
    seed: int = 42,
) -> dict[str, object]:
    clean = validate_predictions(predictions, model_column=model_column, id_column=id_column)
    if permutations < 100:
        raise ValueError("permutations must be at least 100")
    if cluster_column not in clean.columns:
        if cluster_column == "corpus_song_id":
            clean[cluster_column] = clean[id_column]
        else:
            raise ValueError(f"Missing cluster column: {cluster_column}")
    key_columns = [id_column]
    if cluster_column != id_column:
        key_columns.append(cluster_column)
    key_columns.extend(["partition_seed", "outer_fold", "true_label"])
    selected = clean.loc[clean[model_column].isin([model_a, model_b])]
    wide = selected.pivot(index=key_columns, columns=model_column, values="predicted_label")
    if model_a not in wide.columns or model_b not in wide.columns:
        raise ValueError("Both requested models must be present")
    if wide[[model_a, model_b]].isna().any().any():
        raise ValueError("Models do not cover identical evaluation cases")
    wide = wide.reset_index()

    cluster_ids = wide[cluster_column].drop_duplicates().to_numpy()
    cluster_a = _cluster_confusions(
        wide,
        cluster_column=cluster_column,
        truth_column="true_label",
        prediction_column=model_a,
        cluster_ids=cluster_ids,
    ).reshape(len(cluster_ids), -1)
    cluster_b = _cluster_confusions(
        wide,
        cluster_column=cluster_column,
        truth_column="true_label",
        prediction_column=model_b,
        cluster_ids=cluster_ids,
    ).reshape(len(cluster_ids), -1)
    total_a = cluster_a.sum(axis=0)
    total_b = cluster_b.sum(axis=0)
    observed = float(
        _macro_f1_from_confusion(total_a.reshape(4, 4))
        - _macro_f1_from_confusion(total_b.reshape(4, 4))
    )
    swap_delta = cluster_b - cluster_a
    rng = np.random.default_rng(seed)
    at_least_as_extreme = 0
    batch_size = 512
    for start in range(0, permutations, batch_size):
        size = min(batch_size, permutations - start)
        swaps = rng.integers(0, 2, size=(size, len(cluster_ids)), dtype=np.int8)
        changes = swaps @ swap_delta
        permuted_a = (total_a + changes).reshape(size, 4, 4)
        permuted_b = (total_b - changes).reshape(size, 4, 4)
        differences = _macro_f1_from_confusion(permuted_a) - _macro_f1_from_confusion(
            permuted_b
        )
        at_least_as_extreme += int(
            (np.abs(differences) >= abs(observed) - 1e-12).sum()
        )
    p_value = (at_least_as_extreme + 1) / (permutations + 1)
    return {
        "model_a": model_a,
        "model_b": model_b,
        "macro_f1_difference_a_minus_b": float(observed),
        "p_value_two_sided": float(p_value),
        "permutations": permutations,
        "permutation_seed": seed,
        "song_clusters": int(len(cluster_ids)),
        "evaluation_rows": int(len(wide)),
    }


def add_holm_adjustment(
    comparisons: pd.DataFrame,
    p_column: str = "p_value_two_sided",
    alpha: float = 0.05,
) -> pd.DataFrame:
    """Add Holm family-wise-error adjusted p-values to pairwise tests."""

    if comparisons.empty:
        return comparisons.assign(
            p_value_holm=pd.Series(dtype=float),
            reject_0_05_holm=pd.Series(dtype=bool),
        )
    if p_column not in comparisons.columns:
        raise ValueError(f"Missing p-value column: {p_column}")
    if not 0 < alpha < 1:
        raise ValueError("alpha must lie between zero and one")

    output = comparisons.copy()
    order = output[p_column].sort_values().index.tolist()
    adjusted: dict[object, float] = {}
    running_max = 0.0
    total = len(order)
    for rank, row_index in enumerate(order):
        candidate = min(1.0, float(output.loc[row_index, p_column]) * (total - rank))
        running_max = max(running_max, candidate)
        adjusted[row_index] = running_max
    output["p_value_holm"] = pd.Series(adjusted)
    output["reject_0_05_holm"] = output["p_value_holm"] < alpha
    return output


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("predictions", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/statistical_analysis"))
    parser.add_argument("--model-column", default="model_key")
    parser.add_argument("--id-column", default="case_id")
    parser.add_argument(
        "--cluster-column",
        default="corpus_song_id",
        help="Resampling/permutation cluster; section-level protocol uses songs.",
    )
    parser.add_argument("--bootstrap-iterations", type=int, default=2_000)
    parser.add_argument("--permutations", type=int, default=5_000)
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument(
        "--models",
        nargs="+",
        help="Exact predeclared model keys for this multiplicity family",
    )
    parser.add_argument(
        "--analysis-label",
        default="all_models",
        help="Human-readable scope saved in analysis metadata",
    )
    args = parser.parse_args()

    predictions = select_analysis_models(
        pd.read_csv(args.predictions, low_memory=False),
        requested_models=args.models,
        model_column=args.model_column,
        id_column=args.id_column,
    )
    metrics = partition_metrics(predictions, model_column=args.model_column)
    summary = summarise_partition_metrics(metrics, model_column=args.model_column)
    models = sorted(predictions[args.model_column].unique())
    intervals = pd.DataFrame(
        [
            cluster_bootstrap_macro_f1(
                predictions,
                model,
                model_column=args.model_column,
                id_column=args.id_column,
                cluster_column=args.cluster_column,
                n_bootstrap=args.bootstrap_iterations,
                seed=args.seed,
            )
            for model in models
        ]
    )
    comparisons = add_holm_adjustment(pd.DataFrame(
        [
            paired_cluster_permutation_test(
                predictions,
                model_a,
                model_b,
                model_column=args.model_column,
                id_column=args.id_column,
                cluster_column=args.cluster_column,
                permutations=args.permutations,
                seed=args.seed,
            )
            for model_a, model_b in itertools.combinations(models, 2)
        ]
    ))

    args.output_dir.mkdir(parents=True, exist_ok=True)
    metrics.to_csv(args.output_dir / "partition_metrics.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(args.output_dir / "model_summary.csv", index=False, encoding="utf-8-sig")
    intervals.to_csv(args.output_dir / "bootstrap_intervals.csv", index=False, encoding="utf-8-sig")
    comparisons.to_csv(args.output_dir / "paired_permutation_tests.csv", index=False, encoding="utf-8-sig")
    (args.output_dir / "analysis_metadata.json").write_text(
        json.dumps(
            {
                "prediction_file": str(args.predictions),
                "prediction_sha256": file_sha256(args.predictions),
                "models": models,
                "bootstrap_iterations": args.bootstrap_iterations,
                "permutations": args.permutations,
                "random_seed": args.seed,
                "case_id_column": args.id_column,
                "cluster_unit": args.cluster_column,
                "primary_metric": "macro_f1",
                "analysis_label": args.analysis_label,
                "requested_models": args.models,
            },
            ensure_ascii=False,
            indent=2,
        ),
        encoding="utf-8",
    )
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
