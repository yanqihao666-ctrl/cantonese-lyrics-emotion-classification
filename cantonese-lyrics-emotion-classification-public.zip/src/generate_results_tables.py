"""Generate traceable dissertation tables from validated formal artifacts."""

from __future__ import annotations

import argparse
import hashlib
import itertools
import json
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
from sklearn.metrics import precision_recall_fscore_support

from src.statistical_analysis import (
    LABELS,
    partition_metrics,
    select_analysis_models,
    summarise_partition_metrics,
    validate_predictions,
)


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def validate_prediction_hash(
    prediction_path: Path,
    analysis_metadata: dict[str, object],
) -> str:
    actual = file_sha256(prediction_path)
    if analysis_metadata.get("prediction_sha256") != actual:
        raise ValueError(
            "Statistical artifacts do not match the supplied prediction-file hash"
        )
    return actual


def validate_identical_model_coverage(
    predictions: pd.DataFrame,
    expected_partitions: int | None = 15,
) -> pd.DataFrame:
    """Require every compared model to cover the same section/partition cases."""

    clean = validate_predictions(predictions)
    case_columns = ["case_id", "partition_seed", "outer_fold"]
    models = sorted(clean["model_key"].unique())
    reference = None
    for model_key in models:
        model_rows = clean.loc[clean["model_key"] == model_key]
        cases = set(map(tuple, model_rows[case_columns].to_numpy()))
        if reference is None:
            reference = cases
        elif cases != reference:
            missing = len(reference.difference(cases))
            extra = len(cases.difference(reference))
            raise ValueError(
                f"Models do not cover identical cases; {model_key} "
                f"missing={missing}, extra={extra}"
            )
        partitions = model_rows[["partition_seed", "outer_fold"]].drop_duplicates()
        if expected_partitions is not None and len(partitions) != expected_partitions:
            raise ValueError(
                f"{model_key} has {len(partitions)} partitions; "
                f"expected {expected_partitions}"
            )
    return clean


def model_descriptor(model_key: str) -> dict[str, str]:
    if model_key == "classical::validation_selected":
        return {
            "family": "classical",
            "representation": "validation-selected per partition",
            "estimator": "validation-selected per partition",
        }
    parts = model_key.split("::")
    if len(parts) == 3 and parts[0] == "classical":
        return {
            "family": "classical",
            "representation": parts[1],
            "estimator": parts[2],
        }
    if len(parts) == 2 and parts[0] == "transformer":
        return {
            "family": "transformer",
            "representation": "checkpoint tokenizer",
            "estimator": parts[1],
        }
    return {
        "family": "other",
        "representation": "unspecified",
        "estimator": model_key,
    }


def verify_saved_analysis(
    predictions: pd.DataFrame,
    summary: pd.DataFrame,
    intervals: pd.DataFrame,
    comparisons: pd.DataFrame,
) -> None:
    models = set(predictions["model_key"])
    if set(summary["model_key"]) != models:
        raise ValueError("Saved model summary does not match prediction models")
    if set(intervals["model_key"]) != models:
        raise ValueError("Saved bootstrap intervals do not match prediction models")
    comparison_models = set(comparisons.get("model_a", [])).union(
        comparisons.get("model_b", [])
    )
    if len(models) > 1 and comparison_models != models:
        raise ValueError("Saved pairwise comparisons do not cover all prediction models")
    expected_pairs = {
        frozenset(pair) for pair in itertools.combinations(sorted(models), 2)
    }
    observed_pairs = [
        frozenset((row.model_a, row.model_b))
        for row in comparisons[["model_a", "model_b"]].itertuples(index=False)
    ]
    if (
        len(observed_pairs) != len(set(observed_pairs))
        or set(observed_pairs) != expected_pairs
    ):
        raise ValueError("Saved pairwise comparisons are incomplete or duplicated")

    recalculated = summarise_partition_metrics(partition_metrics(predictions))
    columns = [
        "macro_f1_mean",
        "macro_f1_std",
        "weighted_f1_mean",
        "weighted_f1_std",
        "accuracy_mean",
        "accuracy_std",
        "evaluated_partitions",
    ]
    left = summary.set_index("model_key").sort_index()[columns]
    right = recalculated.set_index("model_key").sort_index()[columns]
    if list(left.index) != list(right.index):
        raise ValueError("Saved and recalculated model identities differ")
    numeric_columns = columns[:-1]
    if not np.allclose(
        left[numeric_columns].to_numpy(dtype=float),
        right[numeric_columns].to_numpy(dtype=float),
        equal_nan=True,
        rtol=1e-9,
        atol=1e-12,
    ):
        raise ValueError("Saved model summary is stale or inconsistent with predictions")
    if not left["evaluated_partitions"].equals(right["evaluated_partitions"]):
        raise ValueError("Saved partition counts are inconsistent with predictions")


def build_results_tables(
    predictions: pd.DataFrame,
    summary: pd.DataFrame,
    intervals: pd.DataFrame,
    comparisons: pd.DataFrame,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame]:
    """Build overall, per-class and pairwise dissertation tables."""

    predictions = validate_predictions(predictions)
    verify_saved_analysis(predictions, summary, intervals, comparisons)
    overall = summary.merge(
        intervals[
            [
                "model_key",
                "macro_f1_pooled",
                "ci_95_lower",
                "ci_95_upper",
                "bootstrap_clusters",
                "bootstrap_iterations",
            ]
        ],
        on="model_key",
        how="left",
        validate="one_to_one",
    )
    descriptors = pd.DataFrame(
        [
            {"model_key": key, **model_descriptor(key)}
            for key in overall["model_key"]
        ]
    )
    overall = descriptors.merge(
        overall,
        on="model_key",
        how="right",
        validate="one_to_one",
    )
    counts = (
        predictions.groupby("model_key")
        .agg(
            evaluation_rows=("case_id", "size"),
            unique_sections=("case_id", "nunique"),
            unique_songs=("corpus_song_id", "nunique"),
        )
        .reset_index()
    )
    overall = overall.merge(counts, on="model_key", validate="one_to_one")
    overall = overall.sort_values(
        ["macro_f1_mean", "model_key"],
        ascending=[False, True],
    ).reset_index(drop=True)

    class_partition_rows: list[dict[str, object]] = []
    for (model_key, partition_seed, outer_fold), part in predictions.groupby(
        ["model_key", "partition_seed", "outer_fold"]
    ):
        _, _, f1_values, support = precision_recall_fscore_support(
            part["true_label"],
            part["predicted_label"],
            labels=LABELS,
            zero_division=0,
        )
        for index, label in enumerate(LABELS):
            class_partition_rows.append(
                {
                    "model_key": model_key,
                    "partition_seed": partition_seed,
                    "outer_fold": outer_fold,
                    "label": label,
                    "partition_f1": float(f1_values[index]),
                    "partition_support": int(support[index]),
                }
            )
    partition_class = pd.DataFrame(class_partition_rows)
    class_aggregate = (
        partition_class.groupby(["model_key", "label"], as_index=False)
        .agg(
            class_f1_mean=("partition_f1", "mean"),
            class_f1_std=("partition_f1", "std"),
            evaluated_partitions=("outer_fold", "count"),
            evaluation_rows=("partition_support", "sum"),
        )
    )

    pooled_rows: list[dict[str, object]] = []
    for model_key, part in predictions.groupby("model_key"):
        precision, recall, f1_values, support = precision_recall_fscore_support(
            part["true_label"],
            part["predicted_label"],
            labels=LABELS,
            zero_division=0,
        )
        unique_case_support = (
            part[["case_id", "true_label"]]
            .drop_duplicates()["true_label"]
            .value_counts()
        )
        unique_song_support = (
            part[["corpus_song_id", "true_label"]]
            .drop_duplicates()["true_label"]
            .value_counts()
        )
        for index, label in enumerate(LABELS):
            pooled_rows.append(
                {
                    "model_key": model_key,
                    "label": label,
                    "precision_pooled": float(precision[index]),
                    "recall_pooled": float(recall[index]),
                    "f1_pooled": float(f1_values[index]),
                    "pooled_evaluation_rows": int(support[index]),
                    "unique_case_support": int(unique_case_support.get(label, 0)),
                    "unique_song_support": int(unique_song_support.get(label, 0)),
                }
            )
    per_class = class_aggregate.merge(
        pd.DataFrame(pooled_rows),
        on=["model_key", "label"],
        validate="one_to_one",
    )
    per_class["label"] = pd.Categorical(
        per_class["label"],
        categories=LABELS,
        ordered=True,
    )
    per_class = per_class.sort_values(["model_key", "label"]).reset_index(drop=True)
    per_class["label"] = per_class["label"].astype(str)

    pairwise_columns = [
        "model_a",
        "model_b",
        "macro_f1_difference_a_minus_b",
        "p_value_two_sided",
        "p_value_holm",
        "reject_0_05_holm",
        "permutations",
        "song_clusters",
        "evaluation_rows",
    ]
    missing_pairwise = sorted(set(pairwise_columns).difference(comparisons.columns))
    if missing_pairwise:
        raise ValueError(f"Pairwise artifact is missing columns: {missing_pairwise}")
    pairwise = comparisons[pairwise_columns].sort_values(
        ["p_value_holm", "model_a", "model_b"]
    )
    return overall, per_class, pairwise


def _format_number(value: object, digits: int = 3) -> str:
    if pd.isna(value):
        return "NA"
    return f"{float(value):.{digits}f}"


def is_development_analysis(analysis_label: str | None) -> bool:
    """Return true for any explicitly non-formal development analysis."""
    normalised = str(analysis_label or "").strip().lower()
    return any(
        marker in normalised
        for marker in ("development_silver", "development_only", "ai_preannotation")
    )


def render_markdown(
    overall: pd.DataFrame,
    per_class: pd.DataFrame,
    pairwise: pd.DataFrame,
    analysis_label: str | None = None,
) -> str:
    development_only = is_development_analysis(analysis_label)
    lines = [
        (
            "# Development-only silver-label results tables"
            if development_only
            else "# Auto-generated formal results tables"
        ),
        "",
        (
            "**NOT FORMAL EVALUATION:** targets are AI candidate labels. These "
            "results validate the software pipeline and must not be reported as "
            "human-gold dissertation performance."
            if development_only
            else "These tables are generated from validated artifacts. They contain "
            "no AI-estimated or manually copied values."
        ),
        "",
        "## Overall model comparison",
        "",
        "| Model key | Macro-F1 mean (SD) | Pooled macro-F1 95% CI | "
        "Weighted-F1 mean | Accuracy mean | Partitions |",
        "|---|---:|---:|---:|---:|---:|",
    ]
    for row in overall.itertuples(index=False):
        lines.append(
            f"| `{row.model_key}` | {_format_number(row.macro_f1_mean)} "
            f"({_format_number(row.macro_f1_std)}) | "
            f"{_format_number(row.ci_95_lower)} to {_format_number(row.ci_95_upper)} | "
            f"{_format_number(row.weighted_f1_mean)} | "
            f"{_format_number(row.accuracy_mean)} | "
            f"{int(row.evaluated_partitions)} |"
        )
    lines.extend(
        [
            "",
            "## Per-class results",
            "",
            "| Model key | Label | Partition F1 mean (SD) | Pooled precision | "
            "Pooled recall | Pooled F1 | Unique sections | Source songs |",
            "|---|---|---:|---:|---:|---:|---:|---:|",
        ]
    )
    for row in per_class.itertuples(index=False):
        lines.append(
            f"| `{row.model_key}` | {row.label} | "
            f"{_format_number(row.class_f1_mean)} "
            f"({_format_number(row.class_f1_std)}) | "
            f"{_format_number(row.precision_pooled)} | "
            f"{_format_number(row.recall_pooled)} | "
            f"{_format_number(row.f1_pooled)} | "
            f"{int(row.unique_case_support)} | "
            f"{int(row.unique_song_support)} |"
        )
    lines.extend(
        [
            "",
            "## Paired cluster permutation tests",
            "",
            "| Model A | Model B | Macro-F1 difference (A-B) | Raw p | "
            "Holm p | Holm reject 0.05 |",
            "|---|---|---:|---:|---:|---|",
        ]
    )
    for row in pairwise.itertuples(index=False):
        lines.append(
            f"| `{row.model_a}` | `{row.model_b}` | "
            f"{_format_number(row.macro_f1_difference_a_minus_b)} | "
            f"{_format_number(row.p_value_two_sided, 4)} | "
            f"{_format_number(row.p_value_holm, 4)} | "
            f"{bool(row.reject_0_05_holm)} |"
        )
    lines.extend(
        [
            "",
            "Interpretation must consider effect magnitude, uncertainty, annotation "
            "quality and corpus limits; statistical non-significance is not evidence "
            "of equivalence.",
        ]
    )
    return "\n".join(lines) + "\n"


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("predictions", type=Path)
    parser.add_argument("analysis_dir", type=Path)
    parser.add_argument(
        "--output-dir",
        type=Path,
        default=Path("results/formal/report_tables"),
    )
    parser.add_argument("--expected-partitions", type=int, default=15)
    parser.add_argument("--allow-partial-grid", action="store_true")
    args = parser.parse_args()

    paths = {
        "summary": args.analysis_dir / "model_summary.csv",
        "intervals": args.analysis_dir / "bootstrap_intervals.csv",
        "comparisons": args.analysis_dir / "paired_permutation_tests.csv",
        "metadata": args.analysis_dir / "analysis_metadata.json",
    }
    missing = [str(path) for path in paths.values() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing statistical artifacts: {missing}")
    analysis_metadata = json.loads(paths["metadata"].read_text(encoding="utf-8"))
    prediction_hash = validate_prediction_hash(args.predictions, analysis_metadata)
    scoped_predictions = select_analysis_models(
        pd.read_csv(args.predictions, low_memory=False),
        requested_models=analysis_metadata.get("requested_models"),
    )
    predictions = validate_identical_model_coverage(
        scoped_predictions,
        expected_partitions=None
        if args.allow_partial_grid
        else args.expected_partitions,
    )

    summary = pd.read_csv(paths["summary"])
    intervals = pd.read_csv(paths["intervals"])
    comparisons = pd.read_csv(paths["comparisons"])
    overall, per_class, pairwise = build_results_tables(
        predictions,
        summary,
        intervals,
        comparisons,
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    overall.to_csv(args.output_dir / "overall_model_table.csv", index=False, encoding="utf-8-sig")
    per_class.to_csv(args.output_dir / "per_class_table.csv", index=False, encoding="utf-8-sig")
    pairwise.to_csv(args.output_dir / "pairwise_table.csv", index=False, encoding="utf-8-sig")
    (args.output_dir / "results_tables.md").write_text(
        render_markdown(
            overall,
            per_class,
            pairwise,
            analysis_label=analysis_metadata.get("analysis_label"),
        ),
        encoding="utf-8",
    )
    output_metadata = {
        "generated_at_utc": datetime.now(timezone.utc).isoformat(),
        "predictions_path": str(args.predictions),
        "predictions_sha256": prediction_hash,
        "analysis_artifacts": {
            name: {"path": str(path), "sha256": file_sha256(path)}
            for name, path in paths.items()
        },
        "models": sorted(predictions["model_key"].unique()),
        "partitions_per_model": int(
            predictions[["partition_seed", "outer_fold"]]
            .drop_duplicates()
            .shape[0]
        ),
        "manual_values": False,
        "analysis_label": analysis_metadata.get("analysis_label"),
        "formal_evaluation_eligible": not is_development_analysis(
            analysis_metadata.get("analysis_label")
        ),
    }
    (args.output_dir / "table_generation_metadata.json").write_text(
        json.dumps(output_metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(
        json.dumps(
            {
                "models": len(overall),
                "per_class_rows": len(per_class),
                "pairwise_rows": len(pairwise),
                "output_dir": str(args.output_dir),
            },
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
