"""Build traceable qualitative-error strata from saved paired predictions."""

from __future__ import annotations

import argparse
import itertools
import json
from pathlib import Path

import pandas as pd

from src.statistical_analysis import validate_predictions


SENSITIVE_TEXT_COLUMNS = {
    "lyrics",
    "lyric_excerpt",
    "jyutping",
    "jyutping_search",
    "jyutping_diacritics",
    "text",
    "lyric_text",
    "lyrics_original",
    "orthography_for_modelling",
}


def is_sensitive_text_column(column: object) -> bool:
    """Conservatively block original or transformed lyric-text fields."""
    name = str(column).lower().strip()
    return (
        name in SENSITIVE_TEXT_COLUMNS
        or "lyrics" in name
        or name.startswith("lyric_")
        or name.endswith("_lyric")
        or "jyutping" in name
        or name in {"orthography", "orthography_for_modelling", "input_text"}
    )


def pairwise_case_patterns(
    predictions: pd.DataFrame,
    models: list[str] | None = None,
) -> pd.DataFrame:
    """Classify paired cases without treating repeated folds as independent evidence."""

    clean = validate_predictions(predictions)
    available = sorted(clean["model_key"].unique())
    selected = models or available
    missing = sorted(set(selected).difference(available))
    if missing:
        raise ValueError(f"Requested models not present: {missing}")
    keys = ["case_id"]
    if "corpus_song_id" in clean.columns:
        keys.append("corpus_song_id")
    keys.extend(["partition_seed", "outer_fold", "true_label"])
    rows: list[pd.DataFrame] = []
    for model_a, model_b in itertools.combinations(selected, 2):
        left = clean.loc[clean["model_key"] == model_a, keys + ["predicted_label"]].rename(
            columns={"predicted_label": "predicted_a"}
        )
        right = clean.loc[clean["model_key"] == model_b, keys + ["predicted_label"]].rename(
            columns={"predicted_label": "predicted_b"}
        )
        paired = left.merge(right, on=keys, how="inner", validate="one_to_one")
        if paired.empty:
            continue
        correct_a = paired["predicted_a"] == paired["true_label"]
        correct_b = paired["predicted_b"] == paired["true_label"]
        paired["case_pattern"] = "both_wrong_different"
        paired.loc[correct_a & correct_b, "case_pattern"] = "both_correct"
        paired.loc[correct_a & ~correct_b, "case_pattern"] = "model_a_only"
        paired.loc[~correct_a & correct_b, "case_pattern"] = "model_b_only"
        paired.loc[
            ~correct_a & ~correct_b & (paired["predicted_a"] == paired["predicted_b"]),
            "case_pattern",
        ] = "both_wrong_same"
        paired.insert(0, "model_a", model_a)
        paired.insert(1, "model_b", model_b)
        rows.append(paired)
    if not rows:
        raise ValueError("At least two models with paired cases are required")
    return pd.concat(rows, ignore_index=True)


def build_review_queue(
    predictions: pd.DataFrame,
    metadata: pd.DataFrame | None = None,
    models: list[str] | None = None,
) -> pd.DataFrame:
    """Rank lyric sections by errors, model disagreement and repeat instability."""

    clean = validate_predictions(predictions)
    if models:
        missing = sorted(set(models).difference(clean["model_key"].unique()))
        if missing:
            raise ValueError(f"Requested models not present: {missing}")
        clean = clean.loc[clean["model_key"].isin(models)].copy()

    clean["correct"] = clean["true_label"] == clean["predicted_label"]
    case_truth = clean.groupby("case_id")["true_label"].agg(
        lambda values: values.iloc[0]
    )
    case_summary = clean.groupby("case_id").agg(
        prediction_rows=("predicted_label", "size"),
        models_compared=("model_key", "nunique"),
        overall_error_rate=("correct", lambda values: 1.0 - float(values.mean())),
    )
    if "corpus_song_id" in clean.columns:
        parent_song = clean.groupby("case_id")["corpus_song_id"].agg(
            lambda values: values.iloc[0]
        )
    else:
        parent_song = pd.Series(
            case_summary.index,
            index=case_summary.index,
            name="corpus_song_id",
        )

    case_disagreement = (
        clean.groupby(["case_id", "partition_seed", "outer_fold"])[
            "predicted_label"
        ]
        .nunique()
        .gt(1)
        .groupby("case_id")
        .mean()
        .rename("between_model_disagreement_rate")
    )
    model_instability = (
        clean.groupby(["case_id", "model_key"])["predicted_label"]
        .nunique()
        .gt(1)
        .groupby("case_id")
        .mean()
        .rename("unstable_model_fraction")
    )
    model_prediction_labels = (
        clean.groupby(["case_id", "model_key"])["predicted_label"]
        .agg(lambda values: "|".join(sorted(values.value_counts().index.tolist())))
    )
    predictions_by_model = pd.Series(
        {
            case_id: json.dumps(
                {
                    str(index[1]): str(value)
                    for index, value in song_values.items()
                },
                ensure_ascii=False,
                sort_keys=True,
            )
            for case_id, song_values in model_prediction_labels.groupby(level=0)
        },
        name="predicted_labels_by_model",
    )
    queue = (
        case_summary.join(case_truth.rename("true_label"))
        .join(parent_song.rename("corpus_song_id"))
        .join(case_disagreement)
        .join(model_instability)
        .join(predictions_by_model)
        .reset_index()
    )

    if metadata is not None:
        metadata = metadata.copy()
        if "case_id" not in metadata.columns and "corpus_song_id" in metadata.columns:
            metadata["case_id"] = metadata["corpus_song_id"]
        if "case_id" not in metadata.columns:
            raise ValueError("Metadata must contain case_id")
        if metadata["case_id"].duplicated().any():
            raise ValueError("Metadata case_id must be unique")
        safe_metadata = metadata.drop(
            columns=[
                column
                for column in metadata.columns
                if is_sensitive_text_column(column)
                or (column in queue.columns and column != "case_id")
            ],
            errors="ignore",
        )
        queue = queue.merge(
            safe_metadata,
            on="case_id",
            how="left",
            validate="one_to_one",
        )

    return queue.sort_values(
        [
            "between_model_disagreement_rate",
            "overall_error_rate",
            "unstable_model_fraction",
            "case_id",
        ],
        ascending=[False, False, False, True],
    ).reset_index(drop=True)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("predictions", type=Path)
    parser.add_argument("--metadata", type=Path)
    parser.add_argument("--models", nargs="+")
    parser.add_argument("--output-dir", type=Path, default=Path("results/error_analysis"))
    args = parser.parse_args()

    predictions = pd.read_csv(args.predictions, low_memory=False)
    metadata = pd.read_csv(args.metadata, low_memory=False) if args.metadata else None
    selected_predictions = validate_predictions(predictions)
    if args.models:
        missing = sorted(
            set(args.models).difference(selected_predictions["model_key"].unique())
        )
        if missing:
            raise ValueError(f"Requested models not present: {missing}")
        selected_predictions = selected_predictions.loc[
            selected_predictions["model_key"].isin(args.models)
        ].copy()
    patterns = pairwise_case_patterns(predictions, models=args.models)
    queue = build_review_queue(predictions, metadata=metadata, models=args.models)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    patterns.to_csv(args.output_dir / "pairwise_case_patterns.csv", index=False, encoding="utf-8-sig")
    queue.to_csv(args.output_dir / "qualitative_review_queue.csv", index=False, encoding="utf-8-sig")
    summary = {
        "prediction_rows": len(selected_predictions),
        "pairwise_case_rows": len(patterns),
        "sections_in_review_queue": len(queue),
        "models": sorted(selected_predictions["model_key"].unique()),
        "lyric_text_saved": False,
    }
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
