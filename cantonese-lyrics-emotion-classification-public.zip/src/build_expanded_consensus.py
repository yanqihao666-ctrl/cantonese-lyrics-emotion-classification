"""Build final development labels from three disclosed AI evidence streams."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


LABELS = {"joy", "sadness", "anger", "calmness"}


def choose_consensus(generated: object, scored: object, nli: object) -> dict[str, object]:
    values = [value for value in [generated, scored, nli] if isinstance(value, str) and value in LABELS]
    if not values:
        raise ValueError("No valid label evidence")
    counts = Counter(values)
    label, count = counts.most_common(1)[0]
    tied = list(counts.values()).count(count) > 1
    if tied:
        # The generation vote already includes a separate adjudication pass;
        # prefer it when three evidence streams disagree, then the calibrated score.
        label = generated if generated in LABELS else scored if scored in LABELS else nli
        method = "three_way_tie_generation_adjudication_tiebreak"
    elif count == 3:
        method = "unanimous_three_method_consensus"
    else:
        method = "two_of_three_method_consensus"
    return {
        "emotion": label,
        "consensus_vote_count": int(count if not tied else 1),
        "consensus_tied": bool(tied),
        "consensus_method": method,
    }


def build_consensus(
    scored: pd.DataFrame,
    generated: pd.DataFrame,
    nli: pd.DataFrame,
) -> pd.DataFrame:
    score_columns = [
        "case_id",
        "emotion",
        "confidence_margin",
        "permutation_vote_count",
        "permutation_unanimous",
        "normalised_entropy",
    ]
    generation_columns = ["case_id", "emotion", "ai_prompt_agreement"]
    nli_columns = ["case_id", "candidate_label", "prompt_agreement", "mean_top_two_margin"]
    frame = (
        scored.drop(
            columns=[
                "emotion",
                "needs_human_review",
                "ai_confidence_1_to_5",
                *[column for column in score_columns if column != "case_id"],
            ],
            errors="ignore",
        )
        .merge(
            scored[score_columns].rename(columns={"emotion": "score_label"}),
            on="case_id",
            validate="one_to_one",
        )
        .merge(
            generated[generation_columns].rename(
                columns={"emotion": "generation_label", "ai_prompt_agreement": "generation_prompt_agreement"}
            ),
            on="case_id",
            validate="one_to_one",
        )
        .merge(
            nli[nli_columns].rename(
                columns={
                    "candidate_label": "nli_label",
                    "prompt_agreement": "nli_prompt_agreement",
                    "mean_top_two_margin": "nli_mean_margin",
                }
            ),
            on="case_id",
            validate="one_to_one",
        )
    )
    decisions = pd.DataFrame(
        [
            choose_consensus(row.generation_label, row.score_label, row.nli_label)
            for row in frame.itertuples()
        ]
    )
    for column in decisions:
        frame[column] = decisions[column].values

    original = frame["source_cohort"].eq("original_680")
    if frame.loc[original, "historical_emotion"].isna().any():
        raise ValueError("Every original row must retain a historical V2 label")
    frame.loc[original, "emotion"] = frame.loc[original, "historical_emotion"]
    frame.loc[original, "consensus_method"] = "retained_reviewed_original_v2_label"
    frame.loc[original, "consensus_vote_count"] = pd.NA
    frame.loc[original, "consensus_tied"] = False

    frame["needs_human_review"] = (~original) & (
        frame["consensus_vote_count"].fillna(0).lt(3)
        | frame["consensus_tied"]
        | frame["generation_prompt_agreement"].eq(False)
        | frame["permutation_vote_count"].lt(3)
        | frame["nli_prompt_agreement"].lt(1.0)
    )
    frame["ai_confidence_1_to_5"] = 3
    frame.loc[frame["consensus_vote_count"].eq(3), "ai_confidence_1_to_5"] = 5
    frame.loc[frame["consensus_vote_count"].eq(2), "ai_confidence_1_to_5"] = 4
    frame.loc[frame["consensus_tied"], "ai_confidence_1_to_5"] = 2
    frame.loc[original, "ai_confidence_1_to_5"] = 4
    frame["expanded_ai_label"] = frame["emotion"]
    frame["label_status"] = "three_method_ai_consensus_development_label"
    frame.loc[original, "label_status"] = "retained_original_v2_development_label"
    frame["development_label_source"] = "qwen_generation_plus_calibrated_logits_plus_nli"
    frame.loc[original, "development_label_source"] = "original_v2_research_assisted_review"
    frame["development_only"] = True
    frame["formal_evaluation_eligible"] = False
    frame["consensus_created_at_utc"] = datetime.now(timezone.utc).isoformat()
    if len(frame) != 6000 or frame["case_id"].duplicated().any():
        raise AssertionError("Consensus output must contain 6,000 unique cases")
    if set(frame["emotion"]) != LABELS:
        raise ValueError(f"Expected all four labels, got {set(frame['emotion'])}")
    return frame


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("scored_csv", type=Path)
    parser.add_argument("generated_csv", type=Path)
    parser.add_argument("nli_csv", type=Path)
    parser.add_argument("output_csv", type=Path)
    args = parser.parse_args()
    result = build_consensus(
        pd.read_csv(args.scored_csv, low_memory=False),
        pd.read_csv(args.generated_csv, low_memory=False),
        pd.read_csv(args.nli_csv, low_memory=False),
    )
    args.output_csv.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output_csv, index=False, encoding="utf-8-sig")
    expansion = result["source_cohort"].eq("github_expansion_5320")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(result),
        "songs": int(result["corpus_song_id"].nunique()),
        "artists": int(result["artist"].nunique()),
        "label_counts": result["emotion"].value_counts().to_dict(),
        "expansion_consensus_method_counts": result.loc[
            expansion, "consensus_method"
        ].value_counts().to_dict(),
        "expansion_review_rows": int(result.loc[expansion, "needs_human_review"].sum()),
        "formal_evaluation_eligible": False,
        "warning": "AI-assisted development labels; not independent human gold.",
        "inputs": {
            "scored_sha256": hashlib.sha256(args.scored_csv.read_bytes()).hexdigest(),
            "generated_sha256": hashlib.sha256(args.generated_csv.read_bytes()).hexdigest(),
            "nli_sha256": hashlib.sha256(args.nli_csv.read_bytes()).hexdigest(),
        },
        "output_sha256": hashlib.sha256(args.output_csv.read_bytes()).hexdigest(),
    }
    args.output_csv.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
