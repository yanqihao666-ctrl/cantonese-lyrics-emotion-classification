"""Leakage-aware classical ML experiment runner for labelled Cantonese lyrics."""

from __future__ import annotations

import argparse
import hashlib
import json
import platform
import time
from pathlib import Path

import jieba
import imblearn
import numpy as np
import pandas as pd
import sklearn
from imblearn.over_sampling import RandomOverSampler, SMOTE
from imblearn.pipeline import Pipeline as ImbalancedPipeline
from imblearn.under_sampling import RandomUnderSampler
from sklearn.dummy import DummyClassifier
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.metrics import (
    accuracy_score,
    balanced_accuracy_score,
    f1_score,
    precision_recall_fscore_support,
)
from sklearn.model_selection import StratifiedGroupKFold, StratifiedKFold
from sklearn.naive_bayes import MultinomialNB
from sklearn.pipeline import FeatureUnion, Pipeline
from sklearn.linear_model import LogisticRegression
from sklearn.svm import LinearSVC


LABELS = ["joy", "sadness", "anger", "calmness"]
DEFAULT_SEEDS = [13, 42, 97]
IMBALANCE_STRATEGIES = [
    "baseline",
    "class_weight",
    "random_oversampling",
    "smote",
    "moderate_undersampling",
]


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def jieba_tokenize(text: str) -> list[str]:
    """Segment text for the explicit word-level ablation."""
    return [token.strip() for token in jieba.lcut(str(text), cut_all=False) if token.strip()]


def feature_extractor(name: str):
    char = TfidfVectorizer(
        analyzer="char",
        ngram_range=(2, 5),
        min_df=2,
        max_df=0.98,
        sublinear_tf=True,
        max_features=60_000,
    )
    word = TfidfVectorizer(
        tokenizer=jieba_tokenize,
        token_pattern=None,
        lowercase=False,
        ngram_range=(1, 2),
        min_df=2,
        max_df=0.98,
        sublinear_tf=True,
        max_features=40_000,
    )
    if name == "character_tfidf":
        return char
    if name == "word_tfidf":
        return word
    if name == "combined_tfidf":
        return FeatureUnion([("character", char), ("word", word)])
    raise ValueError(f"Unknown feature set: {name}")


def classifier(name: str, seed: int, class_weighting: bool = True):
    if name == "majority":
        return DummyClassifier(strategy="most_frequent")
    if name == "multinomial_nb":
        return MultinomialNB(alpha=1.0)
    if name == "logistic_regression":
        return LogisticRegression(
            C=4.0,
            class_weight="balanced" if class_weighting else None,
            max_iter=3_000,
            random_state=seed,
            solver="lbfgs",
        )
    if name == "linear_svm":
        return LinearSVC(
            C=1.0,
            class_weight="balanced" if class_weighting else None,
            random_state=seed,
        )
    raise ValueError(f"Unknown classifier: {name}")


def moderate_undersampling_strategy(y) -> dict[str, int]:
    """Cap only the largest class at twice the second-largest class."""

    counts = pd.Series(y).value_counts()
    if len(counts) < 2:
        raise ValueError("Moderate undersampling requires at least two classes")
    majority = str(counts.index[0])
    target = min(int(counts.iloc[0]), 2 * int(counts.iloc[1]))
    return {majority: target}


def expected_resampled_counts(labels: pd.Series, strategy: str) -> dict[str, int]:
    counts = labels.value_counts().reindex(LABELS, fill_value=0).astype(int)
    if strategy in {"baseline", "class_weight"}:
        result = counts
    elif strategy in {"random_oversampling", "smote"}:
        result = pd.Series(int(counts.max()), index=counts.index)
    elif strategy == "moderate_undersampling":
        result = counts.copy()
        target = moderate_undersampling_strategy(labels)
        for label, value in target.items():
            result.loc[label] = value
    else:
        raise ValueError(f"Unknown imbalance strategy: {strategy}")
    return {label: int(result[label]) for label in LABELS}


def build_pipeline(
    feature_name: str,
    model_name: str,
    seed: int,
    imbalance_strategy: str = "class_weight",
) -> Pipeline | ImbalancedPipeline:
    if imbalance_strategy not in IMBALANCE_STRATEGIES:
        raise ValueError(f"Unknown imbalance strategy: {imbalance_strategy}")
    if model_name == "majority":
        if imbalance_strategy != "baseline":
            raise ValueError("The majority baseline does not accept imbalance treatment")
        return Pipeline([("features", TfidfVectorizer(analyzer="char", ngram_range=(2, 3))),
                         ("classifier", classifier(model_name, seed, class_weighting=False))])
    use_class_weight = imbalance_strategy == "class_weight"
    steps = [("features", feature_extractor(feature_name))]
    if imbalance_strategy == "random_oversampling":
        steps.append(("sampler", RandomOverSampler(random_state=seed)))
    elif imbalance_strategy == "smote":
        steps.append(("sampler", SMOTE(random_state=seed, k_neighbors=5)))
    elif imbalance_strategy == "moderate_undersampling":
        steps.append(
            (
                "sampler",
                RandomUnderSampler(
                    sampling_strategy=moderate_undersampling_strategy,
                    random_state=seed,
                ),
            )
        )
    steps.append(
        ("classifier", classifier(model_name, seed, class_weighting=use_class_weight))
    )
    if "sampler" in dict(steps):
        return ImbalancedPipeline(steps)
    return Pipeline(steps)


def validate_training_frame(frame: pd.DataFrame, text_column: str, label_column: str) -> pd.DataFrame:
    missing = sorted({text_column, label_column}.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing training columns: {missing}")
    clean = frame.dropna(subset=[text_column, label_column]).copy()
    clean[label_column] = clean[label_column].astype(str).str.strip().str.lower()
    invalid = sorted(set(clean[label_column]).difference(LABELS))
    if invalid:
        raise ValueError(f"Invalid labels: {invalid}")
    counts = clean[label_column].value_counts()
    absent = sorted(set(LABELS).difference(counts.index))
    if absent:
        raise ValueError(f"All four labels are required; absent labels: {absent}")
    if counts.min() < 2:
        raise ValueError("Each label requires at least two observations")
    return clean


def validate_fixed_partition(
    frame: pd.DataFrame,
    text_column: str,
    label_column: str,
    group_column: str | None,
    split_column: str = "split",
) -> pd.DataFrame:
    clean = validate_training_frame(frame, text_column, label_column)
    if split_column not in clean.columns:
        raise ValueError(f"Missing split column: {split_column}")
    if clean[split_column].isna().any():
        raise ValueError("Split assignments cannot be missing")
    expected = {"train", "validation", "test"}
    observed = set(clean[split_column].astype(str))
    if observed != expected:
        raise ValueError(f"{split_column} must contain exactly {sorted(expected)}")
    for split_name in ["train", "validation", "test"]:
        missing_labels = set(LABELS) - set(
            clean.loc[clean[split_column] == split_name, label_column]
        )
        if missing_labels:
            raise ValueError(f"{split_name} is missing labels: {sorted(missing_labels)}")
    if group_column and group_column in clean.columns:
        overlap = clean.groupby(group_column)[split_column].nunique()
        if overlap.gt(1).any():
            raise ValueError("Group leakage detected across fixed partition")
    if "corpus_song_id" in clean.columns:
        parent_overlap = clean.groupby("corpus_song_id")[split_column].nunique()
        if parent_overlap.gt(1).any():
            raise ValueError("Parent-song leakage detected across fixed partition")
    return clean


def _splitter(frame: pd.DataFrame, label_column: str, group_column: str | None, folds: int, seed: int):
    minimum_class = int(frame[label_column].value_counts().min())
    n_splits = min(folds, minimum_class)
    if n_splits < 2:
        raise ValueError("Insufficient examples for cross-validation")
    if group_column and group_column in frame.columns and frame[group_column].nunique() >= n_splits:
        return StratifiedGroupKFold(n_splits=n_splits, shuffle=True, random_state=seed), frame[group_column]
    return StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=seed), None


def run_experiment(
    frame: pd.DataFrame,
    text_column: str = "lyrics",
    label_column: str = "emotion",
    group_column: str | None = "artist",
    seeds: list[int] | None = None,
    folds: int = 5,
    feature_sets: list[str] | None = None,
    model_names: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict[str, object]]:
    clean = validate_training_frame(frame, text_column, label_column)
    seeds = seeds or DEFAULT_SEEDS
    feature_sets = feature_sets or ["character_tfidf", "word_tfidf", "combined_tfidf"]
    model_names = model_names or ["majority", "multinomial_nb", "logistic_regression", "linear_svm"]
    predictions: list[dict[str, object]] = []
    folds_output: list[dict[str, object]] = []

    for seed in seeds:
        splitter, groups = _splitter(clean, label_column, group_column, folds, seed)
        split_iterator = splitter.split(clean[text_column], clean[label_column], groups)
        splits = list(split_iterator)
        for feature_name in feature_sets:
            for model_name in model_names:
                if model_name == "majority" and feature_name != feature_sets[0]:
                    continue
                for fold_index, (train_index, test_index) in enumerate(splits, start=1):
                    train, test = clean.iloc[train_index], clean.iloc[test_index]
                    pipeline = build_pipeline(
                        feature_name,
                        model_name,
                        seed,
                        imbalance_strategy=(
                            "baseline" if model_name == "majority" else "class_weight"
                        ),
                    )
                    started = time.perf_counter()
                    pipeline.fit(train[text_column], train[label_column])
                    predicted = pipeline.predict(test[text_column])
                    runtime = time.perf_counter() - started
                    macro_f1 = f1_score(test[label_column], predicted, labels=LABELS, average="macro", zero_division=0)
                    weighted_f1 = f1_score(test[label_column], predicted, labels=LABELS, average="weighted", zero_division=0)
                    accuracy = accuracy_score(test[label_column], predicted)
                    folds_output.append(
                        {
                            "seed": seed,
                            "fold": fold_index,
                            "feature_set": feature_name,
                            "model": model_name,
                            "train_size": len(train),
                            "test_size": len(test),
                            "macro_f1": macro_f1,
                            "weighted_f1": weighted_f1,
                            "accuracy": accuracy,
                            "runtime_seconds": runtime,
                        }
                    )
                    precision, recall, class_f1, _ = precision_recall_fscore_support(
                        test[label_column], predicted, labels=LABELS, zero_division=0
                    )
                    per_class = {
                        label: {"precision": float(precision[i]), "recall": float(recall[i]), "f1": float(class_f1[i])}
                        for i, label in enumerate(LABELS)
                    }
                    for row_position, true_label, predicted_label in zip(test_index, test[label_column], predicted):
                        predictions.append(
                            {
                                "row_index": int(row_position),
                                "seed": seed,
                                "fold": fold_index,
                                "feature_set": feature_name,
                                "model": model_name,
                                "true_label": true_label,
                                "predicted_label": predicted_label,
                                "per_class_metrics_for_fold": json.dumps(per_class, sort_keys=True),
                            }
                        )

    fold_frame = pd.DataFrame(folds_output)
    summary = (
        fold_frame.groupby(["feature_set", "model"], as_index=False)
        .agg(
            macro_f1_mean=("macro_f1", "mean"),
            macro_f1_std=("macro_f1", "std"),
            weighted_f1_mean=("weighted_f1", "mean"),
            accuracy_mean=("accuracy", "mean"),
            runtime_seconds_mean=("runtime_seconds", "mean"),
            evaluated_folds=("fold", "count"),
        )
        .sort_values("macro_f1_mean", ascending=False)
    )
    metadata: dict[str, object] = {
        "observations": len(clean),
        "class_distribution": clean[label_column].value_counts().reindex(LABELS, fill_value=0).to_dict(),
        "seeds": seeds,
        "requested_folds": folds,
        "group_column": group_column if group_column in clean.columns else None,
        "python": platform.python_version(),
        "scikit_learn": sklearn.__version__,
        "fixed_hyperparameters": True,
    }
    return summary, fold_frame, pd.DataFrame(predictions), metadata


def run_fixed_split_experiment(
    frame: pd.DataFrame,
    text_column: str = "lyrics",
    label_column: str = "emotion",
    group_column: str | None = "artist",
    id_column: str = "case_id",
    split_column: str = "split",
    seed: int = 42,
    feature_sets: list[str] | None = None,
    model_names: list[str] | None = None,
    imbalance_strategies: list[str] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame, dict[str, object]]:
    """Evaluate classical configurations on one predeclared shared partition."""

    clean = validate_fixed_partition(
        frame,
        text_column=text_column,
        label_column=label_column,
        group_column=group_column,
        split_column=split_column,
    )
    if id_column == "case_id" and id_column not in clean.columns:
        if "corpus_song_id" not in clean.columns:
            raise ValueError("Fixed partition requires case_id")
        clean["case_id"] = clean["corpus_song_id"]
    feature_sets = feature_sets or ["character_tfidf", "word_tfidf", "combined_tfidf"]
    model_names = model_names or ["majority", "multinomial_nb", "logistic_regression", "linear_svm"]
    imbalance_strategies = imbalance_strategies or ["class_weight"]
    invalid_strategies = sorted(set(imbalance_strategies).difference(IMBALANCE_STRATEGIES))
    if invalid_strategies:
        raise ValueError(f"Unknown imbalance strategies: {invalid_strategies}")
    train = clean.loc[clean[split_column] == "train"]
    learning_curve_fraction: float | None = None
    if "learning_curve_fraction" in clean.columns:
        fractions = clean["learning_curve_fraction"].dropna().unique()
        if len(fractions) != 1 or not 0 < float(fractions[0]) <= 1:
            raise ValueError("learning_curve_fraction must contain one value in (0, 1]")
        learning_curve_fraction = float(fractions[0])
    training_groups = (
        int(train[group_column].nunique())
        if group_column and group_column in train.columns
        else None
    )
    training_songs = (
        int(train["corpus_song_id"].nunique())
        if "corpus_song_id" in train.columns
        else None
    )
    metrics_rows: list[dict[str, object]] = []
    predictions: list[dict[str, object]] = []

    for feature_name in feature_sets:
        for model_name in model_names:
            if model_name == "majority" and feature_name != feature_sets[0]:
                continue
            for imbalance_strategy in imbalance_strategies:
                if model_name == "majority" and imbalance_strategy != "baseline":
                    continue
                if model_name == "multinomial_nb" and imbalance_strategy == "class_weight":
                    continue
                pipeline = build_pipeline(
                    feature_name,
                    model_name,
                    seed,
                    imbalance_strategy=imbalance_strategy,
                )
                fit_started = time.perf_counter()
                pipeline.fit(train[text_column], train[label_column])
                fit_seconds = time.perf_counter() - fit_started
                resampled_counts = expected_resampled_counts(
                    train[label_column], imbalance_strategy
                )
                model_key = (
                    f"classical::{feature_name}::{model_name}::{imbalance_strategy}"
                )
                for evaluation_split in ["validation", "test"]:
                    evaluation = clean.loc[clean[split_column] == evaluation_split]
                    prediction_started = time.perf_counter()
                    predicted = pipeline.predict(evaluation[text_column])
                    prediction_seconds = time.perf_counter() - prediction_started
                    precision, recall, class_f1, _ = precision_recall_fscore_support(
                        evaluation[label_column],
                        predicted,
                        labels=LABELS,
                        zero_division=0,
                    )
                    metrics_rows.append(
                        {
                            "seed": seed,
                            "feature_set": feature_name,
                            "model": model_name,
                            "model_key": model_key,
                            "imbalance_strategy": imbalance_strategy,
                            "evaluation_split": evaluation_split,
                            "train_size": len(train),
                            "effective_train_size": sum(resampled_counts.values()),
                            "evaluation_size": len(evaluation),
                            "macro_f1": f1_score(
                                evaluation[label_column],
                                predicted,
                                labels=LABELS,
                                average="macro",
                                zero_division=0,
                            ),
                            "weighted_f1": f1_score(
                                evaluation[label_column],
                                predicted,
                                labels=LABELS,
                                average="weighted",
                                zero_division=0,
                            ),
                            "accuracy": accuracy_score(
                                evaluation[label_column], predicted
                            ),
                            "balanced_accuracy": balanced_accuracy_score(
                                evaluation[label_column], predicted
                            ),
                            "fit_seconds": fit_seconds,
                            "prediction_seconds": prediction_seconds,
                            **{
                                f"effective_train_{label}": resampled_counts[label]
                                for label in LABELS
                            },
                            **{
                                f"{label}_{metric}": float(values[index])
                                for index, label in enumerate(LABELS)
                                for metric, values in [
                                    ("precision", precision),
                                    ("recall", recall),
                                    ("f1", class_f1),
                                ]
                            },
                        }
                    )
                    for row_position, true_label, predicted_label in zip(
                        evaluation.index,
                        evaluation[label_column],
                        predicted,
                    ):
                        record: dict[str, object] = {
                            "row_index": int(row_position),
                            "seed": seed,
                            "feature_set": feature_name,
                            "model": model_name,
                            "model_key": model_key,
                            "imbalance_strategy": imbalance_strategy,
                            "evaluation_split": evaluation_split,
                            "true_label": true_label,
                            "predicted_label": predicted_label,
                            "training_rows": len(train),
                            "effective_training_rows": sum(resampled_counts.values()),
                            "training_songs": training_songs,
                            "training_groups": training_groups,
                        }
                        for trace_column in [
                            id_column,
                            "corpus_song_id",
                            "section_type",
                            "section_index",
                            "occurrence_count",
                            "partition_seed",
                            "outer_fold",
                            "learning_curve_fraction",
                        ]:
                            if trace_column in evaluation.columns:
                                record[trace_column] = evaluation.loc[row_position, trace_column]
                        predictions.append(record)

    metadata: dict[str, object] = {
        "observations": len(clean),
        "split_sizes": clean[split_column].value_counts().reindex(
            ["train", "validation", "test"],
            fill_value=0,
        ).to_dict(),
        "class_counts": {
            split_name: clean.loc[clean[split_column] == split_name, label_column]
            .value_counts()
            .reindex(LABELS, fill_value=0)
            .to_dict()
            for split_name in ["train", "validation", "test"]
        },
        "seed": seed,
        "group_column": group_column if group_column in clean.columns else None,
        "python": platform.python_version(),
        "scikit_learn": sklearn.__version__,
        "imbalanced_learn": imblearn.__version__,
        "imbalance_strategies": imbalance_strategies,
        "resampling_scope": "training split only",
        "expected_training_class_counts_by_strategy": {
            strategy: expected_resampled_counts(train[label_column], strategy)
            for strategy in imbalance_strategies
        },
        "fixed_hyperparameters": True,
        "shared_fixed_partition": True,
        "learning_curve_fraction": learning_curve_fraction,
        "training_rows": len(train),
        "training_songs": training_songs,
        "training_groups": training_groups,
        "case_id_column": id_column,
        "cluster_unit": "corpus_song_id"
        if "corpus_song_id" in clean.columns
        else id_column,
    }
    for identity_column in ["partition_seed", "outer_fold"]:
        if identity_column in clean.columns:
            values = clean[identity_column].dropna().unique()
            if len(values) == 1:
                metadata[identity_column] = int(values[0])
    return pd.DataFrame(metrics_rows), pd.DataFrame(predictions), metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/classical"))
    parser.add_argument("--text-column", default="lyrics")
    parser.add_argument("--label-column", default="emotion")
    parser.add_argument("--group-column", default="artist")
    parser.add_argument("--id-column", default="case_id")
    parser.add_argument("--folds", type=int, default=5)
    parser.add_argument("--seeds", nargs="+", type=int, default=DEFAULT_SEEDS)
    parser.add_argument(
        "--fixed-split",
        action="store_true",
        help="Use the input split column instead of generating internal cross-validation folds",
    )
    parser.add_argument("--split-column", default="split")
    parser.add_argument(
        "--feature-sets",
        nargs="+",
        choices=["character_tfidf", "word_tfidf", "combined_tfidf"],
    )
    parser.add_argument(
        "--models",
        nargs="+",
        choices=["majority", "multinomial_nb", "logistic_regression", "linear_svm"],
    )
    parser.add_argument(
        "--imbalance-strategies",
        nargs="+",
        choices=IMBALANCE_STRATEGIES,
    )
    args = parser.parse_args()

    frame = pd.read_csv(args.input)
    if args.fixed_split:
        if len(args.seeds) != 1:
            raise ValueError("--fixed-split requires exactly one seed")
        metrics, predictions, metadata = run_fixed_split_experiment(
            frame,
            text_column=args.text_column,
            label_column=args.label_column,
            group_column=args.group_column,
            id_column=args.id_column,
            split_column=args.split_column,
            seed=args.seeds[0],
            feature_sets=args.feature_sets,
            model_names=args.models,
            imbalance_strategies=args.imbalance_strategies,
        )
        metadata["input_sha256"] = file_sha256(args.input)
        args.output_dir.mkdir(parents=True, exist_ok=True)
        metrics.to_csv(args.output_dir / "metrics.csv", index=False, encoding="utf-8-sig")
        predictions.to_csv(args.output_dir / "predictions.csv", index=False, encoding="utf-8-sig")
        (args.output_dir / "run_metadata.json").write_text(
            json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
        )
        print(metrics.to_string(index=False))
        return

    summary, fold_frame, predictions, metadata = run_experiment(
        frame,
        text_column=args.text_column,
        label_column=args.label_column,
        group_column=args.group_column,
        seeds=args.seeds,
        folds=args.folds,
        feature_sets=args.feature_sets,
        model_names=args.models,
    )
    metadata["input_sha256"] = file_sha256(args.input)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    summary.to_csv(args.output_dir / "summary.csv", index=False, encoding="utf-8-sig")
    fold_frame.to_csv(args.output_dir / "fold_metrics.csv", index=False, encoding="utf-8-sig")
    predictions.to_csv(args.output_dir / "out_of_fold_predictions.csv", index=False, encoding="utf-8-sig")
    (args.output_dir / "run_metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(summary.to_string(index=False))


if __name__ == "__main__":
    main()
