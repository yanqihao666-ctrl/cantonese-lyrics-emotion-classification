"""Run the compact expanded-corpus Transformer matrix with resume support."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd

from src.run_experiment_matrix import discover_partitions, validate_partition_grid


MODELS = [
    (
        "hfl/chinese-macbert-base",
        "a986e004d2a7f2a1c2f5a3edef4e20604a974ed1",
        ["baseline", "balanced_loss", "balanced_sampler"],
    ),
    (
        "FacebookAI/xlm-roberta-base",
        "e73636d4f797dec63c3081bb6ed5c7b0bb3f2089",
        ["baseline"],
    ),
]


def now() -> str:
    return datetime.now(timezone.utc).isoformat()


def run_name(model: str, seed: int, fold: int, strategy: str) -> str:
    value = (
        f"{model.replace('/', '__')}__trainseed_{seed}"
        f"__partitionseed_{seed}__fold_{fold}"
    )
    if strategy == "balanced_loss":
        value += "__classweight_balanced"
    elif strategy == "balanced_sampler":
        value += "__sampler_balanced"
    return value


def build_jobs(partitions, output_root: Path) -> list[dict]:
    jobs = []
    for partition in partitions:
        for model, revision, strategies in MODELS:
            for strategy in strategies:
                command = [
                    str(Path(sys.executable).resolve()),
                    "-m",
                    "src.transformer_experiment",
                    partition.path,
                    "--model",
                    model,
                    "--model-revision",
                    revision,
                    "--seed",
                    str(partition.partition_seed),
                    "--max-length",
                    "128",
                    "--epochs",
                    "3",
                    "--batch-size",
                    "8",
                    "--gradient-accumulation-steps",
                    "2",
                    "--discard-model-artifacts",
                    "--output-dir",
                    str((output_root / "runs").resolve()),
                ]
                if strategy == "balanced_loss":
                    command += ["--class-weighting", "balanced"]
                elif strategy == "balanced_sampler":
                    command += ["--sampling-strategy", "balanced"]
                name = run_name(
                    model, partition.partition_seed, partition.outer_fold, strategy
                )
                jobs.append(
                    {
                        "job_id": f"{model.replace('/', '__')}__{strategy}__seed_{partition.partition_seed}__fold_{partition.outer_fold}",
                        "model": model,
                        "model_revision": revision,
                        "strategy": strategy,
                        "seed": partition.partition_seed,
                        "fold": partition.outer_fold,
                        "input": partition.path,
                        "input_sha256": partition.input_sha256,
                        "command": command,
                        "run_dir": str((output_root / "runs" / name).resolve()),
                        "expected": str(
                            (output_root / "runs" / name / "run_metadata.json").resolve()
                        ),
                        "status": "pending",
                    }
                )
    return jobs


def matches(job: dict) -> bool:
    path = Path(job["expected"])
    if not path.exists():
        return False
    metadata = json.loads(path.read_text(encoding="utf-8"))
    return all(
        [
            metadata.get("input_sha256") == job["input_sha256"],
            metadata.get("model") == job["model"],
            metadata.get("model_revision") == job["model_revision"],
            metadata.get("partition_seed") == job["seed"],
            metadata.get("outer_fold") == job["fold"],
            metadata.get("max_length") == 128,
            metadata.get("epochs_requested") == 3,
            metadata.get("batch_size") == 8,
            metadata.get("gradient_accumulation_steps") == 2,
        ]
    )


def write_manifest(path: Path, jobs: list[dict]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps({"updated_at_utc": now(), "jobs": jobs}, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )


def collect(jobs: list[dict], output_csv: Path) -> pd.DataFrame:
    rows = []
    for job in jobs:
        metrics_path = Path(job["run_dir"]) / "metrics.json"
        if not metrics_path.exists():
            continue
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))
        for split in ["validation", "test"]:
            prefix = "validation_" if split == "validation" else "test_"
            values = metrics[split]
            row = {
                "model": job["model"],
                "strategy": job["strategy"],
                "seed": job["seed"],
                "outer_fold": job["fold"],
                "evaluation_split": split,
                "training_seconds": metrics.get("training_seconds_wall_clock"),
            }
            row.update(
                {
                    key.removeprefix(prefix): value
                    for key, value in values.items()
                    if key.startswith(prefix)
                }
            )
            rows.append(row)
    result = pd.DataFrame(rows)
    output_csv.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(output_csv, index=False, encoding="utf-8-sig")
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("partitions_dir", type=Path)
    parser.add_argument("--output-root", type=Path, required=True)
    args = parser.parse_args()

    partitions = discover_partitions(args.partitions_dir)
    validate_partition_grid(partitions)
    output_root = args.output_root.resolve()
    jobs = build_jobs(partitions, output_root)
    manifest = output_root / "matrix.json"
    logs = output_root / "logs"
    logs.mkdir(parents=True, exist_ok=True)
    print(json.dumps({"partitions": len(partitions), "jobs": len(jobs)}, indent=2))
    for job in jobs:
        if matches(job):
            job["status"] = "skipped_existing"
            write_manifest(manifest, jobs)
            continue
        job["status"] = "running"
        job["started_at_utc"] = now()
        write_manifest(manifest, jobs)
        stdout_path = logs / f"{job['job_id']}.stdout.log"
        stderr_path = logs / f"{job['job_id']}.stderr.log"
        with stdout_path.open("w", encoding="utf-8") as stdout, stderr_path.open(
            "w", encoding="utf-8"
        ) as stderr:
            completed = subprocess.run(
                job["command"], cwd=Path.cwd(), stdout=stdout, stderr=stderr, check=False
            )
        job["return_code"] = completed.returncode
        job["completed_at_utc"] = now()
        job["status"] = "completed" if completed.returncode == 0 and matches(job) else "failed"
        write_manifest(manifest, jobs)
        if job["status"] == "failed":
            raise RuntimeError(f"{job['job_id']} failed; inspect {stderr_path}")
    collect(jobs, output_root / "all_metrics.csv")


if __name__ == "__main__":
    main()
