"""Aggregate expanded-corpus and fixed-test project evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
from scipy.stats import wilcoxon
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score

from src.statistical_analysis import add_holm_adjustment, validate_predictions


METRICS = [
    "macro_f1",
    "accuracy",
    "balanced_accuracy",
    "joy_f1",
    "sadness_f1",
    "anger_f1",
    "calmness_f1",
]
LABELS = ["joy", "sadness", "anger", "calmness"]


def aggregate(frame: pd.DataFrame, groups: list[str]) -> pd.DataFrame:
    test = frame.loc[frame["evaluation_split"].eq("test")].copy()
    return test.groupby(groups)[METRICS].agg(["mean", "std"]).reset_index()


def flatten(frame: pd.DataFrame) -> pd.DataFrame:
    result = frame.copy()
    result.columns = [
        "_".join(str(value) for value in column if value).rstrip("_")
        if isinstance(column, tuple)
        else column
        for column in result.columns
    ]
    return result


def paired_delta(
    frame: pd.DataFrame,
    *,
    configuration_columns: list[str],
    cohort_column: str = "training_cohort",
) -> pd.DataFrame:
    test = frame.loc[frame["evaluation_split"].eq("test")].copy()
    index = configuration_columns + ["seed", "outer_fold"]
    pivot = test.pivot_table(index=index, columns=cohort_column, values=METRICS)
    rows = []
    for configuration, group in pivot.groupby(level=configuration_columns):
        configuration = configuration if isinstance(configuration, tuple) else (configuration,)
        row = dict(zip(configuration_columns, configuration))
        for metric in METRICS:
            small = group[(metric, "small_680")]
            large = group[(metric, "expanded_train")]
            delta = large - small
            row[f"{metric}_small_mean"] = float(small.mean())
            row[f"{metric}_expanded_mean"] = float(large.mean())
            row[f"{metric}_mean_delta"] = float(delta.mean())
            if metric == "macro_f1":
                try:
                    row["macro_f1_wilcoxon_p_descriptive"] = float(
                        wilcoxon(large, small).pvalue
                    )
                except ValueError:
                    row["macro_f1_wilcoxon_p_descriptive"] = None
        rows.append(row)
    return pd.DataFrame(rows)


def select_classical_by_validation(frame: pd.DataFrame) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Select one classical configuration per partition without reading test scores."""
    data = frame.copy()
    data["configuration"] = (
        data["feature_set"].astype(str)
        + " | "
        + data["model"].astype(str)
        + " | "
        + data["imbalance_strategy"].astype(str)
    )
    validation = data.loc[data["evaluation_split"].eq("validation")].copy()
    selected = (
        validation.sort_values(
            ["seed", "outer_fold", "macro_f1", "configuration"],
            ascending=[True, True, False, True],
            kind="stable",
        )
        .groupby(["seed", "outer_fold"], as_index=False)
        .first()[["seed", "outer_fold", "configuration", "macro_f1"]]
        .rename(columns={"macro_f1": "validation_macro_f1"})
    )
    test = data.loc[data["evaluation_split"].eq("test")].merge(
        selected,
        on=["seed", "outer_fold", "configuration"],
        how="inner",
        validate="one_to_one",
    )
    if len(test) != 15:
        raise ValueError(f"Expected 15 validation-selected classical tests, found {len(test)}")
    test["primary_model"] = "Classical ML (validation-selected)"
    return test, selected


def paired_primary_deltas(frame: pd.DataFrame) -> pd.DataFrame:
    """Describe paired partition differences among the three primary model families."""
    models = sorted(frame["primary_model"].unique())
    rows = []
    for left_index, left in enumerate(models):
        for right in models[left_index + 1 :]:
            pair = frame.loc[frame["primary_model"].isin([left, right])].pivot_table(
                index=["seed", "outer_fold"], columns="primary_model", values=METRICS
            )
            if len(pair) != 15:
                raise ValueError(f"Unequal primary coverage for {left} and {right}")
            row = {"left_model": left, "right_model": right, "partitions": len(pair)}
            for metric in METRICS:
                delta = pair[(metric, right)] - pair[(metric, left)]
                row[f"{metric}_right_minus_left_mean"] = float(delta.mean())
                if metric == "macro_f1":
                    try:
                        row["macro_f1_wilcoxon_p_descriptive"] = float(
                            wilcoxon(pair[(metric, right)], pair[(metric, left)]).pvalue
                        )
                    except ValueError:
                        row["macro_f1_wilcoxon_p_descriptive"] = None
            rows.append(row)
    return pd.DataFrame(rows)


def paired_imbalance_tests(
    frame: pd.DataFrame,
    *,
    family: str,
    strategy_column: str,
    planned_pairs: list[tuple[str, str]],
) -> pd.DataFrame:
    test = frame.loc[frame["evaluation_split"].eq("test")].copy()
    if "outer_fold" not in test.columns:
        if "source_path" not in test.columns:
            raise ValueError("Imbalance results require outer_fold or source_path")
        test["outer_fold"] = pd.to_numeric(
            test["source_path"].astype(str).str.extract(r"fold_(\d+)")[0],
            errors="raise",
        ).astype(int)
    rows = []
    for left, right in planned_pairs:
        pivot = test.loc[test[strategy_column].isin([left, right])].pivot_table(
            index=["seed", "outer_fold"],
            columns=strategy_column,
            values="macro_f1",
        )
        if len(pivot) != 15 or pivot[[left, right]].isna().any().any():
            raise ValueError(f"Incomplete imbalance pair: {family}/{left}/{right}")
        delta = pivot[right] - pivot[left]
        try:
            p_value = float(wilcoxon(pivot[right], pivot[left]).pvalue)
        except ValueError:
            p_value = 1.0
        rows.append(
            {
                "family": family,
                "left_strategy": left,
                "right_strategy": right,
                "mean_macro_f1_left": float(pivot[left].mean()),
                "mean_macro_f1_right": float(pivot[right].mean()),
                "mean_delta_right_minus_left": float(delta.mean()),
                "right_wins": int(delta.gt(0).sum()),
                "ties": int(delta.eq(0).sum()),
                "left_wins": int(delta.lt(0).sum()),
                "p_value_two_sided": p_value,
            }
        )
    return add_holm_adjustment(pd.DataFrame(rows))


def collect_classical_full(root: Path) -> pd.DataFrame:
    frames = []
    for path in sorted(root.glob("classical/seed_*_fold_*/metrics.csv")):
        fold = int(path.parent.name.rsplit("_", 1)[-1])
        frames.append(pd.read_csv(path).assign(outer_fold=fold))
    if not frames:
        raise FileNotFoundError(f"No classical metrics under {root}")
    return pd.concat(frames, ignore_index=True)


def collect_classical_baselines(root: Path) -> pd.DataFrame:
    frames = []
    for path in sorted(root.glob("seed_*_fold_*/metrics.csv")):
        fold = int(path.parent.name.rsplit("_", 1)[-1])
        frames.append(pd.read_csv(path).assign(outer_fold=fold))
    if not frames:
        raise FileNotFoundError(f"No baseline classical metrics under {root}")
    return pd.concat(frames, ignore_index=True)


def collect_selected_classical_predictions(
    roots: list[Path], selection: pd.DataFrame
) -> pd.DataFrame:
    """Materialise test predictions for the validation-selected configuration."""
    selected = selection.rename(columns={"seed": "partition_seed"})[
        ["partition_seed", "outer_fold", "configuration"]
    ]
    frames = []
    for root in roots:
        for path in sorted(root.rglob("predictions.csv")):
            predictions = pd.read_csv(path)
            required = {
                "partition_seed",
                "outer_fold",
                "feature_set",
                "model",
                "imbalance_strategy",
                "evaluation_split",
            }
            if not required.issubset(predictions.columns):
                continue
            predictions = predictions.loc[
                predictions["evaluation_split"].eq("test")
            ].copy()
            predictions["configuration"] = (
                predictions["feature_set"].astype(str)
                + " | "
                + predictions["model"].astype(str)
                + " | "
                + predictions["imbalance_strategy"].astype(str)
            )
            frames.append(
                predictions.merge(
                    selected,
                    on=["partition_seed", "outer_fold", "configuration"],
                    how="inner",
                )
            )
    if not frames:
        raise FileNotFoundError("No validation-selected classical predictions found")
    result = pd.concat(frames, ignore_index=True)
    result["source_model_key"] = result["model_key"]
    result["model_key"] = "classical::validation_selected"
    return result


def collect_primary_transformer_predictions(matrix_path: Path) -> pd.DataFrame:
    payload = json.loads(matrix_path.read_text(encoding="utf-8"))
    frames = []
    for job in payload["jobs"]:
        if job["strategy"] != "baseline" or job["model"] not in {
            "hfl/chinese-macbert-base",
            "FacebookAI/xlm-roberta-base",
        }:
            continue
        path = Path(job["run_dir"]) / "test_predictions.csv"
        if not path.exists():
            raise FileNotFoundError(path)
        frames.append(pd.read_csv(path))
    if len(frames) != 30:
        raise ValueError(f"Expected 30 primary Transformer prediction files, found {len(frames)}")
    return pd.concat(frames, ignore_index=True)


def plot_macro(summary: pd.DataFrame, label_column: str, output: Path) -> None:
    ordered = summary.sort_values("macro_f1_mean")
    fig, ax = plt.subplots(figsize=(9, max(4.5, len(ordered) * 0.48)))
    ax.barh(
        ordered[label_column],
        ordered["macro_f1_mean"],
        xerr=ordered["macro_f1_std"],
        color="#345995",
        alpha=0.9,
    )
    ax.set_xlabel("Test Macro-F1 (mean ± SD across 15 partitions)")
    ax.set_xlim(0, max(0.75, float(ordered["macro_f1_mean"].max()) + 0.1))
    ax.grid(axis="x", alpha=0.2)
    fig.tight_layout()
    fig.savefig(output, dpi=180)
    plt.close(fig)


def plot_class_distribution(frame: pd.DataFrame, output: Path) -> None:
    counts = frame["emotion"].value_counts().reindex(
        ["joy", "sadness", "anger", "calmness"], fill_value=0
    )
    fig, ax = plt.subplots(figsize=(7.5, 4.5))
    bars = ax.bar(counts.index, counts.values, color=["#F4B942", "#345995", "#C44536", "#6C8EAD"])
    ax.bar_label(bars, padding=3)
    ax.set_ylabel("Lyric sections")
    ax.set_title("Frozen 6,000-section label distribution")
    ax.grid(axis="y", alpha=0.2)
    fig.tight_layout()
    fig.savefig(output, dpi=180)
    plt.close(fig)


def plot_primary_confusions(predictions: pd.DataFrame, output: Path) -> None:
    model_order = [
        "classical::validation_selected",
        "transformer::hfl/chinese-macbert-base",
        "transformer::FacebookAI/xlm-roberta-base",
    ]
    titles = ["Classical ML", "Chinese MacBERT", "XLM-R"]
    fig, axes = plt.subplots(1, 3, figsize=(13.5, 4.2), constrained_layout=True)
    for axis, model, title in zip(axes, model_order, titles):
        part = predictions.loc[predictions["model_key"].eq(model)]
        matrix = confusion_matrix(
            part["true_label"],
            part["predicted_label"],
            labels=LABELS,
            normalize="true",
        )
        image = axis.imshow(matrix, vmin=0, vmax=1, cmap="Blues")
        for row in range(4):
            for column in range(4):
                axis.text(
                    column,
                    row,
                    f"{matrix[row, column]:.2f}",
                    ha="center",
                    va="center",
                    color="white" if matrix[row, column] > 0.55 else "black",
                    fontsize=8,
                )
        axis.set_xticks(range(4), ["joy", "sad", "anger", "calm"], rotation=35, ha="right")
        axis.set_yticks(range(4), ["joy", "sad", "anger", "calm"])
        axis.set_title(title)
        axis.set_xlabel("Predicted")
    axes[0].set_ylabel("True label")
    fig.colorbar(image, ax=axes, shrink=0.82, label="Row-normalised share")
    fig.savefig(output, dpi=180)
    plt.close(fig)


def grouped_prediction_performance(
    predictions: pd.DataFrame, group_column: str
) -> pd.DataFrame:
    rows = []
    for (model, group), part in predictions.groupby(["model_key", group_column], dropna=False):
        rows.append(
            {
                "model_key": model,
                group_column: group,
                "prediction_rows": len(part),
                "unique_cases": int(part["case_id"].nunique()),
                "macro_f1_pooled_descriptive": f1_score(
                    part["true_label"],
                    part["predicted_label"],
                    labels=LABELS,
                    average="macro",
                    zero_division=0,
                ),
                "accuracy_pooled_descriptive": accuracy_score(
                    part["true_label"], part["predicted_label"]
                ),
            }
        )
    return pd.DataFrame(rows)


def plot_fixed_test_comparison(
    transformer: pd.DataFrame,
    classical: pd.DataFrame,
    output: Path,
) -> None:
    transformer_test = transformer.loc[transformer["evaluation_split"].eq("test")].copy()
    classical_test = classical.loc[
        classical["evaluation_split"].eq("test")
        & classical["imbalance_strategy"].eq("moderate_undersampling")
    ].copy()
    panels = [
        (transformer_test, "MacBERT baseline"),
        (classical_test, "Classical SVM + undersampling"),
    ]
    fig, axes = plt.subplots(1, 2, figsize=(10.5, 4.8), sharey=True)
    for axis, (frame, title) in zip(axes, panels):
        pivot = frame.pivot_table(
            index=["seed", "outer_fold"],
            columns="training_cohort",
            values="macro_f1",
        )
        for _, row in pivot.iterrows():
            axis.plot(
                [0, 1],
                [row["small_680"], row["expanded_train"]],
                color="#8FAAC0",
                marker="o",
                alpha=0.65,
                linewidth=1.0,
            )
        means = [pivot["small_680"].mean(), pivot["expanded_train"].mean()]
        axis.plot(
            [0, 1],
            means,
            color="#C44536",
            marker="D",
            markersize=7,
            linewidth=3,
            label="Mean",
        )
        axis.set_xticks([0, 1], ["Small training", "Expanded training"])
        axis.set_title(title)
        axis.grid(axis="y", alpha=0.2)
        axis.legend(loc="lower right")
    axes[0].set_ylabel("Test Macro-F1")
    fig.suptitle("Fixed-test effect of expanding the training corpus")
    fig.tight_layout()
    fig.savefig(output, dpi=180)
    plt.close(fig)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("project_root", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    output = root / "results" / "consensus_final_6000" / "analysis"
    output.mkdir(parents=True, exist_ok=True)

    classical_full = collect_classical_full(
        root / "results" / "consensus_final_6000" / "classical_full"
    )
    classical_baselines = collect_classical_baselines(
        root / "results" / "consensus_final_6000" / "classical_baselines"
    )
    classical_full = pd.concat([classical_full, classical_baselines], ignore_index=True)
    classical_full_summary = flatten(
        aggregate(classical_full, ["feature_set", "model", "imbalance_strategy"])
    )
    classical_full_summary["configuration"] = (
        classical_full_summary["feature_set"].astype(str)
        + " | "
        + classical_full_summary["model"].astype(str)
        + " | "
        + classical_full_summary["imbalance_strategy"].astype(str)
    )
    classical_full_summary.to_csv(output / "expanded_classical_summary.csv", index=False)
    selected_classical, classical_selection = select_classical_by_validation(classical_full)
    selected_classical.to_csv(
        output / "classical_validation_selected_test_metrics.csv", index=False
    )
    classical_selection.to_csv(output / "classical_validation_selection.csv", index=False)

    classical_imbalance = pd.read_csv(
        root / "results" / "consensus_final_6000" / "imbalance" / "classical_all_metrics.csv"
    )
    imbalance_summary = flatten(aggregate(classical_imbalance, ["imbalance_strategy"]))
    imbalance_summary.to_csv(output / "expanded_classical_imbalance_summary.csv", index=False)
    classical_imbalance_tests = paired_imbalance_tests(
        classical_imbalance,
        family="classical",
        strategy_column="imbalance_strategy",
        planned_pairs=[
            ("baseline", "class_weight"),
            ("baseline", "random_oversampling"),
            ("baseline", "smote"),
            ("baseline", "moderate_undersampling"),
        ],
    )

    transformers = pd.read_csv(
        root / "results" / "consensus_final_6000" / "transformer_matrix" / "all_metrics.csv"
    )
    transformer_summary = flatten(aggregate(transformers, ["model", "strategy"]))
    transformer_summary["configuration"] = (
        transformer_summary["model"] + " | " + transformer_summary["strategy"]
    )
    transformer_summary.to_csv(output / "expanded_transformer_summary.csv", index=False)
    transformer_imbalance_tests = paired_imbalance_tests(
        transformers.loc[transformers["model"].eq("hfl/chinese-macbert-base")],
        family="transformer",
        strategy_column="strategy",
        planned_pairs=[
            ("baseline", "balanced_loss"),
            ("baseline", "balanced_sampler"),
            ("balanced_loss", "balanced_sampler"),
        ],
    )
    imbalance_tests = pd.concat(
        [classical_imbalance_tests, transformer_imbalance_tests], ignore_index=True
    )
    imbalance_tests.to_csv(output / "imbalance_paired_tests.csv", index=False)

    primary_transformers = transformers.loc[
        transformers["evaluation_split"].eq("test")
        & transformers["strategy"].eq("baseline")
        & transformers["model"].isin(
            ["hfl/chinese-macbert-base", "FacebookAI/xlm-roberta-base"]
        )
    ].copy()
    primary_transformers["primary_model"] = primary_transformers["model"].map(
        {
            "hfl/chinese-macbert-base": "Chinese MacBERT",
            "FacebookAI/xlm-roberta-base": "XLM-R",
        }
    )
    primary = pd.concat(
        [selected_classical, primary_transformers], ignore_index=True, sort=False
    )
    primary_summary = flatten(aggregate(primary, ["primary_model"]))
    primary_summary.to_csv(output / "primary_family_summary.csv", index=False)
    primary_deltas = paired_primary_deltas(primary)
    primary_deltas.to_csv(output / "primary_family_paired_deltas.csv", index=False)

    classical_predictions = collect_selected_classical_predictions(
        [
            root / "results" / "consensus_final_6000" / "classical_full",
            root / "results" / "consensus_final_6000" / "classical_baselines",
        ],
        classical_selection,
    )
    transformer_predictions = collect_primary_transformer_predictions(
        root / "results" / "consensus_final_6000" / "transformer_matrix" / "matrix.json"
    )
    primary_predictions = validate_predictions(
        pd.concat([classical_predictions, transformer_predictions], ignore_index=True)
    )
    coverage = primary_predictions.groupby("model_key").size()
    if len(coverage) != 3 or coverage.nunique() != 1:
        raise ValueError(f"Primary prediction coverage differs: {coverage.to_dict()}")
    primary_predictions.to_csv(
        output / "primary_test_predictions.csv", index=False, encoding="utf-8-sig"
    )
    dataset = pd.read_csv(
        root / "data" / "research_only" / "expanded_6000_consensus_final.csv",
        usecols=["case_id", "emotion", "source_cohort", "consensus_method"],
        low_memory=False,
    )
    plot_class_distribution(dataset, output / "expanded_class_distribution.png")
    enriched_predictions = primary_predictions.merge(
        dataset[["case_id", "source_cohort", "consensus_method"]],
        on="case_id",
        how="left",
        validate="many_to_one",
    )
    grouped_prediction_performance(enriched_predictions, "source_cohort").to_csv(
        output / "performance_by_source_cohort.csv", index=False
    )
    grouped_prediction_performance(enriched_predictions, "consensus_method").to_csv(
        output / "performance_by_label_evidence.csv", index=False
    )
    plot_primary_confusions(
        primary_predictions, output / "primary_confusion_matrices_normalised.png"
    )

    fixed_classical = pd.read_csv(
        root / "results" / "consensus_final_fixed_size" / "classical_all_metrics.csv"
    )
    fixed_classical_summary = flatten(
        aggregate(fixed_classical, ["training_cohort", "imbalance_strategy"])
    )
    fixed_classical_summary.to_csv(output / "fixed_test_classical_summary.csv", index=False)
    fixed_classical_delta = paired_delta(
        fixed_classical, configuration_columns=["imbalance_strategy"]
    )
    fixed_classical_delta.to_csv(output / "fixed_test_classical_paired_deltas.csv", index=False)

    fixed_transformer = pd.read_csv(
        root / "results" / "consensus_final_fixed_size" / "transformer_all_metrics.csv"
    )
    fixed_transformer_summary = flatten(
        aggregate(fixed_transformer, ["training_cohort"])
    )
    fixed_transformer_summary.to_csv(output / "fixed_test_transformer_summary.csv", index=False)
    fixed_transformer_delta = paired_delta(
        fixed_transformer.assign(model="MacBERT baseline"),
        configuration_columns=["model"],
    )
    fixed_transformer_delta.to_csv(output / "fixed_test_transformer_paired_deltas.csv", index=False)
    plot_fixed_test_comparison(
        fixed_transformer,
        fixed_classical,
        output / "fixed_test_training_expansion.png",
    )

    combined = pd.concat(
        [
            classical_full_summary[["configuration", "macro_f1_mean", "macro_f1_std"]],
            transformer_summary[["configuration", "macro_f1_mean", "macro_f1_std"]],
        ],
        ignore_index=True,
    )
    plot_macro(combined, "configuration", output / "expanded_model_macro_f1.png")

    best_classical = classical_full_summary.loc[classical_full_summary["macro_f1_mean"].idxmax()]
    best_imbalance = imbalance_summary.loc[imbalance_summary["macro_f1_mean"].idxmax()]
    best_transformer = transformer_summary.loc[transformer_summary["macro_f1_mean"].idxmax()]
    payload = {
        "best_classical_configuration": best_classical["configuration"],
        "best_classical_macro_f1_mean": float(best_classical["macro_f1_mean"]),
        "best_classical_macro_f1_std": float(best_classical["macro_f1_std"]),
        "best_classical_imbalance_strategy": best_imbalance["imbalance_strategy"],
        "best_classical_imbalance_macro_f1_mean": float(best_imbalance["macro_f1_mean"]),
        "best_transformer_configuration": best_transformer["configuration"],
        "best_transformer_macro_f1_mean": float(best_transformer["macro_f1_mean"]),
        "best_transformer_macro_f1_std": float(best_transformer["macro_f1_std"]),
        "primary_family_results": primary_summary.to_dict(orient="records"),
        "primary_family_paired_deltas": primary_deltas.to_dict(orient="records"),
        "imbalance_paired_tests": imbalance_tests.to_dict(orient="records"),
        "model_selection_note": (
            "Classical configuration is selected independently within each partition "
            "using validation Macro-F1 only. Transformer baselines are fixed a priori; "
            "imbalance variants are reported separately."
        ),
        "fixed_test_classical_deltas": fixed_classical_delta.to_dict(orient="records"),
        "fixed_test_transformer_deltas": fixed_transformer_delta.to_dict(orient="records"),
        "statistical_note": (
            "Wilcoxon values are descriptive because repeated cross-validation folds "
            "are not statistically independent."
        ),
        "evaluation_warning": "AI-assisted labels; not independent human gold.",
    }
    (output / "project_result_summary.json").write_text(
        json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(payload, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
