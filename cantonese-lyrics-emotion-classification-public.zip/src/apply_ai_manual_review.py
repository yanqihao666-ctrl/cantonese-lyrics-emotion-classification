"""Apply the disclosed AI semantic review of all no-majority cases.

The labels below were assigned after reading each disputed lyric section in
song context.  The reviewer is still an AI assistant, so reviewed rows remain
ineligible for formal evaluation and retain the human-review flag.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


LABELS = {"joy", "sadness", "anger", "calmness"}
EXPECTED_INPUT_SHA256 = (
    "395f9794af2f8edbc67865f14daba3ccd74e93faf231872c1ab8fa54f8816993"
)

# Labels correspond to the no-majority rows in source-file order.  The exact
# input hash above prevents this auditable decision list from being silently
# applied to a different ordering or version of the data.
REVIEWED_LABELS = (
    # 0-29
    "joy", "sadness", "calmness", "calmness", "joy", "joy", "joy", "joy",
    "joy", "joy", "joy", "sadness", "joy", "joy", "sadness", "joy", "joy",
    "joy", "sadness", "anger", "sadness", "sadness", "sadness", "sadness",
    "sadness", "sadness", "sadness", "joy", "sadness", "joy",
    # 30-59
    "sadness", "joy", "sadness", "sadness", "calmness", "sadness",
    "sadness", "joy", "joy", "sadness", "joy", "sadness", "sadness",
    "calmness", "joy", "sadness", "sadness", "sadness", "joy", "calmness",
    "anger", "joy", "calmness", "calmness", "sadness", "sadness",
    "calmness", "calmness", "calmness", "calmness",
    # 60-89
    "sadness", "sadness", "sadness", "sadness", "sadness", "sadness",
    "joy", "sadness", "sadness", "joy", "sadness", "sadness", "calmness",
    "calmness", "joy", "joy", "joy", "joy", "joy", "calmness", "joy",
    "calmness", "joy", "joy", "joy", "calmness", "calmness", "calmness",
    "sadness", "sadness",
    # 90-119
    "calmness", "sadness", "sadness", "calmness", "joy", "joy", "joy",
    "joy", "joy", "calmness", "sadness", "anger", "anger", "joy", "joy",
    "joy", "joy", "calmness", "calmness", "joy", "joy", "sadness", "joy",
    "joy", "joy", "joy", "joy", "joy", "sadness", "joy",
    # 120-149
    "sadness", "sadness", "calmness", "calmness", "joy", "anger", "joy",
    "joy", "joy", "sadness", "anger", "anger", "anger", "sadness",
    "sadness", "joy", "joy", "joy", "joy", "joy", "calmness", "joy",
    "joy", "joy", "sadness", "sadness", "sadness", "sadness", "sadness",
    "joy",
    # 150-179
    "joy", "joy", "joy", "joy", "sadness", "sadness", "sadness",
    "sadness", "sadness", "sadness", "anger", "joy", "calmness",
    "calmness", "calmness", "joy", "joy", "calmness", "joy", "calmness",
    "sadness", "calmness", "calmness", "calmness", "anger", "joy", "joy",
    "joy", "joy", "joy",
)

# A second audit targeted rare anger predictions and apparent counterexamples
# in the joy/calmness sets.  Each entry records a changed label only; cases
# judged acceptable are deliberately absent.
QUALITY_CONTROL_OVERRIDES = {
    "C0001-SEC01": ("sadness", "The pledge is framed as an insecure plea in a disappointed love song."),
    "C0001-SEC05": ("sadness", "The exaggerated love-song performance ends in rejection and disbelief."),
    "C0101-SEC02": ("sadness", "The passage centres on emotional distance and failure to understand one another."),
    "C0102-SEC02": ("sadness", "The former pair no longer meet and have moved on to other partners."),
    "C0102-SEC07": ("calmness", "This is a brief, composed acknowledgement of a past relationship."),
    "C0202-SEC06": ("sadness", "Leaving the relationship for mutual relief is resignation, not celebration."),
    "C0302-SEC02": ("joy", "Pride, support and flying imagery make the local affect clearly positive."),
    "C0402-SEC01": ("sadness", "Repeated failure and being relegated to reserve status dominate the devotion."),
    "C0402-SEC04": ("sadness", "The speaker is hurt and sidelined despite remaining loyal."),
    "C0505-SEC07": ("joy", "The chorus is primarily grateful for steadfast love despite self-deprecation."),
    "C0701-SEC04": ("joy", "Home, warmth, care and reunion are explicitly valued."),
    "C0701-SEC07": ("joy", "Home and a caring companion provide explicit comfort and happiness."),
    "C0701-SEC08": ("joy", "The speaker says having the loved one is better than everything else."),
    "C0704-SEC07": ("sadness", "The passage is a distressed plea to restore a deteriorating relationship."),
    "C0802-SEC05": ("sadness", "The section lists a lost love and dismantled home before forced acceptance."),
    "C0802-SEC06": ("sadness", "Giving up the old key is a concise image of loss."),
    "C0804-SEC05": ("sadness", "The hoped-for confession never happens and the pair pass without recognition."),
    "C0805-SEC01": ("anger", "Breathless pursuit and pressure create high-arousal negative affect."),
    "C0904-SEC05": ("sadness", "The adult self feels enslaved and surrounded by evidence of missed chances."),
    "C0904-SEC06": ("sadness", "The letter exposes abandonment of earlier ideals."),
    "C0905-SEC08": ("calmness", "The speaker accepts leaving the stage with dignity and without regret."),
    "C1004-SEC02": ("sadness", "The speaker alone perceives the feeling but cannot attain physical closeness."),
    "C1203-SEC05": ("joy", "The section explicitly recalls carefree nights with close friends."),
    "C1205-SEC06": ("calmness", "Painful growth is processed as reflective acceptance rather than elation."),
    "C1302-SEC03": ("joy", "Sharing, healing and youthful rebellion are positive and energised."),
    "C1302-SEC04": ("joy", "The passage urges wholehearted youthful action without regret."),
    "C1302-SEC06": ("joy", "Freedom from self-imposed limits is expressed as positive encouragement."),
    "C1303-SEC04": ("calmness", "The conventional life path is considered reflectively rather than celebrated."),
    "C1303-SEC05": ("calmness", "The apparent freedom is qualified by pressure to please everyone."),
    "C1304-SEC07": ("anger", "Pride rises explicitly in response to oppression and coercive walls."),
    "C1304-SEC08": ("joy", "The passage turns a disastrous moment into collective hope and confidence."),
    "C1305-SEC04": ("joy", "The speaker values enduring mutual dependence and reconciliation."),
    "C1403-SEC02": ("calmness", "The rhetorical reflection on life is low-arousal and contemplative."),
    "C1405-SEC03": ("joy", "Sweetness, courage and holding on to a shared future dominate."),
    "C1502-SEC04": ("joy", "The section affirms that old ideals and fairy-tale hopes can persist."),
    "C1601-SEC06": ("sadness", "The speaker recalls lowering herself for love and then being abandoned."),
    "C1604-SEC06": ("joy", "The speaker positively reaffirms a childhood aspiration despite hardship."),
    "C1701-SEC01": ("sadness", "Happy family memories are recalled through the pain of a partner's memory loss."),
    "C1701-SEC03": ("sadness", "A tender quarrel is recalled by asking whether the forgetful partner remembers."),
    "C1701-SEC04": ("sadness", "The partner no longer remembers and the speaker is left remembering alone."),
    "C1701-SEC06": ("sadness", "The hope of accompanying the partner to heaven is framed by loss and decline."),
    "C1702-SEC08": ("joy", "Shared courage and hope of return dominate the danger imagery."),
    "C1802-SEC01": ("joy", "The couple's enduring companionship and open declaration of love are positive."),
    "C1802-SEC04": ("joy", "Lifelong commitment and a shared home provide secure positive affect."),
    "C1904-SEC03": ("joy", "The passage imagines lifelong and repeated future intimacy."),
    "C2002-SEC06": ("sadness", "The very short question foregrounds exhaustion in a cold night."),
    "C2003-SEC01": ("joy", "Companionship, kindness and renewed faith overcome catastrophe."),
    "C2005-SEC09": ("joy", "Mutual navigation and reassurance overcome storms and fear."),
}


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def apply_manual_ai_review(
    frame: pd.DataFrame,
    quality_control_overrides: dict[str, tuple[str, str]] | None = None,
) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Return the complete reviewed frame and a compact override audit table."""
    if len(frame) != 680 or frame["case_id"].duplicated().any():
        raise ValueError("Expected exactly 680 unique cases")
    mask = frame["consensus_method"].str.startswith("no_majority", na=False)
    review_indices = frame.index[mask].tolist()
    if len(review_indices) != len(REVIEWED_LABELS):
        raise ValueError(
            f"Expected {len(REVIEWED_LABELS)} no-majority cases, found "
            f"{len(review_indices)}"
        )
    if set(REVIEWED_LABELS) - LABELS:
        raise ValueError("Review decision list contains an invalid label")

    result = frame.copy()
    result["pre_manual_review_label"] = result["ai_label"]
    result["manual_ai_reviewed"] = False
    result["manual_ai_review_label"] = ""
    result["manual_ai_reviewer"] = ""
    result["manual_ai_review_note"] = ""
    result["manual_ai_review_stage"] = ""

    review_time = datetime.now(timezone.utc).isoformat()
    reviewer = "OpenAI Codex (AI semantic reviewer)"
    note = (
        "AI semantic review after reading the disputed section and researched "
        "song context; this is not an independent human gold label."
    )
    for row_index, reviewed_label in zip(review_indices, REVIEWED_LABELS, strict=True):
        result.at[row_index, "ai_label"] = reviewed_label
        result.at[row_index, "ai_confidence_1_to_5"] = 3
        result.at[row_index, "consensus_method"] = "manual_ai_review_of_no_majority"
        result.at[row_index, "manual_ai_reviewed"] = True
        result.at[row_index, "manual_ai_review_label"] = reviewed_label
        result.at[row_index, "manual_ai_reviewer"] = reviewer
        result.at[row_index, "manual_ai_review_note"] = note
        result.at[row_index, "manual_ai_review_stage"] = "no_majority_full_review"
        result.at[row_index, "needs_human_review"] = True
        result.at[row_index, "formal_evaluation_eligible"] = False

    qc_overrides = (
        QUALITY_CONTROL_OVERRIDES
        if quality_control_overrides is None
        else quality_control_overrides
    )
    missing_qc_cases = set(qc_overrides) - set(result["case_id"])
    if missing_qc_cases:
        raise ValueError(f"QC override cases not found: {sorted(missing_qc_cases)}")
    for case_id, (reviewed_label, qc_note) in qc_overrides.items():
        row_index = result.index[result["case_id"].eq(case_id)].item()
        previous_label = str(result.at[row_index, "ai_label"])
        if previous_label == reviewed_label:
            raise ValueError(f"QC override for {case_id} does not change its label")
        result.at[row_index, "ai_label"] = reviewed_label
        result.at[row_index, "ai_confidence_1_to_5"] = 3
        result.at[row_index, "consensus_method"] = "manual_ai_semantic_audit_override"
        result.at[row_index, "manual_ai_reviewed"] = True
        result.at[row_index, "manual_ai_review_label"] = reviewed_label
        result.at[row_index, "manual_ai_reviewer"] = reviewer
        result.at[row_index, "manual_ai_review_note"] = qc_note
        result.at[row_index, "manual_ai_review_stage"] = "targeted_semantic_qc"
        result.at[row_index, "needs_human_review"] = True
        result.at[row_index, "formal_evaluation_eligible"] = False

    result["label_status"] = "ai_research_assisted_preannotation_only"
    result["annotator_type"] = "AI research-assisted pre-annotation"
    result["manual_ai_review_completed_at_utc"] = review_time

    overrides = result.loc[
        result["manual_ai_reviewed"],
        [
            "case_id",
            "corpus_song_id",
            "title",
            "artist",
            "lyrics",
            "pre_manual_review_label",
            "manual_ai_review_label",
            "nli_vote",
            "qwen_direct_vote",
            "qwen_strict_vote",
            "manual_ai_reviewer",
            "manual_ai_review_note",
            "manual_ai_review_stage",
        ],
    ].copy()
    return result, overrides


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--overrides-output", type=Path, required=True)
    args = parser.parse_args()

    input_hash = sha256(args.input)
    if input_hash != EXPECTED_INPUT_SHA256:
        raise ValueError(
            "The consensus input differs from the manually reviewed version: "
            f"expected {EXPECTED_INPUT_SHA256}, found {input_hash}"
        )
    result, overrides = apply_manual_ai_review(pd.read_csv(args.input))
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.overrides_output.parent.mkdir(parents=True, exist_ok=True)
    result.to_csv(args.output, index=False, encoding="utf-8-sig")
    overrides.to_csv(args.overrides_output, index=False, encoding="utf-8-sig")

    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(result),
        "songs": int(result["corpus_song_id"].nunique()),
        "manual_ai_reviewed_rows": int(result["manual_ai_reviewed"].sum()),
        "label_counts": result["ai_label"].value_counts().to_dict(),
        "confidence_counts": (
            result["ai_confidence_1_to_5"].value_counts().sort_index().to_dict()
        ),
        "needs_human_review": int(result["needs_human_review"].sum()),
        "input_sha256": input_hash,
        "output_sha256": sha256(args.output),
        "overrides_sha256": sha256(args.overrides_output),
        "formal_evaluation_eligible": False,
        "warning": (
            "Research-assisted AI pre-annotation only. It is not independent "
            "human gold and must not be used as the formal test reference."
        ),
    }
    args.output.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
