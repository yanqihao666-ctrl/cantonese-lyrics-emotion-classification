"""Generate auditable AI-assisted candidate labels for the pilot corpus.

Outputs from this module are candidate/silver labels, never human gold labels.
The three prompt variants provide a limited prompt-sensitivity check.
"""

from __future__ import annotations

import argparse
import json
import re
from collections import Counter
from pathlib import Path

import pandas as pd
import torch
from transformers import AutoModelForCausalLM, AutoTokenizer


LABELS = ("joy", "sadness", "anger", "calmness")
MODEL_DEFAULT = "Qwen/Qwen2.5-1.5B-Instruct"

SYSTEM_PROMPTS = [
    (
        "You are a careful Cantonese lyric emotion annotator. Judge only the supplied lyric section, "
        "not melody, singer or imagined whole-song context. Choose exactly one of joy, sadness, anger, calmness. "
        "Return strict JSON with keys label, confidence (1-5), mixed (boolean), rationale_chinese."
    ),
    (
        "你是嚴謹的粵語歌詞研究標註員。只根據所提供歌詞段落中敘事聲音的主導情緒分類，"
        "只可選 joy、sadness、anger、calmness。愛情是主題而不是情緒；不要因為提到愛便選joy。"
        "只輸出JSON：label、confidence（1至5）、mixed、rationale_chinese。"
    ),
    (
        "Classify the dominant expressed emotion in the supplied Cantonese lyric section. Use joy for energetic positive emotion, "
        "sadness for low-energy negative emotion, anger for activated negative emotion, and calmness for "
        "peaceful/accepting positive or non-negative emotion. If emotions compete, still choose the dominant "
        "one and set mixed=true. Output JSON only with label, confidence, mixed, rationale_chinese."
    ),
]


def _extract_json(text: str) -> dict[str, object] | None:
    match = re.search(r"\{.*?\}", text, flags=re.DOTALL)
    if not match:
        return None
    try:
        result = json.loads(match.group(0))
    except json.JSONDecodeError:
        return None
    label = str(result.get("label", "")).strip().lower()
    if label not in LABELS:
        return None
    result["label"] = label
    return result


def _consensus(outputs: list[dict[str, object] | None]) -> tuple[str | None, float, bool]:
    labels = [str(item["label"]) for item in outputs if item]
    if not labels:
        return None, 0.0, False
    counts = Counter(labels)
    label, votes = counts.most_common(1)[0]
    tied = list(counts.values()).count(votes) > 1
    return (None if tied else label), votes / len(SYSTEM_PROMPTS), tied


class SilverLabeler:
    def __init__(self, model_name: str) -> None:
        self.model_name = model_name
        self.tokenizer = AutoTokenizer.from_pretrained(model_name)
        self.model = AutoModelForCausalLM.from_pretrained(
            model_name,
            torch_dtype="auto",
            device_map="auto",
        )
        self.model.eval()

    def label(self, lyrics: str, system_prompt: str) -> tuple[dict[str, object] | None, str]:
        messages = [
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": f"歌詞段落：\n{lyrics}\n\n請只依照這段文字標註。"},
        ]
        prompt = self.tokenizer.apply_chat_template(messages, tokenize=False, add_generation_prompt=True)
        inputs = self.tokenizer(prompt, return_tensors="pt", truncation=True, max_length=2048).to(self.model.device)
        with torch.inference_mode():
            generated = self.model.generate(
                **inputs,
                max_new_tokens=160,
                do_sample=False,
                pad_token_id=self.tokenizer.eos_token_id,
            )
        continuation = generated[0, inputs.input_ids.shape[1] :]
        raw = self.tokenizer.decode(continuation, skip_special_tokens=True).strip()
        return _extract_json(raw), raw


def label_frame(frame: pd.DataFrame, labeler: SilverLabeler) -> pd.DataFrame:
    rows: list[dict[str, object]] = []
    for index, row in frame.iterrows():
        parsed: list[dict[str, object] | None] = []
        raw_outputs: list[str] = []
        for prompt in SYSTEM_PROMPTS:
            result, raw = labeler.label(str(row["lyrics"]), prompt)
            parsed.append(result)
            raw_outputs.append(raw)
        consensus, agreement, tied = _consensus(parsed)
        output = row.to_dict()
        output.update(
            {
                "candidate_label": consensus,
                "candidate_agreement": agreement,
                "candidate_tied": tied,
                "candidate_label_method": f"three-prompt greedy consensus; {labeler.model_name}",
                "candidate_outputs_json": json.dumps(parsed, ensure_ascii=False),
                "candidate_raw_outputs_json": json.dumps(raw_outputs, ensure_ascii=False),
                "label_status": "candidate",
            }
        )
        rows.append(output)
        item_id = row.get("case_id", row.get("corpus_song_id"))
        print(f"[{index + 1}/{len(frame)}] {item_id} -> {consensus} ({agreement:.2f})")
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--model", default=MODEL_DEFAULT)
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    labeler = SilverLabeler(args.model)
    labelled = label_frame(frame, labeler)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    labelled.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"Saved {len(labelled)} candidate-labelled rows to {args.output}")


if __name__ == "__main__":
    main()
