"""Audit the dissertation literature matrix, BibTeX library and in-text citations."""

from __future__ import annotations

import argparse
import csv
import json
import re
import unicodedata
from pathlib import Path
from typing import Iterable


REQUIRED_MATRIX_COLUMNS = {
    "citation_key",
    "title",
    "year",
    "quality_notes",
    "source_url",
}
DEFAULT_CITATION_DOCS = (
    "docs/introduction_draft.md",
    "docs/literature_synthesis.md",
    "docs/emotion_taxonomy_rationale.md",
    "docs/methodology_draft.md",
)
SURNAME = r"[A-ZÀ-ÖØ-Þ][A-Za-zÀ-ÖØ-öø-ÿ'’.-]{1,}"
NARRATIVE_CITATION = re.compile(
    rf"(?P<authors>"
    rf"{SURNAME}(?:,\s+{SURNAME})+\s+and\s+{SURNAME}"
    rf"|{SURNAME}\s+and\s+{SURNAME}"
    rf"|{SURNAME}\s+et al\."
    rf"|{SURNAME}'s"
    rf"|{SURNAME}"
    rf")\s*\((?P<year>(?:19|20)\d{{2}})\)"
)
PARENTHETICAL_YEAR = re.compile(r",\s*((?:19|20)\d{2})\s*$")


class ReferenceAuditError(ValueError):
    """Raised when a reference-library invariant is violated."""


def _normalise_text(value: str) -> str:
    value = value.replace("{", "").replace("}", "")
    value = re.sub(r"\\['\"~^`=.]\s*([A-Za-z])", r"\1", value)
    value = unicodedata.normalize("NFKD", value)
    value = "".join(character for character in value if not unicodedata.combining(character))
    return "".join(character.lower() for character in value if character.isalnum())


def _normalise_surname(value: str) -> str:
    value = value.strip().removesuffix("'s").removesuffix("’s")
    return _normalise_text(value)


def _read_matrix(path: Path) -> dict[str, dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        missing = REQUIRED_MATRIX_COLUMNS.difference(reader.fieldnames or ())
        if missing:
            raise ReferenceAuditError(
                f"Literature matrix is missing columns: {sorted(missing)}"
            )
        rows: dict[str, dict[str, str]] = {}
        for line_number, row in enumerate(reader, start=2):
            key = (row.get("citation_key") or "").strip()
            if not key:
                raise ReferenceAuditError(
                    f"Literature matrix row {line_number} has no citation_key"
                )
            if key in rows:
                raise ReferenceAuditError(f"Duplicate literature-matrix key: {key}")
            for column in REQUIRED_MATRIX_COLUMNS:
                if not (row.get(column) or "").strip():
                    raise ReferenceAuditError(
                        f"Literature matrix key {key} has an empty {column}"
                    )
            if not row["source_url"].startswith("https://"):
                raise ReferenceAuditError(
                    f"Literature matrix key {key} requires an HTTPS source_url"
                )
            if not re.fullmatch(r"(?:19|20)\d{2}", row["year"]):
                raise ReferenceAuditError(
                    f"Literature matrix key {key} has invalid year {row['year']!r}"
                )
            rows[key] = row
    return rows


def _bibtex_blocks(text: str) -> Iterable[tuple[str, str, str]]:
    start_pattern = re.compile(r"@(?P<type>[A-Za-z]+)\s*\{\s*(?P<key>[^,\s]+)\s*,")
    position = 0
    while match := start_pattern.search(text, position):
        opening_brace = text.find("{", match.start())
        depth = 0
        closing_brace = None
        for index in range(opening_brace, len(text)):
            if text[index] == "{":
                depth += 1
            elif text[index] == "}":
                depth -= 1
                if depth == 0:
                    closing_brace = index
                    break
        if closing_brace is None:
            raise ReferenceAuditError(
                f"Unclosed BibTeX entry beginning with {match.group('key')}"
            )
        body_start = text.find(",", opening_brace, closing_brace) + 1
        yield match.group("type").lower(), match.group("key"), text[body_start:closing_brace]
        position = closing_brace + 1


def _read_bibtex(path: Path) -> dict[str, dict[str, str]]:
    text = path.read_text(encoding="utf-8")
    entries: dict[str, dict[str, str]] = {}
    field_pattern = re.compile(
        r"(?m)^\s*(?P<name>[A-Za-z]+)\s*=\s*\{(?P<value>.*)\}\s*,?\s*$"
    )
    for entry_type, key, body in _bibtex_blocks(text):
        if key in entries:
            raise ReferenceAuditError(f"Duplicate BibTeX key: {key}")
        fields = {
            match.group("name").lower(): match.group("value").strip()
            for match in field_pattern.finditer(body)
        }
        fields["entry_type"] = entry_type
        for required in ("author", "title", "year", "url"):
            if not fields.get(required):
                raise ReferenceAuditError(
                    f"BibTeX key {key} is missing required field {required}"
                )
        if not fields["url"].startswith("https://"):
            raise ReferenceAuditError(f"BibTeX key {key} requires an HTTPS URL")
        entries[key] = fields
    if not entries:
        raise ReferenceAuditError("No BibTeX entries were found")
    return entries


def _first_author_surname(author_field: str) -> str:
    first_author = re.split(r"\s+and\s+", author_field, maxsplit=1)[0].strip()
    if "," in first_author:
        return first_author.split(",", maxsplit=1)[0].strip()
    return first_author.split()[-1]


def _audit_search_log(path: Path, matrix_keys: set[str]) -> tuple[int, set[str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        required = {
            "search_date",
            "source",
            "exact_query",
            "status",
            "retained_citation_keys",
        }
        missing = required.difference(reader.fieldnames or ())
        if missing:
            raise ReferenceAuditError(
                f"Literature search log is missing columns: {sorted(missing)}"
            )
        logged_keys: set[str] = set()
        row_count = 0
        for line_number, row in enumerate(reader, start=2):
            row_count += 1
            for column in required:
                if not (row.get(column) or "").strip():
                    raise ReferenceAuditError(
                        f"Literature search-log row {line_number} has an empty {column}"
                    )
            keys = {
                key.strip()
                for key in row["retained_citation_keys"].split(";")
                if key.strip()
            }
            unknown = keys.difference(matrix_keys)
            if unknown:
                raise ReferenceAuditError(
                    f"Literature search-log row {line_number} has unknown keys: "
                    f"{sorted(unknown)}"
                )
            logged_keys.update(keys)
    unlogged = matrix_keys.difference(logged_keys)
    if unlogged:
        raise ReferenceAuditError(
            f"Literature-matrix keys absent from the search log: {sorted(unlogged)}"
        )
    return row_count, logged_keys


def _extract_citations(text: str) -> set[tuple[str, str]]:
    citations: set[tuple[str, str]] = set()
    occupied: list[tuple[int, int]] = []
    for match in NARRATIVE_CITATION.finditer(text):
        authors = match.group("authors")
        first_author = re.split(r",|\s+and\s+|\s+et al\.", authors, maxsplit=1)[0]
        normalised_author = _normalise_surname(first_author)
        if len(normalised_author) > 1:
            citations.add((normalised_author, match.group("year")))
        occupied.append(match.span())

    for opening in re.finditer(r"\(([^()\n]+)\)", text):
        if any(start <= opening.start() < end for start, end in occupied):
            continue
        for part in opening.group(1).split(";"):
            year_match = PARENTHETICAL_YEAR.search(part.strip())
            if not year_match:
                continue
            before_year = part[: year_match.start()].strip()
            first_author_match = re.match(SURNAME, before_year)
            if first_author_match:
                normalised_author = _normalise_surname(first_author_match.group())
                if len(normalised_author) > 1:
                    citations.add((normalised_author, year_match.group(1)))
    return citations


def audit_references(
    matrix_path: Path,
    bibliography_path: Path,
    citation_docs: Iterable[Path] = (),
    search_log_path: Path | None = None,
) -> dict[str, object]:
    matrix = _read_matrix(matrix_path)
    bibliography = _read_bibtex(bibliography_path)

    matrix_keys = set(matrix)
    bibliography_keys = set(bibliography)
    if matrix_keys != bibliography_keys:
        raise ReferenceAuditError(
            "Literature matrix and BibTeX keys differ: "
            f"missing_from_bib={sorted(matrix_keys - bibliography_keys)}, "
            f"missing_from_matrix={sorted(bibliography_keys - matrix_keys)}"
        )

    metadata_mismatches: list[str] = []
    author_year_to_key: dict[tuple[str, str], str] = {}
    for key in sorted(matrix):
        matrix_row = matrix[key]
        bib_entry = bibliography[key]
        if matrix_row["year"] != bib_entry["year"]:
            metadata_mismatches.append(
                f"{key}: year {matrix_row['year']} != {bib_entry['year']}"
            )
        if _normalise_text(matrix_row["title"]) != _normalise_text(bib_entry["title"]):
            metadata_mismatches.append(f"{key}: title differs")
        author_year = (
            _normalise_surname(_first_author_surname(bib_entry["author"])),
            bib_entry["year"],
        )
        if author_year in author_year_to_key:
            other = author_year_to_key[author_year]
            raise ReferenceAuditError(
                f"Ambiguous first-author/year pair {author_year}: {other}, {key}"
            )
        author_year_to_key[author_year] = key
    if metadata_mismatches:
        raise ReferenceAuditError(
            "Matrix/BibTeX metadata mismatch: " + "; ".join(metadata_mismatches)
        )

    search_log_rows = 0
    logged_keys: set[str] = set()
    if search_log_path is not None:
        search_log_rows, logged_keys = _audit_search_log(
            search_log_path, matrix_keys
        )

    citation_docs = tuple(citation_docs)
    discovered: dict[str, list[str]] = {}
    unmatched: list[str] = []
    for doc_path in citation_docs:
        if not doc_path.exists():
            raise ReferenceAuditError(f"Citation document does not exist: {doc_path}")
        for author_year in sorted(_extract_citations(doc_path.read_text(encoding="utf-8"))):
            key = author_year_to_key.get(author_year)
            label = f"{author_year[0]}_{author_year[1]}"
            if key is None:
                unmatched.append(f"{doc_path}:{label}")
            else:
                discovered.setdefault(key, []).append(str(doc_path))
    if unmatched:
        raise ReferenceAuditError(
            "In-text citations without a matching BibTeX first-author/year entry: "
            + "; ".join(unmatched)
        )

    return {
        "status": "pass",
        "matrix_entries": len(matrix),
        "bibliography_entries": len(bibliography),
        "citation_documents": len(citation_docs),
        "cited_bibliography_entries": len(discovered),
        "uncited_matrix_entries": sorted(matrix_keys.difference(discovered)),
        "search_log_rows": search_log_rows,
        "search_logged_entries": len(logged_keys),
        "preprint_entries": sorted(
            key
            for key, row in matrix.items()
            if "preprint" in row["venue"].lower()
            or "preprint" in row["quality_notes"].lower()
        ),
    }


def _parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--matrix", type=Path, default=Path("docs/literature_matrix.csv")
    )
    parser.add_argument(
        "--bibliography", type=Path, default=Path("docs/references.bib")
    )
    parser.add_argument(
        "--search-log", type=Path, default=Path("docs/literature_search_log.csv")
    )
    parser.add_argument(
        "--docs",
        nargs="*",
        type=Path,
        default=[Path(path) for path in DEFAULT_CITATION_DOCS],
    )
    parser.add_argument("--output", type=Path)
    return parser.parse_args()


def main() -> None:
    args = _parse_args()
    report = audit_references(
        args.matrix, args.bibliography, args.docs, args.search_log
    )
    rendered = json.dumps(report, ensure_ascii=False, indent=2)
    if args.output:
        args.output.parent.mkdir(parents=True, exist_ok=True)
        args.output.write_text(rendered + "\n", encoding="utf-8")
    print(rendered)


if __name__ == "__main__":
    main()
