"""Create a separately disclosed AI research-assisted annotation pass.

This module deliberately keeps public song context and AI labels out of the
independent blind-human workbooks. Its output is pre-annotation evidence only,
never a human annotation or dissertation gold standard.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
from datetime import datetime, timezone
from pathlib import Path

import numpy as np
import pandas as pd
import torch
from huggingface_hub import model_info
from transformers import AutoModelForCausalLM, AutoTokenizer


LABELS = ["joy", "sadness", "anger", "calmness"]
LABEL_CODES = {1: "joy", 2: "sadness", 3: "anger", 4: "calmness"}
MODEL_DEFAULT = "Qwen/Qwen2.5-1.5B-Instruct"


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _json_object(text: str) -> dict[str, object] | None:
    cleaned = text.strip().replace("```json", "").replace("```", "")
    match = re.search(r"\{.*\}", cleaned, flags=re.DOTALL)
    if not match:
        return None
    try:
        value = json.loads(match.group(0))
    except json.JSONDecodeError:
        return None
    return value if isinstance(value, dict) else None


def _bool(value: object) -> bool:
    if isinstance(value, bool):
        return value
    return str(value).strip().casefold() in {"1", "true", "yes", "y", "是"}


def _label(value: object) -> str | None:
    text = str(value or "").strip().casefold()
    aliases = {
        "喜悦": "joy",
        "喜悅": "joy",
        "快乐": "joy",
        "快樂": "joy",
        "悲伤": "sadness",
        "悲傷": "sadness",
        "难过": "sadness",
        "難過": "sadness",
        "愤怒": "anger",
        "憤怒": "anger",
        "生气": "anger",
        "生氣": "anger",
        "平静": "calmness",
        "平靜": "calmness",
        "安宁": "calmness",
        "安寧": "calmness",
    }
    if text in LABELS:
        return text
    return aliases.get(text)


def _label_from_code(value: object) -> str | None:
    try:
        code = int(float(value))
    except (TypeError, ValueError):
        return None
    return LABEL_CODES.get(code)


def _confidence(value: object, default: int = 2) -> int:
    try:
        number = int(float(value))
    except (TypeError, ValueError):
        number = default
    return min(5, max(1, number))


def _mean_nli_scores(value: object) -> dict[str, float]:
    try:
        records = json.loads(str(value))
    except (json.JSONDecodeError, TypeError):
        return {label: 0.0 for label in LABELS}
    means = {
        label: float(np.mean([float(record.get(label, 0.0)) for record in records]))
        for label in LABELS
    }
    return means


def _load_model(model_name: str):
    revision = model_info(model_name).sha
    tokenizer = AutoTokenizer.from_pretrained(model_name, revision=revision)
    if tokenizer.pad_token_id is None:
        tokenizer.pad_token_id = tokenizer.eos_token_id
    tokenizer.padding_side = "left"
    dtype = torch.float16 if torch.cuda.is_available() else torch.float32
    model = AutoModelForCausalLM.from_pretrained(
        model_name,
        revision=revision,
        dtype=dtype,
        low_cpu_mem_usage=True,
    )
    device = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    model.to(device)
    model.eval()
    return tokenizer, model, device, revision


def _generate_batch(
    tokenizer,
    model,
    device: torch.device,
    prompts: list[str],
    max_new_tokens: int,
) -> list[str]:
    rendered = [
        tokenizer.apply_chat_template(
            [
                {
                    "role": "system",
                    "content": (
                        "你是严谨的粤语歌词研究助理。严格按定义判断，不猜测资料中没有的事实，"
                        "只输出有效JSON，不要Markdown。"
                    ),
                },
                {"role": "user", "content": prompt},
            ],
            tokenize=False,
            add_generation_prompt=True,
        )
        for prompt in prompts
    ]
    inputs = tokenizer(
        rendered,
        return_tensors="pt",
        padding=True,
        truncation=True,
        max_length=2048,
    ).to(device)
    with torch.inference_mode():
        outputs = model.generate(
            **inputs,
            max_new_tokens=max_new_tokens,
            do_sample=False,
            repetition_penalty=1.05,
            pad_token_id=tokenizer.pad_token_id,
            eos_token_id=tokenizer.eos_token_id,
        )
    prompt_length = inputs["input_ids"].shape[1]
    return [
        tokenizer.decode(output[prompt_length:], skip_special_tokens=True).strip()
        for output in outputs
    ]


def _profile_prompt(song: pd.Series, context: pd.Series) -> str:
    wiki = str(context.get("wikipedia_extract") or "").strip()
    if str(context.get("wikipedia_match_status")) != "matched":
        wiki = ""
    return f"""请先研究这首歌的整体叙事，作为后续段落标注的辅助背景。外部资料只可辅助，歌词优先；不要因为曲风直接决定情绪。

歌曲：{song['title']}；歌手：{song['artist']}；年份：{song['release_year']}
公开音乐元数据：类型={context.get('itunes_genre') or '未知'}；专辑={context.get('itunes_collection') or '未知'}；匹配状态={context.get('itunes_match_status')}
公开百科摘要：{wiki[:700] or '没有可靠匹配摘要'}
完整歌词：{str(song['lyrics'])[:2600]}

只输出JSON：
{{"theme":"20至60字主题概括","emotional_arc":"20至60字情绪走向","genre_context":"只复述可证实的类型资料，没有则写未知","context_reliability":"high或medium或low","profile_note":"说明背景如何帮助理解但不替代段落文字"}}"""


def _section_prompt(row: pd.Series) -> str:
    return f"""给下面一个自然结构歌词段落选择唯一主情绪。判断叙述声音在该段落最强烈表达的情绪，允许同一首歌不同段落标签不同。歌曲整体背景只能消除歧义，不能压过段落文字。

标签定义：
- joy：正向且较活跃，如喜悦、希望、兴奋、庆祝、热烈或俏皮爱意。
- sadness：负向且较低唤醒，如悲伤、孤独、遗憾、失去、失望或痛苦思念。
- anger：负向且高唤醒，如愤怒、怨恨、指责、抗议、背叛或对抗。
- calmness：平和或接受，如安慰、满足、温柔、宁静、释然或温和反思。

歌曲：{row['title']}；歌手：{row['artist']}；段落：{row['section_type']}
整体主题辅助：{row.get('theme') or '未知'}
整体情绪走向辅助：{row.get('emotional_arc') or '未知'}
待标段落：{row['lyrics']}

只输出JSON：
{{"label":"joy|sadness|anger|calmness","confidence":1至5整数,"mixed":true或false,"uncertain":true或false,"non_cantonese":true或false,"insufficient_text":true或false,"translation_required":true或false,"alternative_label":"另一可能标签或空字符串","rationale":"20至60字，必须指出段落中的文字线索，不可只说曲风"}}"""


def _adjudication_prompt(row: pd.Series) -> str:
    scores = {label: round(float(row[f"nli_{label}_score"]), 4) for label in LABELS}
    return f"""对歌词段落做严格的最终单标签审查。不要机械多数投票，重新根据文字决定；NLI和第一轮只是弱参考。

固定代码：1=joy（正向且活跃）；2=sadness（失落、孤独、遗憾、痛苦思念）；3=anger（指责、怨恨、对抗、抗议）；4=calmness（平和、安慰、温柔、释然）。
判断规则：爱情、承诺或“爱”字本身不等于joy；若核心是得不到、离别、哭泣或痛苦思念，选2。只有明确指责/对抗强于悲伤时才选3。只有平和接受/安慰强于低落时才选4。必须四选一。

段落：{row['lyrics']}
歌曲主题辅助：{row.get('theme') or '未知'}
第一轮判断：{row.get('direct_label')}，置信度{row.get('direct_confidence')}，理由：{row.get('direct_rationale')}
独立NLI候选：{row.get('nli_candidate_label') or '平票'}；平均分数：{json.dumps(scores, ensure_ascii=False)}

只输出JSON。label_code必须是1、2、3、4中的一个数字；mixed只有两种情绪势均力敌时才为true；mixed或uncertain为true时confidence不得为5：
{{"label_code":1,"confidence":1至5整数,"mixed":false,"uncertain":false,"alternative_code":2或0,"rationale":"20至70字，指出具体文字线索并解释为何主标签强于备选"}}"""


def _write_checkpoint(rows: list[dict[str, object]], path: Path) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    pd.DataFrame(rows).to_csv(path, index=False, encoding="utf-8-sig")


def _build_profiles(
    songs: pd.DataFrame,
    context: pd.DataFrame,
    output_path: Path,
    tokenizer,
    model,
    device: torch.device,
    batch_size: int,
    force: bool,
) -> pd.DataFrame:
    existing: dict[str, dict] = {}
    if output_path.exists() and not force:
        prior = pd.read_csv(output_path)
        existing = {
            str(row["corpus_song_id"]): row.to_dict() for _, row in prior.iterrows()
        }
    context_columns = [
        column
        for column in context.columns
        if column
        not in {
            "title",
            "artist_in_corpus",
            "release_year",
        }
    ]
    merged = songs.merge(
        context[context_columns],
        on="corpus_song_id",
        how="left",
        validate="one_to_one",
    )
    rows = list(existing.values())
    pending = merged.loc[~merged["corpus_song_id"].astype(str).isin(existing)].copy()
    for start in range(0, len(pending), batch_size):
        batch = pending.iloc[start : start + batch_size]
        prompts = [_profile_prompt(row, row) for _, row in batch.iterrows()]
        outputs = _generate_batch(tokenizer, model, device, prompts, max_new_tokens=190)
        for (_, source), raw in zip(batch.iterrows(), outputs):
            parsed = _json_object(raw) or {}
            rows.append(
                {
                    "corpus_song_id": source["corpus_song_id"],
                    "title": source["title"],
                    "artist": source["artist"],
                    "release_year": int(source["release_year"]),
                    "theme": str(parsed.get("theme") or "未能可靠生成主题概括")[:180],
                    "emotional_arc": str(parsed.get("emotional_arc") or "未能可靠生成情绪走向")[:180],
                    "genre_context": str(parsed.get("genre_context") or source.get("itunes_genre") or "未知")[:120],
                    "context_reliability": str(parsed.get("context_reliability") or "low").lower(),
                    "profile_note": str(parsed.get("profile_note") or raw)[:300],
                    "itunes_track_url": source.get("itunes_track_url"),
                    "wikipedia_url": source.get("wikipedia_url"),
                    "profile_parse_ok": bool(parsed),
                }
            )
        _write_checkpoint(rows, output_path)
        print(f"song profiles: {len(rows)}/{len(merged)}", flush=True)
    return pd.DataFrame(rows).sort_values("corpus_song_id")


def _direct_annotations(
    frame: pd.DataFrame,
    output_path: Path,
    tokenizer,
    model,
    device: torch.device,
    batch_size: int,
    force: bool,
) -> pd.DataFrame:
    existing: dict[str, dict] = {}
    if output_path.exists() and not force:
        prior = pd.read_csv(output_path)
        existing = {str(row["case_id"]): row.to_dict() for _, row in prior.iterrows()}
    rows = list(existing.values())
    pending = frame.loc[~frame["case_id"].astype(str).isin(existing)].copy()
    for start in range(0, len(pending), batch_size):
        batch = pending.iloc[start : start + batch_size]
        outputs = _generate_batch(
            tokenizer,
            model,
            device,
            [_section_prompt(row) for _, row in batch.iterrows()],
            max_new_tokens=180,
        )
        for (_, source), raw in zip(batch.iterrows(), outputs):
            parsed = _json_object(raw) or {}
            direct_label = _label(parsed.get("label"))
            rows.append(
                {
                    **source.to_dict(),
                    "direct_label": direct_label,
                    "direct_confidence": _confidence(parsed.get("confidence")),
                    "direct_mixed": _bool(parsed.get("mixed")),
                    "direct_uncertain": _bool(parsed.get("uncertain")),
                    "direct_non_cantonese": _bool(parsed.get("non_cantonese")),
                    "direct_insufficient_text": _bool(parsed.get("insufficient_text")),
                    "direct_translation_required": _bool(parsed.get("translation_required")),
                    "direct_alternative_label": _label(parsed.get("alternative_label")),
                    "direct_rationale": str(parsed.get("rationale") or raw)[:320],
                    "direct_parse_ok": bool(parsed and direct_label),
                }
            )
        _write_checkpoint(rows, output_path)
        print(f"direct annotations: {len(rows)}/{len(frame)}", flush=True)
    return pd.DataFrame(rows).sort_values("case_id")


def _adjudicate(
    frame: pd.DataFrame,
    output_path: Path,
    tokenizer,
    model,
    device: torch.device,
    batch_size: int,
    force: bool,
) -> pd.DataFrame:
    # The strict coded pass reviews every case. This avoids silently retaining
    # a high-confidence but weak first-pass answer.
    selected = frame.copy()
    existing: dict[str, dict] = {}
    if output_path.exists() and not force:
        prior = pd.read_csv(output_path)
        existing = {str(row["case_id"]): row.to_dict() for _, row in prior.iterrows()}
    rows = list(existing.values())
    pending = selected.loc[~selected["case_id"].astype(str).isin(existing)].copy()
    for start in range(0, len(pending), batch_size):
        batch = pending.iloc[start : start + batch_size]
        outputs = _generate_batch(
            tokenizer,
            model,
            device,
            [_adjudication_prompt(row) for _, row in batch.iterrows()],
            max_new_tokens=170,
        )
        for (_, source), raw in zip(batch.iterrows(), outputs):
            parsed = _json_object(raw) or {}
            decision = _label_from_code(parsed.get("label_code")) or _label(
                parsed.get("label")
            )
            rows.append(
                {
                    "case_id": source["case_id"],
                    "adjudicated_label": decision,
                    "adjudicated_confidence": _confidence(parsed.get("confidence")),
                    "adjudicated_mixed": _bool(parsed.get("mixed")),
                    "adjudicated_uncertain": _bool(parsed.get("uncertain")),
                    "adjudicated_alternative_label": _label_from_code(
                        parsed.get("alternative_code")
                    )
                    or _label(parsed.get("alternative_label")),
                    "adjudicated_rationale": str(parsed.get("rationale") or raw)[:350],
                    "adjudication_parse_ok": bool(parsed and decision),
                }
            )
        _write_checkpoint(rows, output_path)
        print(f"adjudications: {len(rows)}/{len(selected)}", flush=True)
    return pd.DataFrame(rows)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("sections_csv", type=Path)
    parser.add_argument("songs_csv", type=Path)
    parser.add_argument("context_csv", type=Path)
    parser.add_argument("candidate_csv", type=Path)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--model", default=MODEL_DEFAULT)
    parser.add_argument("--batch-size", type=int, default=8)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    sections = pd.read_csv(args.sections_csv)
    songs = pd.read_csv(args.songs_csv)
    context = pd.read_csv(args.context_csv)
    candidates = pd.read_csv(args.candidate_csv)
    if len(context) != songs["corpus_song_id"].nunique():
        raise ValueError(
            f"Song context is incomplete: {len(context)} rows for "
            f"{songs['corpus_song_id'].nunique()} songs"
        )
    if len(sections) != 680 or sections["case_id"].duplicated().any():
        raise ValueError("Expected exactly 680 unique section cases")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    torch.manual_seed(42)
    tokenizer, model, device, revision = _load_model(args.model)

    profiles = _build_profiles(
        songs,
        context,
        args.output_dir / "song_profiles.csv",
        tokenizer,
        model,
        device,
        args.batch_size,
        args.force,
    )
    candidate_columns = [
        "case_id",
        "candidate_label",
        "prompt_agreement",
        "candidate_tied",
        "mean_top_two_margin",
        "candidate_scores_json",
    ]
    frame = sections.merge(
        profiles[["corpus_song_id", "theme", "emotional_arc", "genre_context", "context_reliability"]],
        on="corpus_song_id",
        how="left",
        validate="many_to_one",
    ).merge(
        candidates[candidate_columns],
        on="case_id",
        how="left",
        validate="one_to_one",
    )
    frame = frame.rename(columns={"candidate_label": "nli_candidate_label"})
    score_rows = frame["candidate_scores_json"].map(_mean_nli_scores)
    for label in LABELS:
        frame[f"nli_{label}_score"] = score_rows.map(lambda value: value[label])

    direct = _direct_annotations(
        frame,
        args.output_dir / "direct_annotations.csv",
        tokenizer,
        model,
        device,
        args.batch_size,
        args.force,
    )
    adjudicated = _adjudicate(
        direct,
        args.output_dir / "adjudication_annotations.csv",
        tokenizer,
        model,
        device,
        args.batch_size,
        args.force,
    )
    final = direct.merge(adjudicated, on="case_id", how="left", validate="one_to_one")
    mean_score_label = final[[f"nli_{label}_score" for label in LABELS]].idxmax(axis=1)
    mean_score_label = mean_score_label.str.removeprefix("nli_").str.removesuffix("_score")
    final["ai_label"] = (
        final["adjudicated_label"]
        .fillna(final["direct_label"])
        .fillna(final["nli_candidate_label"])
        .fillna(mean_score_label)
    )
    final["ai_confidence_1_to_5"] = final["adjudicated_confidence"].fillna(
        final["direct_confidence"]
    ).astype(int)
    final["mixed"] = final["adjudicated_mixed"].fillna(final["direct_mixed"]).astype(bool)
    final["uncertain"] = (
        final["adjudicated_uncertain"].fillna(final["direct_uncertain"]).astype(bool)
        | final["ai_confidence_1_to_5"].le(2)
    )
    final["alternative_label"] = final["adjudicated_alternative_label"].fillna(
        final["direct_alternative_label"]
    )
    final["rationale"] = final["adjudicated_rationale"].fillna(final["direct_rationale"])
    final["ai_nli_agreement"] = final["ai_label"] == final["nli_candidate_label"]
    final["needs_human_review"] = (
        final["ai_confidence_1_to_5"].le(3)
        | final["mixed"]
        | final["uncertain"]
        | final["direct_non_cantonese"].astype(bool)
        | final["direct_insufficient_text"].astype(bool)
        | ~final["ai_nli_agreement"]
    )
    final["annotator_type"] = "AI research-assisted pre-annotation"
    final["label_status"] = "ai_research_assisted_development_only"
    final["formal_evaluation_eligible"] = False
    final["model_name"] = args.model
    final["model_revision"] = revision
    final["annotated_at_utc"] = datetime.now(timezone.utc).isoformat()

    context_urls = context[["corpus_song_id", "itunes_track_url", "wikipedia_url"]]
    final = final.drop(columns=["itunes_track_url", "wikipedia_url"], errors="ignore").merge(
        context_urls,
        on="corpus_song_id",
        how="left",
        validate="many_to_one",
    )
    output_path = args.output_dir / "ai_research_assisted_annotations.csv"
    final.to_csv(output_path, index=False, encoding="utf-8-sig")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "rows": len(final),
        "songs": int(final["corpus_song_id"].nunique()),
        "label_counts": final["ai_label"].value_counts().to_dict(),
        "needs_human_review": int(final["needs_human_review"].sum()),
        "model_name": args.model,
        "model_revision": revision,
        "device": str(device),
        "sections_sha256": _sha256(args.sections_csv),
        "context_sha256": _sha256(args.context_csv),
        "candidate_sha256": _sha256(args.candidate_csv),
        "output_sha256": _sha256(output_path),
        "formal_evaluation_eligible": False,
        "warning": (
            "This is disclosed AI research-assisted pre-annotation. It is not an "
            "independent human annotation and must not be called human gold."
        ),
    }
    (args.output_dir / "ai_research_assisted_annotations.metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2), flush=True)


if __name__ == "__main__":
    main()
