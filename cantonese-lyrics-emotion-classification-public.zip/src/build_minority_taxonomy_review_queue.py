"""Build an auditable review queue for the refined four-quadrant taxonomy."""

from __future__ import annotations

import argparse
import hashlib
import json
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


ANGER_CUES = (
    "嬲", "憤怒", "怒", "恨", "仇", "憎", "怨", "妒", "嫉", "爭", "鬥",
    "吵", "罵", "逼", "敵", "戰", "反抗", "反擊", "報復", "壓迫", "威脅",
    "瘋", "癲", "魔鬼", "反咬", "埋怨", "不服", "撕破", "挑釁", "恐懼",
    "驚慌", "焦慮", "緊張", "窒息", "失控", "衝突",
)
CALM_CUES = (
    "平靜", "安慰", "溫柔", "溫暖", "陪伴", "陪你", "擁抱", "守護", "祝福",
    "幸福", "安心", "安睡", "美夢", "依靠", "懷抱", "微笑", "滿足", "放低",
    "放下", "釋懷", "平安", "珍惜", "感激", "體諒", "安穩", "寧靜", "甜蜜",
    "照顧", "相依", "到老", "白頭", "承諾",
)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def cue_hits(text: object, cues: tuple[str, ...]) -> list[str]:
    value = str(text)
    return [cue for cue in cues if cue in value]


def build_queue(frame: pd.DataFrame) -> pd.DataFrame:
    clean = frame.copy()
    clean["anger_cue_hits"] = clean["lyrics"].map(lambda value: cue_hits(value, ANGER_CUES))
    clean["calm_cue_hits"] = clean["lyrics"].map(lambda value: cue_hits(value, CALM_CUES))
    clean["anger_vote_present"] = clean[
        ["nli_vote", "qwen_direct_vote", "qwen_strict_vote"]
    ].eq("anger").any(axis=1)
    clean["calm_vote_present"] = clean[
        ["nli_vote", "qwen_direct_vote", "qwen_strict_vote"]
    ].eq("calmness").any(axis=1)
    anger_rank = clean.loc[clean["emotion"].ne("anger"), "nli_anger_score"].rank(
        method="first", ascending=False
    )
    calm_rank = clean.loc[clean["emotion"].ne("calmness"), "nli_calmness_score"].rank(
        method="first", ascending=False
    )
    clean["anger_score_top80"] = False
    clean["calm_score_top80"] = False
    clean.loc[anger_rank.index, "anger_score_top80"] = anger_rank.le(80)
    clean.loc[calm_rank.index, "calm_score_top80"] = calm_rank.le(80)
    clean["review_for_anger_tension"] = clean["emotion"].ne("anger") & (
        clean["anger_vote_present"]
        | clean["anger_score_top80"]
        | clean["anger_cue_hits"].map(bool)
    )
    clean["review_for_calm_tenderness"] = clean["emotion"].ne("calmness") & (
        clean["calm_vote_present"]
        | clean["calm_score_top80"]
        | clean["calm_cue_hits"].map(bool)
    )
    queue = clean.loc[
        clean["review_for_anger_tension"] | clean["review_for_calm_tenderness"]
    ].copy()
    queue["anger_cue_hits"] = queue["anger_cue_hits"].map(lambda values: ";".join(values))
    queue["calm_cue_hits"] = queue["calm_cue_hits"].map(lambda values: ";".join(values))
    queue["proposed_v2_label"] = ""
    queue["review_confidence"] = ""
    queue["review_rationale"] = ""
    queue["reviewer"] = ""
    priority = (
        queue["review_for_anger_tension"].astype(int) * 2
        + queue["review_for_calm_tenderness"].astype(int)
    )
    queue["review_priority"] = priority
    columns = [
        "case_id", "corpus_song_id", "title", "artist", "section_type", "lyrics",
        "emotion", "alternative_label", "mixed", "uncertain", "nli_anger_score",
        "nli_calmness_score", "nli_vote", "qwen_direct_vote", "qwen_strict_vote",
        "anger_cue_hits", "calm_cue_hits", "anger_vote_present", "calm_vote_present",
        "review_for_anger_tension", "review_for_calm_tenderness", "review_priority",
        "theme", "emotional_arc", "source_url", "proposed_v2_label",
        "review_confidence", "review_rationale", "reviewer",
    ]
    return queue[columns].sort_values(
        ["review_priority", "nli_anger_score", "nli_calmness_score"],
        ascending=[False, False, False],
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    queue = build_queue(frame)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    queue.to_csv(args.output, index=False, encoding="utf-8-sig")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_path": str(args.input),
        "source_sha256": sha256(args.input),
        "source_rows": len(frame),
        "review_rows": len(queue),
        "anger_tension_candidates": int(queue["review_for_anger_tension"].sum()),
        "calm_tenderness_candidates": int(queue["review_for_calm_tenderness"].sum()),
        "taxonomy": "docs/emotion_taxonomy_v2.md",
    }
    args.output.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
