"""Fetch auditable public song metadata for AI-assisted annotation.

The output is contextual evidence only. It must never be merged into the
independent blind-human annotation sheets or treated as a gold emotion label.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import time
import unicodedata
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from difflib import SequenceMatcher
from pathlib import Path

import pandas as pd


ITUNES_ENDPOINT = "https://itunes.apple.com/search"
WIKIPEDIA_ENDPOINT = "https://zh.wikipedia.org/w/api.php"
USER_AGENT = (
    "CantoneseLyricsEmotionMSc/1.0 "
    "(non-commercial research metadata audit; contact via project supervisor)"
)

# Manual resolutions for ambiguous catalogue searches, backed by the URLs
# below. They correct contextual lookup results, not emotion labels.
CONTEXT_MATCH_CORRECTIONS: dict[str, dict[str, object]] = {
    "C0802": {
        "canonical_title": "囍帖街",
        "canonical_artist": "謝安琪",
        "wikipedia_match_status": "matched",
        "wikipedia_title": "囍帖街 (歌曲)",
        "wikipedia_url": "https://zh.wikipedia.org/wiki/%E5%9B%8D%E5%B8%96%E8%A1%97_(%E6%AD%8C%E6%9B%B2)",
        "wikipedia_extract": (
            "《囍帖街》由謝安琪演唱；作品以利東街清拆和城市保育为创作背景，"
            "表面借用爱情告别意象表达对旧事物消逝的不舍。"
        ),
    },
    "C1703": {
        "itunes_match_status": "matched",
        "itunes_match_score": 1.0,
        "canonical_title": "天網 (劇集《使徒行者2》主題曲)",
        "canonical_artist": "周柏豪",
        "itunes_genre": "廣東歌/香港流行樂",
        "itunes_release_date": "2017-09-15",
        "itunes_track_url": "https://music.apple.com/mo/song/1842653452",
        "wikipedia_match_status": "matched",
        "wikipedia_title": "2017年度香港四台頒獎禮主要獲獎歌曲列表",
        "wikipedia_url": "https://zh.wikipedia.org/wiki/2017%E5%B9%B4%E5%BA%A6%E9%A6%99%E6%B8%AF%E5%9B%9B%E5%8F%B0%E9%A0%92%E7%8D%8E%E7%A6%AE%E4%B8%BB%E8%A6%81%E7%8D%B2%E7%8D%8E%E6%AD%8C%E6%9B%B2%E5%88%97%E8%A1%A8",
        "wikipedia_extract": "《天網》为周柏豪2017年演唱的粤语歌曲及《使徒行者2》主题曲。",
    },
    "C1704": {
        "itunes_match_status": "matched",
        "itunes_match_score": 1.0,
        "canonical_title": "天敵",
        "canonical_artist": "衛蘭",
        "itunes_genre": "廣東歌/香港流行樂",
        "itunes_release_date": "2017",
        "itunes_track_url": "https://music.apple.com/tw/song/1212415345",
        "wikipedia_match_status": "matched",
        "wikipedia_title": "2017年度新城勁爆頒獎禮得獎名單",
        "wikipedia_url": "https://zh.wikipedia.org/wiki/2017%E5%B9%B4%E5%BA%A6%E6%96%B0%E5%9F%8E%E5%8B%81%E7%88%86%E9%A0%92%E7%8D%8E%E7%A6%AE%E5%BE%97%E7%8D%8E%E5%90%8D%E5%96%AE",
        "wikipedia_extract": "《天敵》由衛蘭演唱、黃偉文填詞，属于2017年粤语流行歌曲。",
    },
}


def _normalise(value: object) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).casefold()
    return re.sub(r"[\W_]+", "", text, flags=re.UNICODE)


def _similarity(left: object, right: object) -> float:
    return SequenceMatcher(None, _normalise(left), _normalise(right)).ratio()


def _request_json(url: str, retries: int = 3) -> dict:
    request = urllib.request.Request(
        url,
        headers={"User-Agent": USER_AGENT, "Accept": "application/json"},
    )
    last_error: Exception | None = None
    for attempt in range(retries):
        try:
            with urllib.request.urlopen(request, timeout=30) as response:
                return json.load(response)
        except Exception as exc:  # network diagnostics are retained in output
            last_error = exc
            time.sleep(1.0 * (attempt + 1))
    raise RuntimeError(f"Request failed after {retries} attempts: {url}") from last_error


def _itunes_lookup(title: str, artist: str, release_year: int) -> dict[str, object]:
    queries = [f"{title} {artist}", title]
    candidates: list[dict] = []
    for query in queries:
        params = urllib.parse.urlencode(
            {
                "term": query,
                "country": "HK",
                "media": "music",
                "entity": "song",
                "limit": 25,
                "lang": "zh_hk",
            }
        )
        payload = _request_json(f"{ITUNES_ENDPOINT}?{params}")
        candidates.extend(payload.get("results", []))
        if candidates:
            break

    scored: list[tuple[float, dict]] = []
    for item in candidates:
        title_score = _similarity(title, item.get("trackName"))
        artist_score = _similarity(artist, item.get("artistName"))
        item_year = str(item.get("releaseDate", ""))[:4]
        year_score = 0.0
        if item_year.isdigit():
            delta = abs(int(item_year) - int(release_year))
            year_score = max(0.0, 1.0 - delta / 10.0)
        score = 0.68 * title_score + 0.22 * artist_score + 0.10 * year_score
        scored.append((score, item))
    if not scored:
        return {
            "itunes_match_status": "not_found",
            "itunes_match_score": 0.0,
            "canonical_title": None,
            "canonical_artist": None,
            "itunes_genre": None,
            "itunes_collection": None,
            "itunes_release_date": None,
            "itunes_track_url": None,
            "itunes_preview_url": None,
        }
    score, best = max(scored, key=lambda pair: pair[0])
    status = "matched" if score >= 0.72 else "needs_review"
    return {
        "itunes_match_status": status,
        "itunes_match_score": round(score, 4),
        "canonical_title": best.get("trackName"),
        "canonical_artist": best.get("artistName"),
        "itunes_genre": best.get("primaryGenreName"),
        "itunes_collection": best.get("collectionName"),
        "itunes_release_date": best.get("releaseDate"),
        "itunes_track_url": best.get("trackViewUrl"),
        "itunes_preview_url": best.get("previewUrl"),
    }


def _wikipedia_lookup(title: str, artist: str) -> dict[str, object]:
    params = urllib.parse.urlencode(
        {
            "action": "query",
            "list": "search",
            "srsearch": f'"{title}" {artist} 歌曲',
            "srlimit": 5,
            "format": "json",
            "utf8": 1,
        }
    )
    payload = _request_json(f"{WIKIPEDIA_ENDPOINT}?{params}")
    results = payload.get("query", {}).get("search", [])
    if not results:
        return {
            "wikipedia_match_status": "not_found",
            "wikipedia_title": None,
            "wikipedia_url": None,
            "wikipedia_extract": None,
        }

    scored: list[tuple[float, dict]] = []
    for item in results:
        result_title = item.get("title", "")
        snippet = re.sub("<[^>]+>", "", item.get("snippet", ""))
        score = (
            0.75 * _similarity(title, result_title)
            + 0.15 * (1.0 if _normalise(artist) in _normalise(snippet) else 0.0)
            + 0.10 * (1.0 if "歌曲" in result_title + snippet else 0.0)
        )
        scored.append((score, item))
    score, best = max(scored, key=lambda pair: pair[0])

    extract_params = urllib.parse.urlencode(
        {
            "action": "query",
            "prop": "extracts",
            "exintro": 1,
            "explaintext": 1,
            "redirects": 1,
            "titles": best["title"],
            "format": "json",
            "utf8": 1,
        }
    )
    extract_payload = _request_json(f"{WIKIPEDIA_ENDPOINT}?{extract_params}")
    pages = extract_payload.get("query", {}).get("pages", {})
    page = next(iter(pages.values()), {})
    extract = re.sub(r"\s+", " ", page.get("extract", "")).strip()
    url_title = urllib.parse.quote(best["title"].replace(" ", "_"))
    status = "matched" if score >= 0.58 else "needs_review"
    return {
        "wikipedia_match_status": status,
        "wikipedia_title": best["title"],
        "wikipedia_url": f"https://zh.wikipedia.org/wiki/{url_title}",
        "wikipedia_extract": extract[:1800] or None,
    }


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("songs_csv", type=Path)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--delay-seconds", type=float, default=0.15)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    songs = pd.read_csv(args.songs_csv)
    required = {"corpus_song_id", "title", "artist", "release_year"}
    missing = sorted(required.difference(songs.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if songs["corpus_song_id"].duplicated().any():
        raise ValueError("songs_csv must contain one row per corpus_song_id")

    existing: dict[str, dict] = {}
    if args.output.exists() and not args.force:
        previous = pd.read_csv(args.output)
        existing = {
            str(row["corpus_song_id"]): row.to_dict()
            for _, row in previous.iterrows()
        }

    rows: list[dict[str, object]] = []
    total = len(songs)
    for index, song in songs.iterrows():
        song_id = str(song["corpus_song_id"])
        if song_id in existing:
            rows.append(existing[song_id])
            continue
        title = str(song["title"])
        artist = str(song["artist"])
        year = int(song["release_year"])
        try:
            itunes = _itunes_lookup(title, artist, year)
        except Exception as exc:
            itunes = {
                "itunes_match_status": f"error:{type(exc).__name__}",
                "itunes_match_score": 0.0,
                "canonical_title": None,
                "canonical_artist": None,
                "itunes_genre": None,
                "itunes_collection": None,
                "itunes_release_date": None,
                "itunes_track_url": None,
                "itunes_preview_url": None,
            }
        try:
            wikipedia = _wikipedia_lookup(title, artist)
        except Exception as exc:
            wikipedia = {
                "wikipedia_match_status": f"error:{type(exc).__name__}",
                "wikipedia_title": None,
                "wikipedia_url": None,
                "wikipedia_extract": None,
            }
        row = {
            "corpus_song_id": song_id,
            "title": title,
            "artist_in_corpus": artist,
            "release_year": year,
            **itunes,
            **wikipedia,
            "retrieved_at_utc": datetime.now(timezone.utc).isoformat(),
            "context_role": "AI-assisted annotation context only; not human gold",
        }
        rows.append(row)
        args.output.parent.mkdir(parents=True, exist_ok=True)
        pd.DataFrame(rows).to_csv(args.output, index=False, encoding="utf-8-sig")
        print(f"[{index + 1}/{total}] {song_id} {title}", flush=True)
        time.sleep(max(0.0, args.delay_seconds))

    output = pd.DataFrame(rows).sort_values("corpus_song_id")
    output["context_manual_correction_applied"] = False
    for song_id, values in CONTEXT_MATCH_CORRECTIONS.items():
        mask = output["corpus_song_id"].astype(str).eq(song_id)
        if not mask.any():
            continue
        for column, value in values.items():
            output.loc[mask, column] = value
        output.loc[mask, "context_manual_correction_applied"] = True
    output.to_csv(args.output, index=False, encoding="utf-8-sig")
    metadata = {
        "created_at_utc": datetime.now(timezone.utc).isoformat(),
        "source_rows": len(songs),
        "output_rows": len(output),
        "source_sha256": _sha256(args.songs_csv),
        "output_sha256": _sha256(args.output),
        "itunes_endpoint": ITUNES_ENDPOINT,
        "wikipedia_endpoint": WIKIPEDIA_ENDPOINT,
        "formal_evaluation_eligible": False,
        "warning": (
            "Public metadata and summaries are contextual evidence only. "
            "Do not expose them to blind human annotators."
        ),
    }
    args.output.with_suffix(".metadata.json").write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
