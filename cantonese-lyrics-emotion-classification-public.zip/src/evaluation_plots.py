"""Create consistent, publication-ready figures from saved formal predictions."""

from __future__ import annotations

import argparse
import re
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.metrics import confusion_matrix

from src.statistical_analysis import (
    LABELS,
    partition_metrics,
    select_analysis_models,
    validate_predictions,
)


CLASS_DISPLAY = {
    "joy": "Joy",
    "sadness": "Sadness",
    "anger": "Anger",
    "calmness": "Calmness",
}


def _set_style() -> None:
    sns.set_theme(style="whitegrid", context="paper", font_scale=1.05)
    plt.rcParams.update(
        {
            "figure.dpi": 120,
            "savefig.dpi": 300,
            "font.family": "DejaVu Sans",
            "axes.titleweight": "bold",
        }
    )


def safe_filename(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", value).strip("_")
    return cleaned or "model"


def plot_confusion_matrices(
    predictions: pd.DataFrame,
    output_dir: Path,
) -> list[Path]:
    """Write count and row-normalised confusion matrices for every model."""

    clean = validate_predictions(predictions)
    output_dir.mkdir(parents=True, exist_ok=True)
    _set_style()
    written: list[Path] = []
    labels_display = [CLASS_DISPLAY[label] for label in LABELS]
    for model_key, model_rows in clean.groupby("model_key"):
        counts = confusion_matrix(
            model_rows["true_label"],
            model_rows["predicted_label"],
            labels=LABELS,
        )
        row_totals = counts.sum(axis=1, keepdims=True)
        normalised = np.divide(
            counts,
            row_totals,
            out=np.zeros_like(counts, dtype=float),
            where=row_totals != 0,
        )

        figure, axes = plt.subplots(1, 2, figsize=(10.5, 4.3), constrained_layout=True)
        sns.heatmap(
            counts,
            annot=True,
            fmt="d",
            cmap="Blues",
            cbar=False,
            xticklabels=labels_display,
            yticklabels=labels_display,
            ax=axes[0],
        )
        sns.heatmap(
            normalised,
            annot=True,
            fmt=".2f",
            vmin=0,
            vmax=1,
            cmap="Blues",
            cbar_kws={"label": "Row proportion"},
            xticklabels=labels_display,
            yticklabels=labels_display,
            ax=axes[1],
        )
        axes[0].set_title("Counts")
        axes[1].set_title("Normalised by true class")
        for axis in axes:
            axis.set_xlabel("Predicted emotion")
            axis.set_ylabel("True emotion")
            axis.tick_params(axis="x", rotation=25)
            axis.tick_params(axis="y", rotation=0)
        figure.suptitle(str(model_key), fontsize=11, fontweight="bold")
        path = output_dir / f"confusion_{safe_filename(str(model_key))}.png"
        figure.savefig(path, bbox_inches="tight")
        plt.close(figure)
        written.append(path)
    return written


def plot_partition_performance(
    metrics: pd.DataFrame,
    output_path: Path,
    metric: str = "macro_f1",
) -> Path:
    """Show partition variability without hiding individual folds."""

    required = {"model_key", "partition_seed", "outer_fold", metric}
    missing = sorted(required.difference(metrics.columns))
    if missing:
        raise ValueError(f"Missing metric columns: {missing}")
    if metrics.empty:
        raise ValueError("Partition metrics cannot be empty")
    _set_style()
    output_path.parent.mkdir(parents=True, exist_ok=True)
    order = (
        metrics.groupby("model_key")[metric]
        .mean()
        .sort_values(ascending=False)
        .index.tolist()
    )
    height = max(4.2, 0.48 * len(order) + 1.6)
    figure, axis = plt.subplots(figsize=(9.2, height), constrained_layout=True)
    values_by_model = [
        metrics.loc[metrics["model_key"] == model_key, metric].astype(float).to_numpy()
        for model_key in order
    ]
    positions = np.arange(1, len(order) + 1)
    axis.boxplot(
        values_by_model,
        positions=positions,
        orientation="horizontal",
        widths=0.58,
        showfliers=False,
        patch_artist=True,
        boxprops={"facecolor": "#b9d8eb", "edgecolor": "#4f7187"},
        medianprops={"color": "#173f5f", "linewidth": 1.4},
        whiskerprops={"color": "#4f7187"},
        capprops={"color": "#4f7187"},
    )
    for position, values in zip(positions, values_by_model):
        offsets = np.linspace(-0.13, 0.13, len(values)) if len(values) > 1 else np.array([0.0])
        axis.scatter(
            values,
            position + offsets,
            color="#174a6e",
            alpha=0.72,
            s=14,
            zorder=3,
        )
    axis.set_xlim(0, 1)
    axis.set_yticks(positions, order)
    axis.invert_yaxis()
    axis.set_xlabel(metric.replace("_", " ").title())
    axis.set_ylabel("")
    axis.set_title("Performance across shared artist-exclusive partitions")
    axis.grid(axis="y", visible=False)
    output_path = output_path.with_suffix(".png")
    figure.savefig(output_path, bbox_inches="tight")
    plt.close(figure)
    return output_path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("predictions", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/evaluation_figures"))
    parser.add_argument(
        "--models",
        nargs="+",
        help="Optional exact model keys to include in the figures.",
    )
    args = parser.parse_args()

    predictions = pd.read_csv(args.predictions, low_memory=False)
    clean = select_analysis_models(predictions, requested_models=args.models)
    metrics = partition_metrics(clean)
    paths = plot_confusion_matrices(clean, args.output_dir)
    paths.append(
        plot_partition_performance(
            metrics,
            args.output_dir / "partition_macro_f1.png",
        )
    )
    print(f"Wrote {len(paths)} evaluation figures to {args.output_dir}")


if __name__ == "__main__":
    main()
