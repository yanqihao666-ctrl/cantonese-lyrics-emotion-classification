"""Cantonese lyric emotion-classification research package."""
