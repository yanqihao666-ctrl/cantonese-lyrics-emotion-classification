"""Create publication-ready plots for the V2 imbalance experiment."""

from __future__ import annotations

import argparse
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd
import seaborn as sns


ORDER = {
    "classical": [
        "baseline",
        "class_weight",
        "random_oversampling",
        "smote",
        "moderate_undersampling",
    ],
    "transformer": ["baseline", "balanced_loss", "balanced_sampler"],
}
COLORS = {"classical": "#4C78A8", "transformer": "#F58518"}


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("fold_metrics", type=Path)
    parser.add_argument("output_dir", type=Path)
    args = parser.parse_args()
    data = pd.read_csv(args.fold_metrics)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    sns.set_theme(style="whitegrid", context="paper")

    fig, axes = plt.subplots(1, 2, figsize=(11, 4.2), sharey=True)
    for axis, family in zip(axes, ["classical", "transformer"]):
        subset = data.loc[data["family"].eq(family)]
        summary = (
            subset.groupby("strategy")["macro_f1"]
            .agg(["mean", "std"])
            .reindex(ORDER[family])
        )
        positions = range(len(summary))
        axis.bar(
            positions,
            summary["mean"],
            yerr=summary["std"],
            capsize=4,
            color=COLORS[family],
            alpha=0.85,
        )
        axis.set_xticks(list(positions))
        axis.set_xticklabels(
            [label.replace("_", "\n") for label in summary.index],
            rotation=0,
        )
        axis.set_title(f"{family.title()} model")
        axis.set_xlabel("Training imbalance strategy")
        axis.set_ylim(0, 0.48)
    axes[0].set_ylabel("Test macro-F1 (mean ± SD across 15 partitions)")
    fig.tight_layout()
    fig.savefig(args.output_dir / "macro_f1_by_strategy.png", dpi=300, bbox_inches="tight")
    plt.close(fig)

    transformer = data.loc[data["family"].eq("transformer")]
    per_class = transformer.melt(
        id_vars=["strategy", "seed", "fold"],
        value_vars=["joy_f1", "sadness_f1", "anger_f1", "calmness_f1"],
        var_name="class",
        value_name="f1",
    )
    per_class["class"] = per_class["class"].str.removesuffix("_f1")
    fig, axis = plt.subplots(figsize=(8.5, 4.5))
    sns.barplot(
        data=per_class,
        x="class",
        y="f1",
        hue="strategy",
        hue_order=ORDER["transformer"],
        errorbar="sd",
        capsize=0.08,
        ax=axis,
    )
    axis.set_xlabel("Emotion class")
    axis.set_ylabel("Test F1 (mean ± SD across 15 partitions)")
    axis.set_title("MacBERT per-class performance under imbalance treatments")
    axis.set_ylim(0, 0.9)
    axis.legend(title="Strategy", frameon=True)
    fig.tight_layout()
    fig.savefig(args.output_dir / "macbert_per_class_f1.png", dpi=300, bbox_inches="tight")
    plt.close(fig)


if __name__ == "__main__":
    main()
