"""Collect and statistically compare the V2 imbalance-treatment experiments."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd
from scipy.stats import wilcoxon


SUMMARY_METRICS = [
    "macro_f1",
    "balanced_accuracy",
    "accuracy",
    "weighted_f1",
    "joy_f1",
    "sadness_f1",
    "anger_f1",
    "calmness_f1",
]


def transformer_strategy(metadata: dict) -> str:
    if metadata.get("class_weighting") == "balanced":
        return "balanced_loss"
    if metadata.get("sampling_strategy") == "balanced":
        return "balanced_sampler"
    return "baseline"


def collect_transformer(root: Path) -> pd.DataFrame:
    rows = []
    for metadata_path in sorted(root.glob("*/run_metadata.json")):
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
        metrics_path = metadata_path.parent / "metrics.json"
        metrics = json.loads(metrics_path.read_text(encoding="utf-8"))["test"]
        row = {
            "family": "transformer",
            "strategy": transformer_strategy(metadata),
            "seed": int(metadata["partition_seed"]),
            "fold": int(metadata["outer_fold"]),
            "model": metadata["model"],
            "input_sha256": metadata["input_sha256"],
            "source_path": str(metadata_path.parent),
        }
        for metric in SUMMARY_METRICS:
            row[metric] = float(metrics[f"test_{metric}"])
        rows.append(row)
    return pd.DataFrame(rows)


def collect_classical(path: Path) -> pd.DataFrame:
    frame = pd.read_csv(path)
    frame = frame.loc[frame["evaluation_split"].eq("test")].copy()
    frame = frame.rename(columns={"imbalance_strategy": "strategy", "outer_fold": "fold"})
    if "fold" not in frame.columns:
        frame["fold"] = frame["source_path"].str.extract(r"fold_(\d+)").astype(int)
    frame["family"] = "classical"
    return frame[["family", "strategy", "seed", "fold", "model_key", *SUMMARY_METRICS, "source_path"]]


def validate_grid(frame: pd.DataFrame, expected_strategies: dict[str, set[str]]) -> None:
    if frame[["family", "strategy", "seed", "fold"]].duplicated().any():
        raise ValueError("Duplicate family/strategy/partition result")
    expected_partitions = {(seed, fold) for seed in [13, 42, 97] for fold in range(1, 6)}
    for family, strategies in expected_strategies.items():
        family_frame = frame.loc[frame["family"].eq(family)]
        if set(family_frame["strategy"]) != strategies:
            raise ValueError(f"Unexpected {family} strategies")
        for strategy in strategies:
            observed = set(
                family_frame.loc[family_frame["strategy"].eq(strategy), ["seed", "fold"]]
                .itertuples(index=False, name=None)
            )
            if observed != expected_partitions:
                raise ValueError(f"Incomplete {family}/{strategy} partition grid")


def holm_adjust(p_values: list[float]) -> list[float]:
    order = sorted(range(len(p_values)), key=lambda index: p_values[index])
    adjusted = [0.0] * len(p_values)
    running = 0.0
    total = len(p_values)
    for rank, index in enumerate(order):
        value = min(1.0, (total - rank) * p_values[index])
        running = max(running, value)
        adjusted[index] = running
    return adjusted


def paired_tests(frame: pd.DataFrame) -> pd.DataFrame:
    rows = []
    planned = {
        "classical": [
            ("baseline", "class_weight"),
            ("baseline", "random_oversampling"),
            ("baseline", "smote"),
            ("baseline", "moderate_undersampling"),
        ],
        "transformer": [
            ("baseline", "balanced_loss"),
            ("baseline", "balanced_sampler"),
            ("balanced_loss", "balanced_sampler"),
        ],
    }
    for family, pairs in planned.items():
        group = frame.loc[frame["family"].eq(family)]
        for left, right in pairs:
            pivot = group.loc[
                group["strategy"].isin([left, right]),
                ["seed", "fold", "strategy", "macro_f1"],
            ].pivot(index=["seed", "fold"], columns="strategy", values="macro_f1")
            if len(pivot) != 15 or pivot.isna().any().any():
                raise ValueError(f"Incomplete pair: {family}/{left}/{right}")
            difference = pivot[right] - pivot[left]
            result = wilcoxon(pivot[right], pivot[left], alternative="two-sided")
            rows.append(
                {
                    "family": family,
                    "strategy_a": left,
                    "strategy_b": right,
                    "mean_macro_f1_a": pivot[left].mean(),
                    "mean_macro_f1_b": pivot[right].mean(),
                    "mean_difference_b_minus_a": difference.mean(),
                    "median_difference_b_minus_a": difference.median(),
                    "wins_b": int(difference.gt(0).sum()),
                    "ties": int(difference.eq(0).sum()),
                    "wins_a": int(difference.lt(0).sum()),
                    "wilcoxon_statistic": float(result.statistic),
                    "p_value": float(result.pvalue),
                }
            )
    cross = frame.loc[
        (
            frame["family"].eq("classical")
            & frame["strategy"].eq("smote")
        )
        | (
            frame["family"].eq("transformer")
            & frame["strategy"].eq("balanced_sampler")
        ),
        ["family", "strategy", "seed", "fold", "macro_f1"],
    ].copy()
    cross["model_strategy"] = cross["family"] + "::" + cross["strategy"]
    pivot = cross.pivot(
        index=["seed", "fold"], columns="model_strategy", values="macro_f1"
    )
    left, right = "classical::smote", "transformer::balanced_sampler"
    difference = pivot[right] - pivot[left]
    result = wilcoxon(pivot[right], pivot[left], alternative="two-sided")
    rows.append(
        {
            "family": "cross_family",
            "strategy_a": left,
            "strategy_b": right,
            "mean_macro_f1_a": pivot[left].mean(),
            "mean_macro_f1_b": pivot[right].mean(),
            "mean_difference_b_minus_a": difference.mean(),
            "median_difference_b_minus_a": difference.median(),
            "wins_b": int(difference.gt(0).sum()),
            "ties": int(difference.eq(0).sum()),
            "wins_a": int(difference.lt(0).sum()),
            "wilcoxon_statistic": float(result.statistic),
            "p_value": float(result.pvalue),
        }
    )
    output = pd.DataFrame(rows)
    output["holm_p_value"] = holm_adjust(output["p_value"].tolist())
    output["significant_holm_0_05"] = output["holm_p_value"].le(0.05)
    return output


def make_summary(frame: pd.DataFrame) -> pd.DataFrame:
    return (
        frame.groupby(["family", "strategy"])[SUMMARY_METRICS]
        .agg(["mean", "std"])
        .reset_index()
        .sort_values(("macro_f1", "mean"), ascending=False)
    )


def write_report(summary: pd.DataFrame, tests: pd.DataFrame, output: Path) -> None:
    flat = summary.copy()
    flat.columns = [
        "_".join(str(part) for part in column if str(part))
        if isinstance(column, tuple)
        else str(column)
        for column in flat.columns
    ]
    lines = [
        "# V2 imbalance-treatment experiment results",
        "",
        "All resampling was confined to the training split of each of 15 artist-exclusive partitions.",
        "Validation and test distributions were never altered.",
        "",
        "## Mean test performance",
        "",
        "| Family | Strategy | Macro-F1 | Balanced accuracy | Accuracy | Anger F1 | Calmness F1 |",
        "|---|---|---:|---:|---:|---:|---:|",
    ]
    for row in flat.itertuples(index=False):
        lines.append(
            f"| {row.family} | {row.strategy} | "
            f"{row.macro_f1_mean:.3f} ± {row.macro_f1_std:.3f} | "
            f"{row.balanced_accuracy_mean:.3f} | {row.accuracy_mean:.3f} | "
            f"{row.anger_f1_mean:.3f} | {row.calmness_f1_mean:.3f} |"
        )
    lines.extend(
        [
            "",
            "## Paired macro-F1 comparisons",
            "",
            "| Family | A | B | Mean B-A | B wins | A wins | Raw p | Holm p |",
            "|---|---|---|---:|---:|---:|---:|---:|",
        ]
    )
    for row in tests.itertuples(index=False):
        lines.append(
            f"| {row.family} | {row.strategy_a} | {row.strategy_b} | "
            f"{row.mean_difference_b_minus_a:+.3f} | {row.wins_b} | {row.wins_a} | "
            f"{row.p_value:.4f} | {row.holm_p_value:.4f} |"
        )
    lines.extend(
        [
            "",
            "The labels are AI-assisted development labels rather than an independently validated human gold standard.",
        ]
    )
    output.write_text("\n".join(lines) + "\n", encoding="utf-8")


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("results_root", type=Path)
    args = parser.parse_args()
    root = args.results_root
    classical = collect_classical(root / "classical_all_metrics.csv")
    transformer = collect_transformer(root / "transformer")
    combined = pd.concat([classical, transformer], ignore_index=True, sort=False)
    validate_grid(
        combined,
        {
            "classical": {
                "baseline",
                "class_weight",
                "random_oversampling",
                "smote",
                "moderate_undersampling",
            },
            "transformer": {"baseline", "balanced_loss", "balanced_sampler"},
        },
    )
    summary = make_summary(combined)
    tests = paired_tests(combined)
    combined.to_csv(root / "imbalance_fold_metrics.csv", index=False, encoding="utf-8-sig")
    summary.to_csv(root / "imbalance_summary.csv", index=False, encoding="utf-8-sig")
    tests.to_csv(root / "imbalance_paired_tests.csv", index=False, encoding="utf-8-sig")
    write_report(summary, tests, root / "IMBALANCE_RESULTS.md")
    print((root / "IMBALANCE_RESULTS.md").read_text(encoding="utf-8"))


if __name__ == "__main__":
    main()
