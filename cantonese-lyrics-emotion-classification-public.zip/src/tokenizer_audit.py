"""Audit Transformer token coverage and truncation without saving lyric text."""

from __future__ import annotations

import argparse
import json
import unicodedata
from pathlib import Path

import numpy as np
import pandas as pd
from transformers import AutoTokenizer


def audit_tokenizer(
    frame: pd.DataFrame,
    tokenizer,
    model_name: str,
    model_revision: str | None,
    text_column: str = "lyrics",
    id_column: str = "case_id",
    max_length: int = 512,
) -> tuple[pd.DataFrame, dict[str, object]]:
    frame = frame.copy()
    if id_column == "case_id" and id_column not in frame.columns:
        if "corpus_song_id" not in frame.columns:
            raise ValueError("Missing case_id")
        frame["case_id"] = frame["corpus_song_id"]
    required = {text_column, id_column}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if frame[list(required)].isna().any().any():
        raise ValueError("Text and identifiers cannot be missing")
    if frame[id_column].duplicated().any():
        raise ValueError(f"{id_column} must be unique")
    if max_length < 8:
        raise ValueError("max_length is implausibly small")

    unk_token_id = getattr(tokenizer, "unk_token_id", None)
    rows: list[dict[str, object]] = []
    for _, source in frame.iterrows():
        text = str(source[text_column])
        encoding = tokenizer(
            text,
            add_special_tokens=True,
            truncation=False,
            return_offsets_mapping=True,
        )
        token_ids = encoding["input_ids"]
        offsets = encoding.get("offset_mapping", [(0, 0)] * len(token_ids))
        token_count = len(token_ids)
        unknown_categories = {
            "unknown_ascii_letter_characters": 0,
            "unknown_cjk_characters": 0,
            "unknown_other_characters": 0,
        }
        if unk_token_id is not None:
            for token_id, (start, end) in zip(token_ids, offsets):
                if token_id != unk_token_id or end <= start:
                    continue
                for character in text[start:end]:
                    if character.isascii() and character.isalpha():
                        unknown_categories["unknown_ascii_letter_characters"] += 1
                    elif "\u4e00" <= character <= "\u9fff":
                        unknown_categories["unknown_cjk_characters"] += 1
                    elif not character.isspace() and not unicodedata.category(character).startswith("P"):
                        unknown_categories["unknown_other_characters"] += 1
        record: dict[str, object] = {
            id_column: source[id_column],
            "model": model_name,
            "model_revision": model_revision,
            "token_count": token_count,
            "tokens_over_limit": max(0, token_count - max_length),
            "would_truncate": token_count > max_length,
            "unknown_token_count": (
                int(sum(token_id == unk_token_id for token_id in token_ids))
                if unk_token_id is not None
                else 0
            ),
            **unknown_categories,
        }
        for metadata_column in [
            "corpus_song_id",
            "section_type",
            "section_index",
            "title",
            "artist",
            "release_year",
        ]:
            if metadata_column in frame.columns:
                record[metadata_column] = source[metadata_column]
        rows.append(record)

    audit = pd.DataFrame(rows)
    token_counts = audit["token_count"].to_numpy()
    summary: dict[str, object] = {
        "model": model_name,
        "model_revision": model_revision,
        "sections": len(audit),
        "source_songs": int(frame["corpus_song_id"].nunique())
        if "corpus_song_id" in frame.columns
        else len(audit),
        "max_length_evaluated": max_length,
        "tokenizer_model_max_length": int(getattr(tokenizer, "model_max_length", max_length)),
        "token_count_min": int(token_counts.min()),
        "token_count_median": float(np.median(token_counts)),
        "token_count_p90": float(np.quantile(token_counts, 0.90)),
        "token_count_p95": float(np.quantile(token_counts, 0.95)),
        "token_count_max": int(token_counts.max()),
        "sections_over_limit": int(audit["would_truncate"].sum()),
        "fraction_over_limit": float(audit["would_truncate"].mean()),
        "tokens_removed_total": int(audit["tokens_over_limit"].sum()),
        "unknown_tokens_total": int(audit["unknown_token_count"].sum()),
        "unknown_tokens_per_section_mean": float(audit["unknown_token_count"].mean()),
        "unknown_ascii_letter_characters_total": int(
            audit["unknown_ascii_letter_characters"].sum()
        ),
        "unknown_cjk_characters_total": int(audit["unknown_cjk_characters"].sum()),
        "unknown_other_characters_total": int(audit["unknown_other_characters"].sum()),
    }
    return audit, summary


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/tokenizer_audit"))
    parser.add_argument("--models", nargs="+", required=True)
    parser.add_argument("--revisions", nargs="*")
    parser.add_argument("--text-column", default="lyrics")
    parser.add_argument("--id-column", default="case_id")
    parser.add_argument("--max-length", type=int, default=512)
    args = parser.parse_args()
    if args.revisions and len(args.revisions) != len(args.models):
        raise ValueError("--revisions must be omitted or contain one value per model")
    revisions = args.revisions or [None] * len(args.models)

    frame = pd.read_csv(args.input, low_memory=False)
    all_rows: list[pd.DataFrame] = []
    summaries: list[dict[str, object]] = []
    for model_name, revision in zip(args.models, revisions):
        tokenizer = AutoTokenizer.from_pretrained(
            model_name,
            revision=revision,
            use_fast=True,
        )
        audit, summary = audit_tokenizer(
            frame,
            tokenizer,
            model_name=model_name,
            model_revision=revision,
            text_column=args.text_column,
            id_column=args.id_column,
            max_length=args.max_length,
        )
        all_rows.append(audit)
        summaries.append(summary)

    args.output_dir.mkdir(parents=True, exist_ok=True)
    pd.concat(all_rows, ignore_index=True).to_csv(
        args.output_dir / "token_counts.csv",
        index=False,
        encoding="utf-8-sig",
    )
    (args.output_dir / "summary.json").write_text(
        json.dumps(summaries, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(summaries, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
