"""Validate the actual PyTorch device with a small matrix operation."""

from __future__ import annotations

import argparse
import json
import platform
import time
from pathlib import Path

import torch


def collect_environment(require_cuda: bool = False, matrix_size: int = 1024) -> dict[str, object]:
    """Return environment metadata and execute work on the selected device."""

    if matrix_size < 2:
        raise ValueError("matrix_size must be at least two")
    cuda_available = torch.cuda.is_available()
    if require_cuda and not cuda_available:
        raise RuntimeError("CUDA is required but torch.cuda.is_available() is false")
    device = torch.device("cuda:0" if cuda_available else "cpu")
    if cuda_available:
        torch.cuda.set_device(0)
        torch.cuda.reset_peak_memory_stats()

    generator = torch.Generator(device=device).manual_seed(42)
    left = torch.randn((matrix_size, matrix_size), generator=generator, device=device)
    right = torch.randn((matrix_size, matrix_size), generator=generator, device=device)
    if cuda_available:
        torch.cuda.synchronize(device)
    started = time.perf_counter()
    product = left @ right
    if cuda_available:
        torch.cuda.synchronize(device)
    operation_seconds = time.perf_counter() - started
    finite = bool(torch.isfinite(product).all().item())
    if not finite:
        raise RuntimeError("Device matrix operation produced non-finite output")

    result: dict[str, object] = {
        "python": platform.python_version(),
        "platform": platform.platform(),
        "torch": torch.__version__,
        "torch_cuda_runtime": torch.version.cuda,
        "cuda_available": cuda_available,
        "device": str(device),
        "device_name": torch.cuda.get_device_name(device) if cuda_available else "CPU",
        "matrix_size": matrix_size,
        "matrix_multiplication_seconds": operation_seconds,
        "finite_output": finite,
    }
    if cuda_available:
        properties = torch.cuda.get_device_properties(device)
        result.update(
            {
                "compute_capability": list(torch.cuda.get_device_capability(device)),
                "device_total_memory_bytes": int(properties.total_memory),
                "peak_allocated_memory_bytes": int(torch.cuda.max_memory_allocated()),
                "cudnn_version": torch.backends.cudnn.version(),
            }
        )
    return result


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("results/environment/gpu_validation.json"),
    )
    parser.add_argument("--require-cuda", action="store_true")
    parser.add_argument("--matrix-size", type=int, default=2048)
    args = parser.parse_args()

    result = collect_environment(
        require_cuda=args.require_cuda,
        matrix_size=args.matrix_size,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(result, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
