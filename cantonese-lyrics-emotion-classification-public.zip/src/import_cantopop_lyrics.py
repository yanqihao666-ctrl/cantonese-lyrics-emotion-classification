"""Extract lyric text from the CC BY 4.0 Cantopop Corpus Humdrum files."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path
import re

import pandas as pd


CORPUS_URL = "https://github.com/jasonleeubc/Cantopop-corpus"
CORPUS_LICENSE = "CC BY 4.0"
SECTION_MARKER = re.compile(r"^\*>([^\t]+)")

# Verified public-source corrections to metadata errors in the upstream files.
# The original values and evidence URLs remain in the derived dataset so the
# intervention is reversible and auditable.
KNOWN_METADATA_CORRECTIONS: dict[str, dict[str, object]] = {
    "C0802": {
        "artist": "謝安琪",
        "metadata_correction_source_url": (
            "https://zh.wikipedia.org/wiki/"
            "%E5%9B%8D%E5%B8%96%E8%A1%97_(%E6%AD%8C%E6%9B%B2)"
        ),
        "metadata_correction_note": "Upstream MGN contains the song title; verified artist is 謝安琪.",
    },
    "C1704": {
        "artist": "衛蘭",
        "release_year": 2017,
        "metadata_correction_source_url": "https://music.apple.com/tw/song/1212415345",
        "metadata_correction_note": (
            "Upstream MGN/year identify the wrong recording; corpus lyrics and credits "
            "match 衛蘭《天敵》, released in 2017."
        ),
    },
}


def _metadata_line(line: str) -> tuple[str, str] | None:
    if not line.startswith("!!!") or ":" not in line:
        return None
    key, value = line[3:].split(":", 1)
    return key.strip(), value.strip()


def _normalise_section_type(value: str) -> str:
    return re.sub(r"[^a-z0-9]+", "_", value.strip().lower()).strip("_") or "unmarked"


def apply_known_metadata_corrections(frame: pd.DataFrame) -> pd.DataFrame:
    """Apply source-backed corrections while retaining every upstream value."""

    required = {"corpus_song_id", "artist", "release_year"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns for metadata correction: {missing}")
    corrected = frame.copy()
    if "source_artist_original" not in corrected.columns:
        corrected["source_artist_original"] = corrected["artist"]
    if "source_release_year_original" not in corrected.columns:
        corrected["source_release_year_original"] = corrected["release_year"]
    if "metadata_correction_applied" not in corrected.columns:
        corrected["metadata_correction_applied"] = False
    if "metadata_correction_source_url" not in corrected.columns:
        corrected["metadata_correction_source_url"] = pd.NA
    if "metadata_correction_note" not in corrected.columns:
        corrected["metadata_correction_note"] = pd.NA
    for song_id, values in KNOWN_METADATA_CORRECTIONS.items():
        mask = corrected["corpus_song_id"].astype(str).eq(song_id)
        if not mask.any():
            continue
        for column in ["artist", "release_year"]:
            if column in values:
                corrected.loc[mask, column] = values[column]
        corrected.loc[mask, "metadata_correction_applied"] = True
        corrected.loc[mask, "metadata_correction_source_url"] = values[
            "metadata_correction_source_url"
        ]
        corrected.loc[mask, "metadata_correction_note"] = values[
            "metadata_correction_note"
        ]
    return corrected


def _read_humdrum(
    path: str | Path,
) -> tuple[dict[str, str], bytes, list[str], list[str], list[dict[str, object]]]:
    """Read one Humdrum file and retain its lyric-bearing structural sections."""
    path = Path(path)
    raw = path.read_bytes()
    lines = raw.decode("utf-8-sig").splitlines()
    metadata: dict[str, str] = {}
    text_index: int | None = None
    jyutping_index: int | None = None
    characters: list[str] = []
    pronunciations: list[str] = []
    current_characters: list[str] = []
    current_pronunciations: list[str] = []
    current_section_type = "unmarked"
    section_occurrences: list[dict[str, object]] = []

    def flush_section() -> None:
        nonlocal current_characters, current_pronunciations
        if not current_characters:
            current_pronunciations = []
            return
        section_occurrences.append(
            {
                "section_type": current_section_type,
                "lyrics": "".join(current_characters),
                "jyutping": " ".join(current_pronunciations),
            }
        )
        current_characters = []
        current_pronunciations = []

    for line in lines:
        item = _metadata_line(line)
        if item:
            metadata[item[0]] = item[1]
            continue

        columns = line.split("\t")
        if line.startswith("**"):
            text_index = columns.index("**text") if "**text" in columns else None
            jyutping_index = columns.index("**jyutping") if "**jyutping" in columns else None
            continue
        section_match = SECTION_MARKER.match(line)
        if section_match:
            flush_section()
            current_section_type = _normalise_section_type(section_match.group(1))
            continue
        if not columns or line.startswith(("!", "*", "=")):
            continue
        if text_index is not None and len(columns) > text_index:
            token = columns[text_index].strip()
            if token not in {"", "."}:
                characters.append(token)
                current_characters.append(token)
        if jyutping_index is not None and len(columns) > jyutping_index:
            token = columns[jyutping_index].strip()
            if token not in {"", "."}:
                pronunciations.append(token)
                current_pronunciations.append(token)

    flush_section()
    return metadata, raw, characters, pronunciations, section_occurrences


def parse_humdrum(path: str | Path) -> dict[str, object]:
    """Extract complete-song metadata and text from one .krn file."""
    path = Path(path)
    metadata, raw, characters, pronunciations, _ = _read_humdrum(path)

    lyric = "".join(characters)
    if not lyric:
        raise ValueError(f"No lyric text extracted from {path}")

    return {
        "corpus_song_id": metadata.get("OTA", path.stem),
        "title": metadata.get("OTL", ""),
        "release_year": metadata.get("RRD", ""),
        "artist": metadata.get("MGN", ""),
        "composer": metadata.get("COM", ""),
        "lyricist": metadata.get("LYR", ""),
        "lyrics": lyric,
        "jyutping": " ".join(pronunciations),
        "character_count": len(lyric),
        "source_file": path.name,
        "source_sha256": hashlib.sha256(raw).hexdigest(),
        "source_url": f"{CORPUS_URL}/blob/main/Humdrum-files/{path.name}",
        "source_dataset": "Cantopop Corpus Project",
        "source_license": CORPUS_LICENSE,
        "emotion_label": pd.NA,
        "label_status": "unlabelled",
    }


def parse_humdrum_sections(path: str | Path) -> list[dict[str, object]]:
    """Extract lyric-bearing structural sections and deduplicate repeats within a song."""
    path = Path(path)
    metadata, raw, _, _, occurrences = _read_humdrum(path)
    song_id = metadata.get("OTA", path.stem)
    unique_sections: list[dict[str, object]] = []
    by_lyric: dict[str, dict[str, object]] = {}

    for occurrence_index, occurrence in enumerate(occurrences, start=1):
        lyric = str(occurrence["lyrics"])
        normalised_lyric = re.sub(r"\s+", "", lyric)
        if not normalised_lyric:
            continue
        if normalised_lyric in by_lyric:
            existing = by_lyric[normalised_lyric]
            existing["occurrence_count"] = int(existing["occurrence_count"]) + 1
            existing["source_section_indices"] = (
                f"{existing['source_section_indices']};{occurrence_index}"
            )
            existing_types = str(existing["source_section_types"]).split(";")
            section_type = str(occurrence["section_type"])
            if section_type not in existing_types:
                existing["source_section_types"] = (
                    f"{existing['source_section_types']};{section_type}"
                )
            pronunciation = str(occurrence["jyutping"])
            pronunciation_hashes = str(existing["_pronunciation_hashes"]).split(";")
            pronunciation_hash = hashlib.sha256(pronunciation.encode("utf-8")).hexdigest()
            if pronunciation_hash not in pronunciation_hashes:
                existing["_pronunciation_hashes"] = (
                    f"{existing['_pronunciation_hashes']};{pronunciation_hash}"
                )
                existing["jyutping_variant_count"] = int(
                    existing["jyutping_variant_count"]
                ) + 1
            continue

        section_type = str(occurrence["section_type"])
        pronunciation = str(occurrence["jyutping"])
        row: dict[str, object] = {
            "case_id": f"{song_id}-SEC{occurrence_index:02d}",
            "corpus_song_id": song_id,
            "section_index": occurrence_index,
            "section_type": section_type,
            "source_section_types": section_type,
            "source_section_indices": str(occurrence_index),
            "occurrence_count": 1,
            "jyutping_variant_count": 1,
            "lyrics": lyric,
            "jyutping": pronunciation,
            "character_count": len(lyric),
            "title": metadata.get("OTL", ""),
            "release_year": metadata.get("RRD", ""),
            "artist": metadata.get("MGN", ""),
            "composer": metadata.get("COM", ""),
            "lyricist": metadata.get("LYR", ""),
            "source_file": path.name,
            "source_sha256": hashlib.sha256(raw).hexdigest(),
            "source_url": f"{CORPUS_URL}/blob/main/Humdrum-files/{path.name}",
            "source_dataset": "Cantopop Corpus Project",
            "source_license": CORPUS_LICENSE,
            "emotion_label": pd.NA,
            "label_status": "unlabelled",
            "_pronunciation_hashes": hashlib.sha256(
                pronunciation.encode("utf-8")
            ).hexdigest(),
        }
        unique_sections.append(row)
        by_lyric[normalised_lyric] = row

    if not unique_sections:
        raise ValueError(f"No lyric sections extracted from {path}")
    for row in unique_sections:
        row.pop("_pronunciation_hashes", None)
    return unique_sections


def import_directory(directory: str | Path) -> pd.DataFrame:
    directory = Path(directory)
    paths = sorted(directory.glob("*.krn"))
    if not paths:
        raise FileNotFoundError(f"No .krn files found under {directory}")
    frame = pd.DataFrame(parse_humdrum(path) for path in paths)
    if frame["corpus_song_id"].duplicated().any():
        raise ValueError("Duplicate corpus_song_id values found")
    return apply_known_metadata_corrections(frame)


def import_section_directory(directory: str | Path) -> pd.DataFrame:
    """Extract all within-song deduplicated structural lyric sections."""
    directory = Path(directory)
    paths = sorted(directory.glob("*.krn"))
    if not paths:
        raise FileNotFoundError(f"No .krn files found under {directory}")
    rows = [section for path in paths for section in parse_humdrum_sections(path)]
    frame = pd.DataFrame(rows)
    if frame["case_id"].duplicated().any():
        raise ValueError("Duplicate case_id values found")
    if frame["corpus_song_id"].nunique() != len(paths):
        raise ValueError("At least one source song is missing from the section dataset")
    return apply_known_metadata_corrections(frame)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("source_directory", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument(
        "--sections-output",
        type=Path,
        help="Optional path for within-song deduplicated structural lyric sections.",
    )
    args = parser.parse_args()
    frame = import_directory(args.source_directory)
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False, encoding="utf-8-sig")
    print(f"Extracted {len(frame)} lyrics to {args.output}")
    if args.sections_output is not None:
        sections = import_section_directory(args.source_directory)
        args.sections_output.parent.mkdir(parents=True, exist_ok=True)
        sections.to_csv(args.sections_output, index=False, encoding="utf-8-sig")
        print(
            f"Extracted {len(sections)} unique lyric sections to "
            f"{args.sections_output}"
        )


if __name__ == "__main__":
    main()
