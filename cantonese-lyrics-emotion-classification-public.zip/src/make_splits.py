"""Create reproducible, class-balanced, group-exclusive dataset splits."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import numpy as np
import pandas as pd


SPLIT_NAMES = ["train", "validation", "test"]
DEFAULT_RATIOS = np.array([0.70, 0.15, 0.15])


def _score_assignment(
    split_sizes: np.ndarray,
    split_classes: np.ndarray,
    target_sizes: np.ndarray,
    target_classes: np.ndarray,
) -> float:
    size_error = np.mean(np.abs(split_sizes - target_sizes) / np.maximum(target_sizes, 1.0))
    class_error = np.mean(np.abs(split_classes - target_classes) / np.maximum(target_classes, 1.0))
    empty_penalty = 5.0 * np.sum(split_classes == 0)
    return float(size_error + 2.0 * class_error + empty_penalty)


def assign_grouped_splits(
    frame: pd.DataFrame,
    label_column: str = "emotion",
    group_column: str = "artist",
    ratios: np.ndarray = DEFAULT_RATIOS,
    seed: int = 42,
    trials: int = 2_000,
) -> tuple[pd.Series, dict[str, object]]:
    required = {label_column, group_column}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing columns: {missing}")
    if frame[[label_column, group_column]].isna().any().any():
        raise ValueError("Labels and groups cannot be missing")
    if "corpus_song_id" in frame.columns:
        parent_group_counts = frame.groupby("corpus_song_id")[group_column].nunique()
        if parent_group_counts.gt(1).any():
            raise ValueError("Each parent song must map to exactly one artist group")
    ratios = np.asarray(ratios, dtype=float)
    if ratios.shape != (3,) or not np.isclose(ratios.sum(), 1.0) or np.any(ratios <= 0):
        raise ValueError("ratios must contain three positive values summing to one")

    labels = sorted(frame[label_column].astype(str).unique())
    if len(labels) < 2:
        raise ValueError("At least two labels are required")
    group_table = pd.crosstab(frame[group_column], frame[label_column]).reindex(columns=labels, fill_value=0)
    if len(group_table) < 3:
        raise ValueError("At least three groups are required")

    group_sizes = group_table.sum(axis=1).to_numpy(dtype=float)
    group_classes = group_table.to_numpy(dtype=float)
    target_sizes = len(frame) * ratios
    target_classes = np.outer(ratios, group_classes.sum(axis=0))
    rng = np.random.default_rng(seed)
    best_score = float("inf")
    best_assignment: np.ndarray | None = None

    for _ in range(trials):
        jitter = rng.random(len(group_table))
        order = np.lexsort((jitter, -group_sizes))
        split_sizes = np.zeros(3)
        split_classes = np.zeros((3, len(labels)))
        assignment = np.full(len(group_table), -1, dtype=int)
        for group_index in order:
            candidates = []
            for split_index in range(3):
                proposed_sizes = split_sizes.copy()
                proposed_classes = split_classes.copy()
                proposed_sizes[split_index] += group_sizes[group_index]
                proposed_classes[split_index] += group_classes[group_index]
                overfill = np.maximum(proposed_sizes - target_sizes * 1.15, 0).sum()
                score = _score_assignment(proposed_sizes, proposed_classes, target_sizes, target_classes)
                candidates.append(score + overfill)
            minimum = min(candidates)
            choices = np.flatnonzero(np.isclose(candidates, minimum))
            chosen = int(rng.choice(choices))
            assignment[group_index] = chosen
            split_sizes[chosen] += group_sizes[group_index]
            split_classes[chosen] += group_classes[group_index]
        score = _score_assignment(split_sizes, split_classes, target_sizes, target_classes)
        if score < best_score:
            best_score = score
            best_assignment = assignment.copy()

    assert best_assignment is not None
    group_to_split = {
        group: SPLIT_NAMES[int(best_assignment[index])] for index, group in enumerate(group_table.index)
    }
    assigned = frame[group_column].map(group_to_split)
    diagnostics_table = pd.crosstab(assigned, frame[label_column]).reindex(
        index=SPLIT_NAMES, columns=labels, fill_value=0
    )
    diagnostics: dict[str, object] = {
        "seed": seed,
        "trials": trials,
        "objective": best_score,
        "ratios_requested": dict(zip(SPLIT_NAMES, ratios.tolist())),
        "rows_per_split": assigned.value_counts().reindex(SPLIT_NAMES, fill_value=0).to_dict(),
        "groups_per_split": frame.assign(_split=assigned).groupby("_split")[group_column].nunique().reindex(SPLIT_NAMES, fill_value=0).to_dict(),
        "class_counts": diagnostics_table.to_dict(orient="index"),
        "group_overlap": False,
        "parent_song_overlap": bool(
            frame.assign(_split=assigned)
            .groupby("corpus_song_id")["_split"]
            .nunique()
            .gt(1)
            .any()
        )
        if "corpus_song_id" in frame.columns
        else False,
        "source_songs_per_split": (
            frame.assign(_split=assigned)
            .groupby("_split")["corpus_song_id"]
            .nunique()
            .reindex(SPLIT_NAMES, fill_value=0)
            .to_dict()
            if "corpus_song_id" in frame.columns
            else None
        ),
    }
    return assigned, diagnostics


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("output", type=Path)
    parser.add_argument("--label-column", default="emotion")
    parser.add_argument("--group-column", default="artist")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--trials", type=int, default=2_000)
    args = parser.parse_args()
    frame = pd.read_csv(args.input)
    frame["split"], diagnostics = assign_grouped_splits(
        frame,
        label_column=args.label_column,
        group_column=args.group_column,
        seed=args.seed,
        trials=args.trials,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    frame.to_csv(args.output, index=False, encoding="utf-8-sig")
    args.output.with_suffix(".split_diagnostics.json").write_text(
        json.dumps(diagnostics, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps(diagnostics, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
