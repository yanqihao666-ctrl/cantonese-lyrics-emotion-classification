"""Validation utilities for the Cantonese lyric-emotion dataset."""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import pandas as pd


PRIMARY_LABELS = {"joy", "sadness", "anger", "calmness"}
LABEL_QUALITY = {"candidate", "silver", "gold"}
SPLITS = {"train", "validation", "test"}

REQUIRED_COLUMNS = {
    "song_id",
    "title",
    "artist",
    "lyrics",
    "source_url",
    "candidate_label",
    "human_label",
    "confidence",
    "duplicate_group",
    "split",
    "label_quality",
}


@dataclass(frozen=True)
class ValidationIssue:
    severity: str
    code: str
    message: str


def load_dataset(path: str | Path) -> pd.DataFrame:
    """Load a UTF-8 CSV without silently converting identifiers to numbers."""
    return pd.read_csv(path, dtype={"song_id": "string", "duplicate_group": "string"})


def validate_dataset(frame: pd.DataFrame) -> list[ValidationIssue]:
    """Return all structural and leakage-related issues found in a dataset."""
    issues: list[ValidationIssue] = []
    missing = sorted(REQUIRED_COLUMNS.difference(frame.columns))
    if missing:
        return [ValidationIssue("error", "missing_columns", f"Missing columns: {missing}")]

    if frame.empty:
        issues.append(ValidationIssue("error", "empty_dataset", "Dataset has no rows."))
        return issues

    if frame["song_id"].isna().any() or frame["song_id"].str.strip().eq("").any():
        issues.append(ValidationIssue("error", "missing_song_id", "Every row requires song_id."))
    if frame["song_id"].duplicated().any():
        issues.append(ValidationIssue("error", "duplicate_song_id", "song_id values must be unique."))

    for column in ("title", "artist", "lyrics", "source_url"):
        if frame[column].isna().any() or frame[column].astype("string").str.strip().eq("").any():
            issues.append(ValidationIssue("error", f"missing_{column}", f"{column} contains empty values."))

    for column in ("candidate_label", "human_label"):
        values = set(frame[column].dropna().astype(str).str.lower())
        invalid = sorted(values.difference(PRIMARY_LABELS))
        if invalid:
            issues.append(ValidationIssue("error", f"invalid_{column}", f"Invalid labels: {invalid}"))

    quality_values = set(frame["label_quality"].dropna().astype(str).str.lower())
    invalid_quality = sorted(quality_values.difference(LABEL_QUALITY))
    if invalid_quality:
        issues.append(ValidationIssue("error", "invalid_label_quality", f"Invalid values: {invalid_quality}"))

    split_values = set(frame["split"].dropna().astype(str).str.lower())
    invalid_splits = sorted(split_values.difference(SPLITS))
    if invalid_splits:
        issues.append(ValidationIssue("error", "invalid_split", f"Invalid splits: {invalid_splits}"))

    confidence = pd.to_numeric(frame["confidence"], errors="coerce")
    if confidence.dropna().lt(1).any() or confidence.dropna().gt(5).any():
        issues.append(ValidationIssue("error", "invalid_confidence", "Confidence must be between 1 and 5."))

    gold = frame["label_quality"].astype("string").str.lower().eq("gold")
    if frame.loc[gold, "human_label"].isna().any():
        issues.append(ValidationIssue("error", "gold_without_human_label", "Gold rows require human_label."))

    grouped_splits = frame.dropna(subset=["duplicate_group", "split"]).groupby("duplicate_group")["split"].nunique()
    if grouped_splits.gt(1).any():
        issues.append(
            ValidationIssue(
                "error",
                "duplicate_group_leakage",
                "At least one duplicate group occurs in multiple data splits.",
            )
        )

    artist_splits = frame.dropna(subset=["artist", "split"]).groupby("artist")["split"].nunique()
    if artist_splits.gt(1).any():
        issues.append(
            ValidationIssue(
                "warning",
                "artist_split_overlap",
                "At least one artist occurs in multiple splits; justify or use a group-aware split.",
            )
        )

    return issues
