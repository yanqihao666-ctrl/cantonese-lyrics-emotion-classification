"""Run the complete shared-partition model matrix with resumable evidence."""

from __future__ import annotations

import argparse
import hashlib
import json
import subprocess
import sys
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from pathlib import Path

import pandas as pd


PRIMARY_TRANSFORMERS = [
    (
        "FacebookAI/xlm-roberta-base",
        "e73636d4f797dec63c3081bb6ed5c7b0bb3f2089",
    ),
    (
        "hfl/chinese-macbert-base",
        "a986e004d2a7f2a1c2f5a3edef4e20604a974ed1",
    ),
]
EXPECTED_SEEDS = [13, 42, 97]
EXPECTED_FOLDS = [1, 2, 3, 4, 5]


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat()


def file_sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


@dataclass
class Partition:
    path: str
    partition_seed: int
    outer_fold: int
    input_sha256: str
    rows: int
    learning_curve_fraction: float | None = None
    training_rows: int | None = None
    training_groups: int | None = None


@dataclass
class ExperimentJob:
    job_id: str
    family: str
    model_key: str
    partition_seed: int
    outer_fold: int
    input_path: str
    input_sha256: str
    command: list[str]
    expected_metadata: str
    stdout_log: str
    stderr_log: str
    learning_curve_fraction: float | None = None
    status: str = "pending"
    started_at_utc: str | None = None
    completed_at_utc: str | None = None
    return_code: int | None = None


def discover_partitions(partitions_dir: Path) -> list[Partition]:
    """Read one identity from each materialised shared-partition CSV."""

    paths = sorted(partitions_dir.glob("*.csv"))
    if not paths:
        raise ValueError(f"No CSV partition files found in {partitions_dir}")
    partitions: list[Partition] = []
    identities: set[tuple[int, int]] = set()
    for path in paths:
        frame = pd.read_csv(path)
        required = {"partition_seed", "outer_fold", "split"}
        missing = sorted(required.difference(frame.columns))
        if missing:
            raise ValueError(f"{path} is missing columns: {missing}")
        seeds = frame["partition_seed"].dropna().unique()
        folds = frame["outer_fold"].dropna().unique()
        if len(seeds) != 1 or len(folds) != 1:
            raise ValueError(f"{path} must contain one partition seed and outer fold")
        if set(frame["split"]) != {"train", "validation", "test"}:
            raise ValueError(f"{path} must contain train, validation and test")
        identity = (int(seeds[0]), int(folds[0]))
        if identity in identities:
            raise ValueError(f"Duplicate partition identity: {identity}")
        identities.add(identity)
        partitions.append(
            Partition(
                path=str(path.resolve()),
                partition_seed=identity[0],
                outer_fold=identity[1],
                input_sha256=file_sha256(path),
                rows=len(frame),
            )
        )
    return sorted(partitions, key=lambda item: (item.partition_seed, item.outer_fold))


def validate_partition_grid(
    partitions: list[Partition],
    seeds: list[int] | None = None,
    folds: list[int] | None = None,
) -> None:
    seeds = seeds or EXPECTED_SEEDS
    folds = folds or EXPECTED_FOLDS
    expected = {(seed, fold) for seed in seeds for fold in folds}
    observed = {(part.partition_seed, part.outer_fold) for part in partitions}
    missing = sorted(expected.difference(observed))
    extra = sorted(observed.difference(expected))
    if missing or extra:
        raise ValueError(f"Partition grid mismatch; missing={missing}, extra={extra}")


def _transformer_run_name(
    model_name: str,
    seed: int,
    outer_fold: int,
    learning_curve_fraction: float | None = None,
) -> str:
    run_name = (
        f"{model_name.replace('/', '__')}__trainseed_{seed}"
        f"__partitionseed_{seed}__fold_{outer_fold}"
    )
    if learning_curve_fraction is not None:
        run_name += f"__fraction_{int(round(learning_curve_fraction * 100)):03d}"
    return run_name


def build_jobs(
    partitions: list[Partition],
    output_root: Path,
    python_executable: Path,
    families: list[str],
    transformer_models: list[tuple[str, str]] | None = None,
) -> list[ExperimentJob]:
    """Create deterministic jobs whose expected outputs cannot collide."""

    invalid_families = sorted(set(families).difference({"classical", "transformer"}))
    if invalid_families:
        raise ValueError(f"Unknown families: {invalid_families}")
    transformer_models = transformer_models or PRIMARY_TRANSFORMERS
    output_root = output_root.resolve()
    logs_dir = output_root / "logs"
    jobs: list[ExperimentJob] = []
    for partition in partitions:
        seed = partition.partition_seed
        fold = partition.outer_fold
        if "classical" in families:
            output_dir = output_root / "classical" / f"seed_{seed}_fold_{fold}"
            job_id = f"classical__seed_{seed}__fold_{fold}"
            jobs.append(
                ExperimentJob(
                    job_id=job_id,
                    family="classical",
                    model_key="classical_matrix",
                    partition_seed=seed,
                    outer_fold=fold,
                    input_path=partition.path,
                    input_sha256=partition.input_sha256,
                    command=[
                        str(python_executable),
                        "-m",
                        "src.classical_experiment",
                        partition.path,
                        "--fixed-split",
                        "--seeds",
                        str(seed),
                        "--id-column",
                        "case_id",
                        "--output-dir",
                        str(output_dir),
                    ],
                    expected_metadata=str(output_dir / "run_metadata.json"),
                    stdout_log=str(logs_dir / f"{job_id}.stdout.log"),
                    stderr_log=str(logs_dir / f"{job_id}.stderr.log"),
                )
            )
        if "transformer" in families:
            for model_name, revision in transformer_models:
                run_name = _transformer_run_name(model_name, seed, fold)
                transformer_root = output_root / "transformer"
                model_slug = model_name.replace("/", "__")
                job_id = f"{model_slug}__seed_{seed}__fold_{fold}"
                jobs.append(
                    ExperimentJob(
                        job_id=job_id,
                        family="transformer",
                        model_key=f"transformer::{model_name}",
                        partition_seed=seed,
                        outer_fold=fold,
                        input_path=partition.path,
                        input_sha256=partition.input_sha256,
                        command=[
                            str(python_executable),
                            "-m",
                            "src.transformer_experiment",
                            partition.path,
                            "--model",
                            model_name,
                            "--model-revision",
                            revision,
                            "--seed",
                            str(seed),
                            "--output-dir",
                            str(transformer_root),
                        ],
                        expected_metadata=str(
                            transformer_root / run_name / "run_metadata.json"
                        ),
                        stdout_log=str(logs_dir / f"{job_id}.stdout.log"),
                        stderr_log=str(logs_dir / f"{job_id}.stderr.log"),
                    )
                )
    job_ids = [job.job_id for job in jobs]
    expected_paths = [job.expected_metadata for job in jobs]
    if len(job_ids) != len(set(job_ids)):
        raise AssertionError("Generated duplicate job identifiers")
    if len(expected_paths) != len(set(expected_paths)):
        raise AssertionError("Generated colliding output paths")
    return jobs


def write_matrix_manifest(
    path: Path,
    partitions: list[Partition],
    jobs: list[ExperimentJob],
) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {
        "updated_at_utc": utc_now(),
        "partition_count": len(partitions),
        "job_count": len(jobs),
        "partitions": [asdict(partition) for partition in partitions],
        "jobs": [asdict(job) for job in jobs],
    }
    path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")


def validate_existing_metadata(job: ExperimentJob) -> None:
    """Reject stale or untraceable output instead of silently resuming past it."""

    metadata_path = Path(job.expected_metadata)
    try:
        metadata = json.loads(metadata_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as error:
        raise RuntimeError(
            f"Existing metadata is unreadable for {job.job_id}; use --force only "
            "after documenting why the prior output is invalid"
        ) from error
    expected = {
        "input_sha256": job.input_sha256,
        "partition_seed": job.partition_seed,
        "outer_fold": job.outer_fold,
    }
    if job.learning_curve_fraction is not None:
        expected["learning_curve_fraction"] = job.learning_curve_fraction
    mismatches = {
        key: {"expected": value, "recorded": metadata.get(key)}
        for key, value in expected.items()
        if metadata.get(key) != value
    }
    if mismatches:
        raise RuntimeError(
            f"Existing output does not match {job.job_id}: {mismatches}. "
            "Refusing to skip stale evidence; use --force only after review."
        )


def execute_jobs(
    jobs: list[ExperimentJob],
    partitions: list[Partition],
    manifest_path: Path,
    workdir: Path,
    force: bool = False,
) -> None:
    """Run jobs sequentially and persist state after every job."""

    for job in jobs:
        expected = Path(job.expected_metadata)
        if expected.exists() and not force:
            validate_existing_metadata(job)
            job.status = "skipped_existing"
            job.completed_at_utc = utc_now()
            job.return_code = 0
            write_matrix_manifest(manifest_path, partitions, jobs)
            continue
        Path(job.stdout_log).parent.mkdir(parents=True, exist_ok=True)
        job.status = "running"
        job.started_at_utc = utc_now()
        write_matrix_manifest(manifest_path, partitions, jobs)
        with Path(job.stdout_log).open("w", encoding="utf-8") as stdout_handle, Path(
            job.stderr_log
        ).open("w", encoding="utf-8") as stderr_handle:
            completed = subprocess.run(
                job.command,
                cwd=workdir,
                stdout=stdout_handle,
                stderr=stderr_handle,
                check=False,
            )
        job.return_code = int(completed.returncode)
        job.completed_at_utc = utc_now()
        if completed.returncode == 0 and expected.exists():
            job.status = "completed"
        else:
            job.status = "failed"
        write_matrix_manifest(manifest_path, partitions, jobs)
        if job.status == "failed":
            raise RuntimeError(
                f"Job {job.job_id} failed; inspect {job.stderr_log}"
            )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("partitions_dir", type=Path)
    parser.add_argument("--output-root", type=Path, default=Path("results/formal"))
    parser.add_argument(
        "--families",
        nargs="+",
        choices=["classical", "transformer"],
        default=["classical", "transformer"],
    )
    parser.add_argument("--allow-partial-grid", action="store_true")
    parser.add_argument("--dry-run", action="store_true")
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()

    partitions = discover_partitions(args.partitions_dir)
    if not args.allow_partial_grid:
        validate_partition_grid(partitions)
    jobs = build_jobs(
        partitions,
        output_root=args.output_root,
        python_executable=Path(sys.executable).resolve(),
        families=args.families,
    )
    manifest_path = args.output_root / "experiment_matrix.json"
    write_matrix_manifest(manifest_path, partitions, jobs)
    print(
        json.dumps(
            {
                "partitions": len(partitions),
                "jobs": len(jobs),
                "manifest": str(manifest_path),
                "dry_run": args.dry_run,
            },
            indent=2,
        )
    )
    if not args.dry_run:
        execute_jobs(
            jobs,
            partitions,
            manifest_path=manifest_path,
            workdir=Path.cwd(),
            force=args.force,
        )


if __name__ == "__main__":
    main()
