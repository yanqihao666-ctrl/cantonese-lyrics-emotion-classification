"""Collect formal test predictions into one statistically auditable table."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from src.statistical_analysis import validate_predictions


PREDICTION_FILENAMES = {
    "predictions.csv",
    "test_predictions.csv",
    "selected_test_predictions.csv",
}


def discover_prediction_files(inputs: list[Path]) -> list[Path]:
    """Resolve explicit files and recursively discover supported prediction files."""

    discovered: set[Path] = set()
    for input_path in inputs:
        if input_path.is_file():
            discovered.add(input_path.resolve())
        elif input_path.is_dir():
            for path in input_path.rglob("*.csv"):
                if path.name in PREDICTION_FILENAMES:
                    discovered.add(path.resolve())
        else:
            raise FileNotFoundError(input_path)
    if not discovered:
        raise ValueError("No prediction files found")
    return sorted(discovered)


def collect_prediction_files(
    paths: list[Path],
    id_column: str = "case_id",
    partition_seeds: list[int] | None = None,
    outer_folds: list[int] | None = None,
) -> tuple[pd.DataFrame, dict[str, object]]:
    """Load test-only predictions and validate one row per model/case."""

    parts: list[pd.DataFrame] = []
    file_rows: list[dict[str, object]] = []
    for path in paths:
        frame = pd.read_csv(path)
        if "evaluation_split" in frame.columns:
            frame = frame.loc[frame["evaluation_split"] == "test"].copy()
        if partition_seeds is not None:
            if "partition_seed" not in frame.columns:
                raise ValueError(f"{path} is missing partition_seed")
            frame = frame.loc[frame["partition_seed"].isin(partition_seeds)].copy()
        if outer_folds is not None:
            if "outer_fold" not in frame.columns:
                raise ValueError(f"{path} is missing outer_fold")
            frame = frame.loc[frame["outer_fold"].isin(outer_folds)].copy()
        if frame.empty:
            continue
        frame["source_prediction_file"] = str(path)
        parts.append(frame)
        file_rows.append(
            {
                "path": str(path),
                "test_prediction_rows": len(frame),
                "model_keys": sorted(frame["model_key"].dropna().astype(str).unique())
                if "model_key" in frame.columns
                else [],
            }
        )
    if not parts:
        raise ValueError("Prediction files contained no test rows")

    combined = pd.concat(parts, ignore_index=True, sort=False)
    validated = validate_predictions(combined, id_column=id_column)
    validated = validated.sort_values(
        ["model_key", "partition_seed", "outer_fold", id_column]
    ).reset_index(drop=True)
    metadata: dict[str, object] = {
        "source_files": file_rows,
        "files": len(file_rows),
        "prediction_rows": len(validated),
        "models": sorted(validated["model_key"].unique()),
        "partition_seeds": sorted(int(value) for value in validated["partition_seed"].unique()),
        "outer_folds": sorted(int(value) for value in validated["outer_fold"].unique()),
        "case_id_column": id_column,
        "cluster_unit": "corpus_song_id"
        if "corpus_song_id" in validated.columns
        else id_column,
        "partition_seed_filter": partition_seeds,
        "outer_fold_filter": outer_folds,
    }
    return validated, metadata


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("inputs", nargs="+", type=Path)
    parser.add_argument("--output", type=Path, default=Path("results/formal_predictions.csv"))
    parser.add_argument("--id-column", default="case_id")
    parser.add_argument("--partition-seeds", nargs="+", type=int)
    parser.add_argument("--outer-folds", nargs="+", type=int)
    args = parser.parse_args()

    paths = discover_prediction_files(args.inputs)
    combined, metadata = collect_prediction_files(
        paths,
        id_column=args.id_column,
        partition_seeds=args.partition_seeds,
        outer_folds=args.outer_folds,
    )
    args.output.parent.mkdir(parents=True, exist_ok=True)
    combined.to_csv(args.output, index=False, encoding="utf-8-sig")
    metadata_path = args.output.with_suffix(".metadata.json")
    metadata_path.write_text(
        json.dumps(metadata, ensure_ascii=False, indent=2),
        encoding="utf-8",
    )
    print(json.dumps(metadata, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
