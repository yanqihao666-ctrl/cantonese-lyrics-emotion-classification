"""Audit AI candidate labels without treating them as ground truth."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd


LABELS = ["joy", "sadness", "anger", "calmness"]


def audit_candidate_labels(frame: pd.DataFrame) -> tuple[dict[str, object], pd.DataFrame]:
    required = {"candidate_label", "prompt_agreement", "mean_top_two_margin", "label_quality"}
    missing = sorted(required.difference(frame.columns))
    if missing:
        raise ValueError(f"Missing candidate columns: {missing}")
    if set(frame["label_quality"].dropna()) != {"candidate"}:
        raise ValueError("All rows must remain explicitly marked as candidate")
    invalid = sorted(set(frame["candidate_label"].dropna()) - set(LABELS))
    if invalid:
        raise ValueError(f"Invalid candidate labels: {invalid}")

    audited = frame.copy()
    audited["prompt_agreement"] = pd.to_numeric(audited["prompt_agreement"], errors="coerce")
    audited["mean_top_two_margin"] = pd.to_numeric(audited["mean_top_two_margin"], errors="coerce")
    if audited[["prompt_agreement", "mean_top_two_margin"]].isna().any().any():
        raise ValueError("Agreement and margin must be numeric")
    audited["review_priority"] = 1.0 - audited["prompt_agreement"] + (1.0 - audited["mean_top_two_margin"])
    audited["high_confidence_candidate"] = (
        audited["prompt_agreement"].eq(1.0) & audited["mean_top_two_margin"].ge(0.15)
    )
    distribution = audited["candidate_label"].value_counts().reindex(LABELS, fill_value=0)
    largest_share = float(distribution.max() / len(audited)) if len(audited) else 0.0
    summary: dict[str, object] = {
        "items": int(len(audited)),
        "candidate_distribution": distribution.to_dict(),
        "largest_candidate_class_share": largest_share,
        "candidate_class_collapse_warning": largest_share > 0.60,
        "unanimous_prompt_items": int(audited["prompt_agreement"].eq(1.0).sum()),
        "two_of_three_prompt_items": int(audited["prompt_agreement"].eq(2 / 3).sum()),
        "tied_or_missing_items": int(audited["candidate_label"].isna().sum()),
        "mean_top_two_margin": float(audited["mean_top_two_margin"].mean()),
        "median_top_two_margin": float(audited["mean_top_two_margin"].median()),
        "high_confidence_candidate_items": int(audited["high_confidence_candidate"].sum()),
        "candidate_methods": sorted(
            audited["candidate_method"].dropna().astype(str).unique().tolist()
        )
        if "candidate_method" in audited.columns
        else [],
        "candidate_model_revisions": sorted(
            audited["candidate_model_revision"].dropna().astype(str).unique().tolist()
        )
        if "candidate_model_revision" in audited.columns
        else [],
        "interpretation": "Candidate labels are for sampling and review prioritisation only; they are not gold labels.",
    }
    safe_columns = [
        column
        for column in [
            "case_id",
            "corpus_song_id",
            "section_type",
            "section_index",
            "title",
            "artist",
            "release_year",
            "candidate_label",
            "prompt_agreement",
            "mean_top_two_margin",
            "review_priority",
            "high_confidence_candidate",
            "candidate_method",
            "candidate_model_revision",
            "label_quality",
        ]
        if column in audited.columns
    ]
    queue = audited.sort_values(
        ["prompt_agreement", "mean_top_two_margin"], ascending=[True, True], na_position="first"
    )[safe_columns]
    return summary, queue


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("input", type=Path)
    parser.add_argument("--output-dir", type=Path, default=Path("results/candidate_label_audit"))
    args = parser.parse_args()
    summary, queue = audit_candidate_labels(pd.read_csv(args.input))
    args.output_dir.mkdir(parents=True, exist_ok=True)
    (args.output_dir / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    queue.to_csv(args.output_dir / "human_review_priority.csv", index=False, encoding="utf-8-sig")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
