# Gold-label adjudication and freeze protocol

Status: implemented; use after both independent workbooks are complete

## Required inputs

- the unchanged licensed source corpus;
- the unchanged researcher key linking blind annotation IDs to unique section `case_id` values and parent song IDs;
- both independently completed blind CSV or XLSX files;
- the completed adjudication queue produced by `annotation_agreement.py`.

The program reads the formatted Excel workbooks from their `Annotations` worksheet. Annotators should never receive the researcher key, the other annotator's decisions or AI candidate labels.

## What enters adjudication

An item requires a separate decision if any of the following holds:

- the two primary labels differ;
- either confidence score is 1 or 2;
- either annotator marks `mixed`, `uncertain`, `non_cantonese`, `insufficient_text` or `translation_required`.

The queue records every applicable reason. Confidence must be an integer from 1 to 5. Score 3 is retained for stratified analysis but does not by itself force adjudication.

## Required decision fields

Every queued row requires:

- `adjudicated_label`: one of joy, sadness, anger or calmness when included;
- `include_in_gold`: an explicit true/false decision;
- `exclusion_reason`: mandatory when excluded;
- `adjudicator_rationale`: concise evidence for the decision;
- `adjudicator_code`: a pseudonymous role/participant code, not an unnecessary name;
- `adjudication_date`: a valid date.

The adjudicator must be competent to interpret the relevant Cantonese text. AI translations or candidate labels may not silently resolve a human disagreement. If language assistance informs a decision, the human verification and limitation should be recorded in the rationale.

The completed decision file must contain exactly the required annotation IDs. Missing decisions and unexplained extra rows stop the freeze. A consensus, unflagged, confidence-above-2 row is included automatically with its agreed label and cannot be changed through the adjudication file.

## Outputs

`build_gold_dataset.py` writes:

- `gold_labelled.csv`: local modelling data with the final `emotion` label;
- `gold_decision_audit.csv`: lyric-free row-level provenance preserving both labels, confidences, flags, reasons, inclusion decision and label source;
- `gold_freeze_metadata.json`: input/output SHA-256 hashes, agreement summary, inclusion/exclusion counts, class counts and artist-group counts.

The two original annotation files are never modified. Excluded cases remain in the decision audit with a reason but not in the modelling dataset.

`case_id` is the unique freeze and modelling key. `corpus_song_id` is retained as the parent-dependence key so all sections from a song can be kept together during evaluation and inferential resampling.

## Formal gate

Before creating cross-validation partitions:

1. confirm the recorded hashes against the files being archived;
2. inspect every exclusion and adjudication rationale;
3. require all four labels in the included dataset;
4. require at least five distinct artists per label for the locked five-fold grouped design;
5. record the clean Git commit and freeze date;
6. do not alter a label or exclusion after viewing model test performance.

If the artist-group requirement fails, stop and agree a revised evaluation design with the supervisor before training. Do not duplicate, oversample or move artists across roles merely to make the existing protocol run.

## Commands

```powershell
.\.venv\Scripts\python.exe -m src.annotation_agreement data\annotation_pilot\annotator_1_blind.xlsx data\annotation_pilot\annotator_2_blind.xlsx --output-dir results\annotation_agreement

.\.venv\Scripts\python.exe -m src.build_gold_dataset data\licensed_text\cantopop_corpus_sections.csv data\annotation_pilot\researcher_key.csv data\annotation_pilot\annotator_1_blind.xlsx data\annotation_pilot\annotator_2_blind.xlsx results\annotation_agreement\adjudication_required.csv --output-dir data\processed --item-id-column case_id
```

No metric from the formal models is needed or permitted at this stage.
