# Core 50 reference plan

## Purpose

This is the controlled citation library for the dissertation **Emotion
Classification in Cantonese Lyrics: A Comparative Study of Transformer-based
and Classical ML Models**. These 50 sources were selected from
`CURATED_100_REFERENCES.md` for direct relevance to the implemented project.

Selection principles:

- prefer original, peer-reviewed and authoritative sources;
- cover every major methodological choice actually used in the project;
- retain enough Cantonese and lyric-specific work to establish the research gap;
- include critical sources on silver labels, disagreement and data validity;
- avoid padding the bibliography with methods that were not implemented.

The dissertation does not need to cite every source in every chapter. Each item
must be cited only where it supports a concrete claim, comparison, design choice
or limitation.

## 1. Lyrics emotion and music-emotion recognition (12)

1. `strapparava_etal_2012` — Strapparava, Mihalcea and Battocchi (2012), [A Parallel Corpus of Music and Lyrics Annotated with Emotions](https://aclanthology.org/L12-1425/). **Use:** human emotion annotation, line-level lyric units and multimodal precedent.
2. `xia_etal_2008` — Xia et al. (2008), [Lyric-based Song Sentiment Classification with Sentiment Vector Space Model](https://aclanthology.org/P08-2034/). **Use:** early Classical ML lyric classification and Chinese-language precedent.
3. `hu_etal_2009` — Hu, Chen and Yang (2009), [Lyric-Based Song Emotion Detection with Affective Lexicon and Fuzzy Clustering Method](https://archives.ismir.net/ismir2009/paper/000041.pdf). **Use:** four-quadrant Chinese lyric classification and taxonomy justification.
4. `malheiro_etal_2018` — Malheiro et al. (2018), [Emotionally-Relevant Features for Classification and Regression of Music Lyrics](https://doi.org/10.1109/TAFFC.2016.2598569). **Use:** lyric features, classification versus dimensional regression and dataset limitations.
5. `edmonds_sedoc_2021` — Edmonds and Sedoc (2021), [Multi-Emotion Classification for Song Lyrics](https://aclanthology.org/2021.wassa-1.24/). **Use:** closest modern lyric-emotion classification comparison.
6. `song_beck_2023` — Song and Beck (2023), [Modeling Emotion Dynamics in Song Lyrics with State Space Models](https://aclanthology.org/2023.tacl-1.10/). **Use:** within-song emotion change and justification for section-level rather than whole-song cases.
7. `agrawal_etal_2021` — Agrawal, Shanker and Alluri (2021), [Transformer-Based Approach Towards Music Emotion Recognition from Lyrics](https://doi.org/10.1007/978-3-030-72240-1_12). **Use:** Transformer precedent for lyric emotion classification.
8. `mihalcea_strapparava_2012` — Mihalcea and Strapparava (2012), [Lyrics, Music, and Emotions](https://aclanthology.org/D12-1054/). **Use:** relationship between lyric and musical emotion information.
9. `liao_etal_2021` — Liao et al. (2021), [Using Transfer Learning to Improve Deep Neural Networks for Lyrics Emotion Recognition in Chinese](https://aclanthology.org/2021.ijclclp-2.1/). **Use:** direct Chinese-lyrics transfer-learning comparator.
10. `fell_etal_2020` — Fell et al. (2020), [Enriching the WASABI Song Corpus with Lyrics Annotations](https://aclanthology.org/2020.lrec-1.262/). **Use:** large automatically enriched lyric corpora and weak-label scale/quality trade-off.
11. `wang_etal_2024` — Wang et al. (2024), [MIR-MLPop](https://doi.org/10.1109/ICASSP48485.2024.10447561). **Use:** multilingual pop dataset and Cantonese resource scarcity.
12. `hu_choi_downie_2017` — Hu, Choi and Downie (2017), [A Framework for Evaluating Multimodal Music Mood Classification](https://doi.org/10.1002/asi.23649). **Use:** evaluation framework and the role of lyric features.

## 2. Cantonese and Chinese NLP (8)

13. `xiang_etal_2024` — Xiang, Liao and Li (2024), [Cantonese Natural Language Processing in the Transformers Era](https://aclanthology.org/2024.sighan-1.8/). **Use:** primary evidence that Cantonese NLP is under-resourced and linguistically distinct.
14. `lee_2023` — Lee (2023), [A Corpus Study of Tone-Melody Correspondence in Cantopop, 2000–2020](https://hdl.handle.net/2429/84374). **Use:** provenance and properties of the original 105-song Cantopop corpus.
15. `lee_2019` — Lee (2019), [An Emotion Detection System for Cantonese](https://cdn.aaai.org/ocs/18309/18309-78928-1-PB.pdf). **Use:** direct Cantonese emotion-detection precedent.
16. `zhang_etal_2024` — Zhang et al. (2024), [Human-LLM Collaborative Construction of a Cantonese Emotion Lexicon](https://arxiv.org/abs/2410.11526). **Use:** Cantonese emotion resources and human–AI labelling context.
17. `cheng_etal_2025` — Cheng, Pan and Li (2025), [ToneCraft](https://aclanthology.org/2025.emnlp-main.18/). **Use:** recent Cantonese lyric NLP and resource construction.
18. `cui_etal_2020` — Cui et al. (2020), [Revisiting Pre-Trained Models for Chinese Natural Language Processing](https://aclanthology.org/2020.findings-emnlp.58/). **Use:** MacBERT architecture and Chinese-specific pretraining.
19. `lee_etal_2022_pycantonese` — Lee et al. (2022), [PyCantonese: Cantonese Linguistics and NLP in Python](https://aclanthology.org/2022.lrec-1.711/). **Use:** Cantonese text processing, Jyutping and reproducible tooling.
20. `lam_lau_lee_2024` — Lam, Lau and Lee (2024), [Multi-Tiered Cantonese Word Segmentation](https://aclanthology.org/2024.lrec-main.1047/). **Use:** word-boundary ambiguity and character-versus-word feature rationale.

## 3. Emotion theory, taxonomy and datasets (7)

21. `russell_1980` — Russell (1980), [A Circumplex Model of Affect](https://doi.org/10.1037/h0077714). **Use:** valence/arousal interpretation of the four categories.
22. `ekman_1992` — Ekman (1992), [An Argument for Basic Emotions](https://doi.org/10.1080/02699939208411068). **Use:** discrete-emotion alternative to dimensional models.
23. `plutchik_2001` — Plutchik (2001), [The Nature of Emotions](https://doi.org/10.1511/2001.4.344). **Use:** emotion inventories and mixed/adjacent emotions.
24. `mohammad_turney_2013` — Mohammad and Turney (2013), [Crowdsourcing a Word-Emotion Association Lexicon](https://doi.org/10.1111/j.1467-8640.2012.00460.x). **Use:** emotion lexicons and annotation methodology.
25. `bostan_klinger_2018` — Bostan and Klinger (2018), [An Analysis of Annotated Corpora for Emotion Classification in Text](https://aclanthology.org/C18-1179/). **Use:** differences among label schemes, domains and corpora.
26. `demszky_etal_2020` — Demszky et al. (2020), [GoEmotions](https://aclanthology.org/2020.acl-main.372/). **Use:** modern fine-grained text-emotion annotation and label ambiguity.
27. `hofmann_etal_2020` — Hofmann et al. (2020), [Appraisal Theories for Emotion Classification in Text](https://aclanthology.org/2020.coling-main.11/). **Use:** implicit emotion, context and why keyword matching is insufficient.

## 4. Transformer and Classical ML foundations (7)

28. `vaswani_etal_2017` — Vaswani et al. (2017), [Attention Is All You Need](https://papers.nips.cc/paper/7181-attention-is-all-you-need). **Use:** Transformer architecture.
29. `devlin_etal_2019` — Devlin et al. (2019), [BERT](https://aclanthology.org/N19-1423/). **Use:** pretrained Transformer fine-tuning.
30. `conneau_etal_2020` — Conneau et al. (2020), [Unsupervised Cross-lingual Representation Learning at Scale](https://aclanthology.org/2020.acl-main.747/). **Use:** XLM-R and multilingual transfer.
31. `salton_buckley_1988` — Salton and Buckley (1988), [Term-Weighting Approaches in Automatic Text Retrieval](https://doi.org/10.1016/0306-4573(88)90021-0). **Use:** TF–IDF representation.
32. `cortes_vapnik_1995` — Cortes and Vapnik (1995), [Support-Vector Networks](https://doi.org/10.1007/BF00994018). **Use:** SVM foundation.
33. `fan_etal_2008` — Fan et al. (2008), [LIBLINEAR](https://www.jmlr.org/papers/v9/fan08a.html). **Use:** linear SVM/logistic regression implementation and scalability.
34. `dodge_etal_2020` — Dodge et al. (2020), [Fine-Tuning Pretrained Language Models](https://arxiv.org/abs/2002.06305). **Use:** seed variability, early stopping and repeated evaluation.

## 5. Class imbalance (5)

35. `chawla_etal_2002` — Chawla et al. (2002), [SMOTE](https://doi.org/10.1613/jair.953). **Use:** explain the implemented SMOTE comparator and its assumptions.
36. `he_garcia_2009` — He and Garcia (2009), [Learning from Imbalanced Data](https://doi.org/10.1109/TKDE.2008.239). **Use:** authoritative imbalance overview.
37. `cui_etal_2019` — Cui et al. (2019), [Class-Balanced Loss Based on Effective Number of Samples](https://openaccess.thecvf.com/content_CVPR_2019/html/Cui_Class-Balanced_Loss_Based_on_Effective_Number_of_Samples_CVPR_2019_paper.html). **Use:** class-weighted loss rationale.
38. `johnson_khoshgoftaar_2019` — Johnson and Khoshgoftaar (2019), [Survey on Deep Learning with Class Imbalance](https://doi.org/10.1186/s40537-019-0192-5). **Use:** Transformer imbalance strategies.
39. `branco_etal_2016` — Branco, Torgo and Ribeiro (2016), [A Survey of Predictive Modeling on Imbalanced Domains](https://doi.org/10.1145/2907070). **Use:** oversampling/undersampling trade-offs and evaluation.

## 6. Evaluation and statistical inference (6)

40. `sokolova_lapalme_2009` — Sokolova and Lapalme (2009), [A Systematic Analysis of Performance Measures for Classification Tasks](https://doi.org/10.1016/j.ipm.2009.03.002). **Use:** accuracy, balanced measures and F1 definitions.
41. `opitz_2024` — Opitz (2024), [A Closer Look at Classification Evaluation Metrics](https://aclanthology.org/2024.tacl-1.46/). **Use:** explicit justification and interpretation of Macro-F1.
42. `cawley_talbot_2010` — Cawley and Talbot (2010), [On Over-fitting in Model Selection and Subsequent Selection Bias](https://www.jmlr.org/papers/v11/cawley10a.html). **Use:** validation-only selection and test-set protection.
43. `berg_kirkpatrick_etal_2012` — Berg-Kirkpatrick, Burkett and Klein (2012), [Statistical Significance in NLP](https://aclanthology.org/D12-1091/). **Use:** paired model comparison.
44. `dror_etal_2018` — Dror et al. (2018), [The Hitchhiker's Guide to Testing Statistical Significance in NLP](https://aclanthology.org/P18-1128/). **Use:** permutation testing and multiplicity-aware interpretation.
45. `du_nguyen_2023` — Du and Nguyen (2023), [Measuring the Instability of Fine-Tuning](https://aclanthology.org/2023.acl-long.342/). **Use:** three seeds, fold variability and reporting dispersion.

## 7. Annotation, silver labels and responsible data (5)

46. `artstein_poesio_2008` — Artstein and Poesio (2008), [Inter-Coder Agreement for Computational Linguistics](https://doi.org/10.1162/coli.07-034-R2). **Use:** explain what is missing without independent human agreement.
47. `ratner_etal_2017` — Ratner et al. (2017), [Snorkel: Rapid Training Data Creation with Weak Supervision](https://www.vldb.org/pvldb/vol11/p269-ratner.pdf). **Use:** multiple noisy labellers and silver-label construction.
48. `leonardelli_etal_2021` — Leonardelli et al. (2021), [Agreeing to Disagree](https://aclanthology.org/2021.emnlp-main.822/). **Use:** disagreement tiers and sensitivity analysis.
49. `bender_friedman_2018` — Bender and Friedman (2018), [Data Statements for NLP](https://aclanthology.org/Q18-1041/). **Use:** dataset provenance, language variety and limitations.
50. `gebru_etal_2021` — Gebru et al. (2021), [Datasheets for Datasets](https://doi.org/10.1145/3458723). **Use:** transparent dataset documentation, intended use and redistribution limits.

## Chapter-level citation allocation

| Dissertation section | Primary reference IDs | Expected distinct sources |
|---|---|---:|
| Introduction and research gap | 1–9, 13–20, 21–27 | 12–18 |
| Literature review | 1–39, 46–50 | 30–40 |
| Methodology | 18–20, 21–24, 28–50 | 18–25 |
| Implementation | 18–20, 28–39, 45, 47, 49–50 | 10–16 |
| Results | 35–45, 48 | 6–10 |
| Discussion and limitations | 1, 4–9, 13–17, 21–27, 35–50 | 15–22 |

## Writing rules

1. Do not attach a citation merely to increase the reference count.
2. Use the original source for a model or method rather than a later blog or
   secondary summary.
3. Distinguish what a cited paper actually showed from an inference made for
   this Cantonese corpus.
4. Never imply that lyric-emotion results from a different language, label set
   or split are directly comparable numerical benchmarks.
5. Cite the dataset source separately from the method used to label it.
6. Cite silver-label and disagreement literature wherever the 6,000-item
   dataset or its performance is interpreted.
7. Use Leeds Harvard consistently in the prose and final reference list.
