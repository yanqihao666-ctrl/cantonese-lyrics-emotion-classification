# Predeclared hyperparameter protocol

Status: locked before human gold labels and formal model scores

## Rationale

The confirmatory comparison uses one fixed configuration per declared model/representation rather than selecting from a large hyperparameter search. Although there are 680 section rows, they are nested within only 105 source songs; repeatedly optimising against a small validation subset could therefore produce high-variance choices and give a misleading advantage to the family receiving the larger search budget.

The search budget for the primary comparison is therefore zero performance-driven alternatives: every setting below was fixed from common text-classification practice, implementation feasibility and the tokenizer audit before gold model results existed. Validation data is used for Transformer early stopping only. Outer-test data is never used for parameter, epoch or checkpoint selection.

## Classical feature settings

| Setting | Character TF-IDF | Word TF-IDF |
|---|---:|---:|
| n-gram range | 2–5 characters | 1–2 Jieba tokens |
| minimum document frequency | 2 | 2 |
| maximum document proportion | 0.98 | 0.98 |
| sublinear term frequency | yes | yes |
| maximum features | 60,000 | 40,000 |
| lowercasing | vectorizer default for characters | disabled |

The combined representation is a feature union of the two unchanged branches.

## Classical classifier settings

| Model | Fixed settings |
|---|---|
| Majority | most frequent training label |
| Multinomial Naive Bayes | `alpha=1.0` |
| Logistic Regression | `C=4.0`, balanced class weights, multinomial-capable L-BFGS solver, maximum 3,000 iterations |
| Linear SVM | `C=1.0`, balanced class weights |

Every non-majority classifier is evaluated with character, word and combined features. The majority prediction is identical across feature representations and is run once.

For the primary family-level comparison, one configuration is selected independently within each outer partition by validation macro-F1. Exact validation ties use ascending `model_key`. This is a predeclared model-selection rule, not a global choice based on pooled validation or test performance. The resulting `classical::validation_selected` comparator may contain different source estimators across partitions, so selection frequencies and margins are reported. RQ2 instead holds Linear SVM fixed while comparing the three representations.

## Transformer settings

| Setting | Fixed value |
|---|---:|
| maximum sequence length | 512 |
| truncation | head–tail |
| training epochs | maximum 5 |
| early-stopping patience | 2 evaluation epochs |
| learning rate | 2e-5 |
| weight decay | 0.01 |
| warm-up ratio | 0.1 |
| per-device training batch | 4 |
| gradient-accumulation steps | 4 |
| effective training batch | 16 |
| evaluation batch | 8 |
| checkpoint criterion | validation macro-F1 |
| precision | FP16 when CUDA is available |

The required checkpoints are pinned XLM-RoBERTa-base and Chinese MacBERT-base revisions. The Cantonese continued-pretraining checkpoint is exploratory and is not substituted into the primary pair after inspecting scores.

## Seeds and partitions

The shared partition seeds are 13, 42 and 97, with five outer artist-grouped folds per seed. Transformer and stochastic classical components use the partition seed as their training seed so the experiment identity is traceable. This does not create independent observations from repeated predictions of the same song; song-clustered inference handles that dependence.

## Sensitivity analysis

If resources permit, a narrowly predeclared sensitivity analysis may vary learning rate or regularisation on development/validation data. It must:

1. be labelled exploratory;
2. use the same candidate count for comparable models within a family;
3. keep outer-test labels inaccessible during selection;
4. retain the fixed configuration above as the primary result;
5. report all tried settings, including failures.

No sensitivity result may retroactively replace the primary setting solely because it improves the aggregate outer-test score.

## Learning-curve scope

RQ3 is not a hyperparameter search. It holds the model settings fixed and changes only the available training subset. The locked scope is seed 42's five outer folds; nominal training-section fractions 0.25, 0.50, 0.75 and 1.00 sampled in whole artist groups; and Character TF-IDF + Linear SVM, XLM-R and MacBERT. Validation/test section IDs remain fixed and parent songs remain intact. No `min_df`, regularisation or Transformer setting may be changed at a small fraction merely to make that point fit.
