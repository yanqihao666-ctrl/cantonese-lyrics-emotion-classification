# Chapter 1: Introduction — working draft

This draft contains no model results. Claims and word allocation should be adapted to the final dissertation template and verified bibliography.

## 1.1 Context and motivation

Song lyrics communicate affect through narrative voice, metaphor, repetition, code-switching and changes across verses and choruses. Automatically classifying that affect can support music retrieval, recommendation and large-scale cultural analysis. It is also a demanding natural-language-processing problem: the emotion expressed in one lyric section is not necessarily the same as its topic, the listener's response, the emotion conveyed by the audio, or the emotion expressed elsewhere in the same song.

Most contemporary text classifiers are based either on sparse lexical representations with classical machine-learning algorithms or on pretrained Transformer language models. Transformers can transfer contextual representations learned from large corpora, but their advantage is not guaranteed when labelled data are scarce, the target language variety is under-represented in pre-training and the domain contains long, figurative text. Strong classical baselines remain important because they require less computation, expose the contribution of textual representation and may generalise more reliably in small datasets.

Cantonese makes this comparison particularly informative. Modern Cantonese NLP is constrained by limited data diversity and by variation between colloquial written Cantonese, standard written Chinese and multilingual code-switching (Xiang et al., 2024). Cantopop lyrics may combine all three. A multilingual model may benefit from broad cross-lingual pre-training; a Chinese-oriented model may represent shared characters well; and a Cantonese-oriented checkpoint may contain more variety-specific information while being less robustly documented or tokenised. These are empirical questions rather than reasons to assume that the most specialised or most complex model will perform best.

## 1.2 Problem definition

This project studies four-class emotion classification from natural structural sections of Cantonese lyrics. A case is a verse, pre-chorus, chorus, bridge, coda or another explicitly marked lyric-bearing section. For each section, the system predicts one dominant emotion: joy, sadness, anger or calmness. This unit retains several connected lines of local context while allowing emotional change within a song; it is neither isolated-line classification nor whole-song classification. The categories are discrete labels covering four interpretable regions of valence-arousal space, but the task is not reduced to positive/negative sentiment or valence prediction.

The comparison faces three connected limitations. First, the documented search did not identify an accessible public benchmark containing Cantonese lyric sections with suitable human emotion labels. Second, the lawful source corpus contains 105 songs and yields 680 within-song-deduplicated structural sections, so observations remain clustered and a single random split would be unstable. Third, artist, parent-song, duplicate and prompt leakage could make apparent performance reflect shortcuts rather than generalisation to unseen artists and independently judged emotions.

The project addresses these limitations by treating dataset construction, annotation reliability and leakage control as part of the research method. Two Cantonese-competent annotators independently label blinded sections; every model uses the same artist-exclusive evaluation cases; all sections from a source song remain in one role; and uncertainty is estimated with parent-song-clustered resampling. AI-generated candidate labels remain separate from human gold labels.

## 1.3 Research gap

Prior work establishes several parts of the problem without resolving their intersection. Lyric-emotion studies use line, verse and song units with different taxonomies, languages and label sources; work on lyric emotion dynamics also shows that a single whole-song label can conceal meaningful changes. Chinese lyric studies provide precedent for four-quadrant emotion annotation and classical lexical methods. Multilingual emotion research shows that cross-lingual transfer can work, while also finding sensitivity to source language and domain. Cantonese NLP research documents resource scarcity, colloquialism and multilinguality, and early Cantonese emotion systems transferred resources from Mandarin and English.

The gap is therefore stated narrowly. The documented literature and dataset search did not identify a reproducible study that compares classical character/word text classifiers with pinned multilingual and Chinese-oriented Transformers on independently validated, section-level Cantonese lyric emotions under artist-exclusive evaluation. This wording does not claim that no related private dataset or unpublished study exists.

## 1.4 Aim and research questions

The aim is:

> To determine how classical machine-learning and Transformer-based approaches compare when classifying emotions expressed in Cantonese song lyrics, with particular attention to low-resource data, textual representation and model errors.

The study answers four questions:

1. How do classical machine-learning and Transformer-based models compare on Cantonese lyric emotion classification?
2. How do character-level and word-level representations affect classical-model performance?
3. How does adding the expansion training corpus affect model performance under a fixed-test design?
4. What class-level and label-evidence patterns characterise model errors?

## 1.5 Objectives

The project objectives are to:

1. construct a provenance-aware section-level Cantonese lyric dataset from lawfully accessible songs;
2. define and pilot a reproducible four-class annotation protocol;
3. quantify independent annotator agreement and preserve ambiguous cases;
4. implement majority, Naive Bayes, logistic-regression and linear-SVM baselines with character, word and combined TF-IDF;
5. fine-tune pinned XLM-RoBERTa-base and Chinese MacBERT-base checkpoints under the same evaluation design;
6. prevent artist and duplicate leakage through shared grouped partitions;
7. compare models using macro-F1, secondary metrics, learning curves, efficiency and cluster-aware uncertainty;
8. analyse errors involving metaphor, mixed affect, written variety, code-switching, repetition and section context;
9. document legal, ethical, professional and generative-AI controls.

## 1.6 Intended contribution

The intended contribution is methodological and empirical rather than architectural. The study provides:

- an auditable workflow for constructing and validating Cantonese lyric-emotion labels;
- a controlled comparison in which model families receive identical artist-exclusive test cases;
- evidence on character versus Standard-Chinese-oriented word segmentation for Cantonese lyrics;
- a tokenizer and transfer analysis across multilingual, Chinese-oriented and exploratory Cantonese checkpoints;
- an uncertainty-aware account of what can and cannot be concluded from 680 sections nested within 105 source songs.

If no model difference is statistically persuasive, that remains a valid finding: it would show that the available evidence is insufficient to justify increased model complexity. Conversely, a Transformer advantage will be interpreted only within the sample, taxonomy and annotation reliability observed.

## 1.7 Scope and exclusions

The study classifies textual emotion expressed by lyric sections. It does not model audio, melody, singer performance or listener-induced emotion. It does not attempt fine-grained multi-label emotion recognition, lyric generation, or general Cantonese sentiment analysis. The 2000-2020 source corpus cannot represent every era, artist or Cantonese-speaking community, and several sections from one song do not create equivalent independent song-level evidence.

The exploratory Cantonese continued-pretraining checkpoint is not allowed to replace the two required Transformer baselines after results are inspected. Unlicensed or provenance-poor lyric collections are excluded regardless of scale. Candidate labels from zero-shot or generative systems are not used as gold evaluation labels.

## 1.8 Dissertation structure

Chapter 2 critically reviews emotion representation, lyric-emotion annotation, classical text classification, multilingual transfer and Cantonese NLP. Chapter 3 presents the corpus, annotation, models, shared evaluation and statistical design. Chapter 4 describes implementation architecture and validation. Chapter 5 reports dataset reliability, model comparisons, learning curves, computational cost and qualitative error analysis. Chapter 6 answers the research questions, states limitations and proposes future work.
