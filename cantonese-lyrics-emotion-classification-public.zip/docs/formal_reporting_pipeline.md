# Formal reporting and multiplicity pipeline

Status: implemented and validated on synthetic predictions before human gold results

## Why this layer is necessary

The classical runner evaluates nine learned model/representation combinations plus one representation-independent majority baseline. Calling the highest test score the "best classical model" would reuse the outer test labels for selection and overstate performance. The reporting workflow therefore constructs a classical-family comparator independently inside each outer partition:

1. rank the 10 configurations by that partition's validation macro-F1;
2. resolve an exact tie by ascending `model_key`, fixed before formal scores;
3. copy only the selected configuration's test predictions;
4. rename the composite `classical::validation_selected`;
5. retain the original source model key and a complete selection audit.

The selected estimator may differ across partitions. Its result estimates the performance of the predeclared validation-selection procedure, not one fixed classical configuration. Selection frequencies and validation margins must therefore be reported.

## Confirmatory and representation families

The primary multiplicity family contains exactly:

- `classical::validation_selected`;
- `transformer::FacebookAI/xlm-roberta-base`;
- `transformer::hfl/chinese-macbert-base`.

This yields three paired comparisons. Cluster-level permutation p-values are Holm-adjusted within these three hypotheses.

RQ2 forms a separate, predeclared family using one fixed classifier:

- `classical::character_tfidf::linear_svm`;
- `classical::word_tfidf::linear_svm`;
- `classical::combined_tfidf::linear_svm`.

Holding the classifier constant makes differences attributable to representation more defensible. Its three paired comparisons receive a separate Holm adjustment. Naive Bayes and Logistic Regression representation results remain useful descriptive or exploratory evidence, but they are not silently added to the confirmatory family after their test scores are seen.

## Integrity controls

`select_classical_configuration.py` requires fixed-partition metadata, unique partition identities, validation and test metrics for the same candidate set, and matching prediction identities. The output metadata hashes every source metric, prediction and run-metadata file. Test metrics appear in the audit for later reporting but are not used by the ranking code.

`statistical_analysis.py --models ...` restricts the requested hypothesis family before calculating any metric, interval, permutation or Holm adjustment. The exact keys and analysis label are saved.

`generate_results_tables.py` then:

- verifies the statistical metadata against the prediction-file SHA-256;
- applies the saved model scope;
- requires identical model/section/partition coverage;
- recalculates partition summaries and compares them with the saved values;
- requires a complete, non-duplicated set of pairwise tests;
- writes overall, per-class and pairwise CSV tables plus Markdown;
- hashes every source artifact used by the tables.

The generated Markdown contains values but no automatic claim that a model is superior. Interpretation remains a research task grounded in effect size, uncertainty, annotation reliability and corpus limitations.

## Synthetic validation

Synthetic tests deliberately give one classical candidate the better validation score and a different candidate the better test score. The selector chooses the validation winner, demonstrating that test performance cannot influence selection. Another test confirms the predeclared tie-break.

The reporting smoke fixture contains two deliberately different synthetic models. It verifies prediction coverage, summary recalculation, clustered uncertainty, paired tests and table rendering. Its values are software checks only and must never be reported as Cantonese lyric-emotion performance.
