# COMP5200M marking alignment

This document converts the official marking guidance into evidence that the project and dissertation must provide. It is a quality-control checklist, not a prediction of the final mark.

## Target standard

The minimum target is the rubric's **Very good (70%+)** band in every category. Work should approach the **Excellent (80%+)** descriptors where feasible, especially in background research, methodological justification and evaluation. A strong implementation cannot compensate for weak research context because background research carries 30% of the mark.

## 1. Background research - 30%

Rubric target: a systematic and thorough scholarly review, clear context for non-specialists, strong critical analysis, and suitable legal, social, ethical and professional discussion.

Evidence already present:

- documented literature search protocol and literature matrix;
- thematic synthesis covering lyric-emotion annotation, low-resource baselines, multilingual transfer and Cantonese NLP;
- a 28-source matrix, 17-entry reproducible search log and key-matched BibTeX library;
- automatic confirmation that all 28 retained sources are cited in the four dissertation-facing drafts;
- an evidence-to-gap map connecting each literature strand to a concrete design control;
- a narrowly stated research gap rather than an unverifiable claim that no relevant dataset exists;
- data-feasibility, copyright, annotation-ethics, bias and generative-AI assessments;
- primary sources for model families and the closest Cantonese work.

Still required:

- convert the working synthesis into the final Chapter 2 prose within the submission word allocation;
- add page numbers for any direct quotation or close, source-specific paraphrase;
- re-run the citation audit after every final chapter edit and render the reference list in the School-approved Leeds style.

## 2. Methodology - 20%

Rubric target: excellent justification of design choices in relation to requirements, professional tool use, version control and clear project planning.

Evidence already present:

- explicit aim, research questions, quality gates and no-result rule;
- provenance-aware corpus schema and deterministic corpus audit;
- independent blinded annotation, confidence and ambiguity flags, agreement and adjudication workflow;
- a reproducibly generated 11-page bilingual annotator pack with explicit ethics, translation and release gates;
- duplicate-aware and artist-exclusive splitting;
- macro-F1 primary metric, per-class analysis, multiple seeds, learning curves and runtime reporting;
- a locked no-search primary hyperparameter protocol, preventing unequal or test-driven tuning;
- Git history, configuration file, modular source tree and automated tests.

Still required:

- obtain supervisor confirmation of the final label taxonomy, ethics route and acceptable AI use;
- predeclare the final evaluation design after observing only label counts and artist coverage, not model scores;
- distinguish 680 section cases from the 105 independent source-song clusters and quantify the resulting uncertainty;
- document project milestones and deviations from the plan.

## 3. Implementation and validation - 20%

Rubric target: a significant technical challenge, substantial complexity, competent achievement of most goals and appropriate validation.

Evidence already present:

- import, validation, audit, annotation, agreement, splitting, classical-model and Transformer runners;
- majority, Naive Bayes, logistic-regression and linear-SVM baselines with character, word and combined TF-IDF;
- multilingual, Chinese-oriented and Cantonese-oriented Transformer candidates;
- saved predictions, metrics, runtime and environment metadata;
- validation that rejects missing classes, duplicate risks and artist leakage;
- a documented software architecture and validation inventory;
- a dissertation evidence register that separates eight verified claims from eight blocked outputs and prohibits `results/smoke` evidence;
- a successful pinned XLM-R end-to-end GPU smoke run with traceable synthetic inputs and outputs;
- 81 passing automated tests as of 30 July 2026, including structural-section extraction, parent-song leakage controls, direct XLSX annotation loading, gold freezing, fraction-addressed/resumable learning curves, test-blind selection, stale-hash refusal, reference consistency, dissertation-evidence controls and terminology/configuration drift checks;
- a resumable 45-job experiment orchestrator validated on a synthetic four-class partition.

Still required:

- use the implemented common cross-validation manifest so all model families receive identical evaluation cases;
- archive exact configurations, package versions, seeds and model revisions;
- preserve the exact Git revision and console logs used for the formal experiments.

## 4. Results, evaluation and discussion - 20%

Rubric target: thorough evaluation, results fully interpreted against the aim and domain, defensible conclusions and detailed future work.

No formal model result exists yet because no human-validated emotion labels exist. This is the correct status.

Required evidence:

- dataset and annotation statistics, agreement, confidence and adjudication outcomes;
- identical artist-grouped evaluation cases for classical and Transformer models;
- macro-F1 with uncertainty, accuracy, weighted-F1 and per-class precision/recall/F1;
- confusion matrices, paired prediction comparisons and an appropriate uncertainty/significance analysis;
- learning curves and runtime/memory or computational-cost comparison;
- ablation of character versus word representation;
- structured error analysis covering metaphor, code-switching, written variety, repetition, mixed emotion and insufficient local context;
- direct answers to every research question, including negative or non-significant findings;
- limitations that distinguish label, sampling, domain, copyright and generalisation threats.

## 5. Presentation - 10%

Rubric target: clear structure and academic English, very good display items, correct and consistent citation formatting.

Required controls:

- one purpose per figure or table and a clear message stated in the surrounding text;
- consistent class order, colours, abbreviations and decimal precision;
- captions that allow figures and tables to be understood without hunting through the chapter;
- appendices for search details, annotation materials, hyperparameters, supplementary metrics, test inventory and AI-use disclosure;
- a completed Word render/accessibility record for the bilingual annotation materials;
- final proofreading for logic, terminology, citation consistency and word limit.

## Highest-priority path to 75+

1. Obtain defensible human labels and agreement evidence.
2. Resolve corpus scale through lawful expansion or explicitly adopt a repeated group-aware low-resource evaluation.
3. Use identical, leakage-free evaluation cases for every model.
4. Produce critical, uncertainty-aware analysis rather than a table of model scores.
5. Maintain traceability from every dissertation number to a saved artifact.
