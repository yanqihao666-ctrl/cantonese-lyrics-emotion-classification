# Formal experiment matrix orchestration

Status: implemented and synthetic end-to-end validation complete

## Purpose

The formal comparison consists of 15 shared artist-exclusive partitions:

- three deterministic partition seeds: 13, 42 and 97;
- five outer folds per seed;
- one classical matrix job per partition;
- two primary Transformer jobs per partition.

This yields 45 auditable jobs: 15 classical jobs and 30 Transformer jobs. A classical job evaluates Multinomial Naive Bayes, logistic regression and linear SVM with character, word and combined TF-IDF, plus one representation-independent majority baseline. Treating these 10 configurations as one job ensures that they consume the same partition file without repeating an identical majority result three times.

## Controls

`src/run_experiment_matrix.py` discovers materialised partition CSVs, reads their embedded seed/fold identity and records a SHA-256 hash for every input. By default it rejects anything other than the exact 3 × 5 formal grid. `--allow-partial-grid` exists only for tests and diagnostics.

Every job receives a unique output directory and log pair. The manifest records the exact Python executable, full command, input hash, expected metadata path, timestamps, return code and status. It is rewritten after every state transition. A failed job stops the sequence rather than allowing an apparently complete but partial experiment.

On a repeated invocation, a job whose expected `run_metadata.json` exists is marked `skipped_existing` only after its input hash, partition seed and outer fold match the current job. Missing, unreadable or stale metadata stops execution. This supports recovery after interruption without silently accepting results from a changed input. `--force` is explicit and should be used only when a documented invalid run must be replaced before results are interpreted.

## Formal commands

First verify the planned grid:

```powershell
.\.venv\Scripts\python.exe -m src.run_experiment_matrix data\processed\cv_partitions --output-root results\formal --dry-run
```

The manifest must report 15 partitions and 45 jobs. Then run:

```powershell
.\.venv\Scripts\python.exe -m src.run_experiment_matrix data\processed\cv_partitions --output-root results\formal
```

The same second command is the recovery command after interruption.

## Validation evidence

The runner was tested at three levels before human labels existed:

1. unit tests verify unique job identifiers/output paths and rejection of an incomplete formal grid;
2. a synthetic four-class partition produces a three-job dry-run plan without loading large models;
3. the full classical job executes all 10 predeclared configurations, writes metrics, predictions and metadata, and is marked `skipped_existing` on a second invocation.

The synthetic execution exposed a scikit-learn compatibility issue: `liblinear` no longer supports the direct four-class configuration used by the project. The pre-result Logistic Regression solver was changed to multinomial-capable L-BFGS, and the four-class fixed-split test now covers this model. No human gold score was available when the change was made.

Synthetic metrics test software behaviour only. They are not estimates of research performance and must not appear in the dissertation results tables.
