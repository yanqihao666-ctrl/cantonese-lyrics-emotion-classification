# Dissertation terminology and consistency contract

Status: controlled writing convention. Machine-readable values are in `configs/dissertation_contract.yaml`.

## Purpose

The dissertation is assembled from several working chapters, protocols and generated artifacts. Small wording differences can silently change the research claim: for example, "best classifier" could imply outer-test selection, and "training-data size affects the two families" does not state that relative performance is being compared. This contract fixes the language that must remain stable across the dissertation, README and experiment configuration.

## Canonical title and aim

Title:

> Emotion Classification in Cantonese Lyrics: a comparative study of Transformer-based and Classical ML models

Aim:

> To determine how classical machine-learning and Transformer-based approaches compare when classifying emotions expressed in Cantonese song lyrics, with particular attention to low-resource data, textual representation and model errors.

The title may be capitalised to match the School template, but its task and comparison must not change.

## Canonical research questions

1. How do classical machine-learning and Transformer-based models compare on Cantonese lyric emotion classification?
2. How do character-level and word-level representations affect classical-model performance?
3. How does training-data size affect the relative performance of the two model families?
4. What linguistic and annotation phenomena account for their errors?

The exact wording is shared by the README, Introduction and Methodology. Chapter 5 and Chapter 6 must answer the same numbered questions.

## Task and metric vocabulary

- Unit of analysis: a natural structural lyric section (for example verse, pre-chorus, chorus, bridge or coda), not an isolated line and not the complete song.
- Case identifier: `case_id`; parent-dependence identifier: `corpus_song_id`.
- Current pre-annotation corpus: 680 unique sections extracted from 105 source songs by 42 canonical artists after correcting two source metadata errors. Eighty-one within-song exact repeated section occurrences are collapsed while their occurrence counts are retained.
- Prediction task: four-class dominant-emotion classification.
- Fixed class order: `joy`, `sadness`, `anger`, `calmness`.
- `mixed` and `uncertain` are flags, not fifth and sixth prediction classes.
- Primary metric: macro-F1.
- Secondary metrics: weighted-F1, accuracy and per-class precision, recall and F1.
- `calmness` is a positive-or-non-negative low-arousal category, not a residual neutral class.
- The dimensional circumplex motivates coverage; this is not valence classification.

Use "human-validated gold labels" only after independent annotation, adjudication and gold freeze. Before that gate, use "annotation workbooks", "candidate labels" or "planned gold-label construction" as appropriate.

## Model vocabulary

First mention:

- XLM-RoBERTa-base (`FacebookAI/xlm-roberta-base`);
- Chinese MacBERT-base (`hfl/chinese-macbert-base`).

Subsequent short forms:

- XLM-R;
- MacBERT.

The two pinned checkpoints are required primary Transformer comparators. `indiejoseph/bert-base-cantonese` is the exploratory Cantonese continued-pretraining checkpoint and cannot replace a required model after test results are inspected.

The classical family is reported as a validation-selected procedure in RQ1. "Best classical model" is prohibited unless the sentence explicitly says which validation-only rule produced the selection. RQ2 holds Linear SVM fixed while comparing character, word and combined TF-IDF.

## Evaluation vocabulary

- Three split seeds: 13, 42 and 97.
- Five outer folds per seed: 15 shared artist-exclusive partitions.
- Validation is drawn only from development artists.
- No artist may cross train, validation and test within a partition.
- Learning curves use the five seed-42 outer folds at nominal 25%, 50%, 75% and 100% training fractions.
- Formal uncertainty uses a song-cluster bootstrap; paired permutation swaps all repeated predictions for a song as one cluster.
- Section-level metric rows are not treated as independent when they share a parent song.
- Holm correction is scoped separately to the declared primary family and RQ2 representation family.

Do not call the 15 partition scores 15 independent datasets. Runtime comparisons are descriptive because hardware paths may differ.

## Tense and evidence gates

- Chapters 1 and 2 may describe the research problem and established literature in present tense.
- Chapter 3 remains future/protocol tense until annotation and formal execution occur; then it must be revised to the method actually used.
- Chapter 4 may describe implemented and tested software in past or present-perfect tense, but synthetic smoke validation must be named as synthetic.
- Chapter 5 retains explicit bracketed placeholders until the named artifacts exist.
- Chapter 6 and the abstract must not contain a final RQ answer before Chapter 5 evidence exists.

Only `docs/results_chapter_template.md` may contain the declared result-placeholder tokens. Markdown link labels are not result placeholders.

## Number and naming style

- Write "680 sections from 105 source songs", "42 canonical artists" and "2000–2020" only when citing the current corrected section extraction/audit.
- Use macro-F1 and weighted-F1 consistently, with a hyphen.
- Use character TF-IDF, word TF-IDF and combined TF-IDF.
- Use artist-exclusive for the partition property and artist-grouped when describing the grouping mechanism.
- Use Cohen's kappa in prose and the symbol κ only after defining it.
- Report effect sizes and intervals before p-values; do not equate non-significance with equivalence.
- Do not use "accuracy" as a synonym for agreement, macro-F1 or general model quality.

## Required audit

Run before every dissertation milestone:

```powershell
.\.venv\Scripts\python.exe -m src.audit_dissertation_consistency --output results\dissertation_consistency_audit.json
```

The audit checks the canonical aim and RQs, chapter numbering, core configuration, model revisions, metric/evaluation constants, result-placeholder scope and known stale phrases. A passing audit proves internal consistency only; it does not prove that blocked results exist or that the prose is academically strong.
