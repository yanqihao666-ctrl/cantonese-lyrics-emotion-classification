# Emotion taxonomy rationale

Status: pre-annotation design, subject to pilot evidence and supervisor approval

## 1. The task remains discrete emotion classification

The primary prediction target is one of four named emotions:

| Label | Operational affect region | Annotation meaning |
|---|---|---|
| `joy` | positive valence, high arousal | delight, hope, excitement, playful affection, triumph or energetic anticipation |
| `anger` | negative valence, high arousal | rage, resentment, accusation, hostility, protest, betrayal or confrontation |
| `sadness` | negative valence, low arousal | grief, loneliness, regret, helplessness, loss or painful longing |
| `calmness` | positive or non-negative valence, low arousal | peace, acceptance, reassurance, contentment, tenderness, serenity or gentle reflection |

Valence and arousal are used to make the four labels cover distinct parts of affective space. They are not separate regression targets, and the project is not renamed or reframed as valence classification.

## 2. Theoretical and empirical basis

Russell's circumplex model organises affect around pleasure-displeasure and activation-deactivation dimensions. The four primary labels provide an interpretable representative category in each quadrant. This is an operational simplification rather than a claim that every lyric emotion is identical to one of four points.

The design also has precedent in music-emotion research. Hu et al. (2009) annotated Chinese lyrics using four valence-arousal quadrants. More recently, the TROMPA-MER dataset grouped emotion terms by quadrant: joy-related terms in positive/high arousal, anger-related terms in negative/high arousal, sadness-related terms in negative/low arousal, and peace/tenderness terms in positive/low arousal.

The taxonomy therefore balances three constraints:

1. coverage of qualitatively different affect regions;
2. labels that trained annotators can apply to natural lyric sections;
3. enough observations per class for a small-corpus comparison.

A much finer taxonomy would better represent fear, disgust, nostalgia, hope and mixed affect, but it would increase annotation ambiguity and reduce the number of training examples per class. Those phenomena remain available through flags, rationales and error analysis.

## 3. Scope of the judgement

The annotation target is:

> the single emotion most strongly expressed by the narrative voice in the supplied lyric section.

Annotators judge textual expression, not the listener's induced emotion, the performer's biography, the audio, or the topic alone. The unit is a source-marked structural section because isolated lines lose local context while a complete song can conceal changes between verses and choruses. The section boundary is therefore a principled compromise rather than an arbitrary fixed-length chunk.

The annotation protocol records confidence and non-primary flags. A `mixed` flag marks two or more comparably prominent emotions; it is not a fifth class. `uncertain` marks cases where a reliable primary judgement is not possible. Original independent judgements remain unchanged after adjudication so that disagreement is measurable.

## 4. Boundary decisions

### Calmness is not neutral

`calmness` requires positive or non-negative low-arousal evidence such as acceptance, reassurance, tenderness or serenity. Emotionally empty, purely descriptive or indeterminate lyrics are `uncertain`, not automatically calm.

### Anger does not absorb every negative high-arousal emotion

Fear, anxiety and tension can occupy the same broad quadrant as anger but are not semantically identical. Annotators must not silently relabel clear fear as anger. They should select the best supported primary category only when anger-related expression is dominant; otherwise they should use `uncertain` and explain the competing emotion. The pilot will show whether this boundary is workable.

### Narrative events are not labels

Conflict does not itself imply anger, and death does not itself imply sadness. The expressed stance of the narrative voice determines the label.

### Dominance does not erase mixed affect

A primary label is required for model training, but `mixed`, confidence and rationale preserve information about transitions, irony and competing emotions. Results will be stratified by agreement and ambiguity where sample size permits.

## 5. Risks and pilot decision rules

The main foreseeable risk is class imbalance. Hu et al.'s four-quadrant Chinese lyric study retained only eight positive/low-arousal songs among 500 high-agreement examples. The current zero-shot candidate output is also sadness-heavy, although that output is model-generated and cannot establish the true corpus distribution.

After two independent Cantonese-competent annotators complete the pilot, the taxonomy will be reviewed using:

- class counts and the smallest-class prevalence;
- raw agreement and Cohen's kappa;
- per-class confusion and confidence distributions;
- frequency and causes of `mixed` and `uncertain` flags;
- whether fear/anxiety repeatedly fails to fit the primary labels;
- whether `calmness` is being used as a residual category.

The four-class design is retained only if each label is sufficiently represented and interpretable for meaningful evaluation. Any revision must be made before formal model comparison, documented as a protocol version change, and approved with the supervisor. Labels must not be redefined after inspecting final test performance.

## Key sources

- Russell, J. A. (1980). *A circumplex model of affect*. Journal of Personality and Social Psychology, 39(6), 1161-1178. https://doi.org/10.1037/h0077714
- Hu, Y., Chen, X. and Yang, D. (2009). *Lyric-based song emotion detection with affective lexicon and fuzzy clustering method*. ISMIR.
- Gómez-Cañón, J. S. et al. (2022). *TROMPA-MER: an open dataset for personalized music emotion recognition*. Journal of Intelligent Information Systems. https://doi.org/10.1007/s10844-022-00746-0
