# Cantonese lyrics emotion annotation guide

Version: 0.1 pilot

## Annotation question

Read the supplied lyric section and answer:

> Which single emotion is most strongly expressed by the narrative voice in this lyric section?

Annotate the emotion expressed by the supplied words, not the emotion created by the melody, singer, production, personal familiarity or an imagined complete-song context.

## Primary labels

### Joy

Positive, energetic or celebratory emotion. Typical evidence includes delight, hope, excitement, playful affection, triumph or enthusiastic anticipation.

Do not select Joy solely because the lyric mentions love. Unrequited, lost or painful love may be Sadness or Anger.

### Sadness

Negative, low-energy emotion. Typical evidence includes grief, loneliness, regret, helplessness, loss, disappointment or longing dominated by pain.

Do not select Sadness for reflective or nostalgic lyrics when the dominant tone is accepting and peaceful; those may be Calmness.

### Anger

Negative, high-energy emotion. Typical evidence includes rage, resentment, accusation, hostility, protest, betrayal or an urge to confront.

Do not select Anger merely because the lyric describes conflict. The narrative voice must predominantly express an activated negative response.

### Calmness

Positive or non-negative, low-energy emotion. Typical evidence includes peace, acceptance, reassurance, contentment, tenderness, serenity or gentle reflection.

Calmness is not a miscellaneous neutral class. Emotionally empty, purely descriptive or genuinely indeterminate lyrics should be marked Uncertain.

## Non-primary flags

These flags do not replace the primary label unless the sample is excluded during adjudication.

- `mixed`: two or more primary emotions are comparably prominent.
- `uncertain`: insufficient evidence, unclear text, inaccessible cultural context or annotator confidence below the threshold.
- `non_cantonese`: the lyric is not predominantly Cantonese.
- `insufficient_text`: instrumental, fragment, excessive repetition or too little lyrical content.
- `translation_required`: the annotator cannot reliably interpret important expressions.

## Decision procedure

1. Read the complete supplied section once without assigning a label.
2. Identify the narrative situation and narrative voice.
3. Highlight or record the textual cues supporting each plausible emotion.
4. Decide whether one emotion is dominant across this section.
5. Assign one primary label and confidence from 1 to 5.
6. Add flags and a short rationale.

## Confidence scale

| Score | Meaning |
|---:|---|
| 5 | Unambiguous dominant emotion with repeated textual evidence |
| 4 | Clear dominant emotion with minor competing cues |
| 3 | Defensible label, but meaningful ambiguity exists |
| 2 | Weak judgement; another label may be equally plausible |
| 1 | Cannot label reliably |

Scores 1-2 require review. Score 3 should be included in disagreement analysis. The untouched gold test set should preferentially contain adjudicated examples with adequate confidence while still representing realistic ambiguity.

## Edge cases

- **Narrative events versus expressed emotion:** a death can be described calmly; label the expression, not the event category.
- **Emotional transition:** label the dominant emotion within the supplied section and set `mixed=true`; record the transition in the rationale.
- **Irony or sarcasm:** use the intended emotion when clear and explain the evidence.
- **Repeated phrase:** repetition within the section can strengthen an emotion. Exact repeated sections from the same song have already been collapsed.
- **Multiple speakers:** judge the dominant narrative voice; flag `mixed` if speakers express competing emotions.
- **Code-switching:** retain the sample if it remains predominantly Cantonese and record the language mixture.
- **Romantic theme:** romance is a topic, not an emotion.

## Pilot protocol

- Annotate the 680 independently randomised sections extracted from 105 source songs.
- Each section should be independently labelled by two Cantonese-competent annotators.
- Annotators must not see candidate metadata labels or each other's decisions.
- Calculate raw agreement, Cohen's kappa and the class distribution.
- Review all disagreements without changing the original annotations.
- Revise this guide before formal annotation and record every revision.

## AI use

AI-generated labels, translations and rationales must be stored separately from human annotations. Annotators should not see AI suggestions during independent gold labelling. In the locked project protocol, AI outputs are review candidates only: they do not enter gold labels, formal training labels or performance evaluation.
