# Learning-curve synthetic validation

Date: 28 July 2026

Status: software evidence only, not model-performance evidence

## Validated behaviour

A synthetic seed-999 partition completed:

- four nested subset plans at 25%, 50%, 75% and 100%;
- a collision check for 12 planned jobs (one classical and two Transformer jobs per fraction);
- actual Character-SVM runs at 50%, 75% and 100%;
- a second invocation in which all three completed jobs were `skipped_existing`;
- prediction collection, identity validation, summary generation and PNG rendering.

The executed subsets contained 8, 12 and 16 training songs/artists respectively while keeping the same four validation and four test cases.

## Expected 25% failure

The old 24-row smoke fixture gives the 25% subset only four training songs: one per emotion. Its class-specific character cues occur in only one document, while the locked TF-IDF setting requires `min_df=2`; after document-frequency pruning no terms remain. The runner stopped and wrote the failing job/log rather than changing the hyperparameter.

The 25% job remains present and collision-free in the dry-run plan, but its metric is not invented. This fixture limitation does not prove the real 105-song 25% subset will fail. The real materialised subset must be checked before formal training, and any infeasibility handled under the locked protocol.

All successful synthetic macro-F1 values are deliberately easy fixture behaviour and must not appear in the dissertation results.
