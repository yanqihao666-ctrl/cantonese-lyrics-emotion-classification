# Chapter 3: Methodology and experimental design — superseded planning draft

> **Status notice (15 August 2026):** This file records the original 680-section
> human-annotation plan and is retained only as project-history evidence. That
> plan was not executed and must not be described as the completed method. The
> authoritative account of the implemented 6,000-section silver-labelled study
> is [final_project_methodology.md](final_project_methodology.md). In particular,
> the statements below about two Cantonese annotators and human gold are planned
> procedures, not completed work.

This chapter draft deliberately contains no model-performance claims. Bracketed items must be completed from saved artifacts after human annotation and formal experiments.

## 3.1 Research design

This study adopts a controlled comparative experimental design to investigate emotion classification in Cantonese song lyrics. The independent comparison is model family and textual representation; the primary outcome is macro-averaged F1 on artist-exclusive test cases. The study does not propose a new neural architecture. Its contribution is a reproducible comparison under the linguistic, annotation and sampling constraints of a low-resource setting.

The design addresses four research questions:

1. How do classical machine-learning and Transformer-based models compare on Cantonese lyric emotion classification?
2. How do character-level and word-level representations affect classical-model performance?
3. How does adding the expansion training corpus affect model performance under a fixed-test design?
4. What class-level and label-evidence patterns characterise model errors?

All model families receive identical outer test sections. Model selection and early stopping use validation data drawn only from the corresponding development partition. Test predictions are saved before aggregation, and the same section-level cases are paired in all model comparisons.

## 3.2 Corpus and unit of analysis

The primary source is the Cantopop Corpus, used under CC BY 4.0. After correcting two source metadata errors with retained evidence URLs, the audited local version contains 105 songs by 42 canonical artists, released from 2000 to 2020, with structural Humdrum markers, lyric text and Jyutping. The extraction procedure identifies lyric-bearing verse, pre-chorus, chorus, bridge, coda, strophe and interlude spans. It produced 761 section occurrences; 81 exact within-song repetitions were collapsed, leaving 680 unique modelling and annotation cases. The retained `occurrence_count` records repetition without asking annotators to label identical text repeatedly. The median section contains 47.5 characters and the longest contains 162.

The natural structural section is the unit of analysis. It preserves several connected lines and local narrative context, unlike isolated-line classification, while avoiding the construct assumption that one emotion dominates an entire song. A stable `case_id` identifies each section and `corpus_song_id` identifies its parent song. Section type is retained for audit and qualitative analysis but excluded from predictive features.

The corpus was selected because it provides lawful access, Cantonese-oriented transcription, explicit structure and song-level provenance. Its main weakness is the number of independent songs and artists, not merely the number of rows after segmentation. It is therefore described as a high-provenance low-resource corpus, not as a representative sample of all Cantopop. Artist-exclusive evaluation and parent-song-aware inference prevent the 680 sections from being presented as 680 independent songs.

Automated quality checks found no missing lyric text and no exact duplicate section after extraction. Six English or non-lexical vocalisation sections have no Jyutping transcription because they contain no Chinese lyric tokens; they remain visible for human `non_cantonese` or `insufficient_text` review. At the predeclared cosine threshold of 0.88, 29 near-duplicate pairs were found, all within the same parent song and none across songs. Parent-song/artist grouping therefore contains this leakage risk. Derived corpus statistics may be distributed, but lyric text remains in a local licensed-data directory and is excluded from public outputs unless the licence and dissertation-submission route permit it.

A possible 827-song expansion corpus reported by Lee (2026) was not included because no public download or external-use licence was identified. It will enter the study only if the author provides the data and explicit permitted-use terms. This separates desirable scale from lawful availability.

## 3.3 Emotion taxonomy

The dependent variable is a single discrete label: `joy`, `sadness`, `anger` or `calmness`. These categories occupy positive/high-arousal, negative/low-arousal, negative/high-arousal and positive-or-non-negative/low-arousal regions of Russell's (1980) circumplex respectively. The dimensional framework explains category coverage; the prediction task remains named-emotion classification rather than valence classification.

The four-class design follows four-quadrant precedents in Chinese lyric and music-emotion research (Hu et al., 2009; Gómez-Cañón et al., 2022). It also limits annotation burden and per-class sparsity. It cannot represent every fine-grained emotion. Fear, nostalgia, hope, disgust, irony and mixed affect are therefore retained in annotator flags and rationales rather than silently forced into semantically inappropriate classes.

`calmness` is not a residual neutral class: it requires evidence of peace, acceptance, reassurance, contentment, tenderness or gentle reflection. Conflict alone does not imply `anger`, and a sad event does not itself imply `sadness`; annotators judge the emotion expressed by the lyric's narrative voice. A `mixed` flag records competing emotions, while `uncertain` marks a judgement that cannot be made reliably.

## 3.4 Annotation and gold-label construction

Two Cantonese-competent annotators independently read every section and answer: “Which single emotion is most strongly expressed by the narrative voice in this lyric section?” They judge only the supplied local text rather than melody, production, singer identity, personal familiarity or an imagined complete-song context. Their workbooks are independently randomised and contain neither parent-song/title/artist metadata nor AI candidate labels. Each annotation records a primary label, confidence from 1 to 5, ambiguity flags and a short textual rationale.

Raw agreement and Cohen's kappa will quantify reliability. Per-class confusion, confidence and the frequency of `mixed`, `uncertain`, `translation_required`, `non_cantonese` and `insufficient_text` flags will diagnose failures hidden by one aggregate coefficient. Every disagreement, confidence score of 1–2 and flagged item is reviewed in a separate adjudication stage; score 3 remains visible in ambiguity-stratified analysis. Every queued decision records a final label or documented exclusion, rationale, pseudonymous adjudicator code and date. The frozen gold manifest hashes the licensed source, key, two unchanged workbooks, decision file, modelling output and lyric-free audit.

The taxonomy passes the pilot only if all four classes have enough examples and distinct artist groups to support the predeclared grouped evaluation, and if disagreement does not reveal a systematic category failure. Revisions are documented and supervisor-approved before formal model comparison. Class definitions will not be changed after inspecting final test scores.

Zero-shot and generative outputs are weak candidate labels only. They are stored separately, hidden from annotators and excluded from gold evaluation. Their purpose is to test pipeline behaviour and prioritise difficult cases, not to replace human linguistic judgement.

## 3.5 Preprocessing and representations

The main text input is the original text of one extracted structural section. Metadata such as artist, title, release year, section type and occurrence count is excluded from predictive features to prevent shortcuts. Model outputs retain `case_id`, parent `corpus_song_id` and non-text audit metadata for traceability and error analysis; saved prediction tables do not contain lyric text.

Classical models use three representations:

- character TF–IDF with 2–5-character n-grams;
- Jieba word TF–IDF with 1–2-word n-grams;
- a feature union of character and word TF–IDF.

Character n-grams are the primary classical representation because they avoid assuming that a Standard-Chinese word segmenter provides correct boundaries for written Cantonese. The Jieba representation is retained as an explicit ablation that tests this assumption. Both use document-frequency filtering, sublinear term frequency and a predeclared maximum feature count. No stopword list is used because short function words and Cantonese-specific particles may carry stylistic or emotional information.

Transformer text is tokenised by the exact tokenizer associated with each pinned checkpoint. The new audit covered all 680 sections. Maximum sequence lengths were 131 tokens for XLM-R and 164 for both MacBERT tokenizers; no section exceeded the 512-token limit. Therefore no formal section input is expected to be truncated at the declared limit. The runner still supports deterministic head-tail truncation as a documented safeguard, but truncation is no longer an explanatory variable in the main section-level analysis.

## 3.6 Models

The non-learning majority classifier establishes a lower-bound sanity check. The classical family comprises Multinomial Naive Bayes, class-weighted logistic regression and class-weighted linear support-vector classification. These models provide interpretable and computationally efficient baselines that remain competitive in small text datasets.

The required Transformer comparison contains:

- `FacebookAI/xlm-roberta-base`, representing multilingual transfer;
- `hfl/chinese-macbert-base`, representing transfer from Standard-Chinese-oriented pre-training.

Exact repository revisions are pinned in the experiment configuration. `indiejoseph/bert-base-cantonese` is exploratory rather than a required primary model because its model card provides limited training/evaluation detail and its tokenizer audit found substantially more unknown tokens, especially for capitalised English code-switching. It will not replace either main Transformer in the confirmatory comparison.

Transformer fine-tuning uses an effective batch size of 16 through batch size 4 and four gradient-accumulation steps, a maximum of five epochs, weight decay 0.01, warm-up ratio 0.1 and validation macro-F1 for checkpoint selection. Early stopping patience is two evaluation epochs. Mixed precision is enabled only when CUDA is available. Exact device, package versions, runtime, seed, data-file hash and model revision are saved per run.

## 3.7 Hyperparameter control

The primary comparison uses one fixed, predeclared configuration per declared model/representation rather than an open-ended search. This reduces selection variance on a small validation set and prevents better-funded tuning from being confused with model-family quality. The performance-driven search budget is zero for every candidate configuration: classical regularisation and the Transformer learning rate were locked before human gold labels and formal scores existed. Transformer validation data is used only for early stopping and best-epoch selection.

To compare families without choosing the highest outer-test result, one classical configuration is selected separately inside each outer partition using validation macro-F1. An exact validation tie is resolved by ascending model key. Only that configuration's held-out test predictions enter the composite `classical::validation_selected`; the source configuration and every candidate score remain in an audit table. This estimates the declared selection procedure rather than retroactively naming one globally best classical model. For RQ2, Linear SVM is held fixed and character, word and combined representations are compared directly. The exact settings and fitted configurations are recorded in the hyperparameter protocol.

No parameter may be selected from outer-test macro-F1. If a small sensitivity analysis is run, it will use the same candidate count for comparable models within a family, retain the fixed result as primary and be reported as exploratory. Any deviation caused by GPU memory or convergence will be logged before viewing aggregate test results.

## 3.8 Shared artist-exclusive evaluation

A random section split could place sections from the same song, or different songs by the same artist, in training and test data. The model could then exploit repeated motifs, vocabulary, narrative persona or writing style. The formal evaluation therefore groups by artist; because every source song has one artist identity, this also keeps all sections of a song in the same train, validation or test role.

Three deterministic split seeds (13, 42 and 97) are each used to create five outer `StratifiedGroupKFold` partitions. For each outer fold, test artists are fixed first. A validation fold is then selected only from the remaining development artists by minimising size and class-proportion error among candidates that contain every label. Train, validation and test roles are mutually exclusive by artist. The manifest generator refuses to continue if any class has fewer than five distinct artist groups or if any role lacks a class.

This produces 15 shared partitions. Each section appears once in the outer test role per five-fold repeat and therefore three times across repeats. Sections from one parent song always travel together. These repeated predictions and co-song sections are not independent observations. The evaluation consequently reports section-level metrics and partition-level dispersion while using the parent song as the cluster for resampling.

## 3.9 Metrics and statistical analysis

Macro-F1 is the primary metric because it gives equal importance to all four classes and is less dominated by a frequent class than accuracy. Secondary metrics are weighted-F1, accuracy and per-class precision, recall and F1. Confusion matrices use the fixed order joy, sadness, anger and calmness.

For each model, mean and standard deviation are reported across the 15 predeclared partitions. A song-cluster bootstrap with 2,000 resamples produces a 95% interval for pooled macro-F1 while keeping all repeated predictions for a sampled song together. Pairwise model differences use a paired permutation test with 5,000 iterations: all predictions belonging to a song are swapped between the two models as one cluster. Holm's method controls family-wise error separately across the three primary family comparisons and the three fixed-Linear-SVM representation comparisons. Other comparisons are descriptive or labelled exploratory.

The resampling interval and permutation test answer different questions. The interval describes score uncertainty under clustered resampling; the paired test assesses whether the observed model difference is unusually large under exchangeability. Statistical non-significance will not be interpreted as proof of equivalence, particularly with 105 songs.

## 3.10 Learning curves, efficiency and error analysis

Learning curves target 25%, 50%, 75% and 100% of the training rows within all five seed-42 outer folds while sampling only whole artist groups. Subsets are nested and class-complete; validation and test `case_id` values remain fixed. The compared models are Character TF-IDF + Linear SVM, XLM-R and MacBERT. Holding the classical configuration fixed avoids confounding data size with configuration selection. The curve reports achieved section, source-song and artist ranges, every fold point and an across-fold mean. It is descriptive rather than a new significance-test family. An infeasible fraction is reported or revised with supervisor agreement before comparable test scores are viewed; locked TF-IDF thresholds are not relaxed post hoc.

Efficiency reporting includes fit/fine-tuning wall-clock time, prediction time, device and, where reliably measurable, peak GPU memory. Runtime is descriptive because the two families use different hardware paths; it is not treated as a hardware-independent property.

Qualitative analysis uses saved paired predictions and a predeclared codebook:

- metaphor or indirect expression;
- mixed emotion or narrative transition;
- code-switching;
- colloquial Cantonese versus standard written Chinese;
- negation or contrast;
- repetition;
- insufficient local section context;
- low human agreement or confidence.

Cases will be selected by transparent strata: shared errors, classical-only successes, Transformer-only successes and disagreements between Transformer checkpoints. Cantonese interpretation will be checked by a competent speaker rather than inferred solely by the researcher or an AI translation.

## 3.11 Reproducibility and implementation validation

The implementation is modular rather than notebook-dependent. Import, corpus audit, annotation preparation, agreement, split creation, classical modelling, Transformer modelling, validation-only classical selection, prediction collection, statistical analysis and table generation are separate command-line modules. CSV/JSON artifacts form explicit interfaces between stages.

At the pre-result stage, 81 automated tests cover structural-section extraction, schema invariants, CSV/XLSX annotation loading, agreement and adjudication rules, hash-backed gold freezing, duplicate and parent-song leakage, artist-exclusive splitting, nested and fraction-addressed learning curves, experiment-matrix identity and stale-output refusal, validation-only model selection, metric calculation, scoped multiplicity families, tokenizer auditing, head-tail truncation, prediction uniqueness, song-clustered resampling, Holm correction, artifact-verified table generation, qualitative review queues, GPU validation and evaluation-figure creation. Both required Transformers also completed full-length mixed-precision forward/backward checks at batch 4 x 512 tokens. Synthetic fixtures validated the 10-configuration classical matrix, resumable learning-curve jobs, reporting pipeline and gold freeze. These are implementation checks, not performance evidence. Real-corpus audits complement synthetic tests. Formal runs will record the Git commit identifier and preserve their exact inputs and console logs.

## 3.12 Legal, ethical and validity considerations

The project minimises redistribution of copyrighted or licensed lyric text and records the licence/provenance of each source. Annotators should receive an information sheet and consent procedure appropriate to the University's ethics route; demographic data will not be collected unless necessary. Annotator competence and workload must be reported without exposing identities.

Construct validity is threatened by reducing complex affect to four labels and by assigning one dominant category to a section that may itself contain a transition. Source structural boundaries may not always coincide with emotional boundaries. Internal validity is threatened by label noise, artist or parent-song leakage, duplicate versions, parameter selection and fine-tuning instability. External validity is limited by 680 sections nested within 105 curated songs, 42 canonical artists and the 2000-2020 period. Conclusion validity is limited by class imbalance, co-song dependence, correlated repeated predictions and the smaller effective number of song clusters. The annotation protocol, grouped repeated evaluation, saved paired predictions and parent-song-clustered uncertainty analysis mitigate but do not eliminate these threats.
