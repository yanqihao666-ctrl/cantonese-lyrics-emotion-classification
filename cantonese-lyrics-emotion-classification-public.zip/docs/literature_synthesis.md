# Chapter 2: Background and related work — working draft

## 2.1 Lyric emotion classification is annotation-sensitive

Lyric emotion research has used small corpora and several incompatible targets. Strapparava et al. (2012) released 100 popular songs with line-level emotion annotation and demonstrated that lyric and music representations can support emotion classification. Edmonds and Sedoc (2021) later studied multi-emotion classification from the reader's perspective, including song-level re-annotation, and found that small in-domain lyric datasets could be marginally more effective than transferring BERT models trained on larger social-media or dialogue emotion datasets.

Bostan and Klinger (2018) show more generally that emotion corpora differ in taxonomy, domain and annotation format, and that pooling every available corpus is not automatically beneficial. GoEmotions (Demszky et al., 2020) demonstrates how much richer emotion language can be than a four-class scheme, while also illustrating the annotation cost and ambiguity created by fine-grained multi-label targets. Leonardelli et al. (2021), in another subjective classification domain, show that low agreement can represent genuine ambiguity rather than careless annotation.

Song and Beck (2023) make the temporal limitation of a whole-song label explicit: their state-space formulation models changing emotion intensity through lyric sentences rather than assuming that affect is constant. Their task and supervision are not directly comparable with the present four-class task, but the work shows what is lost when one dominant label compresses a narrative trajectory.

These studies support three design decisions. First, the annotation question must state whose emotion is being judged and at what unit. This project asks for the dominant emotion expressed by the narrative voice in one natural structural section. Second, transfer from a non-lyric emotion dataset cannot be assumed to solve the lyric task because narrative structure, repetition, metaphor and emotional transitions differ from short social-media text. Third, disputed cases should be retained and analysed with confidence and `mixed` flags instead of silently filtering every difficult section. The chosen unit is a compromise: it preserves more local context than a line while exposing within-song changes concealed by a single song label. Source-defined boundaries may still fail to coincide with emotional boundaries, so this remains a construct-validity limitation.

Russell's (1980) circumplex model provides a theoretical organisation for the four primary labels. Joy, anger, sadness and calmness act as discrete representatives of positive/high-arousal, negative/high-arousal, negative/low-arousal and positive-or-non-negative/low-arousal regions respectively. This does not convert the task into valence prediction: the model still predicts named emotion categories, while the dimensional account makes their coverage and boundaries explicit. The taxonomy is provisional until a two-annotator pilot tests class representation, agreement and recurring out-of-taxonomy cases.

Sources:

- https://aclanthology.org/L12-1425/
- https://aclanthology.org/2021.wassa-1.24/
- https://aclanthology.org/C18-1179/
- https://aclanthology.org/2020.acl-main.372/
- https://aclanthology.org/2021.emnlp-main.822/
- https://aclanthology.org/2023.tacl-1.10/
- https://doi.org/10.1037/h0077714

## 2.2 Low-resource comparisons require strong simple baselines

Early Chinese lyric studies provide direct precedent for strong non-neural baselines. Xia et al. (2008) compared a sentiment-specific vector representation and ordinary vector-space features with SVM, while Hu et al. (2009) used an affective lexicon and fuzzy clustering on a four-quadrant Chinese lyric corpus. The latter retained 500 of 981 collected songs only when at least six of seven judges agreed, but its positive-low-arousal class contained only eight songs. These studies demonstrate both the relevance of Chinese lyric-specific representation and the risk that agreement filtering and natural emotion distribution create severe class imbalance.

Malheiro et al. (2018) provide stronger feature-level evidence from English lyrics: their experiments compared bag-of-words with stylistic, structural and semantic features under four-quadrant and dimensional targets. The reported gains show that repetition and lyric structure can add information beyond ordinary lexical counts, but many of their lexicons and linguistic resources are English-specific. Reimplementing them directly in Cantonese would therefore conflate model family with uneven feature-resource quality. This project instead keeps the confirmatory classical comparison language-agnostic and treats repetition and related structure as error-analysis phenomena.

Barnes (2023) systematically compared rule-based, dictionary-based, few-shot, prompting and cross-lingual methods in low-resource sentiment and emotion settings. Simple approaches sometimes matched or exceeded few-shot and prompting methods, especially for emotion classification. This evidence makes majority, TF-IDF, logistic-regression and linear-SVM baselines scientifically necessary rather than merely historical.

Agrawal et al. (2021) report an XLNet-based lyric-emotion approach across existing datasets. It supplies direct precedent for Transformer lyric modelling, but its dataset-dependent targets and splits do not isolate a model-family effect under shared cases. Its result motivates a Transformer comparator; it does not establish that a Transformer should outperform TF-IDF on 105 Cantonese songs.

For Cantonese lyrics, character n-grams are especially defensible because they avoid assuming that a Standard-Chinese segmenter gives linguistically correct Cantonese word boundaries. Word-level Jieba features remain useful as an explicit contrast, not as an unquestioned default.

Source:

- https://aclanthology.org/2023.wassa-1.26/
- https://aclanthology.org/P08-2034/
- https://archives.ismir.net/ismir2009/paper/000041.pdf
- https://doi.org/10.1109/TAFFC.2016.2598569
- https://doi.org/10.1007/978-3-030-72240-1_12

## 2.3 Multilingual transfer is promising but domain and variety matter

BERT established the general pretrain-and-fine-tune approach (Devlin et al., 2019). XLM-R extended it using large-scale multilingual pretraining (Conneau et al., 2020), while XLM-EMO later demonstrated competitive zero-shot emotion prediction across multilingual social-media datasets (Bianchi et al., 2022). MacBERT provides a strong Chinese-oriented comparator through corrective pretraining (Cui et al., 2020).

Lamprinidis et al. (2021) found that typological similarity and diversity of source languages affect cross-lingual emotion transfer. However, none of these results establishes that a multilingual or Standard-Chinese model will represent written Cantonese lyrics well. Cantonese lyrics may mix standard written Chinese, colloquial Cantonese characters, English code-switching and culturally specific figurative language. The primary comparison between XLM-R and MacBERT is therefore a transfer study rather than a foregone Transformer victory. The Cantonese continued-pretraining checkpoint remains exploratory: the project's tokenizer audit found that it handles capitalised English code-switching less completely than the two required baselines, and its model documentation is weaker.

Sources:

- https://aclanthology.org/N19-1423/
- https://aclanthology.org/2020.acl-main.747/
- https://aclanthology.org/2020.findings-emnlp.58/
- https://aclanthology.org/2022.wassa-1.18/
- https://aclanthology.org/2021.wassa-1.7/

## 2.4 Cantonese emotion NLP remains under-resourced

Lee (2019) presented an early Cantonese text-emotion system that transferred Mandarin emotion resources through Cantonese-Mandarin lexical mappings and added English-Mandarin mappings for code-switching. The work provides a direct precedent for Cantonese emotion detection, but its social-media domain, small evaluation set and pre-Transformer method leave lyric classification unresolved.

Xiang et al. (2024) describe modern Cantonese NLP as constrained by limited data diversity and by colloquialism and multilinguality. Their review supports the low-resource motivation and the inclusion of language-aware error analysis, but it does not justify claiming that no Cantonese lyric-emotion dataset exists anywhere. The defensible claim is narrower: the documented search did not identify an accessible, section-level, emotion-labelled Cantonese benchmark meeting this project's requirements.

Zhang et al. (2024) demonstrate a human-LLM workflow for constructing a Cantonese emotion lexicon from multilingual resources and colloquial sources. This is relevant evidence that AI can assist resource development, but it is a preprint about lexicon construction rather than independent song-level classification. It therefore supports transparent weak-label assistance, not the substitution of model outputs for the project's human gold standard.

Sources:

- https://cdn.aaai.org/ocs/18309/18309-78928-1-PB.pdf
- https://aclanthology.org/2024.sighan-1.8/
- https://arxiv.org/abs/2410.11526

## 2.5 Dataset scale cannot replace provenance and label validity

The CC BY 4.0 Cantopop Corpus documented by Lee (2023) supplies 105 song-level lyric and Jyutping transcriptions with stable provenance, but no emotion labels. MIR-MLPop supplies 30 Cantonese lyric-alignment records (Wang et al., 2024) but is also unlabelled for emotion. ToneCraft (Cheng et al., 2025) releases hundreds of thousands of short Cantonese lyric-generation instruction examples, demonstrating that large lyric-derived resources can be assembled. Its current repository, however, lacks stable song-level identity, emotion labels and an explicit data licence, so it cannot support the main artist-exclusive evaluation.

Lee (2026) reports a separate 827-song teaching corpus covering 1971-2022 and selected from three Hong Kong annual-award inventories. It is a strong potential expansion source, but the paper does not provide a public corpus link or an external-use licence. Scale therefore cannot be treated as availability: access and permitted-use terms must be obtained from the author before the data enter this study.

The WASABI enrichment work illustrates the opposite scale-quality trade-off: Fell et al. (2020) automatically derived annotations over a very large lyric collection, but weak automatic labels are not interchangeable with task-specific human judgements. The resulting strategy is to preserve the 105-song corpus as a high-provenance source, derive 680 traceable structural sections, validate human gold labels, and expand only through sources with documented lawful access and song-level identity. AI or zero-shot outputs may form a candidate layer, but final evaluation must remain on independently validated gold labels.

Sources:

- https://cantopop.humdrum.org/
- https://github.com/york135/MIRMLPop
- https://aclanthology.org/2025.emnlp-main.18/
- https://doi.org/10.56040/slle2314
- https://aclanthology.org/2020.lrec-1.262/

## 2.6 Small-corpus model rankings require uncertainty analysis

Transformer fine-tuning can be unstable across random seeds, especially on small datasets. Du and Nguyen (2023) further show that standard deviation alone provides only a narrow view of instability. Berg-Kirkpatrick et al. (2012) demonstrate that sample size and test choice affect the reliability of statistical conclusions in NLP and motivate paired resampling for metrics such as F1.

This evidence rules out reporting a single train/test split and a single seed as a reliable model ranking. The project therefore predeclares repeated artist-grouped evaluation, identical test cases for all models, saved paired predictions, song-cluster bootstrap intervals and paired randomisation tests. Because the same song is predicted in multiple repeats, the song - not the prediction row - is the resampling unit.

Sources:

- https://aclanthology.org/2023.acl-long.342/
- https://aclanthology.org/D12-1091/

## 2.7 Evidence-to-gap map

| Evidence strand | What the literature establishes | What remains unresolved | Consequence for this study |
|---|---|---|---|
| Lyric emotion | Lyrics can support emotion prediction, but studies use incompatible units, taxonomies and label perspectives | Whether one dominant Cantonese section-level label can be annotated reliably | Blind dual annotation, adjudication and ambiguity-stratified analysis |
| Classical lyric models | Lexical, structural and semantic features can be competitive | Whether language-independent character or Standard-Chinese word features work better for Cantonese | Fixed-model character/word/combined TF-IDF comparison |
| Transformer lyric models | Contextual encoders can perform well on existing lyric datasets | Whether gains survive a shared low-resource, artist-exclusive comparison | Identical cases and validation-only selection across families |
| Multilingual transfer | Cross-lingual emotion transfer is possible but depends on source language and domain | Whether multilingual or Standard-Chinese pretraining transfers better to written Cantonese lyrics | Pinned XLM-R and MacBERT primary comparison |
| Cantonese resources | Cantonese NLP is under-resourced and mixes written varieties; larger lyric resources exist | No verified accessible section-level emotion benchmark with the required provenance and labels was found | High-provenance 680-section dataset nested within 105 songs, lawful expansion only, narrow novelty claim |
| Evaluation | Small-data fine-tuning and significance conclusions are unstable | How much an apparent ranking depends on artists, seeds and repeated songs | Shared grouped folds, clustered resampling and learning curves |

## 2.8 Research gap and contribution

The reviewed literature supports lyric emotion classification, multilingual transfer and Cantonese emotion processing separately, but does not provide a reproducible benchmark comparing classical and Transformer models on section-level Cantonese lyric emotion classification. This project addresses that intersection through:

1. a provenance-aware Cantonese lyric dataset workflow;
2. an operational four-class annotation protocol with independent agreement measurement;
3. a controlled comparison of character/word classical baselines with required multilingual and Chinese-oriented Transformers, plus a clearly separated exploratory Cantonese checkpoint audit;
4. artist-exclusive and duplicate-aware evaluation;
5. learning-curve, computational-cost and qualitative linguistic error analysis.

The contribution is not a novel neural architecture. It is an evidence-based account of when model complexity helps in a low-resource Cantonese lyric setting and how conclusions change with label quality and training-data size.
