# Project management and decision log

This log records substantive decisions and deviations. Git commits and saved artifacts provide the underlying evidence.

| Date | Milestone or decision | Evidence | Consequence |
|---|---|---|---|
| 21 July 2026 | Fixed the research aim as a comparison of Transformer and classical ML models for four-class Cantonese lyric emotion classification | `research_plan.md`; `dissertation_outline.md` | Valence/arousal remains a rationale for category coverage, not a replacement prediction task |
| 21–23 July 2026 | Audited candidate sources and selected the CC BY 4.0 Cantopop Corpus as the lawful pilot | `data_feasibility_report.md`; corpus audit artifacts | Main pilot contains 105 songs; lyric text stays outside Git |
| 23 July 2026 | Implemented import, validation, duplicate audit, blinded annotation and agreement pipeline | Git commit `1e5d0fd` | Human labels can be collected without exposing candidate labels or artist/title metadata |
| 23 July 2026 | Implemented grouped splits and initial classical/Transformer runners | Git commit `6611199` | Artist leakage becomes a testable invariant rather than a manual assumption |
| 26–27 July 2026 | Investigated larger corpora, including ToneCraft and Lee's reported 827-song corpus | `data_feasibility_report.md`; `corpus_access_request_draft.md` | Neither enters the study without song identity, access and permitted-use terms |
| 27 July 2026 | Implemented a shared three-seed, five-fold artist-exclusive manifest and independent validation split | Git commit `c37e057` | All model families can receive identical evaluation cases |
| 27 July 2026 | Completed model-card, revision and tokenizer audits | `transformer_model_audit.md`; `results/tokenizer_audit` | XLM-R and MacBERT are required; Cantonese BERT is exploratory |
| 27 July 2026 | Predeclared cluster-aware statistical analysis and fixed hyperparameters | `statistical_analysis_plan.md`; `hyperparameter_protocol.md` | Prevents test-driven tuning and treating repeated song predictions as independent |
| 27–28 July 2026 | Added prediction identity/collection, learning-curve and qualitative-error controls | `software_architecture_and_validation.md`; then-46-test suite | Outer folds cannot silently overwrite each other; duplicate prediction cases are rejected |
| 28 July 2026 | Completed the pinned three-template zero-shot candidate audit | `candidate_label_findings.md`; `results/candidate_label_audit` | Strong sadness concentration triggered class-collapse warning; candidates remain hidden from annotators and excluded from gold evaluation |
| 28 July 2026 | Installed and validated CUDA PyTorch, then completed a pinned XLM-R synthetic smoke run | `gpu_setup_and_validation.md`; `transformer_smoke_validation.md` | Confirmed the real GPU path and corrected early-stopping metric-prefix and warm-up compatibility before formal experiments |
| 28 July 2026 | Implemented and validated the resumable 45-job formal experiment matrix | `experiment_matrix_orchestration.md`; 49-test suite | Every formal input is hashed, every job has a collision-free output/log path, and interrupted runs refuse stale evidence rather than overwriting or silently skipping it |
| 28 July 2026 | Replaced Logistic Regression's incompatible `liblinear` solver with multinomial-capable L-BFGS | synthetic four-class matrix execution; regression test | Corrected a scikit-learn 1.9 compatibility failure before any human gold-label score existed |
| 28 July 2026 | Implemented validation-only classical selection and hash-verified results tables | `formal_reporting_pipeline.md`; 55-test suite | Prevents naming a test-selected classical winner, separates primary/RQ2 Holm families and removes manual table transcription |
| 28 July 2026 | Implemented direct XLSX agreement, mandatory adjudication and hash-backed gold freezing | `gold_label_freeze_protocol.md`; 61-test suite | Preserves original judgements, routes low confidence/flags to review and makes every final label or exclusion auditable before modelling |
| 28 July 2026 | Locked and implemented the 60-job RQ3 learning-curve workflow | `learning_curve_protocol.md`; `learning_curve_smoke_validation.md`; 66-test suite | Fractions cannot overwrite one another, achieved group sizes are reported and changed evaluation cases are rejected |
| 28 July 2026 | Completed the dissertation source and citation audit | `literature_matrix.csv`; `literature_search_log.csv`; `references.bib`; `citation_and_source_audit.md`; 69-test suite | All 28 retained sources are logged, key-matched and cited; only one is a clearly marked preprint, and unmatched author-year citations now fail automatically |
| 28 July 2026 | Integrated the six-chapter dissertation plan and evidence register | `dissertation_master_plan.md`; `implementation_chapter_draft.md`; `dissertation_evidence_register.csv`; 72-test suite | Word allocation remains proportional until the Minerva limit is confirmed; verified claims and blocked formal outputs cannot be silently conflated |
| 29 July 2026 | Generated and fully rendered an 11-page bilingual annotator pack | `deliverables/Annotator_Pack_DRAFT.docx`; `annotator_pack_validation.md`; `scripts/build_annotator_pack.py` | Recruitment material is review-ready but explicitly blocked from distribution until ethics, supervisor and Cantonese-language checks are complete |
| 29 July 2026 | Locked dissertation terminology and added automated drift detection | `configs/dissertation_contract.yaml`; `dissertation_consistency_contract.md`; `results/dissertation_consistency_audit.json`; 76-test suite | README and Chapters 1–5 now share exact RQs, chapter numbering, model identities, evaluation constants and controlled placeholder scope |
| 30 July 2026 | Replaced whole-song cases with natural structural lyric sections after reviewing annotation burden and construct validity | `cantopop_corpus_sections.csv`; regenerated annotation workbooks; section-level code/tests | 761 occurrences became 680 unique cases after 81 within-song exact repetitions were collapsed; `case_id` is the modelling key and `corpus_song_id` remains the dependence cluster |
| 27 July 2026 | Drafted the methods chapter before formal results | `methodology_draft.md` | The eventual dissertation can distinguish planned methods from post-result interpretation |

## Deviations from the initial plan

### Corpus size

The preferred plan was to obtain at least 250–500 licensed songs. The strongest accessible high-provenance source currently contains 105. Natural structural parsing increases the number of annotation/model cases to 680 without pretending that they are independent songs. Repeated artist-exclusive evaluation and parent-song-clustered inference preserve the effective sampling limitation. Lawful expansion remains preferable if access is granted.

### Gold labels

No suitable public Cantonese lyric-emotion labels were found. Dataset construction and inter-annotator reliability therefore became a central method component. Formal model results are blocked until independent human annotation and adjudication are complete. AI candidate labels do not remove this dependency.

### Cantonese-specific Transformer

A Cantonese continued-pretraining model was initially considered a potential primary comparator. Its documentation is incomplete and its tokenizer produced substantially more unknown tokens than XLM-R and MacBERT on code-switched lyrics. It was moved to exploratory status before gold model scores existed.

### Sequence handling

The initial Transformer plan used ordinary truncation. The full-song tokenizer audit found four MacBERT/Cantonese-BERT songs longer than 512 tokens, so the implementation added deterministic head-tail truncation. After the unit changed to structural sections, that result became design history; a new section-level tokenizer audit is required before formal training.

## Current gate and next milestone

The implementation, annotation package, direct Excel agreement reader, gold-freeze pipeline, GPU environment, Transformer smoke validation, formal experiment orchestrator and reporting controls are ready. The next scientific gate is the return of two independently completed Cantonese annotation sheets. The formal execution checklist defines the required adjudication, freeze and audit sequence. No candidate or synthetic result may be reported as the dissertation's model performance.
