# Zero-shot candidate-label audit

Status: legacy whole-song weak-label diagnostic, not transferable to the section-level dataset, not human annotation and not model-performance evaluation

## Reproducible setup

- Model: `MoritzLaurer/mDeBERTa-v3-base-mnli-xnli`
- Pinned revision: `8adb042d524ecd5c26d3e3ba0e3fbcf7e2d0864c`
- Input: 105 complete lyrics from the audited Cantopop Corpus
- Method: zero-shot NLI with three independently worded Chinese hypothesis templates
- Consensus: majority top-ranked label across the three templates

The modelling unit subsequently changed to 680 structural lyric sections. These 105 whole-song candidates are retained only to document the earlier pipeline and bias check; they must not be joined to, sampled as, or reported as candidate labels for the section cases.

The raw candidate file remains in ignored local interim data. The tracked audit outputs contain identifiers, metadata and derived scores, but no lyric text.

## Observed candidate distribution

| Candidate label | Songs | Share |
|---|---:|---:|
| Joy | 13 | 12.4% |
| Sadness | 70 | 66.7% |
| Anger | 2 | 1.9% |
| Calmness | 20 | 19.0% |
| Total | 105 | 100.0% |

The largest class exceeds the predeclared 60% class-collapse warning threshold. This is evidence of a strongly sadness-dominant candidate process, not evidence that two-thirds of the corpus is truly sad.

## Prompt sensitivity and confidence

- 86/105 items received the same top label from all three templates.
- 19/105 received a two-of-three majority.
- No item had a three-way tie or missing consensus.
- Mean top-two probability margin: 0.320.
- Median top-two probability margin: 0.281.
- 66 items met the mechanical high-confidence-candidate rule of unanimous prompts and mean margin at least 0.15.

Prompt agreement is internal model consistency, not validity against human judgement. A unanimous biased system may still be wrong.

## Research decision

These outputs will:

- verify the weak-label pipeline;
- prioritise low-agreement/low-margin cases for later review;
- support a candidate-versus-gold bias analysis after human labels exist.

They will not:

- be shown to independent annotators;
- be used as the gold test target;
- be reported as formal accuracy, F1 or annotation prevalence;
- be used to rebalance the gold corpus without checking the human class distribution.

The sadness concentration and near-absence of anger strengthen the case for independent Cantonese annotation and per-class evaluation.
