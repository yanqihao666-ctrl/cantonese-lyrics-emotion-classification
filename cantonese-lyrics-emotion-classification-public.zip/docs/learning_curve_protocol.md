# RQ3 learning-curve protocol

Status: locked before human gold model scores

## Question and scope

RQ3 asks how labelled training-data size affects the two model families. The analysis is descriptive and uses:

- partition seed 42;
- all five artist-exclusive outer folds for that seed;
- 25%, 50%, 75% and 100% nominal section-row fractions of each training role, sampled in whole artist groups;
- Character TF-IDF + Linear SVM;
- XLM-RoBERTa-base;
- Chinese MacBERT-base.

This creates 20 nested data subsets and 60 model jobs. Using five folds limits GPU cost while exposing partition variability. Seed 42 was fixed before gold scores. The classical model is fixed rather than validation-selected so that changing training size is not confounded with changing estimator/representation.

## Subset construction

Only training artists are reduced. Validation and outer-test section IDs remain identical across all four fractions and all three models for a fold; parent songs therefore remain intact. The optimiser searches deterministic artist orderings for nested, class-complete prefixes close to the requested row count and full-training class proportions.

Nominal percentages are not treated as achieved sample sizes. Results report mean/minimum/maximum training sections, source songs and artists at each fraction because grouped sampling cannot usually hit the percentage exactly.

## Identity and execution

Every subset contains one `learning_curve_fraction`. The fraction propagates into:

- the materialised CSV;
- its SHA-256 and matrix manifest entry;
- the job ID and output directory;
- run metadata;
- every test prediction.

The Transformer directory ends in `fraction_025`, `fraction_050`, `fraction_075` or `fraction_100`; folds and fractions therefore cannot overwrite one another. Resume validates input hash, seed, fold and fraction before skipping an existing job.

The classical learning curve runs only character TF-IDF + Linear SVM. The main formal matrix still evaluates all 10 classical configurations.

## Analysis

The collector requires one prediction per model, fraction, section, seed and fold. It rejects:

- changed validation/test coverage across fractions;
- disagreement about true labels;
- duplicate predictions;
- different achieved training sizes across models;
- non-monotonic training-section or artist counts.

The main figure shows test macro-F1 against nominal training-section fraction, with every fold as a semi-transparent point and the across-fold mean as a line. The summary also reports weighted-F1, accuracy and achieved section/source-song/artist counts. With only five folds, the curve is descriptive: it is not used for a new family of significance tests or precise extrapolation to a larger corpus.

## Infeasible fractions

A fraction may be infeasible if it cannot retain all four classes or if the locked feature/model pipeline cannot fit the resulting sample. The program must stop and preserve the failure. The researcher may:

1. report that point as infeasible; or
2. agree a revised curve design with the supervisor before viewing comparable test results.

It is not permitted to lower `min_df`, change labels, duplicate songs or move evaluation artists solely to make a point run. Any revised fraction set is a documented protocol deviation.
