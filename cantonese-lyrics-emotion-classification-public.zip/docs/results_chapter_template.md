# Chapter 5: Results, evaluation and discussion — artifact-driven template

Do not replace placeholders with expected or AI-invented values. Every number must be copied or programmatically generated from the named artifact.

## 5.1 Dataset and annotation outcomes

Report:

- final included/excluded section counts and reasons, plus distinct source-song counts;
- class and artist distributions;
- raw agreement and Cohen's kappa with an uncertainty interval if computed;
- per-class annotator confusion;
- confidence distribution and counts of each ambiguity flag;
- number and rule of adjudicated cases.

Primary artifacts:

- `results/section_data_audit/summary.json`;
- `results/annotation_agreement/agreement_summary.json`;
- `results/annotation_agreement/label_confusion.csv`;
- `results/annotation_agreement/adjudication_required.csv`;
- `data/processed/gold_decision_audit.csv`;
- `data/processed/gold_freeze_metadata.json`.

Required interpretation:

> Agreement of [value] indicates [careful interpretation], but the lower agreement for [class/boundary] shows that [construct limitation]. [Count] sections were flagged as mixed/uncertain, so the gold labels should be understood as adjudicated dominant-emotion judgements rather than objective properties.

Do not describe kappa as “accuracy”. Explain prevalence effects and inspect the confusion matrix.

## 5.2 Shared evaluation partitions

Table:

| Statistic | Mean | Minimum | Maximum |
|---|---:|---:|---:|
| Training sections | [artifact] | [artifact] | [artifact] |
| Validation sections | [artifact] | [artifact] | [artifact] |
| Test sections | [artifact] | [artifact] | [artifact] |
| Training source songs | [artifact] | [artifact] | [artifact] |
| Validation source songs | [artifact] | [artifact] | [artifact] |
| Test source songs | [artifact] | [artifact] | [artifact] |
| Training artists | [artifact] | [artifact] | [artifact] |
| Validation artists | [artifact] | [artifact] | [artifact] |
| Test artists | [artifact] | [artifact] | [artifact] |

Source: `data/processed/cv_manifest.diagnostics.json`.

State that all 15 partitions contain every class and have no artist overlap only if the diagnostics confirm both conditions.

## 5.3 Primary model comparison (RQ1)

Main table:

| Model | Macro-F1 mean | SD across partitions | Cluster-bootstrap 95% CI | Weighted-F1 | Accuracy | Mean fit time |
|---|---:|---:|---:|---:|---:|---:|
| Validation-selected classical procedure | [artifact] | [artifact] | [artifact] | [artifact] | [artifact] | [artifact] |
| XLM-RoBERTa-base | [artifact] | [artifact] | [artifact] | [artifact] | [artifact] | [artifact] |
| Chinese MacBERT-base | [artifact] | [artifact] | [artifact] | [artifact] | [artifact] | [artifact] |

Sources:

- `results/formal/primary_statistical_analysis/model_summary.csv`;
- `results/formal/primary_statistical_analysis/bootstrap_intervals.csv`;
- `results/formal/classical_validation_selection/selection_audit.csv`;
- `results/formal/report_tables/overall_model_table.csv`;
- per-run metadata/metrics files.

Report which classical source configuration was selected in each partition and the selection frequencies. Do not rename the fixed configuration with the highest outer-test score as the best classical model.
Report the majority baseline separately as a descriptive sanity check; it is not part of the three-model primary permutation family.

The narrative should lead with the size and uncertainty of differences, not merely rank models. For example:

> [Model A] had a mean macro-F1 [difference] higher than [Model B]. The clustered interval was [interval], and the Holm-adjusted paired permutation result was [value]. This provides [strong/limited/no] evidence of a difference on this corpus; it does not establish superiority for Cantonese lyrics generally.

## 5.4 Character and word representation (RQ2)

Compare the same classifier across:

- character TF-IDF;
- Jieba word TF-IDF;
- combined features.

Avoid comparing character-SVM to word-logistic-regression and attributing the entire difference to representation. Include paired differences and per-class changes. Relate any advantage to written Cantonese boundary assumptions; do not claim the model has learned Cantonese linguistics without supporting analysis.

## 5.5 Learning curves (RQ3)

Figure: macro-F1 against nominal 25%, 50%, 75% and 100% training fractions sampled by whole artist groups, with visible partition points.

Sources:

- `results/formal/learning_curve_analysis/learning_curve_summary.csv`;
- `results/formal/learning_curve_analysis/learning_curve_partition_metrics.csv`;
- `results/formal/learning_curve_analysis/learning_curve_analysis_metadata.json`;
- `results/formal/learning_curves/learning_curve_matrix.json`.

Required discussion:

- whether the curves have plateaued;
- whether rankings change with data scale;
- whether a Transformer is more data-hungry;
- achieved section/source-song/artist counts, not nominal percentages alone;
- whether class coverage made any subset infeasible.
- whether any locked feature pipeline was infeasible at a small fraction and how this was handled without post-test tuning.

Do not extrapolate a precise performance level at 500 or 800 songs from four small points.

## 5.6 Per-class behaviour

For each required model, show row-normalised confusion matrices and a compact per-class table. Discuss whether errors follow expected quadrant boundaries, such as sadness–calmness or sadness–anger, and connect those patterns to human disagreement.

If a class has very few examples, state its test count beside its F1. A zero or highly variable class F1 may be a sampling limitation rather than definitive evidence that every model cannot recognise that emotion.

## 5.7 Statistical comparisons

Sources: `results/formal/primary_statistical_analysis/paired_permutation_tests.csv` and the separately scoped RQ2 representation analysis.

Report:

- exact declared comparisons;
- unadjusted and Holm-adjusted p-values;
- paired macro-F1 difference and test direction;
- number of parent-song clusters and permutations;
- effect magnitude regardless of significance.

The 15 partition scores are not 15 independent datasets. Do not run an uncorrected t-test over fold scores and report it as the primary inference.

## 5.8 Efficiency

Table:

| Model | Device | Parameters/features | Mean training time | Mean prediction time | Peak GPU memory if available |
|---|---|---:|---:|---:|---:|

Different hardware paths make runtime descriptive. Compare the practical cost of reproducing or deploying a model, and distinguish model download/preparation time from fine-tuning time.

## 5.9 Qualitative error analysis (RQ4)

Use `results/formal/error_analysis/qualitative_review_queue.csv` and `results/formal/error_analysis/pairwise_case_patterns.csv` to select:

- shared errors;
- classical-only successes;
- Transformer-only successes;
- XLM-R/MacBERT disagreements;
- unstable cases across repeats.

Code each reviewed case for the predeclared phenomena. Include short lyric excerpts only when licence/submission rules permit, with translation verified by a Cantonese-competent person. Avoid cherry-picking only entertaining examples; state the selection rule and denominator.

Suggested synthesis table:

| Phenomenon | Reviewed cases | Shared errors | Classical-only errors | Transformer-only errors | Interpretation |
|---|---:|---:|---:|---:|---|
| Mixed/transition | [artifact/review] | | | | |
| Metaphor/indirectness | | | | | |
| Code-switching | | | | | |
| Colloquial written Cantonese | | | | | |
| Negation/contrast | | | | | |
| Repetition | | | | | |
| Insufficient section context | | | | | |

## 5.10 Direct answers to the research questions

End the chapter with one evidence-bounded paragraph per research question. Each answer should state:

1. the observed direction and magnitude;
2. uncertainty;
3. the most relevant qualitative explanation;
4. the limit on generalisation.

Negative, unstable or statistically inconclusive evidence must be reported directly rather than converted into a success claim.

## 5.11 Threats to validity

Separate:

- construct validity: four classes, section boundaries, dominant-emotion judgement and mixed affect;
- internal validity: annotation error, parameter choice, parent-song/artist leakage and stochastic training;
- external validity: 680 sections nested in 105 songs, artists, 2000-2020 period and written variety;
- conclusion validity: imbalance, co-song dependence, repeated predictions, low effective sample size and multiple comparisons;
- legal/operational constraints: permitted corpus access and limited redistribution.
