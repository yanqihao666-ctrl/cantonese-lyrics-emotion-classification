# Dissertation outline

## 1. Introduction

Context, motivation, problem definition, research gap, aim, objectives, research questions, contributions and chapter overview.

## 2. Background and related work

Emotion representation; lyrics-based emotion classification; Cantonese NLP; classical text classification; pretrained Transformers; datasets and annotation; critical synthesis and research gap.

## 3. Methodology and experimental design

Research design; emotion taxonomy; data provenance and annotation; preprocessing; leakage controls; models; hyperparameter selection; metrics; statistical analysis; reproducibility; legal, social, ethical and professional issues.

## 4. Implementation and validation

Software architecture; environment; pipeline components; experiment management; automated tests; baseline validation; implementation decisions and limitations.

## 5. Results, evaluation and discussion

Dataset analysis; primary model comparison; representation ablation; learning curves; stability and uncertainty; computational cost; confusion matrices; qualitative error taxonomy; answers to research questions; comparison with prior work.

## 6. Conclusions and future work

Contributions, direct answers to research questions, limitations, responsible interpretation and detailed future research.

## Appendices

Search protocol, annotation guide, full hyperparameters, supplementary results, test inventory, project-management evidence and AI-use statement.
