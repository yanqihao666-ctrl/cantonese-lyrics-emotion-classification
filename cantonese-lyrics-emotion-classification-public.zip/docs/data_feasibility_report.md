# Data and model feasibility report

Date reviewed: 27 July 2026

Decision update, 28 July 2026: the annotation and experiment recommendations below record the initial feasibility stage. The later locked protocol supersedes silver-label training: all 105 main-corpus songs require human gold labels, AI candidates remain hidden from annotators and outside performance evaluation, XLM-R and MacBERT are the two required Transformers, and the classical-family comparator is selected per outer partition using validation data only. See `methodology_draft.md`, `hyperparameter_protocol.md` and `formal_reporting_pipeline.md`.

## Executive finding

The review did not identify a ready-to-use, public, emotion-labelled Cantonese song-lyrics dataset of sufficient size for supervised model comparison. The project is feasible, but its central research contribution must include dataset construction and transparent label validation. Public Cantonese resources can support language verification, model selection and pipeline validation; they do not replace the required lyric-emotion dataset.

## Relevant resources

| Resource | What it provides | Suitability for the main experiment | Decision |
|---|---|---|---|
| Cantopop Corpus Project | CC BY 4.0 lyric and Jyutping transcriptions for a 105-song corpus created for tone-melody research | Lawful, high-provenance main pilot, but not emotion-labelled | Use as the main pilot and obtain independent human emotion labels |
| MIR-MLPop | 90 aligned songs across Mandarin, Cantonese and Hokkien, including 30 Cantonese songs | Too small and not emotion-labelled; designed for lyric transcription/alignment | Use only for pipeline inspection or a small external audit if licensing permits |
| Lyrics emotion dataset (University of Coimbra) | 180 manually rated lyrics and 771 tag-labelled lyrics in four Russell quadrants | Emotion labels are relevant, but the corpus is not Cantonese | Possible secondary validation or methodological reference, not the primary dataset |
| CAVES | Cantonese audiovisual emotional speech with seven acted emotions | Wrong domain and modality | Background comparison only |
| HKCanCor/PyCantonese resources | Machine-readable Cantonese corpora and language tooling | Not lyrics and not emotion-labelled | Possible language-character and tokenisation support |
| Lee (2026) Cantopop teaching corpus | 827 Cantonese songs from 1971-2022, selected from three Hong Kong annual-award inventories | Highly relevant potential expansion, but the paper does not provide a public download or a data licence | Request research access and permitted-use terms from the author; do not use unless clarified |

Sources:

- Cantopop Corpus Project: https://cantopop.humdrum.org/
- MIR-MLPop dataset description: https://york135.github.io/dataset/
- University of Coimbra MIR datasets: https://mir.dei.uc.pt/downloads.html
- CAVES dataset description: https://researchers.westernsydney.edu.au/en/datasets/cantonese-audio-visual-emotional-speech-caves-dataset/
- PyCantonese corpus documentation: https://docs.pycantonese.org/stable/data.html
- Lee (2026) Cantopop teaching corpus: https://doi.org/10.56040/slle2314

## Evidence for the research gap

Xiang, Liao and Li describe Cantonese NLP as under-resourced in both data scale and diversity, and identify colloquialism and multilinguality as challenges for Transformer-based approaches. This supports the low-resource motivation, but the dissertation must not claim that no Cantonese lyric-emotion dataset exists globally; it may state only that the documented search did not identify an accessible benchmark meeting the study requirements.

Primary source:

- Xiang, R., Liao, M. and Li, J. (2024), *Cantonese Natural Language Processing in the Transformers Era*: https://aclanthology.org/2024.sighan-1.8/

## Candidate Transformer models

### Required baselines

1. **XLM-RoBERTa-base** - multilingual transfer baseline.
2. **Chinese MacBERT-base** - Standard-Chinese-oriented transfer baseline.

### Cantonese-specific candidate

`indiejoseph/bert-base-cantonese` is a continued-pretraining model based on `bert-base-chinese`, reportedly trained on approximately 198 million Cantonese Common Crawl tokens. It is a stronger initial candidate than selecting an undocumented community emotion classifier, because the downstream classification head will be trained consistently on this project's data.

Model card: https://huggingface.co/indiejoseph/bert-base-cantonese

`zijie-zhang/CantoneseBERT` is a newer community/course-project model with extensive self-reported pretraining and downstream results. It may be included only after the exact checkpoint, tokenizer, licence, reproducibility and evaluation evidence have been audited. It should not automatically replace a better-documented baseline.

Model card: https://huggingface.co/zijie-zhang/CantoneseBERT

## Recommended dataset design

### Source audit update

The public MIR-MLPop repository was inspected directly. Its Cantonese subset contains 30 records with `song_id`, YouTube URL, temporally aligned character/pronunciation annotations, filler segments and an original train/test designation. The repository states that academic use is allowed and commercial use is prohibited. It is therefore retained as an unlabelled pipeline-validation resource, not incorporated into the main emotion benchmark without separate labels and provenance handling.

Repository: https://github.com/york135/MIRMLPop

The Cantopop Corpus public song-list endpoint was first imported as metadata only. The subsequent transcription import initially contained 43 distinct artist strings; public-context verification identified two metadata errors, leaving 42 canonical artists across 105 songs from 2000 through 2020. Artist concentration is material: the largest artist has 11 songs and the two most frequent artists together account for 20% of the corpus. These records must not be randomly split across training and testing without an artist-overlap analysis. The formal human emotion field remains unlabelled.

The corresponding public GitHub repository was subsequently audited. It includes a CC BY 4.0 `LICENSE` file and 105 UTF-8 Humdrum `*.krn` transcriptions with separate melodic, textual and Jyutping spines. The text can therefore support a reproducible academic pilot with attribution. Extracted text is nevertheless kept outside version control by default so that the final dissertation can take a conservative approach to redistribution and document the exact source revision and file hashes.

### ToneCraft source audit (26 July 2026)

The 2025 EMNLP paper *ToneCraft: Cantonese Lyrics Generation with Harmony of Tones and Pitches* states that its code and data are public and that Cantonese lyrics were collected for lyric-generation training. The linked repository was inspected at its current `main` revision. Its `data/` directory contains four JSON instruction datasets totalling 297,976 short segment-level examples:

- `canto_hmn_continue_rhyme_kr.json`: 43,977 rows;
- `canto_hmn_gen_kr.json`: 174,074 rows;
- `canto_hmn_gen_mask.json`: 4,000 rows;
- `zh_hmn_continue_kr.json`: 75,925 rows.

This resource is not incorporated into the emotion-classification corpus. The released rows are generation instructions and short outputs rather than documented song-level observations; they do not provide emotion labels, stable song identifiers or sufficient provenance to construct artist-exclusive evaluation splits. The repository also contains no explicit `LICENSE`, `COPYING` or `NOTICE` file. Consequently, its presence demonstrates that larger Cantonese lyric-derived resources are technically possible, but it does not currently satisfy this project's provenance, licensing or evaluation requirements. It may be reconsidered only after clarification from the authors or supervisor.

Sources:

- Peer-reviewed paper: https://aclanthology.org/2025.emnlp-main.18/
- Official repository: https://github.com/purepasser-by/ToneCraft

### Lee (2026) expansion lead (27 July 2026)

Lee reports a teaching-oriented Cantopop corpus assembled in 2022. The authors first gathered 852 songs from the annual awards of Radio Television Hong Kong, Television Broadcasts Limited and Commercial Radio, then removed Putonghua songs. The resulting corpus contains 827 Cantonese songs from 1971-2022 and 285,681 Chinese-character tokens.

This is the strongest expansion lead found so far because it has song-level scope, a substantially wider time period and an academically documented construction process. However, the publication does not state that the corpus is publicly downloadable, does not provide a data licence and does not describe whether external researchers may receive full lyric text. The project must therefore request access and permitted-use terms from the author rather than scrape or assume redistribution rights.

Source and contact:

- Paper: https://doi.org/10.56040/slle2314
- Author contact reported in the paper: `slee@cuhk.edu.hk`

### Scale targets and fallback design

- Preferred expansion: at least 250-500 licensed, song-identified Cantonese lyrics after cleaning.
- Stretch target: 800 or more songs if research access to the Lee corpus or a comparable lawful source is granted.
- Minimum viable design: retain the audited 105-song corpus as an explicitly low-resource pilot and use repeated artist-grouped cross-validation rather than presenting a single small holdout as a stable benchmark.
- Four primary labels: joy, sadness, anger and calmness.
- A balanced sampling target, while retaining and reporting the natural distribution separately if possible.
- Natural structural-section labels with optional `mixed/uncertain` flags. The current extraction yields 680 unique sections from 105 source songs after collapsing 81 exact within-song repeated occurrences.

### Provenance table

For every observation, retain:

```text
case_id, song_id, section_type, occurrence_count, title, artist, release_year, source_url, source_access_date,
language_evidence, candidate_label_source, annotator_label,
confidence, disagreement_flag, duplicate_group
```

### Annotation strategy

AI may assist candidate selection, translation and first-pass labelling, but AI-only labels are insufficient for a high-confidence gold test set. The recommended design is:

1. Produce candidate labels from documented metadata and an AI-assisted pass.
2. Create a detailed annotation guide with positive and negative examples.
3. Ask at least two Cantonese-competent annotators to label a stratified gold subset independently.
4. Keep every evaluation fold or final test set inside the human-validated subset.
5. Report Cohen's kappa (or Krippendorff's alpha if the annotation design requires it).
6. Resolve disagreements using a documented adjudication rule.
7. Treat the remaining automatically assisted training observations as silver labels, and run a gold-only versus silver-plus-gold sensitivity experiment.

This design turns a limitation into a research contribution: the study can measure whether larger weakly labelled training data improve performance on human-validated Cantonese evaluation cases.

## Required supervisor decisions

1. Whether the four proposed emotion classes are acceptable.
2. Whether recruiting Cantonese-speaking annotators requires ethics approval.
3. Whether annotators may be compensated and through which approved route.
4. Whether the University can advise on lyric copyright and storage.
5. Whether a human-validated test set plus silver-labelled training set is acceptable.

## Initial recommended experiment design (superseded by the locked protocol)

### Primary comparison

- Character TF-IDF + Linear SVM
- Character TF-IDF + Logistic Regression
- Word TF-IDF + a validation-selected classical classifier
- XLM-RoBERTa-base
- Chinese MacBERT-base
- Cantonese BERT, subject to model audit

### Dataset-quality experiment

- Gold-only training
- Silver-only training
- Silver pretraining followed by gold fine-tuning, or combined silver-plus-gold training
- Evaluation only on the untouched human-validated gold test set

### Robustness checks

- Artist-grouped split
- Near-duplicate detection
- Three or more random seeds
- Per-class and macro metrics
- Learning curves
- Confidence intervals
- Qualitative error analysis reviewed with Cantonese support

## Go/no-go and redesign criteria

The four-class project should proceed only if the pilot establishes:

- enough examples and artist groups in every class to construct leakage-free evaluation folds;
- raw agreement and chance-corrected agreement sufficient to defend the label definitions, with all thresholds declared before looking at model performance;
- adequate separation between the four concepts;
- legal and ethical approval for the proposed data workflow;
- no severe source or artist concentration that makes evaluation meaningless.

For five-fold artist-grouped evaluation, each class should ideally occur in at least five distinct artist groups; a class with fewer than roughly 12-15 usable songs will produce especially unstable per-class estimates. These are design warnings rather than excuses to relabel cases for balance.

If these gates fail, the response should be to revise the annotation definitions, sampling process, evaluation procedure or data source with the supervisor. The title can remain unchanged; the study should not manufacture confidence in unreliable labels.
