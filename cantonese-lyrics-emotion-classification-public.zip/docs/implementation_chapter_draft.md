# Chapter 4: Implementation and validation — working draft

This chapter describes implementation evidence, not model-performance results. Synthetic fixtures and smoke runs are used only to validate execution paths.

## 4.1 Architecture and design objective

The software was implemented as a sequence of command-line modules connected by CSV and JSON artifacts. This structure was chosen over a single exploratory notebook because the project contains several irreversible scientific boundaries: annotator judgements must remain blind, the gold labels must be frozen before modelling, every family must receive the same outer test cases, and reported tables must correspond to the predictions that were statistically analysed. Each boundary is therefore represented by an explicit file interface and a validation step.

The pipeline has five layers. The data layer imports and audits the licensed corpus. The annotation layer creates blind workbooks, measures agreement and freezes adjudicated labels. The evaluation layer generates shared artist-exclusive partitions. The modelling layer runs classical and Transformer configurations without changing those partitions. The reporting layer selects the classical procedure using validation data, combines held-out predictions, performs clustered statistical analysis and generates tables from hash-matched artifacts.

Raw lyric text is kept in the local licensed-data directory and excluded from version control. Downstream audit, prediction and reporting files contain stable song identifiers and only the metadata needed for traceability. This reduces unnecessary redistribution while preserving the ability to reproduce derived statistics locally.

## 4.2 Corpus and annotation modules

The import code reconstructs full songs from the source Humdrum files and, separately, parses explicit structural markers into lyric-bearing sections while preserving Jyutping and bibliographic metadata. It emits a unique `case_id` for each retained section and a parent `corpus_song_id`. Within-song exact repeated lyric sections are collapsed and their `occurrence_count`, original positions and source section types are retained. Schema validation rejects missing identifiers and duplicate case keys. A separate section audit measures text completeness, artist concentration, time coverage, exact duplication and near-duplicate similarity.

`prepare_annotation.py` separates the researcher's identifying key from the files sent to annotators. Each 680-row workbook is independently randomised and omits case keys, parent-song identity, title, artist, structural type and AI candidate labels. Excel validation constrains the primary label, confidence and flags while leaving a free-text rationale field. The agreement module reads the workbooks directly rather than relying on a manual CSV conversion. It checks anonymous section coverage and confidence types before calculating raw agreement, Cohen's kappa and the label-confusion table.

The adjudication queue is rule-driven. Every primary-label disagreement, confidence score of one or two, and any flagged item requires a decision. The gold builder refuses an incomplete or extra decision queue and preserves both original judgements beside the final included label or exclusion. Its metadata records SHA-256 hashes for the licensed source, researcher key, both workbooks, adjudication file, modelling dataset and lyric-free decision audit. Consequently, subsequent experiments can identify the exact human evidence on which they depend.

## 4.3 Shared evaluation implementation

Random section-level splitting would permit sections from the same song, or songs by the same artist, to appear in development and test roles. The implementation instead creates three repeated five-fold outer evaluations using split seeds 13, 42 and 97. `StratifiedGroupKFold` assigns artist groups to the outer folds. This automatically binds every section from a source song to one role. For each outer fold, a validation partition is chosen only from the remaining development artists by minimising size and class-proportion error among class-complete candidates.

The manifest generator checks that train, validation and test artists are disjoint and that every role contains every class. It records section case IDs, while materialised data retain parent-song and artist IDs, duplicate groups, role, split seed and fold. Each of the 15 materialised partition files is the common input to every model family; model runners do not construct their own test sets. This changes shared evaluation from a reporting promise into a testable input invariant.

RQ3 uses a separate subset builder over the five seed-42 partitions. It samples whole artist groups at nominal 25%, 50%, 75% and 100% training fractions, keeps validation and test cases fixed and nests smaller subsets inside larger ones. Because group sampling cannot usually match an exact percentage, metadata records achieved song and artist counts. The runner includes the fraction in every identity and refuses a resumed job whose subset hash has changed.

## 4.4 Classical and Transformer runners

The classical runner implements a majority baseline and ten learning configurations: Multinomial Naive Bayes, class-weighted logistic regression and class-weighted Linear SVM over character, Jieba word and combined TF-IDF representations, with the majority case recorded once. The vectorisers are fitted only on the training role. Validation and test predictions remain separate, and the runner writes configuration, partition identity, timing, package versions and per-case outputs.

Logistic regression uses the L-BFGS solver. This replaced `liblinear` after a synthetic four-class execution exposed incompatibility with multinomial handling in the pinned scikit-learn version. The correction was made before human gold labels or formal scores existed, so it is an implementation compatibility decision rather than performance-driven tuning.

The Transformer runner loads the tokenizer and weights from pinned Hugging Face repository revisions. XLM-R and MacBERT are the required models. Each run uses training batch size four, four gradient-accumulation steps, mixed precision when CUDA is available, and validation macro-F1 for checkpoint selection. Test metrics are calculated only after the selected checkpoint has been fixed.

The earlier tokenizer audit over full songs found some sequences above 512 tokens, motivating a tested head-tail safeguard. Because the final modelling unit is substantially shorter, that full-song result is now historical design evidence rather than a formal input audit. The tokenizer audit will be regenerated on the frozen sections; tests continue to cover short sequences, exact-boundary cases and long inputs.

## 4.5 Experiment orchestration and evidence identity

Formal RQ1 execution comprises 45 jobs: one complete classical matrix and two required Transformer runs for each of 15 partitions. `run_experiment_matrix.py` constructs this grid before training and rejects missing, duplicated or colliding jobs. Every output and log path includes model family, partition seed and outer fold.

The matrix stores a persistent status record after each job. Resume is permitted only when the saved run metadata agrees with the current input hash, partition identity, seed and expected model. A file in the expected directory is therefore not sufficient evidence of completion. This prevents an interrupted experiment, changed gold dataset or reused directory from silently mixing incompatible results.

The RQ3 orchestrator applies the same controls to 20 fraction-addressed subsets and three fixed models, producing 60 planned jobs. The 25% synthetic execution deliberately exposed a case in which the locked `min_df=2` TF-IDF configuration had no surviving terms. The implementation reports such a fraction as infeasible instead of changing a parameter after observing outcomes. This is a validation of the declared decision rule, not a real-corpus learning-curve result.

## 4.6 Test-blind selection and reporting

The primary classical comparator is a procedure rather than a test-selected global winner. For each outer partition, `select_classical_configuration.py` ranks candidate configurations using validation macro-F1 only and resolves an exact tie by ascending model key. It then copies only that configuration's untouched test predictions into `classical::validation_selected`. The selection audit retains every candidate score, selected source key and input hash.

Primary statistical analysis accepts an explicit model list. This prevents exploratory models from entering the confirmatory multiplicity family by directory discovery. The primary family contains the validation-selected classical procedure, XLM-R and MacBERT. RQ2 is analysed separately with Linear SVM held fixed across the three representations.

Before aggregation, the collector rejects duplicated model/section/partition cases and unequal coverage. The statistical module calculates section-level partition metrics, parent-song-cluster bootstrap intervals, paired parent-song permutation tests and Holm-adjusted p-values. Clustering keeps all sections and repeated-fold predictions for one song together. The table generator independently recalculates summaries, verifies the combined prediction hash against the statistical metadata and refuses incomplete pairwise tests. Thus dissertation tables are generated from the same held-out section cases that support the inference.

## 4.7 Validation strategy

Validation combines schema checks, invariant tests, known-output unit tests and end-to-end synthetic smoke runs. As of 30 July 2026, 81 automated tests cover structural-section extraction, annotation workbooks, agreement and adjudication, gold freezing, parent-song/artist leakage, learning-curve nesting, model outputs, truncation, matrix identity, test-blind selection, song-clustered resampling, result-table hashes, GPU checks, citation consistency, claim-to-artifact registration and dissertation-consistency drift.

Synthetic tests establish software behaviour only. For example, deliberately separable fixtures check that metric and reporting code can recover known predictions, while altered hashes confirm that stale outputs are rejected. The synthetic macro-F1 values are never used as project evidence.

The hardware path was tested separately. CUDA PyTorch completed a finite operation on the available NVIDIA GPU. Both required Transformers completed mixed-precision forward and backward passes at batch size four and sequence length 512. A pinned XLM-R synthetic fine-tuning run also exercised tokenisation, checkpoint selection and output generation. These checks show that the declared formal configuration is executable on the available machine; they do not predict real-corpus performance.

## 4.8 Technical decisions and limitations

Three implementation decisions were particularly consequential. First, artist identity is part of evaluation control but not a predictive feature. Second, validation-only selection and hash verification prevent a convenient test result from changing the declared comparator. Third, long-lyric handling preserves both narrative endpoints rather than privileging the opening.

The modular pipeline adds operational complexity: formal execution produces many small artifacts and depends on strict naming and metadata. This cost is intentional because 680 rows are nested in only 105 source songs, making an undetected label, split or dependence error proportionally serious. Automated checks reduce but do not eliminate scientific risk. They cannot establish that the taxonomy represents Cantonese lyric emotion well, that structural sections coincide with emotional units, that annotators understand every cultural reference, or that a statistically uncertain model difference is meaningful. Those questions require the human-label and formal evaluation evidence reported in Chapter 5.

## 4.9 Formal validation still required

Before this chapter can be changed from a pre-results implementation account to a completed account, the final dissertation must record:

- the frozen-gold manifest and class/artist feasibility checks;
- the Git commit used for all formal runs;
- the completed 45-job and 60-job matrix summaries;
- any failed or repeated run and its documented cause;
- exact formal environment metadata and elapsed time;
- the final full-suite test result;
- confirmation that every Chapter 5 number was generated from the retained artifacts.
