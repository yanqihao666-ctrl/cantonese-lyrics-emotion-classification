# GPU setup and validation

Validated: 28 July 2026

## Environment

The project machine contains an NVIDIA GeForce RTX 5060 Laptop GPU with 8,151 MiB reported by `nvidia-smi`. The platform-neutral requirement initially installed `torch 2.13.0+cpu`, so CUDA was unavailable.

The environment was changed to the official Windows CPython 3.12 wheel:

```powershell
python -m pip install --no-deps torch==2.13.0+cu130 --index-url https://download.pytorch.org/whl/cu130
```

Because the project path is deep, direct wheel extraction first exceeded the Windows path-length limit. The successful installation used a temporary short `subst` drive pointing to the project root. No project source or data path changed.

## Validation criteria

Installation is considered valid only when all of the following pass:

1. `torch` imports successfully;
2. `torch.cuda.is_available()` is true;
3. the reported device is the expected RTX 5060;
4. a real CUDA matrix multiplication completes with finite output;
5. `pip check` reports no broken requirements.

Run the reproducible check with:

```powershell
.\.venv\Scripts\python.exe -m src.gpu_environment_check --require-cuda --matrix-size 2048 --output results\environment\gpu_validation.json
```

The tracked JSON artifact records the PyTorch/CUDA build, device, compute capability, memory and measured validation operation. Its time is an environment sanity check, not a formal model-efficiency result.

## Full-length Transformer memory checks

Both required checkpoints completed a mixed-precision forward and backward pass at the declared per-device shape of batch 4 × 512 tokens:

| Model | Trainable parameters | Peak allocated | Peak reserved | Outcome |
|---|---:|---:|---:|---|
| XLM-RoBERTa-base | 278,046,724 | 2.17 GiB | 2.81 GiB | finite loss; passed |
| Chinese MacBERT-base | 102,270,724 | 1.42 GiB | 1.52 GiB | finite loss; passed |

Artifacts:

- `results/environment/transformer_memory_smoke.json`;
- `results/environment/macbert_memory_smoke.json`.

These checks show that the fixed batch size fits the 8GB device with material headroom. They use synthetic token IDs and are memory/implementation checks, not speed benchmarks or emotion results.

## Reproduction note

`requirements.txt` deliberately keeps `torch==2.13.0` platform-neutral. CUDA wheel indexes are operating-system and hardware dependent, so a clean environment must install the appropriate official PyTorch wheel separately and record the resulting build. Formal Transformer run metadata independently records the detected device and exact `torch` version.
