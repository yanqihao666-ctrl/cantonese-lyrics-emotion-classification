# Official dissertation structure alignment

Source authority: `C:/Users/20479/Downloads/Structure of MSc Dissertation  (2).docx`

Project type: **Empirical Investigation (EI)**. The project constructs and
analyses a dataset, executes controlled model experiments, and validates the
resulting empirical evidence. It is not primarily a Software Product,
Exploratory Software or Theoretical Study project.

## Required six-chapter structure

### Chapter 1. Introduction

The following sections are compulsory and will retain the supplied titles:

1.1 Project Aim

- The first paragraph begins: “The aim of this project is to …”.
- It defines the aim in no more than a few sentences.
- The remainder explains the context and core terminology for a computer
  science audience.

1.2 Objectives

- A concise enumerated list of tasks completed to achieve the aim.

1.3 Deliverables

- Frozen 6,000-section dataset and provenance/audit material.
- Reproducible Classical ML and Transformer experiment pipeline.
- Leakage-controlled partitions, saved predictions and statistical analysis.
- Figures, tables, robustness analysis and the MSc dissertation.

1.4 Ethical, Legal, and Social Issues

- Copyright and non-redistribution of lyric text.
- AI-assisted silver labels and absence of independent human validation.
- Dataset and model bias, class imbalance and responsible result claims.
- Reproducibility and appropriate disclosure of AI assistance.

### Chapter 2. Background Research

2.1 Literature Survey

- Cantonese and low-resource NLP.
- Lyrics emotion and music-emotion recognition.
- Emotion theories, taxonomies and labelled corpora.
- Weak supervision and annotation validity.
- Critical research gap.

2.2 Methods and Techniques

- TF-IDF and Classical ML classifiers.
- Transformer fine-tuning, XLM-R and MacBERT.
- Class-imbalance strategies.
- Leakage-controlled cross-validation, metrics and statistical inference.

2.3 Choice of Methods

- Concise closure explaining the selected four-class task, models,
  artist-exclusive repeated folds, Macro-F1, balanced loss and silver-label
  sensitivity analysis.

### Chapter 3. Datasets and Experimental Design

This is the specified EI chapter type.

3.1 Datasets/Data Sources

- Original 680-section Cantopop cohort and 5,320-section expansion.
- Source provenance, unit of analysis, preprocessing and deduplication.
- Silver-label construction and evidence tiers.
- Final distribution, artists, parent songs, copyright and intended use.

3.2 Empirical Process/Experimental Setup/Experimental Design

- Research questions and independent/dependent variables.
- Models, representations and hyperparameters.
- Three seeds by five artist-exclusive folds.
- Parent-song leakage control and validation-only selection.
- Imbalance experiments and fixed-test expansion comparison.
- Metrics, saved predictions, clustered uncertainty and statistical tests.

### Chapter 4. Results of the Empirical Investigation

- Dataset and class-distribution results.
- RQ1 primary model-family comparison.
- RQ2 character/word representation comparison.
- RQ3 680-versus-expanded training comparison.
- Class-imbalance results.
- Per-class results, confusion matrices and descriptive error patterns.

This chapter reports the empirical findings. Implementation details appear in
Chapter 3 where they explain the empirical process, or in an appendix where
they are needed for reproducibility.

### Chapter 5. Validation and Critical Evaluation of Results

The supplied EI title is “Validation of Results”; the expanded title keeps that
required purpose while making the discussion function explicit.

- Data-integrity, duplicate and leakage validation.
- Automated-test and artifact-completeness validation.
- Statistical uncertainty and robustness of model ordering.
- Silver-label evidence-tier sensitivity analysis.
- Comparison with the selected literature.
- Construct, internal, conclusion and external validity threats.
- Limitations: missing human gold, class imbalance, corpus expansion
  confounding, copyright constraints and lack of external test data.

### Chapter 6. Conclusions and Future Work

6.1 Conclusions

- Direct answers to the research questions.
- Evidence-bounded contributions and no human-accuracy claim.

6.2 Future Work

- Independent stratified Cantonese-speaker audit.
- External evaluation corpus and further qualitative analysis.
- Improved minority-class data and cautiously selected model extensions.

## End matter

- A complete reference list is required.
- Appendices are optional and will hold detailed fold metrics, configuration
  inventories, extra confusion matrices, audit summaries and reproduction
  commands.

## Requirements not stated in this source

The supplied document does **not** state a word limit, font, font size, line
spacing, page margins, cover-page template, referencing style or rules for
counting tables/appendices. These must come from the current assessment brief,
programme handbook, Minerva submission page or explicit supervisor guidance.

The source explicitly says that project planning, risk mitigation, comparisons
of waterfall/agile methods, descriptions of previously studied modules and a
self-appraisal section are not required and do not earn marks.
