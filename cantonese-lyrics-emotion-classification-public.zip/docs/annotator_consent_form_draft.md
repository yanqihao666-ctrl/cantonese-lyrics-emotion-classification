# Annotator consent form — draft for ethics/supervisor review

Study: *Emotion Classification in Cantonese Lyrics: a Comparative Study of Transformer-based and Classical ML Models*

Participant ID: ____________________

Please initial each box:

| Statement | Initials |
|---|---|
| I confirm that I have read and understood the participant information sheet dated __________, version __________. | |
| I have had an opportunity to ask questions and received satisfactory answers. | |
| I understand that participation is voluntary and that I may withdraw until the stated deadline without giving a reason. | |
| I understand that some lyrics may contain emotionally difficult themes and that I may skip items or stop. | |
| I understand how my annotation responses and any contact/consent information will be stored and used. | |
| I understand that anonymised quotations from my short annotation rationales may be used in the dissertation or related academic outputs. | |
| I understand that my identity will not be reported and that annotators will not be individually ranked. | |
| I agree not to redistribute the supplied lyric workbook or text. | |
| I am at least 18 years old and consent to participate. | |

Participant name: ____________________

Signature: ____________________  Date: ____________________

Researcher name: ____________________

Signature: ____________________  Date: ____________________

Withdrawal contact and deadline: [insert approved details]

This form must be stored separately from the annotation workbook.

