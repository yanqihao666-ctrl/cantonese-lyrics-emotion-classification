# Emotion taxonomy v2: four valence-arousal quadrants

This taxonomy refines the original four labels without changing the project task.
The modelling output names remain `joy`, `sadness`, `anger` and `calmness`, while
their operational meanings cover the four valence-arousal quadrants.

| Model label | Operational name | Valence | Arousal | Include | Exclude |
|---|---|---|---|---|---|
| `joy` | joy / excitement | positive | high | celebration, energetic hope, exhilaration, confident triumph | quiet affection or reassurance |
| `calmness` | calmness / tenderness | positive | low | peace, tenderness, reassurance, acceptance, gentle affection, contentment | neutral narration or passive sadness |
| `anger` | anger / tension | negative | high | anger, resentment, confrontation, protest, jealousy, fear, anxiety, pressure, emotional agitation | grief or resignation without activation |
| `sadness` | sadness / bitterness | negative | low | grief, loss, loneliness, regret, despair, resignation | explicit confrontation, agitation or threat |

## Decision rules

1. Label the dominant perceived emotion expressed in the section itself. Song-level
   context may resolve references but must not overwrite clear local wording.
2. A negative passage is `anger` only when high activation is textually evident;
   negative subject matter alone is not enough.
3. `calmness` is positive low-arousal affect, not a neutral or uncertain fallback.
4. Quiet love, reassurance and acceptance belong to `calmness`; energetic optimism
   and celebration belong to `joy`.
5. Preserve `mixed` and `uncertain` as review flags rather than model classes.
6. Never change a label merely to improve class balance. Each change requires a
   section-specific rationale and the prior label must remain auditable.

All v2 labels remain AI research-assisted development labels until independently
checked by a Cantonese-speaking annotator.
