# Dataset expansion to 6,000 sections

## Scope

The target is **6,000 total lyric sections**, consisting of the existing 680
Cantopop Corpus sections and 5,320 newly selected sections. Each new item is a
non-overlapping excerpt of two or three Chinese lyric lines, rather than a full
song.

## Expansion source and rights boundary

The expansion source is the Feitsui GitHub repository at commit
`6189bcc2db41a59531714f938a4a96aac631d068`. Its dump contains 6,593 lyric
records and a singer catalogue. The repository software has an MIT licence,
but this does **not** establish permission to redistribute the copyrighted
lyrics. Consequently:

- raw and derived lyric text is stored only in the git-ignored
  `data/research_only/` directory;
- the data is used locally for non-commercial university research;
- public project releases contain code, hashes, aggregate statistics and
  source links, but not the expanded lyric text;
- every row records its source URL, repository revision and a content hash.

## Inclusion and cleaning rules

1. Retain entries from the source's Cantonese catalogue. Its `mandarin` field
   is treated as counterpart metadata, not as a language flag for the lyric.
2. Exclude songs with missing or ambiguous artist mappings.
3. Keep Chinese lyric lines and remove Jyutping, timestamps and credit lines.
4. Form non-overlapping two-line excerpts, adding a third line only when the
   first two are too short.
5. Retain excerpts containing 24–90 normalized characters.
6. Remove repeated excerpts within a song and exact normalized duplicates
   across the source.
7. Select at most three excerpts per song and 40 per artist, using seeded
   round-robin sampling across artists.

## Labelling status

The expanded labels are AI-assisted development labels under the same
four-class taxonomy (joy, sadness, anger and calmness). They are not human gold
labels and must not be described as such. Formal claims must state this
limitation and report a manual quality audit on a stratified sample before the
dissertation is submitted.

An initial numeric-code pilot was rejected after reversing the code order
caused 4,166 of 6,000 decisions to disagree. A literal-label generation pass
improved overall agreement to 80.1%, but class-specific auditing still exposed
strong order sensitivity for `joy`. The final expansion label therefore uses
three disclosed evidence streams: (1) direct literal-label generation with an
adjudication pass, (2) four cyclic A-D permutations scored from next-token
logits with a content-free prior removed, and (3) an independent multilingual
NLI classifier using three hypothesis templates. Original-corpus V2 labels are
retained; expansion cases use unanimity, two-of-three majority, or a documented
adjudicated-generation tie-break. These remain development labels, not gold.

## Before/after comparison

Two comparisons are required:

1. **Fixed-test data-size comparison:** preserve an artist-exclusive held-out
   test set and train the same model first on the smaller training data and
   then on the expanded training data. This isolates the effect of adding data.
2. **Expanded-corpus cross-validation:** repeat artist-exclusive five-fold
   cross-validation with three seeds on all 6,000 sections for the final model
   comparison.

All resampling or weighting is fitted only on each training split. Validation
and test distributions remain unchanged. Macro-F1 remains the primary metric.
