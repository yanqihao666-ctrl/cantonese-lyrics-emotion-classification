# Transformer model selection audit

Date checked: 27 July 2026

The comparison needs models that represent distinct transfer assumptions rather than a collection chosen after seeing test scores. Repository revisions are pinned so later model-hub changes cannot silently alter the experiments.

## Predeclared models

| Role | Model | Pinned revision | Licence | Rationale | Main limitation |
|---|---|---|---|---|---|
| Multilingual transfer | `FacebookAI/xlm-roberta-base` | `e73636d4f797dec63c3081bb6ed5c7b0bb3f2089` | MIT | Strong, widely used multilingual baseline; pretrained on 100 languages and suitable for sequence-classification fine-tuning | Not lyric-specific, and written Cantonese adequacy must be established empirically |
| Standard-Chinese transfer | `hfl/chinese-macbert-base` | `a986e004d2a7f2a1c2f5a3edef4e20604a974ed1` | Apache-2.0 | Chinese-oriented comparator with corrective pretraining; tests whether Chinese specialisation helps more than broad multilingual transfer | Standard written Chinese is not equivalent to colloquial written Cantonese |
| Cantonese continued pretraining, exploratory | `indiejoseph/bert-base-cantonese` | `65442e1c2227c3d5394dfd44ea52400d0ec73679` | CC BY 4.0 | Continued pretraining from Chinese BERT on a reported 198 million Cantonese Common Crawl tokens, with 500 additional common Cantonese characters | Model card leaves intended-use, limitation, training-data and downstream-evaluation details incomplete |

Official model cards:

- https://huggingface.co/FacebookAI/xlm-roberta-base
- https://huggingface.co/hfl/chinese-macbert-base
- https://huggingface.co/indiejoseph/bert-base-cantonese

## Decision

XLM-R and MacBERT are the required Transformer comparison. The Cantonese continued-pretraining model is included as an exploratory third model only if tokenizer inspection, GPU smoke testing and the fixed compute budget succeed. It must not replace either primary baseline after test results are seen.

The Cantonese model is scientifically interesting but less thoroughly documented. A strong result would be evidence for continued pretraining in this corpus, not proof that the checkpoint is generally superior. A weak result could reflect pretraining quality, tokenizer behaviour, domain mismatch or small labelled data rather than the value of Cantonese-specific modelling in general.

## Fair-comparison controls

- Same human-gold labels and shared artist-exclusive partitions.
- Same maximum input length unless a pre-result tokenizer audit justifies a documented model-specific exception.
- Same declared learning-rate search space, epoch cap and early-stopping rule.
- Three training seeds and all five outer folds, subject to the final feasible design.
- Validation data only for checkpoint selection.
- Test predictions saved once per declared run.
- Parameter count, wall-clock time, device and peak memory reported alongside predictive metrics.
- Exact model ID, revision, tokenizer revision, package versions and input hash retained.

## Tokenizer audit on the 105-song corpus

The pinned tokenizers were run on the complete local lyric texts with special tokens included. Only derived counts were saved. This table predates the change to structural-section inputs and is retained as implementation history; a new audit over the frozen sections is required before formal training.

| Model | Median tokens | 95th percentile | Maximum | Whole songs over 512 | Unknown tokens |
|---|---:|---:|---:|---:|---:|
| XLM-R | 302 | 419.6 | 478 | 0/105 | 5 |
| MacBERT | 367 | 505.4 | 557 | 4/105 | 11 |
| Cantonese BERT | 367 | 505.4 | 557 | 4/105 | 161 |

For the earlier whole-song inputs, XLM-R represented every lyric within 512 tokens, while MacBERT and Cantonese BERT would have truncated four songs. The replacement section-level audit covered 680 cases and found maximum lengths of 131 tokens for XLM-R and 164 for both MacBERT tokenizers, with zero cases over 512. The runner retains the tested head-tail safeguard, but truncation is not expected to affect the formal section inputs.

| Model | Section median tokens | Section maximum | Sections over 512 |
|---|---:|---:|---:|
| XLM-R | 42 | 131 | 0/680 |
| MacBERT | 49 | 164 | 0/680 |
| Cantonese BERT | 49 | 164 | 0/680 |

The Cantonese checkpoint produced 709 ASCII-letter characters inside unknown-token spans, concentrated in code-switched songs, despite having fewer unknown CJK characters than MacBERT. The published tokenizer loads 500 additional vocabulary items (`len(tokenizer)=21,628` versus a base vocabulary size of 21,128), but its configuration has `do_lower_case=False`; MacBERT has `do_lower_case=True`. Simple probes consequently map several capitalised English words to `[UNK]` in the Cantonese checkpoint. This is a material tokenizer limitation and reinforces its exploratory status. It is not evidence that the model is generally unsuitable for Cantonese; it is evidence that this checkpoint's handling of English code-switching differs sharply on this corpus.

Machine-readable outputs:

- `results/tokenizer_audit/summary.json`
- `results/tokenizer_audit/token_counts.csv`

## GPU load and memory validation

Both required primary models were loaded at their pinned revisions and completed a mixed-precision forward/backward pass at batch 4 × 512 tokens:

| Model | Trainable parameters | Peak allocated memory | Peak reserved memory |
|---|---:|---:|---:|
| XLM-R | 278,046,724 | 2.17 GiB | 2.81 GiB |
| MacBERT | 102,270,724 | 1.42 GiB | 1.52 GiB |

The declared batch size is feasible on the RTX 5060 Laptop GPU. Exact machine-readable evidence is stored in `results/environment/transformer_memory_smoke.json` and `results/environment/macbert_memory_smoke.json`. The exploratory Cantonese checkpoint must still be loaded immediately before any optional run; its inclusion remains conditional and cannot replace either primary model after test inspection.
