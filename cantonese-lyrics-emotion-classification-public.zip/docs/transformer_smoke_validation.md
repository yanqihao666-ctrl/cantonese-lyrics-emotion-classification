# Transformer GPU smoke validation

Validated: 28 July 2026

## Purpose

This test verifies the complete Transformer implementation path before human gold labels exist. It is not a model-performance experiment.

The input is the tracked synthetic fixture `tests/fixtures/transformer_smoke.csv`:

- 16 synthetic training rows;
- 4 synthetic validation rows;
- 4 synthetic test rows;
- equal representation of all four labels;
- distinct synthetic artist groups across roles;
- partition seed 999 and outer fold 1, reserved for smoke testing.

No value in this run may be reported as evidence about real Cantonese lyrics.

## Configuration

| Field | Recorded value |
|---|---|
| Model | `FacebookAI/xlm-roberta-base` |
| Revision | `e73636d4f797dec63c3081bb6ed5c7b0bb3f2089` |
| Input SHA-256 | `b8a65f97cc042d5084134ab7d98bdd6a6c4919b2cce2065cb8fa57ec1ae734a9` |
| Epochs | 1 |
| Maximum length | 64 |
| Training batch | 4 |
| Gradient accumulation | 1 |
| Explicit warm-up steps | 1 |
| Device | NVIDIA GeForce RTX 5060 Laptop GPU |
| PyTorch | `2.13.0+cu130` |
| Transformers | `5.14.1` |

## Validation outcomes

The run completed successfully and produced:

- a saved validation/test/train metrics file;
- four test predictions using the common `model_key`, label and partition schema;
- model revision, input hash, split sizes, class counts and exact environment metadata;
- a unique run directory containing training seed, partition seed and outer fold;
- a checkpoint selected by validation macro-F1;
- a separately saved best model.

The first smoke execution revealed two compatibility details before formal experiments:

1. a post-training validation call used the prefix `validation_`, causing the early-stopping callback to search for `eval_macro_f1` and emit a misleading warning even though epoch-time early stopping had received the correct metric;
2. `warmup_ratio` was deprecated in the installed Transformers version.

The runner was corrected to evaluate with the callback-compatible `eval_` prefix and rename metrics only after evaluation. The warm-up ratio is now converted to explicit optimiser steps before `TrainingArguments` is created. A repeated smoke run completed without either warning.

The model-load report states that the sequence-classification head is newly initialised and language-model-head weights are unused. This is expected when adapting a base masked-language-model checkpoint for a new four-class classification task.

Separate full-length checks then executed a mixed-precision forward/backward pass at batch 4 × 512 tokens for both required models. XLM-R peaked at 2.17 GiB allocated memory and MacBERT at 1.42 GiB, so the declared per-device batch fits the 8GB GPU without reducing the effective batch configuration.

## Artifact boundary

Tracked smoke artifacts:

- `results/smoke/.../run_metadata.json`;
- `results/smoke/.../metrics.json`;
- `results/smoke/.../test_predictions.csv`.

Large checkpoints and `best_model` directories are ignored by Git. The synthetic macro-F1 and accuracy values are implementation diagnostics only and are intentionally excluded from dissertation result tables.
