# Draft request for research access to the 827-song Cantopop corpus

Do not send this unchanged. Add the student's full name, University of Leeds email address, programme, supervisor name and any required ethics or data-management information.

## Suggested email

**Subject:** Research access enquiry: Cantopop lyrics corpus for MSc emotion-classification study

Dear Dr Lee,

I am an MSc Computer Science student at the University of Leeds. My dissertation project is titled *Emotion Classification in Cantonese Lyrics: a Comparative Study of Transformer-based and Classical ML Models*.

I read your 2026 article, *Positioning Pop Songs in the Chinese Language Education Curriculum*, and noted the corpus of 827 Cantonese songs from 1971-2022 described in Section 4.2. I am writing to ask whether this corpus is available for non-commercial academic research, and if so, under what access, storage, citation and redistribution conditions.

The intended use is text-only emotion classification. I would retain song-level identifiers for artist-exclusive evaluation, obtain independent human emotion annotations, store full lyric text securely, and publish only derived statistics, labels and code unless redistribution of text is explicitly permitted. I would also follow any conditions required by the corpus owners and my University.

If the full corpus cannot be shared, access to the song inventory and metadata, or guidance on an approved source from which the texts may be obtained, would still be extremely helpful.

Could you please advise:

1. whether the corpus or song inventory is available to external researchers;
2. the licence or permitted-use terms;
3. whether full lyric text may be processed locally for non-commercial research;
4. whether artist, title, year and source metadata are included;
5. the preferred citation and acknowledgement.

Thank you for considering my request.

Kind regards,

[Student name]  
MSc Computer Science, University of Leeds  
[University email]  
[Supervisor name]

## Record if sent

- Date sent:
- Address used: `slee@cuhk.edu.hk`
- Response date:
- Permission conditions:
- Files or metadata received:
- Supervisor informed:
