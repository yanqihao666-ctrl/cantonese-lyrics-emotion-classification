# Curated 100-reference reading list

## Scope

Project: **Emotion Classification in Cantonese Lyrics: A Comparative Study of
Transformer-based and Classical ML Models**.

This is a candidate reading library, not a requirement to cite all 100 items.
Items marked **Core** should normally support the dissertation directly. Items
marked **Support** justify a specific method or limitation. Items marked
**Extension** are useful when space permits. Prefer the peer-reviewed version
over an arXiv version where both exist.

## A. Lyrics emotion and music-emotion recognition (1–20)

1. **Core** — Strapparava, C., Mihalcea, R. and Battocchi, A. (2012), [A Parallel Corpus of Music and Lyrics Annotated with Emotions](https://aclanthology.org/L12-1425/), LREC.
2. **Core** — Xia, Y., Wang, L., Wong, K.-F. and Xu, M. (2008), [Lyric-based Song Sentiment Classification with Sentiment Vector Space Model](https://aclanthology.org/P08-2034/), ACL-HLT.
3. **Core** — Hu, Y., Chen, X. and Yang, D. (2009), [Lyric-Based Song Emotion Detection with Affective Lexicon and Fuzzy Clustering Method](https://archives.ismir.net/ismir2009/paper/000041.pdf), ISMIR.
4. **Core** — Malheiro, R., Panda, R., Gomes, P. and Paiva, R.P. (2018), [Emotionally-Relevant Features for Classification and Regression of Music Lyrics](https://doi.org/10.1109/TAFFC.2016.2598569), IEEE Transactions on Affective Computing.
5. **Core** — Edmonds, D. and Sedoc, J. (2021), [Multi-Emotion Classification for Song Lyrics](https://aclanthology.org/2021.wassa-1.24/), WASSA.
6. **Core** — Song, Y. and Beck, D. (2023), [Modeling Emotion Dynamics in Song Lyrics with State Space Models](https://aclanthology.org/2023.tacl-1.10/), TACL.
7. **Core** — Agrawal, Y., Shanker, R.G.R. and Alluri, V. (2021), [Transformer-Based Approach Towards Music Emotion Recognition from Lyrics](https://doi.org/10.1007/978-3-030-72240-1_12), ECIR.
8. **Core** — Mihalcea, R. and Strapparava, C. (2012), [Lyrics, Music, and Emotions](https://aclanthology.org/D12-1054/), EMNLP-CoNLL.
9. **Core** — Liao, J.-Y. et al. (2021), [Using Transfer Learning to Improve Deep Neural Networks for Lyrics Emotion Recognition in Chinese](https://aclanthology.org/2021.ijclclp-2.1/), ROCLING/IJCLCLP.
10. **Core** — Yang, D. and Lee, W.-S. (2009), [Music Emotion Identification from Lyrics](https://doi.org/10.1109/ISM.2009.123), IEEE ISM.
11. **Support** — Laurier, C., Grivolla, J. and Herrera, P. (2008), [Multimodal Music Mood Classification Using Audio and Lyrics](https://doi.org/10.1109/ICMLA.2008.96), ICMLA.
12. **Support** — Delbouys, R., Hennequin, R., Piccoli, F., Royo-Letelier, J. and Moussallam, M. (2018), [Music Mood Detection Based on Audio and Lyrics with Deep Neural Net](https://arxiv.org/abs/1809.07276), ISMIR.
13. **Support** — Fell, M., Cabrio, E., Korfed, E., Buffa, M. and Gandon, F. (2020), [Love Me, Love Me, Say (and Write!) that You Love Me: Enriching the WASABI Song Corpus with Lyrics Annotations](https://aclanthology.org/2020.lrec-1.262/), LREC.
14. **Support** — Gómez-Cañón, J.S. et al. (2022), [TROMPA-MER: An Open Dataset for Personalized Music Emotion Recognition](https://doi.org/10.1007/s10844-022-00746-0), Journal of Intelligent Information Systems.
15. **Core** — Wang, J.-Y., Wang, C.-C., Leong, C.-I. and Jang, J.-S.R. (2024), [MIR-MLPop: A Multilingual Pop Music Dataset with Time-Aligned Lyrics and Audio](https://doi.org/10.1109/ICASSP48485.2024.10447561), ICASSP.
16. **Support** — Hu, X., Choi, K. and Downie, J.S. (2017), [A Framework for Evaluating Multimodal Music Mood Classification](https://doi.org/10.1002/asi.23649), JASIST.
17. **Support** — Patra, B.G., Das, D. and Bandyopadhyay, S. (2016), [Multimodal Mood Classification Framework for Hindi Songs](https://doi.org/10.13053/CyS-20-3-2492), Computación y Sistemas.
18. **Extension** — Hu, X. and Downie, J.S. (2010), *When Lyrics Outperform Audio for Music Mood Classification: A Feature Analysis*, ISMIR.
19. **Extension** — Panda, R., Malheiro, R. and Paiva, R.P. (2018), [Musical Texture and Expressivity Features for Music Emotion Recognition](https://archives.ismir.net/ismir2018/paper/000054.pdf), ISMIR.
20. **Extension** — Chen, X. et al. (2020), [A Multimodal Music Emotion Classification Method Based on Multifeature Combined Network Classifier](https://doi.org/10.1155/2020/4606027), Mathematical Problems in Engineering.

## B. Cantonese, Chinese and low-resource NLP (21–35)

21. **Core** — Xiang, R., Liao, M. and Li, J. (2024), [Cantonese Natural Language Processing in the Transformers Era](https://aclanthology.org/2024.sighan-1.8/), SIGHAN.
22. **Core** — Lee, Y.H. (2023), [A Corpus Study of Tone-Melody Correspondence in Cantopop, 2000–2020](https://hdl.handle.net/2429/84374), University of British Columbia thesis.
23. **Core** — Lee, J. (2019), [An Emotion Detection System for Cantonese](https://cdn.aaai.org/ocs/18309/18309-78928-1-PB.pdf), FLAIRS.
24. **Core** — Zhang, Y. et al. (2024), [Human-LLM Collaborative Construction of a Cantonese Emotion Lexicon](https://arxiv.org/abs/2410.11526), arXiv.
25. **Core** — Cheng, J., Pan, C. and Li, S. (2025), [ToneCraft: Cantonese Lyrics Generation with Harmony of Tones and Pitches](https://aclanthology.org/2025.emnlp-main.18/), EMNLP.
26. **Core** — Cui, Y. et al. (2020), [Revisiting Pre-Trained Models for Chinese Natural Language Processing](https://aclanthology.org/2020.findings-emnlp.58/), Findings of EMNLP.
27. **Support** — Min, J. et al. (2025), [CantoNLU: A Benchmark for Cantonese Natural Language Understanding](https://arxiv.org/abs/2510.20670), arXiv.
28. **Support** — Jiang, J. et al. (2025), [Developing and Utilizing a Large-Scale Cantonese Dataset for Multi-Tasking in Large Language Models](https://aclanthology.org/2025.findings-emnlp.102/), Findings of EMNLP.
29. **Support** — Jiang, J. et al. (2024), [How Far Can Cantonese NLP Go? Benchmarking Cantonese Capabilities of Large Language Models](https://arxiv.org/abs/2408.16756), arXiv.
30. **Support** — Lee, J.L. et al. (2022), [PyCantonese: Cantonese Linguistics and NLP in Python](https://aclanthology.org/2022.lrec-1.711/), LREC.
31. **Support** — Lam, C., Lau, C.M. and Lee, J.L. (2024), [Multi-Tiered Cantonese Word Segmentation](https://aclanthology.org/2024.lrec-main.1047/), LREC-COLING.
32. **Support** — Wang, L., Wong, D.F., Chao, L.S., Lu, Y. and Xing, J. (2011), [Toward a Parallel Corpus of Spoken Cantonese and Written Chinese](https://aclanthology.org/I11-1174/), IJCNLP.
33. **Support** — Sun, Z. et al. (2021), [ChineseBERT: Chinese Pretraining Enhanced by Glyph and Pinyin Information](https://aclanthology.org/2021.acl-long.161/), ACL-IJCNLP.
34. **Extension** — Barnes, J. (2023), [Sentiment and Emotion Classification in Low-resource Settings](https://aclanthology.org/2023.wassa-1.26/), WASSA.
35. **Extension** — Öhman, E., Pàmies, M., Kajava, K. and Tiedemann, J. (2020), [XED: A Multilingual Dataset for Sentiment Analysis and Emotion Detection](https://aclanthology.org/2020.coling-main.575/), COLING.

## C. Emotion theory, taxonomy and text-emotion datasets (36–50)

36. **Core** — Russell, J.A. (1980), [A Circumplex Model of Affect](https://doi.org/10.1037/h0077714), Journal of Personality and Social Psychology.
37. **Core** — Ekman, P. (1992), [An Argument for Basic Emotions](https://doi.org/10.1080/02699939208411068), Cognition and Emotion.
38. **Core** — Plutchik, R. (2001), [The Nature of Emotions](https://doi.org/10.1511/2001.4.344), American Scientist.
39. **Support** — Posner, J., Russell, J.A. and Peterson, B.S. (2005), [The Circumplex Model of Affect: An Integrative Approach to Affective Neuroscience](https://doi.org/10.1017/S0033291705005725), Psychological Medicine.
40. **Support** — Scherer, K.R. (2005), [What Are Emotions? And How Can They Be Measured?](https://doi.org/10.1177/0539018405058216), Social Science Information.
41. **Extension** — Cowen, A.S. and Keltner, D. (2017), [Self-report Captures 27 Distinct Categories of Emotion Bridged by Continuous Gradients](https://doi.org/10.1073/pnas.1702247114), PNAS.
42. **Core** — Mohammad, S.M. and Turney, P.D. (2013), [Crowdsourcing a Word-Emotion Association Lexicon](https://doi.org/10.1111/j.1467-8640.2012.00460.x), Computational Intelligence.
43. **Core** — Bostan, L.-A.-M. and Klinger, R. (2018), [An Analysis of Annotated Corpora for Emotion Classification in Text](https://aclanthology.org/C18-1179/), COLING.
44. **Core** — Demszky, D. et al. (2020), [GoEmotions: A Dataset of Fine-Grained Emotions](https://aclanthology.org/2020.acl-main.372/), ACL.
45. **Support** — Mohammad, S.M. et al. (2018), [SemEval-2018 Task 1: Affect in Tweets](https://aclanthology.org/S18-1001/), SemEval.
46. **Support** — Lamprinidis, S., Bianchi, F., Hardt, D. and Hovy, D. (2021), [Universal Joy: A Data Set and Results for Classifying Emotions Across Languages](https://aclanthology.org/2021.wassa-1.7/), WASSA.
47. **Support** — Bianchi, F., Nozza, D. and Hovy, D. (2022), [XLM-EMO: Multilingual Emotion Prediction in Social Media Text](https://aclanthology.org/2022.wassa-1.18/), WASSA.
48. **Support** — Muhammad, S.H. et al. (2025), [BRIGHTER: Bridging the Gap in Human-Annotated Textual Emotion Recognition Datasets for 28 Languages](https://aclanthology.org/2025.acl-long.436/), ACL.
49. **Support** — Hofmann, J., Troiano, E., Sassenberg, K. and Klinger, R. (2020), [Appraisal Theories for Emotion Classification in Text](https://aclanthology.org/2020.coling-main.11/), COLING.
50. **Extension** — Klinger, R. et al. (2018), [IEST: WASSA-2018 Implicit Emotions Shared Task](https://aclanthology.org/W18-6206/), WASSA.

## D. Transformer and Classical ML foundations (51–65)

51. **Core** — Vaswani, A. et al. (2017), [Attention Is All You Need](https://papers.nips.cc/paper/7181-attention-is-all-you-need), NeurIPS.
52. **Core** — Devlin, J., Chang, M.-W., Lee, K. and Toutanova, K. (2019), [BERT: Pre-training of Deep Bidirectional Transformers for Language Understanding](https://aclanthology.org/N19-1423/), NAACL-HLT.
53. **Core** — Conneau, A. et al. (2020), [Unsupervised Cross-lingual Representation Learning at Scale](https://aclanthology.org/2020.acl-main.747/), ACL.
54. **Support** — Liu, Y. et al. (2019), [RoBERTa: A Robustly Optimized BERT Pretraining Approach](https://arxiv.org/abs/1907.11692), arXiv.
55. **Core** — Salton, G. and Buckley, C. (1988), [Term-Weighting Approaches in Automatic Text Retrieval](https://doi.org/10.1016/0306-4573(88)90021-0), Information Processing & Management.
56. **Core** — Cortes, C. and Vapnik, V. (1995), [Support-Vector Networks](https://doi.org/10.1007/BF00994018), Machine Learning.
57. **Core** — Joachims, T. (1998), [Text Categorization with Support Vector Machines: Learning with Many Relevant Features](https://doi.org/10.1007/BFb0026683), ECML.
58. **Core** — Fan, R.-E. et al. (2008), [LIBLINEAR: A Library for Large Linear Classification](https://www.jmlr.org/papers/v9/fan08a.html), JMLR.
59. **Support** — McCallum, A. and Nigam, K. (1998), [A Comparison of Event Models for Naive Bayes Text Classification](https://cdn.aaai.org/Workshops/1998/WS-98-05/WS98-05-007.pdf), AAAI Workshop.
60. **Support** — Cavnar, W.B. and Trenkle, J.M. (1994), [N-Gram-Based Text Categorization](https://www.researchgate.net/publication/2375544_N-Gram-Based_Text_Categorization), SDAIR.
61. **Support** — Mikolov, T. et al. (2013), [Efficient Estimation of Word Representations in Vector Space](https://arxiv.org/abs/1301.3781), ICLR workshop.
62. **Support** — Pennington, J., Socher, R. and Manning, C.D. (2014), [GloVe: Global Vectors for Word Representation](https://aclanthology.org/D14-1162/), EMNLP.
63. **Support** — Joulin, A. et al. (2017), [Bag of Tricks for Efficient Text Classification](https://aclanthology.org/E17-2068/), EACL.
64. **Extension** — Kim, Y. (2014), [Convolutional Neural Networks for Sentence Classification](https://aclanthology.org/D14-1181/), EMNLP.
65. **Core** — Dodge, J. et al. (2020), [Fine-Tuning Pretrained Language Models: Weight Initializations, Data Orders, and Early Stopping](https://arxiv.org/abs/2002.06305), arXiv.

## E. Class imbalance and long-tailed learning (66–77)

66. **Core** — Chawla, N.V., Bowyer, K.W., Hall, L.O. and Kegelmeyer, W.P. (2002), [SMOTE: Synthetic Minority Over-sampling Technique](https://doi.org/10.1613/jair.953), JAIR.
67. **Core** — He, H. and Garcia, E.A. (2009), [Learning from Imbalanced Data](https://doi.org/10.1109/TKDE.2008.239), IEEE TKDE.
68. **Core** — Buda, M., Maki, A. and Mazurowski, M.A. (2018), [A Systematic Study of the Class Imbalance Problem in Convolutional Neural Networks](https://doi.org/10.1016/j.neunet.2018.07.011), Neural Networks.
69. **Core** — Cui, Y. et al. (2019), [Class-Balanced Loss Based on Effective Number of Samples](https://openaccess.thecvf.com/content_CVPR_2019/html/Cui_Class-Balanced_Loss_Based_on_Effective_Number_of_Samples_CVPR_2019_paper.html), CVPR.
70. **Support** — Lin, T.-Y. et al. (2017), [Focal Loss for Dense Object Detection](https://openaccess.thecvf.com/content_ICCV_2017/html/Lin_Focal_Loss_for_ICCV_2017_paper.html), ICCV.
71. **Core** — Johnson, J.M. and Khoshgoftaar, T.M. (2019), [Survey on Deep Learning with Class Imbalance](https://doi.org/10.1186/s40537-019-0192-5), Journal of Big Data.
72. **Support** — Japkowicz, N. and Stephen, S. (2002), [The Class Imbalance Problem: A Systematic Study](https://doi.org/10.1023/A:1014201411984), Intelligent Data Analysis.
73. **Support** — Batista, G.E.A.P.A., Prati, R.C. and Monard, M.C. (2004), [A Study of the Behavior of Several Methods for Balancing Machine Learning Training Data](https://doi.org/10.1145/1007730.1007735), SIGKDD Explorations.
74. **Support** — Branco, P., Torgo, L. and Ribeiro, R.P. (2016), [A Survey of Predictive Modeling on Imbalanced Domains](https://doi.org/10.1145/2907070), ACM Computing Surveys.
75. **Extension** — Drummond, C. and Holte, R.C. (2003), [C4.5, Class Imbalance, and Cost Sensitivity: Why Under-Sampling Beats Over-Sampling](https://www.site.uottawa.ca/~nat/Courses/csi5386_2008/Presentations/C4.5ClassImbalance.pdf), ICML Workshop.
76. **Extension** — Wallace, B.C. et al. (2011), [Class Imbalance, Redux](https://doi.org/10.1109/ICDM.2011.33), IEEE ICDM.
77. **Extension** — Kang, B. et al. (2020), [Decoupling Representation and Classifier for Long-Tailed Recognition](https://openreview.net/forum?id=r1gRTCVFvB), ICLR.

## F. Evaluation, cross-validation and statistical inference (78–90)

78. **Core** — Sokolova, M. and Lapalme, G. (2009), [A Systematic Analysis of Performance Measures for Classification Tasks](https://doi.org/10.1016/j.ipm.2009.03.002), Information Processing & Management.
79. **Core** — Opitz, J. (2024), [A Closer Look at Classification Evaluation Metrics and a Critical Reflection of Common Evaluation Practice](https://aclanthology.org/2024.tacl-1.46/), TACL.
80. **Support** — Kohavi, R. (1995), [A Study of Cross-Validation and Bootstrap for Accuracy Estimation and Model Selection](https://www.ijcai.org/Proceedings/95-2/Papers/016.pdf), IJCAI.
81. **Core** — Cawley, G.C. and Talbot, N.L.C. (2010), [On Over-fitting in Model Selection and Subsequent Selection Bias in Performance Evaluation](https://www.jmlr.org/papers/v11/cawley10a.html), JMLR.
82. **Core** — Varma, S. and Simon, R. (2006), [Bias in Error Estimation When Using Cross-Validation for Model Selection](https://doi.org/10.1186/1471-2105-7-91), BMC Bioinformatics.
83. **Support** — Varoquaux, G. (2018), [Cross-Validation Failure: Small Sample Sizes Lead to Large Error Bars](https://doi.org/10.1016/j.neuroimage.2017.06.061), NeuroImage.
84. **Support** — Dietterich, T.G. (1998), [Approximate Statistical Tests for Comparing Supervised Classification Learning Algorithms](https://doi.org/10.1162/089976698300017197), Neural Computation.
85. **Support** — Nadeau, C. and Bengio, Y. (2003), [Inference for the Generalization Error](https://doi.org/10.1023/A:1024068626366), Machine Learning.
86. **Core** — Berg-Kirkpatrick, T., Burkett, D. and Klein, D. (2012), [An Empirical Investigation of Statistical Significance in NLP](https://aclanthology.org/D12-1091/), EMNLP-CoNLL.
87. **Core** — Dror, R. et al. (2018), [The Hitchhiker's Guide to Testing Statistical Significance in Natural Language Processing](https://aclanthology.org/P18-1128/), ACL.
88. **Support** — Reimers, N. and Gurevych, I. (2017), [Reporting Score Distributions Makes a Difference: Performance Study of LSTM-networks for Sequence Tagging](https://aclanthology.org/D17-1035/), EMNLP.
89. **Core** — Du, Y. and Nguyen, D. (2023), [Measuring the Instability of Fine-Tuning](https://aclanthology.org/2023.acl-long.342/), ACL.
90. **Extension** — Bengio, Y. and Grandvalet, Y. (2004), [No Unbiased Estimator of the Variance of K-Fold Cross-Validation](https://www.jmlr.org/papers/v5/grandvalet04a.html), JMLR.

## G. Annotation, weak supervision and silver labels (91–96)

91. **Core** — Cohen, J. (1960), [A Coefficient of Agreement for Nominal Scales](https://doi.org/10.1177/001316446002000104), Educational and Psychological Measurement.
92. **Core** — Artstein, R. and Poesio, M. (2008), [Inter-Coder Agreement for Computational Linguistics](https://doi.org/10.1162/coli.07-034-R2), Computational Linguistics.
93. **Support** — Snow, R. et al. (2008), [Cheap and Fast—but Is It Good? Evaluating Non-Expert Annotations for Natural Language Tasks](https://aclanthology.org/D08-1027/), EMNLP.
94. **Core** — Dawid, A.P. and Skene, A.M. (1979), [Maximum Likelihood Estimation of Observer Error-Rates Using the EM Algorithm](https://doi.org/10.2307/2346806), Applied Statistics.
95. **Core** — Ratner, A.J. et al. (2017), [Snorkel: Rapid Training Data Creation with Weak Supervision](https://www.vldb.org/pvldb/vol11/p269-ratner.pdf), VLDB.
96. **Core** — Leonardelli, E. et al. (2021), [Agreeing to Disagree: Annotating Offensive Language Datasets with Annotators' Disagreement](https://aclanthology.org/2021.emnlp-main.822/), EMNLP.

## H. Data documentation, ethics and responsible NLP (97–100)

97. **Core** — Bender, E.M. and Friedman, B. (2018), [Data Statements for Natural Language Processing: Toward Mitigating System Bias and Enabling Better Science](https://aclanthology.org/Q18-1041/), TACL.
98. **Core** — Gebru, T. et al. (2021), [Datasheets for Datasets](https://doi.org/10.1145/3458723), Communications of the ACM.
99. **Support** — Mitchell, M. et al. (2019), [Model Cards for Model Reporting](https://doi.org/10.1145/3287560.3287596), FAT*.
100. **Core** — Bender, E.M., Gebru, T., McMillan-Major, A. and Shmitchell, S. (2021), [On the Dangers of Stochastic Parrots: Can Language Models Be Too Big?](https://doi.org/10.1145/3442188.3445922), FAccT.

## Recommended dissertation use

- **Introduction:** approximately 10–15 items, mostly from A, B and C.
- **Literature review:** approximately 35–50 items across A–E and G.
- **Methodology:** approximately 15–25 items from D–G.
- **Discussion and limitations:** approximately 15–25 items from A–C and G–H.
- A single paper may be cited in multiple chapters. The final bibliography should
  include only sources actually cited in the submitted dissertation.

For a 70–75 target, read the 51 **Core** items first, then add only the Support
and Extension items that contribute to a specific comparison, methodological
choice, or limitation.
