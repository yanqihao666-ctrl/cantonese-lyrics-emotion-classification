# Software architecture and validation inventory

Status: implementation evidence before formal gold-label experiments

## Architecture

```mermaid
flowchart LR
    A["Licensed lyric sources"] --> B["Import and schema validation"]
    B --> C["Corpus audit<br/>duplicates, language, provenance"]
    C --> D["Blinded human annotation"]
    D --> E["Agreement and adjudication"]
    E --> F["Gold-labelled dataset"]
    F --> G["Shared artist-exclusive CV manifest"]
    G --> H["Classical ML runner"]
    G --> I["Transformer runner"]
    H --> O["Validation-only classical selection"]
    O --> J["Test predictions + metadata"]
    I --> J
    J --> K["Prediction collector and integrity checks"]
    K --> L["Metrics, cluster bootstrap and paired permutation tests"]
    L --> M["Hash-verified figures, tables and error analysis"]

    N["AI/zero-shot candidates"] -. "hidden from annotators; never gold" .-> D
```

The modules communicate through explicit CSV and JSON artifacts. This makes each dissertation number traceable to an input, configuration and saved output rather than to notebook state.

## Module responsibilities

| Stage | Main modules | Responsibility and control |
|---|---|---|
| Import | `import_cantopop_corpus.py`, `import_cantopop_lyrics.py`, `import_mirmlpop.py` | Convert permitted sources to a common schema and extract natural lyric sections while preserving case and parent-song identifiers |
| Validation and audit | `data_validation.py`, `data_audit.py`, `plot_data_audit.py` | Reject invalid gold rows, identify duplicates and near duplicates, quantify corpus coverage, produce derived figures |
| Annotation and gold freeze | `prepare_annotation.py`, `annotation_agreement.py`, `build_gold_dataset.py` | Create blind sheets, calculate agreement, require documented adjudication and freeze a hash-backed gold dataset without overwriting original decisions |
| Candidate labels | `silver_label_zero_shot.py`, `silver_label_llm.py`, `candidate_label_audit.py` | Produce weak suggestions separately and measure prompt sensitivity/class collapse |
| Shared evaluation | `make_cv_manifest.py`, `make_splits.py` | Generate deterministic artist-exclusive train/validation/test roles and materialise identical inputs |
| Experiment orchestration | `run_experiment_matrix.py` | Validate the exact formal grid, hash inputs, generate collision-free jobs, persist status/logs and resume without overwriting completed runs |
| Learning curves | `make_learning_curve_subsets.py`, `run_learning_curve_matrix.py`, `learning_curve_analysis.py` | Materialise nested artist subsets, address every fraction uniquely, run 60 predeclared jobs and reject changed evaluation coverage |
| Classical models | `classical_experiment.py` | Evaluate majority, Naive Bayes, logistic regression and linear SVM with character, word and combined TF-IDF |
| Classical selection | `select_classical_configuration.py` | Select one candidate per outer partition using validation macro-F1 only and preserve a hash-backed audit |
| Transformers | `tokenizer_audit.py`, `transformer_experiment.py` | Audit coverage/truncation; fine-tune pinned checkpoints with early stopping and saved environment metadata |
| Aggregation | `collect_predictions.py` | Keep test rows only and reject missing, conflicting or duplicate model/case predictions |
| Statistical analysis | `statistical_analysis.py` | Restrict predeclared hypothesis families; produce section-level partition metrics, parent-song-cluster bootstrap intervals, paired clustered permutation tests and Holm adjustment |
| Formal reporting | `generate_results_tables.py` | Verify hashes/coverage, recalculate summaries and generate overall, per-class and pairwise dissertation tables |

## Validation strategy

Validation operates at four levels:

1. **Schema invariants.** Required identifiers, labels, groups and split roles cannot be missing; section `case_id` values must be unique and parent-song IDs retained.
2. **Research-design invariants.** Every split contains all four labels, artists do not cross roles, and shared partition identifiers propagate into every prediction.
3. **Known-output unit tests.** Synthetic inputs test perfect agreement, perfect classification, expected duplicate detection, head-tail token retention and statistical behaviour under deliberately different predictions.
4. **Artifact-level checks.** Corpus and tokenizer audits run on the real 105-song source; package versions, model revisions, hashes, seeds, runtime and device are saved with experiments.

The tests do not establish scientific performance. They establish that the implementation calculates and records the intended quantities and fails loudly when core assumptions are violated.

## Automated test inventory

As of 29 July 2026, the full suite contains 76 tests.

| Area | Tests | Examples of the property checked |
|---|---:|---|
| Annotation | 7 | blindness, CSV/XLSX loading, agreement, low-confidence/flag routing and invalid confidence rejection |
| Gold-label freeze | 4 | required adjudication, consensus preservation, section-case identity and documented exclusion |
| Data import | 5 | Humdrum extraction, structural sections, metadata schema and time-ordered lyric reconstruction |
| Corpus validation/audit | 6 | gold-source constraint, duplicate-group leakage, near-duplicate detection, figure creation |
| Splitting and learning curves | 8 | artist and parent-song exclusivity, reproducibility, class coverage, partition materialisation and nested group subsets |
| Learning-curve orchestration/analysis | 4 | unique fraction paths, resumable execution, achieved-size checks and unchanged evaluation cases |
| Classical experiments | 2 | traceable outputs, separation of validation and test roles |
| Classical validation selection | 2 | test-blind selection and deterministic tie resolution |
| Experiment orchestration | 3 | unique traceable jobs, rejection of an incomplete formal grid, and stale-output refusal on resume |
| Transformer experiments | 8 | metric calculation, artist/parent-song leakage, head-tail truncation, partition/fraction identity, warm-up and metric-prefix handling |
| Weak labels | 6 | valid-output parsing, consensus rules, prompt agreement, pinned revision and class-collapse warning |
| Tokenizer audit | 1 | derived truncation/unknown-token statistics without saving lyric text |
| Prediction collection | 2 | multi-model combination and duplicate model/case rejection |
| Statistical analysis | 6 | partition aggregation, scoped model families, parent-song-clustered resampling, duplicate rejection and Holm correction |
| Formal result tables | 3 | prediction-hash matching, identical case coverage, summary recalculation and artifact-driven rendering |
| Evaluation figures | 1 | count/normalised confusion matrices and partition-variability plot creation |
| Qualitative error analysis | 1 | paired correctness strata and lyric-free review queue construction |
| GPU environment | 1 | an actual finite matrix operation on the detected execution device |
| Transformer memory | 1 | valid full-length smoke-test dimensions before loading a large checkpoint |
| References and citations | 3 | matrix/BibTeX identity, search-log coverage and unmatched in-text citation rejection |
| Dissertation evidence | 3 | verified-artifact existence, complete chapter coverage and prohibition of smoke evidence |
| Dissertation consistency | 4 | canonical RQs, placeholder scope, chapter numbering and pinned model-revision drift |

The command used for verification is:

```powershell
.\.venv\Scripts\python.exe -m pytest -q
```

The reported count should be updated automatically in the dissertation evidence log after any test is added or removed.

## Remaining validation before formal results

- after gold annotation, create all 15 shared partitions and audit their class/artist counts;
- dry-run the formal matrix and require exactly 45 collision-free jobs before training;
- run every declared model on the exact same test cases;
- verify the combined prediction table before any aggregate results are written;
- verify the validation-selection audit and keep primary/RQ2 multiplicity families separate;
- generate tables only when prediction and statistical-artifact hashes match;
- preserve console logs and the Git commit identifier used for formal runs.
