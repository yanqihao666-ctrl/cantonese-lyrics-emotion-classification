# Dissertation master plan

Status: controlled post-experiment writing plan (updated 15 August 2026)

Authoritative citation library: `docs/CORE_50_REFERENCE_PLAN.md`. The earlier
100-item list is a discovery pool, not a requirement to cite every item.

## Confirmed format

The supplied `Structure of MSc Dissertation  (2).docx` classifies this work as
an **Empirical Investigation** and requires six chapters. The authoritative
mapping is recorded in `docs/OFFICIAL_DISSERTATION_STRUCTURE_ALIGNMENT.md`:

1. Introduction;
2. Literature Survey / Background Research;
3. Datasets and Experimental Design;
4. Results of the Empirical Investigation;
5. Validation and Critical Evaluation of Results;
6. Conclusions and Future Work.

It also states that the whole dissertation should be brief, focused and written in clear, short sentences. The public [2025/26 COMP5200M catalogue](https://catalogue.leeds.ac.uk/Module/TP/COMP/5200M/202526) confirms that the module is assessed 100% by dissertation, but it does not publish a word limit. No absolute word target should therefore be presented as official until the current Minerva assessment brief or supervisor confirms it.

Let `W` be the official maximum count for the main dissertation text. The provisional budget is:

| Component | Share of `W` | Purpose |
|---|---:|---|
| Abstract | 3% | Question, data, method, principal verified findings and bounded conclusion |
| Chapter 1: Introduction | 10% | Mandatory aim, objectives, deliverables, ethical/legal/social issues, context and scope |
| Chapter 2: Background and related work | 25% | Critical synthesis supporting the 30%-weighted background criterion |
| Chapter 3: Datasets and experimental design | 22% | Mandatory data sources and empirical process, including models, splits, metrics and tools |
| Chapter 4: Results of the empirical investigation | 18% | Dataset, model-family, representation, expansion, imbalance and per-class results |
| Chapter 5: Validation and critical evaluation | 15% | Integrity, statistics, robustness, literature comparison, discussion and validity threats |
| Chapter 6: Conclusions and future work | 7% | Direct answers, contributions, limits and prioritised future research |

This is a percentage budget, not a substitute word limit. If the official brief counts the abstract or tables differently, `W` and the allocations must be adjusted before final editing.

## Single source of truth by chapter

| Chapter | Primary working source | Current state | What remains |
|---|---|---|---|
| 1 | `docs/introduction_draft.md` | Requires restructuring | Use the compulsory 1.1 Aim, 1.2 Objectives, 1.3 Deliverables and 1.4 Ethical/Legal/Social sections |
| 2 | `docs/literature_synthesis.md` and `docs/CORE_50_REFERENCE_PLAN.md` | Initial synthesis plus controlled 50-source library | Rewrite as a critical synthesis using only claims verified from the selected sources |
| 3 | `docs/final_project_methodology.md` | Authoritative implemented method | Reorganise into compulsory 3.1 Datasets/Data Sources and 3.2 Empirical Process/Experimental Design |
| 4 | Frozen result artifacts | Experiments complete | Present results by research question without repeating the method |
| 5 | Audits, statistics and robustness artifacts | Validation complete | Validate and critically evaluate results, compare literature and state threats to validity |
| 6 | Not drafted as findings | Ready after Chapter 5 synthesis | Write only after Chapter 5 directly answers all RQs |
| Appendices | Protocol and audit documents under `docs/` | Mostly ready | Select material that evidences rigour without moving essential argument out of the main text |

Older feasibility notes do not override the locked methodology. Where documents disagree, the authority order is:

1. frozen silver-dataset metadata and completed experiment artifacts;
2. `docs/final_project_methodology.md`, the completion report and statistical plans;
3. current implementation and tests;
4. early feasibility or candidate-label notes.

## Narrative contract

The final dissertation should make one cumulative argument:

> It is not known whether Transformer models provide a reliable advantage over
> strong sparse-text baselines for Cantonese lyric sections under severe class
> imbalance. This project provides an internally controlled comparison using a
> disclosed 6,000-section AI-assisted silver-labelled corpus, shared
> artist-exclusive partitions, parent-song leakage controls, validation-only
> selection and uncertainty analysis, while treating missing human validation
> as the principal construct-validity limitation.

Each chapter advances that argument:

- Chapter 1 establishes why the comparison matters and states a narrow, defensible gap.
- Chapter 2 shows why label perspective, language variety, domain and sample size prevent a result from another dataset being assumed here.
- Chapter 3 translates those threats into annotation, grouping, model and statistical controls.
- Chapter 4 demonstrates that the controls are implemented as executable invariants rather than intentions.
- Chapter 5 reports the evidence, including ambiguity and inconclusive differences.
- Chapter 6 states what the evidence supports and what remains unknown.

## Required display items

Only display items with an analytical purpose enter the main text:

| Chapter | Required item | Message |
|---|---|---|
| 1 | Project deliverables summary | Required outputs are concrete and traceable |
| 2 | Evidence-to-gap map | Existing strands do not resolve the controlled Cantonese comparison |
| 3 | End-to-end experimental design | Silver labels are frozen before shared grouped evaluation and reporting |
| 3 | Model/RQ matrix | Each model or representation answers a declared research question |
| 3 | Software evidence-flow diagram | Hash-backed artifacts prevent silent drift and manual result transcription |
| 4 | Silver-label evidence tiers and artist distribution | Provenance, agreement tier and imbalance determine what can be concluded |
| 4 | Primary comparison table | Effect magnitude and uncertainty matter more than rank |
| 4 | RQ2 representation table | Representation is compared with classifier held fixed |
| 4 | Fixed-test expansion plot | Adding the expansion corpus changes model behaviour |
| 4 | Confusion matrices | Per-class failures qualify aggregate metrics |
| 5 | Robustness and validity table | Sensitivity evidence is separated from human validation |

Supplementary folds, full configurations, all confusion counts and test inventory belong in appendices unless needed to understand the argument.

## Result-writing gate

Model scores, class prevalence, robustness results and significance claims may
now be written only from the frozen artifacts under
`results/consensus_final_6000/` and `results/consensus_final_fixed_size/`.
Independent human agreement and human-gold accuracy remain prohibited claims
because those artifacts do not exist. Qualitative Cantonese interpretations
must be marked as AI/researcher-assisted unless checked by a competent speaker.
Synthetic smoke artifacts remain implementation checks only.

## Final editing order

1. Rewrite Chapter 3 into the mandatory EI data and experimental-design sections.
2. Write Chapter 4 from the frozen result tables and figures.
3. Write Chapter 5 from integrity audits, statistical evidence and the robustness report.
4. Write Chapter 6 and the abstract from the bounded Chapters 4–5 conclusions.
5. Rewrite Chapter 2 using the controlled 50-source citation library and mandatory 2.1–2.3 sections.
6. Rewrite Chapter 1 using mandatory Sections 1.1–1.4.
7. Apply the confirmed word budget and audit every number, citation and caption.
8. Render the full dissertation and obtain supervisor feedback.
