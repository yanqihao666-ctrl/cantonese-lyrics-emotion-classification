# Citation and source audit

Status: dissertation-working bibliography verified on 28 July 2026

## Referencing convention

The working drafts use Leeds Harvard author-date citations. The University of Leeds Library requires an in-text author/year citation and a corresponding full reference for every quoted, paraphrased, summarised or otherwise used source. For three or more authors, the working drafts therefore use first-author surname plus `et al.`. Direct quotations and close paraphrases must add page numbers in the final dissertation.

The final submission template or School guidance must still be checked in case COMP5200M specifies Leeds Numeric or another style. Changing the rendered style must not change the underlying source metadata or citation coverage.

Official guidance:

- https://library.leeds.ac.uk/info/1402/referencing/50/leeds_harvard_style
- https://library.leeds.ac.uk/referencing-examples/9/leeds-harvard/542/standard
- https://library.leeds.ac.uk/info/1402/referencing/48/

## Controlled artifacts

- `docs/literature_matrix.csv`: 28 sources with task, language, data, method, limitation, relevance, quality note and authoritative URL.
- `docs/literature_search_log.csv`: 17 documented searches covering every retained matrix key.
- `docs/references.bib`: 28 complete machine-readable references whose keys exactly match the matrix.
- `docs/literature_synthesis.md`: critical synthesis rather than a paper-by-paper list.
- `results/reference_audit.json`: reproducible audit summary.
- `src/audit_references.py`: rejects missing/duplicate keys, missing core metadata, title/year disagreement, non-HTTPS source locations and unmatched author-year citations.

Of the 28 sources, 26 are peer-reviewed conference or journal publications, one is the primary University of British Columbia master's thesis underlying the corpus, and one is a clearly identified arXiv preprint. The preprint is not used as primary evidence for model performance.

## Metadata corrections made during the audit

1. The Cantopop corpus thesis title was corrected to *A Corpus Study of Tone-Melody Correspondence in Cantopop, 2000–2020* and the author was verified as Yin Hei (Jason) Lee.
2. The internal key for Strapparava et al. (2012) was corrected from the misspelled `strappavara_etal_2012`.
3. Agrawal et al. (2021) was reclassified from an arXiv preprint to its peer-reviewed ECIR publication and linked through DOI `10.1007/978-3-030-72240-1_12`.
4. Gómez-Cañón et al.'s TROMPA-MER article was added because it was cited in the taxonomy and methodology but absent from the original matrix. It was published online in 2022 and assigned to journal volume 60 in 2023; the working citation consistently uses the online-publication year 2022 and records the issue-year distinction.
5. Song and Beck (2023) and Malheiro et al. (2018) were added to strengthen the treatment of within-song emotion dynamics and classical lyric-specific features.

## Verification hierarchy

Metadata was checked against the most authoritative accessible record in this order:

1. publisher or DOI metadata;
2. ACL Anthology or ISMIR Archive;
3. official university repository or author-maintained corpus site;
4. arXiv only for the one unpublished preprint.

Search-engine snippets and secondary bibliography sites were used only to locate primary records, not as the final metadata authority. The literature synthesis distinguishes evidence that is directly comparable with this study from evidence transferred across language, domain, task or annotation perspective.

All 28 matrix URLs were checked on 28 July 2026. Twenty-seven returned HTTP 200 and the IEEE DOI target returned HTTP 202 while resolving to the correct document record; none failed or redirected to an unrelated source.

## Reproduction

Run:

```powershell
.\.venv\Scripts\python.exe -m src.audit_references --output results\reference_audit.json
```

A passing audit proves internal key, title, year and author-year coverage consistency. It does not prove that every interpretive claim is correct. Before submission, any direct quotation or highly specific numerical claim must be rechecked against the full source and supplied with a page number where Leeds Harvard requires one.
