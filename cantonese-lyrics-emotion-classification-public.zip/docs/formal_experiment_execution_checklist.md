# Formal experiment execution checklist

Status: use only after both independent annotation workbooks have been returned

This is the operational gate between annotation and reportable model results. Tick each item in order. Do not use zero-shot candidates, synthetic smoke metrics or partial runs as dissertation performance evidence.

## A. Freeze the gold data

- [ ] Retain the two original annotator files unchanged and calculate raw agreement, Cohen's kappa, per-class disagreement and the adjudication queue directly from the returned XLSX/CSV files.
- [ ] Adjudicate every disagreement and every required low-confidence/ambiguity case; document who made the decision and why.
- [ ] Confirm that every row has one of `joy`, `sadness`, `anger`, `calmness`, a unique `case_id`, a parent `corpus_song_id`, an artist and source provenance.
- [ ] Confirm that every class occurs in at least five distinct artist groups. If not, stop and revise the evaluation design with the supervisor before any model score is inspected.
- [ ] Run the gold builder; archive `gold_labelled.csv`, the lyric-free decision audit and the freeze metadata together.
- [ ] Confirm every input/output SHA-256, all four class counts and at least five distinct artists per label before splitting.
- [ ] Commit the frozen labels, or their permitted non-text metadata/manifest, and record the Git commit used for all formal runs.

## B. Freeze the evaluation

- [ ] Generate the 15 shared partitions using seeds 13, 42 and 97 with five artist-exclusive outer folds.
- [ ] Inspect the manifest: no artist, parent song or duplicate group may cross train, validation and test; every role must contain all four labels.
- [ ] Confirm that the two primary Transformers and all classical configurations use these exact materialised CSV files.
- [ ] Run the matrix in planning mode and verify exactly 15 partitions and 45 jobs:

```powershell
.\.venv\Scripts\python.exe -m src.run_experiment_matrix data\processed\cv_partitions --output-root results\formal --dry-run
```

- [ ] Re-run the CUDA validation and record GPU, PyTorch/CUDA versions and available memory.
- [ ] Confirm the pinned model revisions and predeclared hyperparameters. Do not change them in response to test scores.

## C. Execute and verify

- [ ] Remove `--dry-run` and execute the matrix. Preserve its manifest and logs. If interrupted, run the same command again; completed jobs should be skipped.
- [ ] Require 15 completed classical jobs, 15 XLM-R jobs and 15 MacBERT jobs, with one metadata file per job.
- [ ] Select one classical configuration per partition from validation macro-F1 only; inspect all 15 audit rankings and selection frequencies.
- [ ] Verify that every expected model/section/partition test prediction exists exactly once before calculating aggregate metrics.
- [ ] Run the three-model primary family and the fixed-Linear-SVM RQ2 representation family separately; do not mix their Holm corrections.
- [ ] Combine test-only predictions, then run the predeclared cluster bootstrap, paired permutation tests, plots and error-analysis queue.
- [ ] Generate dissertation tables only after the prediction hash, identical case coverage and recalculated summaries pass.
- [ ] Dry-run RQ3 and require 5 base folds, 20 nested subsets and 60 unique fraction-addressed jobs.
- [ ] Inspect achieved counts and feasibility before RQ3 training; preserve and report an infeasible fraction rather than tuning to force it.
- [ ] Verify identical validation/test IDs across all RQ3 models/fractions before generating the curve.
- [ ] Populate dissertation tables only from saved machine-readable artifacts. Keep validation and test findings visibly separate.
- [ ] Archive the gold-data hash, CV manifest, matrix manifest, prediction files, environment metadata, logs and Git commit together.

## D. Interpretation lock

- [ ] Report macro-F1 as primary; include weighted-F1, accuracy, per-class results, confusion matrices and across-partition variability.
- [ ] Discuss effect sizes and uncertainty, not only rankings or p-values.
- [ ] Analyse predeclared error strata and have Cantonese interpretations checked by a competent speaker.
- [ ] Label any later sensitivity analysis as exploratory. Never redefine labels, remove difficult sections or tune against outer-test results.
- [ ] State the constraints plainly: 680 sections nested within 105 high-provenance source songs, annotator reliability, class balance, artist coverage and limited external validity.
