# Research plan

## Aim

To determine how classical machine-learning and Transformer-based approaches compare when classifying emotions expressed in Cantonese song lyrics, with particular attention to low-resource data, textual representation and model errors.

## Intended contribution

The project will provide a controlled comparison rather than a leaderboard of unrelated models. Its contribution will be based on a documented Cantonese lyric dataset, leakage-aware evaluation, character-versus-word ablation, learning curves, computational-cost reporting and qualitative error analysis.

## Core experimental matrix

| Family | Representation/model | Required role |
|---|---|---|
| Non-learning | Majority class | Sanity baseline |
| Classical | Character TF-IDF + Logistic Regression/SVM | Cantonese-friendly baseline |
| Classical | Word TF-IDF + Logistic Regression/SVM | Tokenisation comparison |
| Classical | Combined TF-IDF + validation-selected classifier | Controlled feature comparison |
| Transformer | XLM-RoBERTa-base | Multilingual transfer baseline |
| Transformer | Chinese MacBERT-base | Standard-Chinese transfer baseline |

The required Transformer pair is locked to the pinned XLM-RoBERTa-base and Chinese MacBERT-base revisions. The Cantonese continued-pretraining checkpoint remains exploratory and cannot replace either required model after test scores are viewed.

## Required evaluation

- Identical predeclared section-level evaluation cases for all model families
- Repeated outer cross-validation for 680 sections nested within 105 source songs
- Group-aware splitting by artist where feasible
- No parent song may cross train, validation and test roles
- Duplicate and near-duplicate leakage checks
- Macro-F1 as the primary metric
- Accuracy, weighted-F1 and per-class metrics
- Confusion matrices
- Three or more random seeds for stochastic models
- Learning curves using 25%, 50%, 75% and 100% of training data
- Runtime and computational-cost comparison
- Confidence intervals or an appropriate paired significance procedure
- Structured qualitative analysis of misclassified lyric sections

The shared manifest uses three declared split seeds and five outer folds. Within each outer fold, validation artists are selected only from the remaining development data. The resulting materialised files are used unchanged by the classical and Transformer runners. Model scores must not influence split selection.

## Dataset quality gates

The main experiment must not begin until:

1. the operational definitions of all emotion classes are documented;
2. a pilot sample has tested whether annotators can apply the categories;
3. the provenance and legal basis of every lyric source are recorded;
4. duplicate songs, alternate versions and within-song repeated sections are addressed;
5. label reliability is measured or the labels are explicitly described as weak/silver labels;
6. the absence of Cantonese expertise in the primary researcher is mitigated and disclosed.

## COMP5200M rubric alignment

### Background research (30%)

Systematic search, thematic synthesis, critical comparison, explicit research gap, and substantive legal, social, ethical and professional analysis.

### Methodology (20%)

Every data, label, split, feature, model and metric choice must be justified against the research questions. Git history and project decisions must provide evidence of professional management.

### Implementation and validation (20%)

Modular code, configuration-driven experiments, automated data checks, unit tests, reproducible environments and validation against simple known baselines.

### Results, evaluation and discussion (20%)

Results must answer each research question, quantify uncertainty, discuss failures and avoid claims beyond the dataset and evaluation design.

### Presentation (10%)

Concise academic English, consistent citations, publication-quality figures and tables, a coherent chapter structure and useful appendices.

## Immediate risks

| Risk | Consequence | Mitigation |
|---|---|---|
| No established labelled dataset | Invalid or weak conclusions | Pilot annotation; supervisor support; transparent silver-label design if necessary |
| Researcher lacks Cantonese proficiency | Cleaning and error-analysis errors | Cantonese-speaking reviewer(s), documented translations and sampling audits |
| Copyright restrictions | Dataset cannot be distributed | Store raw lyrics locally; publish identifiers, labels and acquisition procedure only |
| Artist or duplicate leakage | Inflated test performance | Group split and similarity-based duplicate checks |
| Class imbalance | Misleading accuracy | Macro-F1, per-class results, stratification and sensitivity analysis |
| Transformer instability on small data | Unreliable ranking | Multiple seeds, early stopping and confidence intervals |

## No-result rule

Numbers may enter the dissertation only when they can be traced to saved experiment outputs. Expected, illustrative or AI-generated values must never be presented as observed results.
