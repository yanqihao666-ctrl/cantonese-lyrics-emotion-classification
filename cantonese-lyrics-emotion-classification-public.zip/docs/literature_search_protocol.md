# Literature search protocol

## Review purpose

To identify evidence relevant to: (1) textual emotion classification in lyrics; (2) emotion taxonomies and annotation; (3) Cantonese NLP and transfer learning; (4) classical versus Transformer text classification under limited labels; and (5) reliable evaluation of small, imbalanced text datasets.

## Research databases

- ACM Digital Library
- IEEE Xplore
- ACL Anthology
- Scopus or Web of Science through the University of Leeds
- Google Scholar for forward/backward citation discovery only
- ISMIR proceedings archive

## Search strings

Run each concept family separately and in combinations. Record database, date, exact query and result count.

```text
(lyrics OR "song lyrics") AND (emotion classification OR emotion recognition)
(Cantonese OR Yue Chinese) AND (NLP OR "natural language processing")
(Cantonese OR Yue Chinese) AND (emotion OR sentiment) AND text
(lyrics OR poetry) AND (BERT OR Transformer) AND emotion
(lyrics OR poetry) AND (SVM OR "logistic regression" OR TF-IDF) AND emotion
(low-resource OR "small dataset") AND emotion classification AND Transformer
(emotion annotation) AND (inter-annotator agreement OR Cohen's kappa)
```

## Inclusion criteria

- Peer-reviewed papers, peer-reviewed workshop papers, dataset papers or authoritative model/dataset documentation.
- Direct relevance to at least one review purpose.
- Sufficient methodological detail to assess data, labels, models and evaluation.
- English or Chinese-language source that can be interpreted reliably.
- Earlier foundational work retained when it defines a taxonomy, metric or benchmark.

## Exclusion criteria

- Generic sentiment papers with no transferable methodological relevance.
- Papers reporting only an unsupported accuracy number.
- Non-authoritative reposts when the original paper or repository is available.
- Studies whose data provenance or label definition cannot be established.
- Duplicate publications; retain the most complete version and record related versions.

## Screening and extraction

For every retained paper record:

```text
citation, year, venue, task, language, domain, dataset_size,
label_taxonomy, annotation_method, models, split_strategy,
primary_metric, strongest_result, limitations, relevance_to_RQ,
quality_notes, source_url
```

Screen title/abstract first, then full text. Record an exclusion reason at the full-text stage. Use backward references and forward citations for the most relevant seed papers.

## Critical synthesis themes

The dissertation will synthesise evidence rather than describe papers sequentially:

1. Competing definitions of emotion in lyrics.
2. Domain differences between lyrics, social media and ordinary prose.
3. Data scarcity, weak labels and annotation subjectivity.
4. Character, word and subword representations for Cantonese.
5. Transfer from Standard Chinese and multilingual pretraining.
6. Leakage, artist effects, class imbalance and unreliable accuracy reporting.
7. The performance-computation-interpretability trade-off.

## Reproducibility record

The performed searches are recorded in `docs/literature_search_log.csv`, and retained sources are extracted in `docs/literature_matrix.csv`. The current log covers ACL/ISMIR and official dataset/model discovery. The student must still run the same concept families through Scopus or Web of Science, ACM Digital Library and IEEE Xplore using University access, record result counts and screen any additional candidates. Search dates matter because model and dataset availability changes over time.
