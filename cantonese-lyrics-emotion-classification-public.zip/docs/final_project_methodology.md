# Final implemented project methodology

## Study status and claim boundary

This is the authoritative description of the implemented project. The study is
a controlled comparison of Classical ML and Transformer models on a disclosed
AI-assisted **silver-labelled** Cantonese-lyrics corpus. It does not contain an
independently annotated human-gold test set. Consequently, results estimate
agreement with the frozen silver labels under unseen-artist evaluation; they do
not establish definitive human-level or real-world emotion accuracy.

## Task and data

The task assigns one dominant label—`joy`, `sadness`, `anger` or `calmness`—to
each short lyric section. The frozen dataset contains 6,000 unique sections
from 3,246 parent songs and 257 artists. It combines 680 original reviewed
development sections with 5,320 expansion sections obtained from the Feitsui
GitHub source pinned at commit
`6189bcc2db41a59531714f938a4a96aac631d068`.

The final distribution is sadness 4,340 (72.3%), joy 736 (12.3%), calmness 703
(11.7%) and anger 221 (3.7%). This severe natural and labelling imbalance is a
central experimental condition rather than a property hidden by accuracy.
Lyric text and derived text remain local and research-only because the source
repository's software licence does not establish permission to redistribute
the underlying lyrics.

## Silver-label construction

Expansion labels combine three independently executed evidence streams:

1. direct Qwen label generation followed by a structured adjudication prompt;
2. Qwen next-token option scoring over four A–D label permutations with
   content-free calibration; and
3. multilingual NLI scoring over three hypothesis templates.

Of the 5,320 expansion sections, 1,847 have unanimous three-method consensus,
3,055 have a two-of-three majority, and 418 have a three-way conflict resolved
by the documented generation/adjudication tie-break. The 680 original labels
are retained as a separate provenance tier. Every row records source, model
revision, scoring evidence, consensus method and whether human review remains
needed. `formal_evaluation_eligible` is false throughout.

This design reduces dependence on a single prompt, but it cannot establish
construct validity against Cantonese-speaking annotators. Agreement between AI
methods may also be correlated because the systems share pretrained language
representations. The terms *gold label*, *ground truth* and *human validated*
must therefore not be used for this dataset.

## Leakage-controlled evaluation

Three partition seeds (13, 42 and 97) each generate five outer folds. Train,
validation and test roles are exclusive by artist, and every section from a
parent song stays in one role. Automated audits found no artist or parent-song
overlap. All model families and imbalance strategies use the same materialised
partitions.

Classical resampling and weighting are fitted only within the training split.
Transformer class weights and balanced sampling also use training labels only.
Validation and test distributions are never resampled. Classical family
selection is performed independently within each outer partition using only
validation Macro-F1; exact ties use a stable lexical key. Transformer baselines
were fixed before aggregation, while imbalance variants are reported as a
separate analysis.

## Models and representations

Classical experiments compare word TF–IDF, character TF–IDF and their union
with Multinomial Naive Bayes, logistic regression and Linear SVM variants. The
primary Classical comparator is the configuration selected by validation in
each partition. The Transformer baselines are
`FacebookAI/xlm-roberta-base` and `hfl/chinese-macbert-base`, with exact model
revisions stored in run metadata.

Transformer inputs use deterministic head–tail truncation at 128 tokens. The
complete audit found only 2 of 6,000 XLM-R inputs and 4 of 6,000 MacBERT inputs
over this limit, so truncation is unlikely to drive aggregate differences.

## Outcomes and inference

Macro-F1 is primary because each class contributes equally. Balanced accuracy,
accuracy and per-class precision, recall and F1 are secondary. Results are
reported as mean and standard deviation over all 15 partitions. Pooled
uncertainty uses 2,000 song-cluster bootstrap resamples. Paired model tests use
5,000 song-cluster permutations and Holm correction within the declared model
comparison family. Partition-level Wilcoxon tests are explicitly descriptive
because repeated cross-validation folds are dependent.

The primary comparison uses untreated MacBERT and XLM-R baselines and the
validation-selected Classical model. Imbalance treatments answer a separate
question. This prevents the best outer-test imbalance result from silently
replacing the primary configuration.

## Training-corpus expansion comparison

The 680-versus-expanded comparison fixes the validation and test cases within
each pair and changes the available training corpus. Expansion artists that
overlap held-out artists are removed from training. This controls test-case
difficulty, but it is not a pure causal learning-curve experiment: corpus
source, section-length distribution and label-generation route change with
training size. The defensible conclusion is therefore the effect of *adding
this expanded silver-labelled corpus*, not the universal effect of multiplying
sample size.

## Label-evidence robustness analysis

Saved primary predictions are re-scored on five predetermined evidence subsets:

- all silver labels;
- all labels except the 418 three-way tie-breaks;
- original reviewed plus unanimous expansion labels;
- unanimous expansion labels only; and
- the 680 original reviewed labels only.

No model is retrained and no subset is promoted to primary after viewing its
score. Chinese MacBERT ranks first in all five subsets. This strengthens the
internal conclusion that its model-family ordering is not produced solely by
the weakest tie-break labels. It does not supply missing human validity.
Performance on unanimous labels is especially high but that tier is 85.4%
sadness and may reward agreement with related AI labellers; it must be treated
as sensitivity evidence, not as a cleaner human benchmark.

## Reproducibility and limitations

The pipeline stores dataset hashes, model revisions, seeds, split manifests,
per-run metadata and case-level predictions without lyric text. Automated tests
cover construction, split invariants, model metrics, result collection,
statistical analysis and the silver-label robustness module. The final audit
checks 6,000 unique cases, 15 leakage-free partitions, all 60 Transformer jobs,
all fixed-test jobs and equal prediction coverage.

Remaining threats are: no independent human test set; severe class imbalance;
possible shared-model bias in label consensus; source and label-route
confounding in the expansion comparison; no external corpus; limited
Cantonese-speaker-led qualitative analysis; and restrictions on lyric-text
redistribution. These are limitations of the evidence, not software failures.
