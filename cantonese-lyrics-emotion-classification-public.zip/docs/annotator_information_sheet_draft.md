# Annotator information sheet — draft for ethics/supervisor review

Do not distribute until the bracketed details and the University's ethics requirements have been confirmed.

## Study title

*Emotion Classification in Cantonese Lyrics: a Comparative Study of Transformer-based and Classical ML Models*

## Invitation and purpose

You are invited to help create reliable emotion labels for a University of Leeds MSc Computer Science research project. The study compares computational methods for identifying emotions expressed in Cantonese song lyrics. Please read this information before deciding whether to participate.

## Why you have been invited

The task requires someone who can understand written Cantonese lyrics, including colloquial expressions and occasional code-switching. You should be at least 18 years old and sufficiently comfortable reading the supplied lyrics to make independent judgements.

## What participation involves

You will receive a workbook containing 680 anonymised lyric sections extracted from 105 source songs and shown in random order. Exact repeated sections within the same song are shown once. For each section, you will:

1. choose the dominant expressed emotion from joy, sadness, anger or calmness;
2. give a confidence score from 1 to 5;
3. mark any applicable ambiguity flags;
4. write a brief rationale where requested.

You should judge the narrative voice in the supplied section only, not its melody, performer, your personal emotional response or an assumed whole-song meaning. You will not see another annotator's decisions or computer-generated suggestions during the independent task.

Expected time: [insert estimate after a timed mini-pilot]. You may take breaks and complete the workbook over [insert permitted period].

## Voluntary participation and withdrawal

Participation is voluntary. You may stop without giving a reason. You may request withdrawal of your responses until [insert withdrawal deadline/event], after which anonymised responses may have been combined into aggregate analysis and may no longer be identifiable for removal.

To withdraw, contact [student name and University email] and quote your participant ID. Do not include unnecessary personal information in the annotation workbook.

## Possible risks or discomfort

Some sections may discuss loss, relationship conflict, loneliness, death or other emotionally difficult topics. You may skip a section, mark it `uncertain`, take a break or withdraw. The task is not a test of you, and disagreement between annotators is expected in subjective emotion judgements.

## Benefits and compensation

There is no guaranteed personal benefit. Your judgements may help evaluate language technology for an under-resourced language variety. Compensation: [state amount and approved payment route, or state that participation is unpaid].

## Data and confidentiality

The study records annotations under a pseudonymous annotator ID. Names, contact details and consent records will be stored separately from annotation responses with access limited to the student and, where necessary, the supervisor. The dissertation will report aggregate agreement and may discuss anonymised examples; it will not name or rank annotators.

Annotation responses will be stored on [approved University/local encrypted storage], retained for [approved retention period] and then deleted or anonymised according to the approved plan. Identifiable participant data will not be submitted to external generative-AI services.

The lyric texts are licensed creative works supplied only for this research task. Please do not redistribute the workbook or lyrics.

## Use of automated tools

Machine-generated candidate labels may be created separately for research purposes, but they are hidden during independent annotation. Human responses will form the basis of gold-label evaluation after documented adjudication. The project may use permitted generative AI for code and drafting support, but personal participant information will not be uploaded.

## Approval and contacts

Ethics/approval reference: [insert reference or documented School determination]

Student researcher: [name, University email]

Supervisor: [name, University email]

For a concern or complaint not resolved by the research team: [insert School/University contact required by the approved template]
