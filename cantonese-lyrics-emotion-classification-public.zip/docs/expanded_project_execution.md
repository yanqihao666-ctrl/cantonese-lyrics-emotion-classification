# Expanded 6,000-section project execution

This document records the reproducible project workflow. Raw and derived lyric
text remains under git-ignored `data/research_only/` and must not be published.

## Frozen dataset

- Dataset: `data/research_only/expanded_6000_consensus_final.csv`
- Rows: 6,000
- Songs: 3,246
- Artists: 257
- Labels: sadness 4,340; joy 736; calmness 703; anger 221
- Original cohort: 680 reviewed V2 development labels
- Expansion cohort: 5,320 three-method AI-consensus development labels
- Formal human-gold eligibility: false

## Leakage control

The main evaluation uses 15 artist-exclusive partitions: three random seeds
(13, 42 and 97) times five outer folds. Every model and imbalance treatment
uses the same partition files. Sampling or weighting operates only inside the
training split.

The data-size comparison uses another paired 15-partition design. Within each
pair, validation and test cases are exactly identical; only training data is
expanded. Expansion rows whose artist occurs in validation or test are
excluded from training.

## Model families

- Classical: majority, Multinomial Naive Bayes, Logistic Regression and Linear
  SVM with character, word and combined TF-IDF.
- Transformers: XLM-R base and Chinese MacBERT base.
- Imbalance: untreated baseline, class-weighted loss, random oversampling,
  SMOTE, moderate undersampling and Transformer weighted sampling.

Macro-F1 is primary. Accuracy, balanced accuracy and per-class precision,
recall and F1 are retained. Every run records input hashes, fixed model
revisions, seeds, split identity and environment metadata.

## Completed results (2026-08-12)

- Validation-selected Classical ML: Macro-F1 0.352 (SD 0.015).
- XLM-R baseline: Macro-F1 0.368 (SD 0.029).
- Chinese MacBERT baseline: Macro-F1 0.558 (SD 0.022).
- Chinese MacBERT balanced loss: Macro-F1 0.579 (SD 0.013).
- Fixed-test MacBERT data-size comparison: 0.254 on the small training cohort
  versus 0.457 with expanded training, mean paired delta +0.203.
- Final integrity audit: passed.

These remain development results on AI-assisted labels, not independent
human-gold evaluation results.
