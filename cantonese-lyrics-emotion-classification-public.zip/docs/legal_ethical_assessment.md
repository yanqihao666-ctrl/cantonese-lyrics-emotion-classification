# Legal, ethical and professional assessment

## Copyright and lawful access

Song lyrics are normally copyright works. The main pilot corpus is taken from the Cantopop Corpus Project, whose repository provides an explicit CC BY 4.0 licence. Source URLs, file hashes and attribution are retained.

UK Intellectual Property Office guidance explains that the text-and-data-mining exception permits computational copies for non-commercial research only when the researcher already has lawful access to the works. It does not justify bypassing technological protection measures or obtaining material from an unlawful source. The project therefore does not assume that any publicly visible lyric page may automatically be scraped and redistributed.

Official guidance:

- https://www.gov.uk/guidance/exceptions-to-copyright
- https://www.gov.uk/government/uploads/system/uploads/attachment_data/file/359251/Exceptions_to_copyright_-_Research.pdf

Controls:

- Raw lyric text is stored locally and excluded from Git.
- Public artifacts contain identifiers, attribution, hashes, labels and derived statistics rather than full lyrics.
- Additional corpora are admitted only after documenting source, access date, licence or lawful-access basis, song identity and redistribution limits.
- ToneCraft data is currently excluded because the repository has no explicit data licence and does not preserve sufficient song-level provenance for this evaluation.
- MIR-MLPop remains an unlabelled pipeline resource and is not represented as an emotion benchmark.

This document records a research risk assessment, not legal advice. Any expansion using non-CC lyrics should be discussed with the supervisor or University library/copyright support.

## Human annotation and research ethics

The proposed gold-label procedure involves judgements from Cantonese-competent annotators. Before recruitment, the student should confirm whether School ethics review is required, particularly if annotators are recruited, compensated or asked for demographic information.

Minimum controls:

- provide an information sheet describing purpose, task, time, data use and withdrawal procedure;
- collect informed consent where required;
- avoid collecting unnecessary names, contact details or sensitive demographic data;
- store annotator identity separately from annotation responses;
- use pseudonymous annotator IDs in analysis;
- do not expose annotators to another annotator's or AI's labels before independent annotation;
- document compensation and recruitment route;
- report disagreement without criticising individual annotators.

Draft information and consent materials are provided in `annotator_information_sheet_draft.md` and `annotator_consent_form_draft.md`. They contain placeholders and must not be distributed until the supervisor or School confirms the ethics route and required template.

## Data protection

The lyric corpus contains public creative works rather than participant personal data. Annotation recruitment may create personal data such as contact details or consent records. Those records should be stored separately with restricted access and retained only for the approved period. No personally identifiable participant information should be sent to external AI services.

## Bias and representativeness

The source corpus contains 105 songs and yields 680 within-song-deduplicated sections. It is balanced by release year but not by artist, topic, gender, era beyond 2000-2020 or natural emotion distribution. Multiple sections from one song are correlated evidence, not independent expansion. These facts limit generalisation.

Controls:

- artist-exclusive splits that also bind all sections from a parent song;
- class and artist distributions reported for every split;
- learning curves and uncertainty estimates;
- explicit distinction between corpus distribution and balanced sampling;
- qualitative review of code-switching, colloquial characters, metaphor and emotional transitions;
- no claim that the sample represents all Cantonese music or all Cantonese-speaking communities.

## AI annotation risks

Zero-shot or generative models may reproduce Standard-Chinese, English-language or cultural biases. An earlier full-song three-template audit produced a severe class concentration; because the final unit is now the section, those candidate labels are retained only as historical pipeline evidence and are not transferred to the section dataset. The episode reinforces that model output cannot be accepted as ground truth.

Controls:

- three-prompt sensitivity analysis;
- retain complete per-class scores and top-two margins;
- audit class collapse before using candidates for sampling;
- prioritise low-agreement and low-margin items for human review;
- evaluate final systems only against independently human-validated gold labels;
- report candidate/gold agreement when gold labels become available.

## Professional reproducibility

- Fixed random seeds and configuration-driven experiments.
- Automated validation for missing data, duplicate leakage and artist overlap.
- Out-of-fold predictions retained for paired comparisons.
- Exact package versions and device metadata saved.
- Negative or non-significant results reported honestly.
- Raw copyrighted text excluded from public repository artifacts.
