from pathlib import Path

from src.run_experiment_matrix import Partition
from src.run_imbalance_matrix import build_jobs, transformer_run_name


def test_imbalance_jobs_are_collision_safe():
    partition = Partition(
        path="partition.csv",
        partition_seed=13,
        outer_fold=1,
        input_sha256="abc",
        rows=680,
    )
    jobs = build_jobs([partition], Path("results"), ["classical", "transformer"])
    assert len(jobs) == 4
    assert len({job["job_id"] for job in jobs}) == 4
    assert len({job["expected"] for job in jobs}) == 4
    assert any("--imbalance-strategies" in job["command"] for job in jobs)


def test_transformer_strategy_names_do_not_collide():
    names = {
        transformer_run_name("hfl/chinese-macbert-base", 42, 3, strategy)
        for strategy in ["baseline", "balanced_loss", "balanced_sampler"]
    }
    assert len(names) == 3
