import pandas as pd

from src.import_feitsui_github import (
    balanced_select,
    build_artist_lookup,
    chinese_lyric_lines,
    segment_lines,
)


def test_extracts_chinese_lines_and_drops_jyutping_and_metadata():
    raw = "作词：某人\n我仍然相信明天会更好\nngo5 jing4 jin4\n与你一起走过这段长路\nnei5 tung4 ngo5"
    assert chinese_lyric_lines(raw) == [
        "我仍然相信明天会更好",
        "与你一起走过这段长路",
    ]


def test_segments_are_two_or_three_lines_and_deduplicated():
    lines = [
        "我仍然相信明天会更好",
        "与你一起走过这段长路",
        "即使风雨从来没有停下",
        "我们仍然向前看见阳光",
        "我仍然相信明天会更好",
        "与你一起走过这段长路",
    ]
    result = segment_lines(lines, min_chars=10, max_chars=80)
    assert result == [
        "我仍然相信明天会更好\n与你一起走过这段长路",
        "即使风雨从来没有停下\n我们仍然向前看见阳光",
    ]


def test_artist_lookup_does_not_misuse_mandarin_counterpart_metadata():
    singers = [
        {
            "name": "甲",
            "songs": [
                {"url": "u1", "mandarin": ""},
                {"url": "u2", "mandarin": "国语歌名"},
            ],
        },
        {"name": "乙", "songs": [{"url": "u1", "mandarin": ""}]},
    ]
    assert build_artist_lookup(singers) == {"u1": ["乙", "甲"], "u2": ["甲"]}


def test_balanced_selection_respects_caps():
    rows = []
    for artist in ["甲", "乙", "丙"]:
        for song in range(3):
            for section in range(4):
                rows.append(
                    {
                        "artist": artist,
                        "corpus_song_id": f"{artist}-{song}",
                        "case_id": f"{artist}-{song}-{section}",
                    }
                )
    result = balanced_select(
        pd.DataFrame(rows),
        12,
        max_sections_per_artist=4,
        max_sections_per_song=2,
    )
    assert len(result) == 12
    assert result["artist"].value_counts().max() == 4
    assert result["corpus_song_id"].value_counts().max() <= 2
