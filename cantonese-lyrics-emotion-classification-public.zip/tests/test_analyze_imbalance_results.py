from src.analyze_imbalance_results import holm_adjust


def test_holm_adjust_is_monotone_in_rank_and_bounded():
    raw = [0.01, 0.04, 0.20]
    adjusted = holm_adjust(raw)
    assert adjusted == [0.03, 0.08, 0.20]
    assert all(raw_value <= adjusted_value <= 1 for raw_value, adjusted_value in zip(raw, adjusted))
