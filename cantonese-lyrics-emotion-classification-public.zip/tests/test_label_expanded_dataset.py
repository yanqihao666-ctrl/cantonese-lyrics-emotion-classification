import pandas as pd

from src.label_expanded_dataset import parse_code, parse_label, resolve_decisions


def test_parse_code_honours_pass_specific_mapping():
    assert parse_code("2", {1: "joy", 2: "sadness"}) == "sadness"
    assert parse_code("answer: 4", {4: "calmness"}) == "calmness"
    assert parse_code("unknown", {1: "joy"}) is None


def test_parse_label_uses_words_not_position_codes():
    assert parse_label("sadness") == "sadness"
    assert parse_label("Label: ANGER") == "anger"
    assert parse_label("2") is None


def test_resolution_uses_agreement_then_adjudication():
    result = resolve_decisions(
        pd.Series(["joy", "sadness"]),
        pd.Series(["joy", "anger"]),
        pd.Series([None, "anger"]),
    )
    assert result["expanded_ai_label"].tolist() == ["joy", "anger"]
    assert result["ai_prompt_agreement"].tolist() == [True, False]
    assert result["needs_human_review"].tolist() == [False, True]
