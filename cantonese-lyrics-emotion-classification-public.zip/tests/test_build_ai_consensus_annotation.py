import pandas as pd

from src.build_ai_consensus_annotation import consensus_decision


def _row(nli: str, direct: str, strict: str) -> pd.Series:
    return pd.Series(
        {
            "nli_candidate_label": nli,
            "direct_label": direct,
            "adjudicated_label": strict,
            "direct_confidence": 4,
            "adjudicated_confidence": 4,
            "direct_mixed": False,
            "adjudicated_mixed": False,
            "direct_uncertain": False,
            "adjudicated_uncertain": False,
            "direct_non_cantonese": False,
            "direct_insufficient_text": False,
            "direct_rationale": "直接判断理由",
            "adjudicated_rationale": "严格判断理由",
            "nli_joy_score": 0.1,
            "nli_sadness_score": 0.6,
            "nli_anger_score": 0.1,
            "nli_calmness_score": 0.2,
        }
    )


def test_unanimous_consensus_can_receive_high_confidence():
    decision = consensus_decision(_row("sadness", "sadness", "sadness"))
    assert decision["ai_label"] == "sadness"
    assert decision["consensus_method"] == "three_way_unanimous"
    assert decision["ai_confidence_1_to_5"] == 5
    assert not decision["needs_human_review"]


def test_two_of_three_majority_remains_reviewable():
    decision = consensus_decision(_row("calmness", "joy", "joy"))
    assert decision["ai_label"] == "joy"
    assert decision["consensus_method"] == "two_of_three_majority"
    assert decision["needs_human_review"]


def test_three_way_disagreement_uses_low_confidence_nli_tiebreak():
    decision = consensus_decision(_row("calmness", "joy", "sadness"))
    assert decision["ai_label"] == "calmness"
    assert decision["consensus_method"] == "no_majority_nli_tiebreak"
    assert decision["ai_confidence_1_to_5"] == 2
    assert decision["uncertain"]
