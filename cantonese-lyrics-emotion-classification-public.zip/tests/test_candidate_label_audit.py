import pandas as pd

from src.candidate_label_audit import audit_candidate_labels


def test_candidate_audit_flags_class_collapse_and_orders_review():
    frame = pd.DataFrame(
        {
            "corpus_song_id": ["a", "b", "c", "d"],
            "candidate_label": ["joy", "joy", "joy", "sadness"],
            "prompt_agreement": [1.0, 2 / 3, 1.0, 2 / 3],
            "mean_top_two_margin": [0.3, 0.05, 0.2, 0.1],
            "candidate_method": ["zero-shot@test"] * 4,
            "candidate_model_revision": ["test"] * 4,
            "label_quality": ["candidate"] * 4,
        }
    )
    summary, queue = audit_candidate_labels(frame)
    assert summary["candidate_class_collapse_warning"]
    assert queue.iloc[0]["corpus_song_id"] == "b"
    assert summary["high_confidence_candidate_items"] == 2
    assert summary["candidate_model_revisions"] == ["test"]
