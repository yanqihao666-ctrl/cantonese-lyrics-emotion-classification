import sys
from pathlib import Path

import pandas as pd

from src.run_experiment_matrix import execute_jobs
from src.run_learning_curve_matrix import (
    build_learning_jobs,
    discover_base_partitions,
    materialise_learning_matrix,
    validate_nested_subsets,
)


def _base_partition(path: Path) -> None:
    rows = []
    cues = {
        "joy": "happybright",
        "sadness": "sadlonely",
        "anger": "angryfight",
        "calmness": "calmquiet",
    }
    for label, cue in cues.items():
        for index in range(4):
            rows.append(
                {
                    "corpus_song_id": f"train_{label}_{index}",
                    "lyrics": f"{cue}{cue}{index}",
                    "emotion": label,
                    "artist": f"train_{label}_{index}",
                    "split": "train",
                    "partition_seed": 42,
                    "outer_fold": 1,
                }
            )
        for split in ["validation", "test"]:
            rows.append(
                {
                    "corpus_song_id": f"{split}_{label}",
                    "lyrics": f"{cue}{cue}{split}",
                    "emotion": label,
                    "artist": f"{split}_{label}",
                    "split": split,
                    "partition_seed": 42,
                    "outer_fold": 1,
                }
            )
    pd.DataFrame(rows).to_csv(path, index=False)


def test_learning_curve_jobs_are_nested_unique_and_fraction_addressed(
    tmp_path: Path,
):
    partitions_dir = tmp_path / "partitions"
    partitions_dir.mkdir()
    _base_partition(partitions_dir / "seed_42_fold_1.csv")
    base_paths = discover_base_partitions(partitions_dir)
    subsets = materialise_learning_matrix(
        base_paths,
        subsets_root=tmp_path / "subsets",
        fractions=[0.5, 1.0],
    )
    validate_nested_subsets(subsets)
    jobs = build_learning_jobs(
        subsets,
        output_root=tmp_path / "results",
        python_executable=Path("python.exe"),
        families=["classical", "transformer"],
    )

    assert len(subsets) == 2
    assert len(jobs) == 6
    assert len({job.job_id for job in jobs}) == 6
    assert len({job.expected_metadata for job in jobs}) == 6
    assert any("__fraction_050" in job.expected_metadata for job in jobs)
    transformer_jobs = [job for job in jobs if job.family == "transformer"]
    assert transformer_jobs
    assert all("--discard-model-artifacts" in job.command for job in transformer_jobs)


def test_classical_learning_jobs_execute_and_resume_by_fraction(tmp_path: Path):
    partitions_dir = tmp_path / "partitions"
    partitions_dir.mkdir()
    _base_partition(partitions_dir / "seed_42_fold_1.csv")
    subsets = materialise_learning_matrix(
        discover_base_partitions(partitions_dir),
        subsets_root=tmp_path / "subsets",
        fractions=[0.5, 1.0],
    )
    jobs = build_learning_jobs(
        subsets,
        output_root=tmp_path / "results",
        python_executable=Path(sys.executable),
        families=["classical"],
    )
    manifest = tmp_path / "results" / "learning_curve_matrix.json"

    execute_jobs(jobs, subsets, manifest, workdir=Path.cwd())
    assert {job.status for job in jobs} == {"completed"}
    execute_jobs(jobs, subsets, manifest, workdir=Path.cwd())
    assert {job.status for job in jobs} == {"skipped_existing"}
