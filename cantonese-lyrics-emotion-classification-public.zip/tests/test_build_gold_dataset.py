import pandas as pd
import pytest

from src.annotation_agreement import ADJUDICATION_DECISION_COLUMNS
from src.build_gold_dataset import build_gold_dataset


LABELS = ["joy", "sadness", "anger", "calmness"]


def _inputs():
    source = pd.DataFrame(
        {
            "corpus_song_id": ["C1", "C2", "C3", "C4", "C5"],
            "lyrics": ["one", "two", "three", "four", "five"],
            "artist": ["A1", "A2", "A3", "A4", "A5"],
        }
    )
    key = pd.DataFrame(
        {
            "annotation_id": ["N1", "N2", "N3", "N4", "N5"],
            "corpus_song_id": ["C1", "C2", "C3", "C4", "C5"],
        }
    )
    rows_a = []
    rows_b = []
    labels_a = ["joy", "sadness", "anger", "calmness", "joy"]
    labels_b = ["joy", "anger", "anger", "calmness", "joy"]
    for index, annotation_id in enumerate(key["annotation_id"]):
        common = {
            "annotation_id": annotation_id,
            "confidence_1_to_5": 5,
            "mixed": False,
            "uncertain": False,
            "non_cantonese": False,
            "insufficient_text": False,
            "translation_required": False,
            "rationale": "",
        }
        rows_a.append({**common, "human_label": labels_a[index]})
        rows_b.append({**common, "human_label": labels_b[index]})
    return source, key, pd.DataFrame(rows_a), pd.DataFrame(rows_b)


def _decision(
    annotation_id: str = "N2",
    label: str = "sadness",
    include: bool = True,
    exclusion_reason: str = "",
) -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "annotation_id": annotation_id,
                "adjudicated_label": label,
                "include_in_gold": include,
                "exclusion_reason": exclusion_reason,
                "adjudicator_rationale": "reviewed both rationales",
                "adjudicator_code": "ADJ-01",
                "adjudication_date": "2026-07-28",
            }
        ],
        columns=["annotation_id", *ADJUDICATION_DECISION_COLUMNS],
    )


def test_gold_builder_preserves_consensus_and_uses_adjudication():
    source, key, a, b = _inputs()
    csv_like_decision = _decision()
    csv_like_decision["exclusion_reason"] = float("nan")
    gold, audit, metadata = build_gold_dataset(
        source,
        key,
        a,
        b,
        csv_like_decision,
    )
    assert len(gold) == 5
    assert gold.set_index("corpus_song_id").loc["C2", "emotion"] == "sadness"
    assert (
        audit.set_index("corpus_song_id").loc["C2", "label_source"]
        == "adjudication"
    )
    assert (
        audit.set_index("corpus_song_id").loc["C1", "label_source"]
        == "independent_agreement"
    )
    assert metadata["required_adjudication_items"] == 1
    assert metadata["raw_annotations_overwritten"] is False
    assert metadata["all_four_labels_present"] is True
    assert metadata["artist_groups_per_class"] == {
        "joy": 2,
        "sadness": 1,
        "anger": 1,
        "calmness": 1,
    }
    assert metadata["supports_five_fold_artist_grouping"] is False


def test_gold_builder_rejects_missing_required_adjudication():
    source, key, a, b = _inputs()
    empty = pd.DataFrame(columns=["annotation_id", *ADJUDICATION_DECISION_COLUMNS])
    with pytest.raises(ValueError, match="missing=\\['N2'\\]"):
        build_gold_dataset(source, key, a, b, empty)


def test_exclusion_requires_reason_and_removes_item():
    source, key, a, b = _inputs()
    invalid = _decision(include=False)
    with pytest.raises(ValueError, match="exclusion_reason"):
        build_gold_dataset(source, key, a, b, invalid)

    valid = _decision(include=False, exclusion_reason="insufficient_text")
    gold, audit, metadata = build_gold_dataset(source, key, a, b, valid)
    assert "C2" not in set(gold["corpus_song_id"])
    assert not bool(
        audit.set_index("corpus_song_id").loc["C2", "include_in_gold"]
    )
    assert metadata["excluded_items"] == 1


def test_gold_builder_uses_case_id_for_section_level_items():
    source = pd.DataFrame(
        {
            "case_id": ["C1-SEC01", "C1-SEC02"],
            "corpus_song_id": ["C1", "C1"],
            "lyrics": ["first section", "second section"],
            "artist": ["Artist", "Artist"],
        }
    )
    key = pd.DataFrame(
        {
            "annotation_id": ["ANN-1", "ANN-2"],
            "case_id": ["C1-SEC01", "C1-SEC02"],
            "corpus_song_id": ["C1", "C1"],
        }
    )
    annotations = pd.DataFrame(
        {
            "annotation_id": ["ANN-1", "ANN-2"],
            "human_label": ["joy", "sadness"],
            "confidence_1_to_5": [5, 4],
            "mixed": [False, False],
            "uncertain": [False, False],
            "non_cantonese": [False, False],
            "insufficient_text": [False, False],
            "translation_required": [False, False],
            "rationale": ["clear", "clear"],
        }
    )
    empty_adjudication = pd.DataFrame(
        columns=["annotation_id", *ADJUDICATION_DECISION_COLUMNS]
    )

    gold, audit, metadata = build_gold_dataset(
        source,
        key,
        annotations,
        annotations.copy(),
        empty_adjudication,
    )

    assert set(gold["case_id"]) == {"C1-SEC01", "C1-SEC02"}
    assert gold["corpus_song_id"].nunique() == 1
    assert "case_id" in audit.columns
    assert metadata["item_id_column"] == "case_id"
    assert metadata["distinct_songs"] == 1
