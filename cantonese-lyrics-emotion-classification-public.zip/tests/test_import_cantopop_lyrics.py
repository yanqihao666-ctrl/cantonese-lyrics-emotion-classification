from pathlib import Path

import pandas as pd

from src.import_cantopop_lyrics import (
    apply_known_metadata_corrections,
    parse_humdrum,
    parse_humdrum_sections,
)


def test_parse_humdrum_extracts_text_and_metadata(tmp_path: Path) -> None:
    source = tmp_path / "C9999.krn"
    source.write_text(
        "!!!OTL: 測試歌\n"
        "!!!OTA: C9999\n"
        "!!!MGN: 測試歌手\n"
        "**kern\t**text\t**jyutping\n"
        "4c\t粵\tjyut6\n"
        "4d\t語\tjyu5\n"
        "4r\t.\t.\n"
        "*-\t*-\t*-\n",
        encoding="utf-8",
    )
    row = parse_humdrum(source)
    assert row["corpus_song_id"] == "C9999"
    assert row["lyrics"] == "粵語"
    assert row["jyutping"] == "jyut6 jyu5"
    assert row["character_count"] == 2


def test_parse_humdrum_sections_uses_structure_and_deduplicates_repeats(
    tmp_path: Path,
) -> None:
    source = tmp_path / "C9998.krn"
    source.write_text(
        "!!!OTA: C9998\n"
        "!!!OTL: Test title\n"
        "!!!MGN: Test artist\n"
        "**kern\t**text\t**jyutping\n"
        "*>verse\t*>verse\t*>verse\n"
        "4c\t甲\tgaap3\n"
        "4d\t乙\tjyut6\n"
        "*>chorus\t*>chorus\t*>chorus\n"
        "4e\t丙\tbing2\n"
        "4f\t丁\tding1\n"
        "*>chorus\t*>chorus\t*>chorus\n"
        "4e\t丙\tbing2\n"
        "4f\t丁\tding1\n"
        "*-\t*-\t*-\n",
        encoding="utf-8",
    )

    sections = parse_humdrum_sections(source)

    assert [row["case_id"] for row in sections] == [
        "C9998-SEC01",
        "C9998-SEC02",
    ]
    assert [row["section_type"] for row in sections] == ["verse", "chorus"]
    assert sections[1]["occurrence_count"] == 2
    assert sections[1]["source_section_indices"] == "2;3"
    assert sections[1]["lyrics"] == "丙丁"
    assert all(row["corpus_song_id"] == "C9998" for row in sections)


def test_known_metadata_corrections_retain_upstream_values_and_sources() -> None:
    frame = pd.DataFrame(
        [
            {"corpus_song_id": "C0802", "artist": "囍帖街", "release_year": 2008},
            {"corpus_song_id": "C1704", "artist": "天敵", "release_year": 2014},
            {"corpus_song_id": "C9999", "artist": "原歌手", "release_year": 2020},
        ]
    )
    corrected = apply_known_metadata_corrections(frame).set_index("corpus_song_id")
    assert corrected.loc["C0802", "artist"] == "謝安琪"
    assert corrected.loc["C1704", "artist"] == "衛蘭"
    assert corrected.loc["C1704", "release_year"] == 2017
    assert corrected.loc["C1704", "source_artist_original"] == "天敵"
    assert bool(corrected.loc["C1704", "metadata_correction_applied"])
    assert not bool(corrected.loc["C9999", "metadata_correction_applied"])
