from pathlib import Path

import pandas as pd
import pytest

from src.collect_predictions import collect_prediction_files, discover_prediction_files


def _prediction_rows(model_key: str, predicted: list[str]) -> pd.DataFrame:
    return pd.DataFrame(
        {
            "corpus_song_id": ["C1", "C2", "C3", "C4"],
            "partition_seed": [13] * 4,
            "outer_fold": [1] * 4,
            "model_key": [model_key] * 4,
            "evaluation_split": ["test"] * 4,
            "true_label": ["joy", "sadness", "anger", "calmness"],
            "predicted_label": predicted,
        }
    )


def test_collect_prediction_files_combines_models(tmp_path: Path):
    classical = tmp_path / "classical" / "predictions.csv"
    transformer = tmp_path / "transformer" / "test_predictions.csv"
    classical.parent.mkdir()
    transformer.parent.mkdir()
    _prediction_rows(
        "classical::character_tfidf::linear_svm",
        ["joy", "sadness", "anger", "calmness"],
    ).to_csv(classical, index=False)
    _prediction_rows(
        "transformer::FacebookAI/xlm-roberta-base",
        ["sadness", "anger", "calmness", "joy"],
    ).to_csv(transformer, index=False)

    paths = discover_prediction_files([tmp_path])
    combined, metadata = collect_prediction_files(paths)

    assert len(paths) == 2
    assert len(combined) == 8
    assert metadata["files"] == 2
    assert len(metadata["models"]) == 2


def test_collect_prediction_files_rejects_duplicate_model_cases(tmp_path: Path):
    first = tmp_path / "one.csv"
    second = tmp_path / "two.csv"
    rows = _prediction_rows(
        "classical::character_tfidf::linear_svm",
        ["joy", "sadness", "anger", "calmness"],
    )
    rows.to_csv(first, index=False)
    rows.to_csv(second, index=False)

    with pytest.raises(ValueError, match="one prediction"):
        collect_prediction_files([first, second])


def test_collect_prediction_files_can_filter_a_partition(tmp_path: Path):
    path = tmp_path / "predictions.csv"
    first = _prediction_rows("model", ["joy", "sadness", "anger", "calmness"])
    second = first.assign(partition_seed=42, outer_fold=2)
    pd.concat([first, second], ignore_index=True).to_csv(path, index=False)

    combined, metadata = collect_prediction_files(
        [path],
        partition_seeds=[42],
        outer_folds=[2],
    )

    assert len(combined) == 4
    assert combined["partition_seed"].eq(42).all()
    assert combined["outer_fold"].eq(2).all()
    assert metadata["partition_seed_filter"] == [42]
    assert metadata["outer_fold_filter"] == [2]
