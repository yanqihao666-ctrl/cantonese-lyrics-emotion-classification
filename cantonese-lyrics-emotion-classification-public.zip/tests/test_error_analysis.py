import pandas as pd

from src.error_analysis import build_review_queue, pairwise_case_patterns


def _predictions() -> pd.DataFrame:
    truth = ["joy", "sadness", "anger", "calmness"]
    rows = []
    for seed, fold in [(13, 1), (42, 1)]:
        for model, values in [
            ("model_a", truth),
            ("model_b", ["sadness", "sadness", "anger", "joy"]),
        ]:
            for index, (true_label, prediction) in enumerate(zip(truth, values), start=1):
                rows.append(
                    {
                        "corpus_song_id": f"C{index}",
                        "partition_seed": seed,
                        "outer_fold": fold,
                        "model_key": model,
                        "true_label": true_label,
                        "predicted_label": prediction,
                    }
                )
    return pd.DataFrame(rows)


def test_pairwise_patterns_and_review_queue_are_traceable():
    predictions = _predictions()
    patterns = pairwise_case_patterns(predictions)
    metadata = pd.DataFrame(
        {
            "corpus_song_id": ["C1", "C2", "C3", "C4"],
            "title": ["one", "two", "three", "four"],
            "lyrics": ["secret"] * 4,
            "lyrics_original": ["original secret"] * 4,
            "orthography_for_modelling": ["normalised secret"] * 4,
            "jyutping_variant_count": [1] * 4,
        }
    )
    queue = build_review_queue(predictions, metadata=metadata)

    assert set(patterns["case_pattern"]) == {"both_correct", "model_a_only"}
    assert queue.iloc[0]["corpus_song_id"] in {"C1", "C4"}
    assert "title" in queue.columns
    assert "lyrics" not in queue.columns
    assert "lyrics_original" not in queue.columns
    assert "orthography_for_modelling" not in queue.columns
    assert "jyutping_variant_count" not in queue.columns
    assert queue["prediction_rows"].eq(4).all()
