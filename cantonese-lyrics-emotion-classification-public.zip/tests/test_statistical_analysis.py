import pandas as pd
import pytest

from src.statistical_analysis import (
    add_holm_adjustment,
    cluster_bootstrap_macro_f1,
    paired_cluster_permutation_test,
    partition_metrics,
    select_analysis_models,
    summarise_partition_metrics,
    validate_predictions,
)


LABELS = ["joy", "sadness", "anger", "calmness"]


def prediction_frame() -> pd.DataFrame:
    rows = []
    for partition_seed in [13, 42]:
        for outer_fold in [1, 2]:
            for label_index, label in enumerate(LABELS):
                for item in range(4):
                    song_id = f"{label}_{outer_fold}_{item}"
                    rows.append(
                        {
                            "corpus_song_id": song_id,
                            "partition_seed": partition_seed,
                            "outer_fold": outer_fold,
                            "model_key": "perfect",
                            "true_label": label,
                            "predicted_label": label,
                        }
                    )
                    rows.append(
                        {
                            "corpus_song_id": song_id,
                            "partition_seed": partition_seed,
                            "outer_fold": outer_fold,
                            "model_key": "shifted",
                            "true_label": label,
                            "predicted_label": LABELS[(label_index + 1) % len(LABELS)],
                        }
                    )
    return pd.DataFrame(rows)


def test_partition_metrics_and_summary_keep_models_separate():
    metrics = partition_metrics(prediction_frame())
    summary = summarise_partition_metrics(metrics)
    perfect = summary.loc[summary["model_key"] == "perfect"].iloc[0]
    shifted = summary.loc[summary["model_key"] == "shifted"].iloc[0]
    assert perfect["macro_f1_mean"] == 1.0
    assert shifted["macro_f1_mean"] == 0.0
    assert perfect["evaluated_partitions"] == 4


def test_cluster_bootstrap_and_paired_permutation_detect_large_difference():
    frame = prediction_frame()
    interval = cluster_bootstrap_macro_f1(
        frame,
        "perfect",
        n_bootstrap=100,
        seed=7,
    )
    comparison = paired_cluster_permutation_test(
        frame,
        "perfect",
        "shifted",
        permutations=200,
        seed=7,
    )
    assert interval["macro_f1_pooled"] == 1.0
    assert interval["ci_95_lower"] == 1.0
    assert comparison["macro_f1_difference_a_minus_b"] == 1.0
    assert comparison["p_value_two_sided"] < 0.05


def test_prediction_validation_rejects_duplicate_model_cases():
    frame = prediction_frame()
    duplicated = pd.concat([frame, frame.iloc[[0]]], ignore_index=True)
    with pytest.raises(ValueError, match="one prediction"):
        validate_predictions(duplicated)


def test_holm_adjustment_is_monotonic_and_controls_familywise_threshold():
    comparisons = pd.DataFrame(
        {
            "comparison": ["a", "b", "c"],
            "p_value_two_sided": [0.01, 0.03, 0.20],
        }
    )
    adjusted = add_holm_adjustment(comparisons)
    assert adjusted.loc[0, "p_value_holm"] == pytest.approx(0.03)
    assert adjusted.loc[1, "p_value_holm"] == pytest.approx(0.06)
    assert adjusted.loc[2, "p_value_holm"] == pytest.approx(0.20)
    assert adjusted["reject_0_05_holm"].tolist() == [True, False, False]


def test_predeclared_model_scope_excludes_other_models_before_analysis():
    frame = prediction_frame()
    selected = select_analysis_models(frame, ["perfect"])
    assert selected["model_key"].unique().tolist() == ["perfect"]
    with pytest.raises(ValueError, match="absent"):
        select_analysis_models(frame, ["not_a_model"])


def test_section_predictions_are_resampled_by_parent_song():
    rows = []
    labels = ["joy", "sadness", "anger", "calmness"]
    for index, label in enumerate(labels):
        song_id = "song_a" if index < 2 else "song_b"
        case_id = f"{song_id}-SEC{index + 1:02d}"
        for model_key, predicted in [
            ("perfect", label),
            ("shifted", labels[(index + 1) % len(labels)]),
        ]:
            rows.append(
                {
                    "case_id": case_id,
                    "corpus_song_id": song_id,
                    "partition_seed": 13,
                    "outer_fold": 1,
                    "model_key": model_key,
                    "true_label": label,
                    "predicted_label": predicted,
                }
            )
    frame = pd.DataFrame(rows)
    interval = cluster_bootstrap_macro_f1(
        frame,
        "perfect",
        n_bootstrap=100,
        seed=7,
    )
    comparison = paired_cluster_permutation_test(
        frame,
        "perfect",
        "shifted",
        permutations=100,
        seed=7,
    )
    assert interval["bootstrap_clusters"] == 2
    assert comparison["song_clusters"] == 2
    assert comparison["evaluation_rows"] == 4
