import pandas as pd
import pytest

from src.build_silver_development_dataset import (
    build_silver_development_dataset,
)


def _source() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "case_id": ["C1-SEC01", "C1-SEC02", "C2-SEC01"],
            "corpus_song_id": ["C1", "C1", "C2"],
            "artist": ["A", "A", "B"],
            "lyrics": ["one", "two", "three"],
        }
    )


def _candidates() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "case_id": ["C1-SEC01", "C1-SEC02", "C2-SEC01"],
            "candidate_label": ["joy", None, "sadness"],
            "prompt_agreement": [1.0, 1 / 3, 2 / 3],
            "mean_top_two_margin": [0.5, 0.01, 0.2],
            "candidate_method": ["fixture"] * 3,
            "candidate_model_revision": ["fixture-revision"] * 3,
            "candidate_tied": [False, True, False],
        }
    )


def test_builder_marks_candidates_development_only_and_excludes_ties():
    development, metadata = build_silver_development_dataset(
        _source(),
        _candidates(),
    )
    assert development["case_id"].tolist() == ["C1-SEC01", "C2-SEC01"]
    assert development["emotion"].tolist() == ["joy", "sadness"]
    assert development["label_quality"].eq("silver").all()
    assert not development["formal_evaluation_eligible"].any()
    assert metadata["included_development_rows"] == 2
    assert metadata["excluded_rows"] == 1
    assert metadata["formal_evaluation_eligible"] is False


def test_builder_rejects_mismatched_case_coverage():
    with pytest.raises(ValueError, match="identical case_id"):
        build_silver_development_dataset(
            _source(),
            _candidates().iloc[:-1],
        )
