from pathlib import Path
import shutil

import pytest

from src.audit_dissertation_consistency import (
    DissertationConsistencyError,
    audit_dissertation_consistency,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]
FIXTURE_FILES = [
    "README.md",
    "configs/base.yaml",
    "configs/dissertation_contract.yaml",
    "docs/research_plan.md",
    "docs/introduction_draft.md",
    "docs/literature_synthesis.md",
    "docs/methodology_draft.md",
    "docs/implementation_chapter_draft.md",
    "docs/results_chapter_template.md",
]


def _copy_fixture(tmp_path: Path) -> Path:
    root = tmp_path / "project"
    for relative_path in FIXTURE_FILES:
        source = PROJECT_ROOT / relative_path
        target = root / relative_path
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(source, target)
    return root


def test_project_dissertation_consistency_passes():
    report = audit_dissertation_consistency(PROJECT_ROOT)

    assert report["status"] == "pass"
    assert report["check_count"] == 8
    assert report["research_question_count"] == 4
    assert report["chapter_count"] == 5
    assert report["labels"] == ["joy", "sadness", "anger", "calmness"]
    assert report["split_seeds"] == [13, 42, 97]
    assert report["expected_partitions"] == 15
    assert report["placeholder_counts"]["docs/results_chapter_template.md"] == 57
    assert report["task_unit"] == "structural_lyric_section"
    assert report["case_id_column"] == "case_id"
    assert report["parent_song_column"] == "corpus_song_id"


def test_research_question_drift_is_rejected(tmp_path):
    root = _copy_fixture(tmp_path)
    readme = root / "README.md"
    text = readme.read_text(encoding="utf-8")
    text = text.replace(
        "What class-level and label-evidence patterns characterise model errors?",
        "What linguistic features cause model errors?",
    )
    readme.write_text(text, encoding="utf-8")

    with pytest.raises(
        DissertationConsistencyError, match="Research-question drift"
    ):
        audit_dissertation_consistency(root)


def test_result_placeholder_outside_template_is_rejected(tmp_path):
    root = _copy_fixture(tmp_path)
    introduction = root / "docs" / "introduction_draft.md"
    introduction.write_text(
        introduction.read_text(encoding="utf-8") + "\n[artifact]\n",
        encoding="utf-8",
    )

    with pytest.raises(
        DissertationConsistencyError,
        match="placeholder found outside approved template",
    ):
        audit_dissertation_consistency(root)


def test_model_revision_drift_is_rejected(tmp_path):
    root = _copy_fixture(tmp_path)
    config = root / "configs" / "base.yaml"
    text = config.read_text(encoding="utf-8")
    text = text.replace(
        "e73636d4f797dec63c3081bb6ed5c7b0bb3f2089",
        "0000000000000000000000000000000000000000",
    )
    config.write_text(text, encoding="utf-8")

    with pytest.raises(
        DissertationConsistencyError, match="Model revision drift"
    ):
        audit_dissertation_consistency(root)
