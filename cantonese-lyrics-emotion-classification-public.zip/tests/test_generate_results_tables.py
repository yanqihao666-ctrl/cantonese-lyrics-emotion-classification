from pathlib import Path

import pandas as pd
import pytest

from src.generate_results_tables import (
    build_results_tables,
    file_sha256,
    is_development_analysis,
    render_markdown,
    validate_identical_model_coverage,
    validate_prediction_hash,
)
from src.statistical_analysis import (
    add_holm_adjustment,
    cluster_bootstrap_macro_f1,
    paired_cluster_permutation_test,
    partition_metrics,
    summarise_partition_metrics,
)


LABELS = ["joy", "sadness", "anger", "calmness"]


def _predictions() -> pd.DataFrame:
    rows = []
    for outer_fold in [1, 2]:
        for label_index, label in enumerate(LABELS):
            song_id = f"{label}_{outer_fold}"
            for model_key, predicted in [
                ("classical::validation_selected", label),
                (
                    "transformer::example",
                    LABELS[(label_index + 1) % len(LABELS)],
                ),
            ]:
                rows.append(
                    {
                        "corpus_song_id": song_id,
                        "partition_seed": 13,
                        "outer_fold": outer_fold,
                        "model_key": model_key,
                        "true_label": label,
                        "predicted_label": predicted,
                    }
                )
    return pd.DataFrame(rows)


def _analysis_artifacts(predictions: pd.DataFrame):
    metrics = partition_metrics(predictions)
    summary = summarise_partition_metrics(metrics)
    intervals = pd.DataFrame(
        [
            cluster_bootstrap_macro_f1(
                predictions,
                model_key,
                n_bootstrap=100,
                seed=7,
            )
            for model_key in sorted(predictions["model_key"].unique())
        ]
    )
    models = sorted(predictions["model_key"].unique())
    comparisons = add_holm_adjustment(
        pd.DataFrame(
            [
                paired_cluster_permutation_test(
                    predictions,
                    models[0],
                    models[1],
                    permutations=100,
                    seed=7,
                )
            ]
        )
    )
    return summary, intervals, comparisons


def test_results_tables_are_recalculated_and_rendered_from_artifacts():
    predictions = validate_identical_model_coverage(
        _predictions(),
        expected_partitions=2,
    )
    summary, intervals, comparisons = _analysis_artifacts(predictions)

    overall, per_class, pairwise = build_results_tables(
        predictions,
        summary,
        intervals,
        comparisons,
    )
    markdown = render_markdown(overall, per_class, pairwise)

    assert len(overall) == 2
    assert len(per_class) == 8
    assert len(pairwise) == 1
    assert "classical::validation_selected" in markdown
    assert "AI-estimated" in markdown


def test_ai_preannotation_analysis_is_never_marked_formal():
    assert is_development_analysis("ai_preannotation_shared_fold_development_only")
    assert is_development_analysis("development_silver_rq2")
    assert not is_development_analysis("primary_family_comparison")


def test_results_table_validation_rejects_unequal_model_cases():
    predictions = _predictions()
    incomplete = predictions.drop(
        predictions.loc[predictions["model_key"] == "transformer::example"].index[0]
    )
    with pytest.raises(ValueError, match="identical cases"):
        validate_identical_model_coverage(incomplete, expected_partitions=2)


def test_results_table_validation_rejects_stale_prediction_hash(tmp_path: Path):
    prediction_path = tmp_path / "predictions.csv"
    prediction_path.write_text("first", encoding="utf-8")
    metadata = {"prediction_sha256": file_sha256(prediction_path)}
    assert validate_prediction_hash(prediction_path, metadata) == metadata[
        "prediction_sha256"
    ]

    prediction_path.write_text("changed", encoding="utf-8")
    with pytest.raises(ValueError, match="prediction-file hash"):
        validate_prediction_hash(prediction_path, metadata)
