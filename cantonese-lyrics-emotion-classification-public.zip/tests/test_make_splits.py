import pandas as pd

from src.make_splits import assign_grouped_splits


def test_grouped_splits_have_no_group_overlap_and_cover_classes():
    rows = []
    for group_index in range(24):
        for label in ["joy", "sadness", "anger", "calmness"]:
            rows.append({"artist": f"artist_{group_index}", "emotion": label})
    frame = pd.DataFrame(rows)
    assigned, diagnostics = assign_grouped_splits(frame, seed=7, trials=100)
    check = frame.assign(split=assigned).groupby("artist")["split"].nunique()
    assert check.max() == 1
    assert set(assigned) == {"train", "validation", "test"}
    assert all(all(count > 0 for count in counts.values()) for counts in diagnostics["class_counts"].values())


def test_split_assignment_is_reproducible():
    frame = pd.DataFrame(
        {
            "artist": [f"a{i // 4}" for i in range(48)],
            "emotion": (["joy", "sadness", "anger", "calmness"] * 12),
        }
    )
    first, _ = assign_grouped_splits(frame, seed=42, trials=50)
    second, _ = assign_grouped_splits(frame, seed=42, trials=50)
    assert first.tolist() == second.tolist()
