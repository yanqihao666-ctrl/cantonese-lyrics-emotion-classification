import pandas as pd

from src.plot_data_audit import create_audit_figures


def test_audit_figures_are_created(tmp_path):
    frame = pd.DataFrame(
        {
            "release_year": [2000, 2000, 2001, 2001],
            "artist": ["A", "B", "A", "C"],
            "observed_character_count": [200, 250, 300, 350],
        }
    )
    outputs = create_audit_figures(frame, tmp_path)
    assert len(outputs) == 3
    assert all(path.exists() and path.stat().st_size > 0 for path in outputs)
