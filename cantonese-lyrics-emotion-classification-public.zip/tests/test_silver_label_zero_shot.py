from src.silver_label_zero_shot import consensus_from_rankings


def test_zero_shot_consensus_and_agreement():
    rankings = [
        {"joy": 0.7, "sadness": 0.1, "anger": 0.1, "calmness": 0.1},
        {"joy": 0.6, "sadness": 0.2, "anger": 0.1, "calmness": 0.1},
        {"sadness": 0.4, "joy": 0.3, "anger": 0.2, "calmness": 0.1},
    ]
    label, agreement, tied = consensus_from_rankings(rankings)
    assert label == "joy"
    assert agreement == 2 / 3
    assert not tied


def test_zero_shot_consensus_handles_no_outputs():
    assert consensus_from_rankings([]) == (None, 0.0, False)
