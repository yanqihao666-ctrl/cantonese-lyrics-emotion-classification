import pandas as pd
import pytest

from src.annotation_agreement import calculate_agreement
from src.tabular_io import read_annotation_file


def annotations(labels):
    return pd.DataFrame(
        {
            "annotation_id": ["A", "B", "C", "D"],
            "human_label": labels,
            "confidence_1_to_5": [5, 4, 3, 5],
            "mixed": [False] * 4,
            "uncertain": [False] * 4,
            "non_cantonese": [False] * 4,
            "insufficient_text": [False] * 4,
            "translation_required": [False] * 4,
            "rationale": [""] * 4,
        }
    )


def test_perfect_agreement():
    frame = annotations(["joy", "sadness", "anger", "calmness"])
    summary, confusion, adjudication = calculate_agreement(frame, frame)
    assert summary["raw_label_agreement"] == 1.0
    assert summary["cohen_kappa"] == 1.0
    assert confusion.values.trace() == 4
    assert adjudication.empty


def test_disagreement_requires_adjudication():
    a = annotations(["joy", "sadness", "anger", "calmness"])
    b = annotations(["sadness", "sadness", "anger", "calmness"])
    summary, _, adjudication = calculate_agreement(a, b)
    assert summary["adjudication_items"] == 1
    assert adjudication.iloc[0]["annotation_id"] == "A"


def test_blank_label_is_rejected():
    a = annotations(["joy", "sadness", "anger", ""])
    with pytest.raises(ValueError, match="invalid or blank"):
        calculate_agreement(a, a)


def test_low_confidence_agreement_still_requires_adjudication():
    a = annotations(["joy", "sadness", "anger", "calmness"])
    b = a.copy()
    a.loc[a["annotation_id"] == "B", "confidence_1_to_5"] = 2
    summary, _, adjudication = calculate_agreement(a, b)
    assert summary["low_confidence_items"] == 1
    assert adjudication["annotation_id"].tolist() == ["B"]
    assert adjudication.iloc[0]["adjudication_reasons"] == "low_confidence"


def test_fractional_confidence_is_rejected():
    frame = annotations(["joy", "sadness", "anger", "calmness"])
    frame["confidence_1_to_5"] = frame["confidence_1_to_5"].astype(float)
    frame.loc[0, "confidence_1_to_5"] = 2.5
    with pytest.raises(ValueError, match="integer"):
        calculate_agreement(frame, frame)


def test_completed_excel_annotation_sheet_is_read_directly(tmp_path):
    frame = annotations(["joy", "sadness", "anger", "calmness"])
    workbook = tmp_path / "annotator.xlsx"
    with pd.ExcelWriter(workbook, engine="openpyxl") as writer:
        pd.DataFrame({"instruction": ["synthetic"]}).to_excel(
            writer,
            sheet_name="Instructions",
            index=False,
        )
        frame.to_excel(writer, sheet_name="Annotations", index=False)

    loaded = read_annotation_file(workbook)
    summary, _, _ = calculate_agreement(loaded, loaded)
    assert summary["items"] == 4
    assert summary["raw_label_agreement"] == 1.0
