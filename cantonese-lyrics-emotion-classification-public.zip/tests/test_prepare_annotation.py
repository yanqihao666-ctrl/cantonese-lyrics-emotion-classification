import pandas as pd

from src.prepare_annotation import ANNOTATION_COLUMNS, prepare_annotation_files


def test_annotation_sheets_are_blinded_and_complete(tmp_path):
    frame = pd.DataFrame(
        {
            "case_id": ["C1-SEC01", "C1-SEC02"],
            "corpus_song_id": ["C1", "C2"],
            "title": ["Title 1", "Title 2"],
            "artist": ["Artist 1", "Artist 2"],
            "release_year": [2000, 2001],
            "lyrics": ["歌詞一", "歌詞二"],
            "jyutping": ["go1 ci4", "go1 ci4"],
        }
    )
    prepare_annotation_files(frame, tmp_path, annotators=2)
    sheet = pd.read_csv(tmp_path / "annotator_1_blind.csv")
    key = pd.read_csv(tmp_path / "researcher_key.csv")
    assert sheet.columns.tolist() == ANNOTATION_COLUMNS
    assert "title" not in sheet.columns and "artist" not in sheet.columns
    assert set(key["case_id"]) == {"C1-SEC01", "C1-SEC02"}
    assert set(key["corpus_song_id"]) == {"C1", "C2"}
    assert (tmp_path / "annotator_2_blind.csv").exists()
