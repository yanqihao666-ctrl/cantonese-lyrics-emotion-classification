import json
from pathlib import Path

import pandas as pd

from src.select_classical_configuration import (
    SELECTED_MODEL_KEY,
    discover_classical_runs,
    select_classical_runs,
)


def _write_run(run_dir: Path, validation_a: float, validation_b: float) -> None:
    run_dir.mkdir(parents=True)
    metric_rows = []
    for split, score_a, score_b in [
        ("validation", validation_a, validation_b),
        ("test", 0.10, 0.90),
    ]:
        for model_key, score in [
            ("classical::character_tfidf::linear_svm", score_a),
            ("classical::word_tfidf::logistic_regression", score_b),
        ]:
            _, feature_set, model = model_key.split("::")
            metric_rows.append(
                {
                    "model_key": model_key,
                    "feature_set": feature_set,
                    "model": model,
                    "evaluation_split": split,
                    "macro_f1": score,
                }
            )
    pd.DataFrame(metric_rows).to_csv(run_dir / "metrics.csv", index=False)

    prediction_rows = []
    for split in ["validation", "test"]:
        for model_key, prediction in [
            ("classical::character_tfidf::linear_svm", "sadness"),
            ("classical::word_tfidf::logistic_regression", "joy"),
        ]:
            prediction_rows.append(
                {
                    "corpus_song_id": f"{split}_song",
                    "partition_seed": 13,
                    "outer_fold": 1,
                    "model_key": model_key,
                    "evaluation_split": split,
                    "true_label": "joy",
                    "predicted_label": prediction,
                }
            )
    pd.DataFrame(prediction_rows).to_csv(run_dir / "predictions.csv", index=False)
    (run_dir / "run_metadata.json").write_text(
        json.dumps(
            {
                "partition_seed": 13,
                "outer_fold": 1,
                "input_sha256": "fixture",
                "shared_fixed_partition": True,
            }
        ),
        encoding="utf-8",
    )


def test_selection_uses_validation_not_better_test_score_and_audits_choice(
    tmp_path: Path,
):
    run_dir = tmp_path / "seed_13_fold_1"
    _write_run(run_dir, validation_a=0.80, validation_b=0.70)

    discovered = discover_classical_runs([tmp_path])
    predictions, audit, metadata = select_classical_runs(discovered)

    assert predictions["model_key"].unique().tolist() == [SELECTED_MODEL_KEY]
    assert predictions["source_model_key"].unique().tolist() == [
        "classical::character_tfidf::linear_svm"
    ]
    selected = audit.loc[audit["selected"]].iloc[0]
    assert selected["macro_f1"] == 0.80
    assert selected["test_macro_f1"] == 0.10
    assert metadata["test_metric_used_for_selection"] is False


def test_validation_tie_uses_predeclared_lexicographic_key(tmp_path: Path):
    run_dir = tmp_path / "seed_13_fold_1"
    _write_run(run_dir, validation_a=0.75, validation_b=0.75)

    predictions, audit, _ = select_classical_runs([run_dir])

    assert predictions["source_model_key"].unique().tolist() == [
        "classical::character_tfidf::linear_svm"
    ]
    assert audit.iloc[0]["validation_rank"] == 1
