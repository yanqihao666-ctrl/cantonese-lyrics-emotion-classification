import pandas as pd
import pytest

from src.make_cv_manifest import (
    create_repeated_group_manifest,
    materialise_partition,
    write_materialised_partitions,
)


LABELS = ["joy", "sadness", "anger", "calmness"]


def balanced_group_frame(groups: int = 24) -> pd.DataFrame:
    rows = []
    for group_index in range(groups):
        for label in LABELS:
            rows.append(
                {
                    "corpus_song_id": f"song_{group_index}_{label}",
                    "artist": f"artist_{group_index}",
                    "emotion": label,
                    "lyrics": f"{label} text {group_index}",
                }
            )
    return pd.DataFrame(rows)


def test_manifest_is_reproducible_complete_and_artist_exclusive():
    frame = balanced_group_frame()
    first, diagnostics = create_repeated_group_manifest(
        frame,
        seeds=[13, 42],
        outer_folds=4,
        inner_folds=4,
    )
    second, _ = create_repeated_group_manifest(
        frame,
        seeds=[13, 42],
        outer_folds=4,
        inner_folds=4,
    )
    pd.testing.assert_frame_equal(first, second)
    assert len(first) == len(frame) * 2 * 4
    assert len(diagnostics["partitions"]) == 8

    for (seed, outer_fold), assignment in first.groupby(["seed", "outer_fold"]):
        joined = frame.merge(assignment, on="corpus_song_id", validate="one_to_one")
        assert set(joined["split"]) == {"train", "validation", "test"}
        assert joined.groupby("artist")["split"].nunique().max() == 1
        for split_name in ["train", "validation", "test"]:
            assert set(joined.loc[joined["split"] == split_name, "emotion"]) == set(LABELS)

    for seed, assignments in first.groupby("seed"):
        test_counts = assignments.loc[assignments["split"] == "test", "corpus_song_id"].value_counts()
        assert test_counts.eq(1).all(), seed


def test_materialise_partition_attaches_exactly_one_role_per_observation():
    frame = balanced_group_frame()
    manifest, _ = create_repeated_group_manifest(
        frame,
        seeds=[7],
        outer_folds=4,
        inner_folds=4,
    )
    partition = materialise_partition(frame, manifest, seed=7, outer_fold=2)
    assert len(partition) == len(frame)
    assert partition["split"].notna().all()
    assert partition.groupby("artist")["split"].nunique().max() == 1
    assert partition["partition_seed"].eq(7).all()
    assert partition["outer_fold"].eq(2).all()


def test_manifest_rejects_too_few_groups_per_label():
    frame = pd.DataFrame(
        {
            "corpus_song_id": [f"s{i}" for i in range(8)],
            "artist": ["a", "a", "b", "b", "c", "c", "d", "d"],
            "emotion": ["joy", "sadness"] * 4,
        }
    )
    with pytest.raises(ValueError, match="distinct groups"):
        create_repeated_group_manifest(frame, outer_folds=5)


def test_section_manifest_keeps_parent_song_sections_together():
    source = balanced_group_frame(groups=16)
    sections = pd.concat(
        [
            source.assign(
                case_id=source["corpus_song_id"] + "-SEC01",
            ),
            source.assign(
                case_id=source["corpus_song_id"] + "-SEC02",
            ),
        ],
        ignore_index=True,
    )
    manifest, diagnostics = create_repeated_group_manifest(
        sections,
        id_column="case_id",
        seeds=[13],
        outer_folds=4,
        inner_folds=4,
    )
    for _, assignment in manifest.groupby(["seed", "outer_fold"]):
        joined = sections.merge(assignment, on="case_id", validate="one_to_one")
        assert joined.groupby("corpus_song_id")["split"].nunique().max() == 1
    assert all(
        not partition["parent_song_overlap"]
        for partition in diagnostics["partitions"]
    )


def test_materialised_partitions_are_written_for_every_seed_and_fold(tmp_path):
    frame = balanced_group_frame()
    manifest, _ = create_repeated_group_manifest(
        frame,
        seeds=[7, 9],
        outer_folds=4,
        inner_folds=4,
    )
    paths = write_materialised_partitions(frame, manifest, tmp_path)
    assert len(paths) == 8
    example = pd.read_csv(paths[0])
    assert len(example) == len(frame)
    assert set(example["split"]) == {"train", "validation", "test"}
    assert {"partition_seed", "outer_fold"}.issubset(example.columns)
