from src.import_mirmlpop import reconstruct_lyrics


def test_reconstruct_lyrics_uses_temporal_order() -> None:
    aligned = [[2.0, 2.5, "語", "jyu"], [1.0, 1.5, "粵", "jyut"]]
    assert reconstruct_lyrics(aligned) == "粵語"


def test_reconstruct_lyrics_ignores_incomplete_items() -> None:
    aligned = [[1.0, 1.5], [2.0, 2.5, "歌", "go"]]
    assert reconstruct_lyrics(aligned) == "歌"
