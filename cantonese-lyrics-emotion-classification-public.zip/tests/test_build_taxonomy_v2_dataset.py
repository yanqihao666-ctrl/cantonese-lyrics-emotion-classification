import pandas as pd
import pytest

from src.build_taxonomy_v2_dataset import build_v2


def source_frame():
    return pd.DataFrame(
        {
            "case_id": ["A", "B"],
            "emotion": ["sadness", "joy"],
            "lyrics": ["x", "y"],
        }
    )


def override_frame():
    return pd.DataFrame(
        {
            "case_id": ["A"],
            "expected_v1_label": ["sadness"],
            "v2_label": ["anger"],
            "confidence": [5],
            "evidence": ["cue"],
            "rationale": ["reason"],
            "reviewer": ["AI reviewer"],
            "review_stage": ["targeted"],
        }
    )


def test_build_v2_changes_only_audited_row():
    result = build_v2(source_frame(), override_frame()).set_index("case_id")
    assert result.at["A", "emotion"] == "anger"
    assert bool(result.at["A", "v2_label_changed"])
    assert result.at["A", "v2_previous_emotion"] == "sadness"
    assert result.at["B", "emotion"] == "joy"
    assert not bool(result.at["B", "v2_label_changed"])


def test_build_v2_rejects_stale_expected_label():
    overrides = override_frame()
    overrides.loc[0, "expected_v1_label"] = "joy"
    with pytest.raises(ValueError, match="audited expectations"):
        build_v2(source_frame(), overrides)


def test_build_v2_rejects_unknown_case_id():
    overrides = override_frame()
    overrides.loc[0, "case_id"] = "missing"
    with pytest.raises(ValueError, match="absent from source"):
        build_v2(source_frame(), overrides)
