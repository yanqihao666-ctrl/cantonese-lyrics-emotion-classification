import pandas as pd

from src.audit_expanded_dataset import audit


def _base() -> dict:
    return {
        "case_id": ["a", "b"],
        "corpus_song_id": ["s1", "s2"],
        "artist": ["x", "y"],
        "lyrics": ["開心歌詞", "傷心歌詞"],
        "emotion": ["joy", "sadness"],
        "source_cohort": ["expansion", "expansion"],
        "needs_human_review": [False, "true"],
        "normalized_lyric_sha256": ["h1", "h2"],
        "character_count": [4, 4],
    }


def test_audit_supports_final_three_method_consensus_schema() -> None:
    data = _base()
    data.update(
        {
            "generation_label": ["joy", "sadness"],
            "score_label": ["joy", "joy"],
            "nli_label": ["joy", "sadness"],
        }
    )
    report, per_class, _, confusion = audit(pd.DataFrame(data))

    assert report["method_vote_coverage_rows"] == 2
    assert report["method_full_agreement_rows"] == 1
    assert report["review_rows"] == 1
    assert report["vote_columns"] == [
        "generation_label",
        "score_label",
        "nli_label",
    ]
    assert per_class.loc[per_class.emotion.eq("joy"), "method_full_agreement_rate"].item() == 1
    assert confusion.loc["joy", "joy"] == 1


def test_audit_keeps_legacy_two_prompt_schema_compatible() -> None:
    data = _base()
    data.update(
        {
            "pass_a_label": ["joy", "sadness"],
            "pass_b_label": ["joy", "sadness"],
        }
    )
    report, _, _, _ = audit(pd.DataFrame(data))

    assert report["vote_columns"] == ["pass_a_label", "pass_b_label"]
    assert report["method_full_agreement_rows"] == 2
