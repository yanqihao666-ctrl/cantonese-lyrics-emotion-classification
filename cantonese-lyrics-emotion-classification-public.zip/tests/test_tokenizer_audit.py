import pandas as pd

from src.tokenizer_audit import audit_tokenizer


class FakeTokenizer:
    unk_token_id = 0
    model_max_length = 512

    def __call__(
        self,
        text,
        add_special_tokens=True,
        truncation=False,
        return_offsets_mapping=False,
    ):
        tokens = [101] + [0 if character == "冇" else ord(character) for character in text] + [102]
        result = {"input_ids": tokens}
        if return_offsets_mapping:
            result["offset_mapping"] = [(0, 0)] + [
                (index, index + 1) for index in range(len(text))
            ] + [(0, 0)]
        return result


def test_tokenizer_audit_reports_truncation_without_lyric_text():
    frame = pd.DataFrame(
        {
            "corpus_song_id": ["a", "b"],
            "lyrics": ["short", "longer冇"],
            "artist": ["artist_a", "artist_b"],
        }
    )
    rows, summary = audit_tokenizer(
        frame,
        FakeTokenizer(),
        model_name="fake",
        model_revision="revision",
        max_length=8,
    )
    assert "lyrics" not in rows.columns
    assert rows["would_truncate"].tolist() == [False, True]
    assert rows["unknown_token_count"].tolist() == [0, 1]
    assert rows["unknown_cjk_characters"].tolist() == [0, 1]
    assert summary["sections_over_limit"] == 1
    assert summary["fraction_over_limit"] == 0.5
