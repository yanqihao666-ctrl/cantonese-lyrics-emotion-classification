from pathlib import Path

import pandas as pd
import pytest

from src.learning_curve_analysis import (
    learning_curve_metrics,
    plot_learning_curves,
    validate_learning_predictions,
)


LABELS = ["joy", "sadness", "anger", "calmness"]


def _predictions() -> pd.DataFrame:
    rows = []
    for outer_fold in [1, 2]:
        for fraction, training_rows, training_groups in [
            (0.5, 8, 8),
            (1.0, 16, 16),
        ]:
            for label_index, label in enumerate(LABELS):
                song_id = f"{outer_fold}_{label}"
                for model_key, prediction in [
                    ("classical::character_tfidf::linear_svm", label),
                    (
                        "transformer::example",
                        label
                        if fraction == 1.0
                        else LABELS[(label_index + 1) % len(LABELS)],
                    ),
                ]:
                    rows.append(
                        {
                            "corpus_song_id": song_id,
                            "partition_seed": 42,
                            "outer_fold": outer_fold,
                            "model_key": model_key,
                            "true_label": label,
                            "predicted_label": prediction,
                            "learning_curve_fraction": fraction,
                            "training_rows": training_rows,
                            "training_groups": training_groups,
                        }
                    )
    return pd.DataFrame(rows)


def test_learning_curve_summary_records_achieved_sizes_and_plot(tmp_path: Path):
    predictions = validate_learning_predictions(_predictions())
    partition_metrics, summary = learning_curve_metrics(predictions)
    output = tmp_path / "curve.png"
    plot_learning_curves(partition_metrics, summary, output)

    transformer = summary.loc[
        summary["model_key"] == "transformer::example"
    ].set_index("learning_curve_fraction")
    assert transformer.loc[0.5, "macro_f1_mean"] == 0.0
    assert transformer.loc[1.0, "macro_f1_mean"] == 1.0
    assert transformer.loc[0.5, "training_rows_mean"] == 8
    assert len(partition_metrics) == 8
    assert output.exists() and output.stat().st_size > 0


def test_learning_curve_validation_rejects_changed_evaluation_cases():
    predictions = _predictions()
    index = predictions.loc[
        (predictions["model_key"] == "transformer::example")
        & (predictions["learning_curve_fraction"] == 0.5)
    ].index[0]
    incomplete = predictions.drop(index)
    with pytest.raises(ValueError, match="identical cases"):
        validate_learning_predictions(incomplete)
