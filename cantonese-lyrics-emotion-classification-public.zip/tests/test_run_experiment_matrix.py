import json
from pathlib import Path

import pandas as pd
import pytest

from src.run_experiment_matrix import (
    build_jobs,
    discover_partitions,
    execute_jobs,
    validate_partition_grid,
)


def _write_partition(path: Path, seed: int, fold: int) -> None:
    pd.DataFrame(
        {
            "partition_seed": [seed, seed, seed],
            "outer_fold": [fold, fold, fold],
            "split": ["train", "validation", "test"],
        }
    ).to_csv(path, index=False)


def test_experiment_matrix_has_unique_traceable_jobs(tmp_path: Path):
    partitions_dir = tmp_path / "partitions"
    partitions_dir.mkdir()
    _write_partition(partitions_dir / "one.csv", 13, 1)
    _write_partition(partitions_dir / "two.csv", 13, 2)
    partitions = discover_partitions(partitions_dir)
    jobs = build_jobs(
        partitions,
        output_root=tmp_path / "results",
        python_executable=Path("python.exe"),
        families=["classical", "transformer"],
    )

    assert len(partitions) == 2
    assert len(jobs) == 6
    assert len({job.job_id for job in jobs}) == 6
    assert len({job.expected_metadata for job in jobs}) == 6
    assert all(job.input_sha256 for job in jobs)


def test_formal_grid_validation_rejects_missing_partitions(tmp_path: Path):
    partition_path = tmp_path / "one.csv"
    _write_partition(partition_path, 13, 1)
    partitions = discover_partitions(tmp_path)
    with pytest.raises(ValueError, match="missing"):
        validate_partition_grid(partitions)


def test_resume_requires_matching_input_hash_and_partition_identity(tmp_path: Path):
    partition_path = tmp_path / "one.csv"
    _write_partition(partition_path, 13, 1)
    partitions = discover_partitions(tmp_path)
    jobs = build_jobs(
        partitions,
        output_root=tmp_path / "results",
        python_executable=Path("python.exe"),
        families=["classical"],
    )
    metadata_path = Path(jobs[0].expected_metadata)
    metadata_path.parent.mkdir(parents=True)
    matching_metadata = {
        "input_sha256": jobs[0].input_sha256,
        "partition_seed": 13,
        "outer_fold": 1,
    }
    metadata_path.write_text(json.dumps(matching_metadata), encoding="utf-8")
    manifest_path = tmp_path / "results" / "experiment_matrix.json"

    execute_jobs(jobs, partitions, manifest_path, workdir=tmp_path)
    assert jobs[0].status == "skipped_existing"

    matching_metadata["input_sha256"] = "stale"
    metadata_path.write_text(json.dumps(matching_metadata), encoding="utf-8")
    with pytest.raises(RuntimeError, match="stale evidence"):
        execute_jobs(jobs, partitions, manifest_path, workdir=tmp_path)
