import pytest

from src.gpu_environment_check import collect_environment


def test_environment_check_executes_matrix_operation():
    result = collect_environment(matrix_size=8)
    assert result["matrix_size"] == 8
    assert result["finite_output"] is True
    assert result["matrix_multiplication_seconds"] >= 0

    with pytest.raises(ValueError, match="at least two"):
        collect_environment(matrix_size=1)

