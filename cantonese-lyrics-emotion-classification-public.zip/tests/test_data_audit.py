import pandas as pd

from src.data_audit import audit_corpus, cjk_fraction, normalise_lyrics


def test_normalisation_and_cjk_fraction():
    assert normalise_lyrics("Ａ B，愛！") == "ab愛"
    assert cjk_fraction("愛你") == 1.0


def test_audit_detects_near_duplicate_group():
    frame = pd.DataFrame(
        {
            "corpus_song_id": ["a", "b", "c"],
            "title": ["A", "B", "C"],
            "artist": ["x", "x", "y"],
            "release_year": [2000, 2001, 2002],
            "lyrics": ["今天我真的很快樂一起唱歌", "今天我真的很快樂，一起唱歌！", "離開以後只剩孤單"],
            "jyutping": ["a b c", "a b c", "d e f"],
            "source_license": ["CC BY 4.0"] * 3,
        }
    )
    audited, pairs, summary = audit_corpus(frame, near_duplicate_threshold=0.8)
    assert len(pairs) == 1
    assert audited.loc[0, "duplicate_group"] == audited.loc[1, "duplicate_group"]
    assert summary["sections"] == 3
    assert summary["source_songs"] == 3
