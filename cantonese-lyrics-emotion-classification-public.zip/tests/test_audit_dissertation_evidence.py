from pathlib import Path

import pytest

from src.audit_dissertation_evidence import (
    DissertationEvidenceError,
    audit_dissertation_evidence,
)


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_project_dissertation_evidence_register_passes():
    restricted_dataset = PROJECT_ROOT / "data" / "licensed_text" / "cantopop_corpus_sections.csv"
    if not restricted_dataset.exists():
        pytest.skip("restricted lyric corpus is intentionally excluded from the submission repository")
    report = audit_dissertation_evidence(
        PROJECT_ROOT / "docs" / "dissertation_evidence_register.csv",
        PROJECT_ROOT,
    )

    assert report["status"] == "pass"
    assert report["register_entries"] == 16
    assert report["status_counts"] == {"blocked": 8, "verified": 8}
    assert report["chapters_covered"] == ["1", "2", "3", "4", "5", "6"]
    assert report["smoke_artifacts_authorised"] == 0


def test_missing_verified_artifact_is_rejected(tmp_path):
    register = tmp_path / "register.csv"
    register.write_text(
        "evidence_id,chapter,claim_or_output,status,authoritative_artifact,"
        "entry_condition,allowed_use\n"
        "E1,1,Claim,verified,results/missing.json,Condition,Use\n"
        "E2,2,Claim,blocked,results/future.json,Condition,Use\n"
        "E3,3,Claim,blocked,results/future.json,Condition,Use\n"
        "E4,4,Claim,blocked,results/future.json,Condition,Use\n"
        "E5,5,Claim,blocked,results/future.json,Condition,Use\n"
        "E6,6,Claim,blocked,results/future.json,Condition,Use\n",
        encoding="utf-8",
    )

    with pytest.raises(DissertationEvidenceError, match="missing artifact"):
        audit_dissertation_evidence(register, tmp_path)


def test_smoke_artifact_cannot_be_registered(tmp_path):
    register = tmp_path / "register.csv"
    register.write_text(
        "evidence_id,chapter,claim_or_output,status,authoritative_artifact,"
        "entry_condition,allowed_use\n"
        "E1,1,Claim,blocked,results/smoke/metrics.json,Condition,Use\n"
        "E2,2,Claim,blocked,results/future.json,Condition,Use\n"
        "E3,3,Claim,blocked,results/future.json,Condition,Use\n"
        "E4,4,Claim,blocked,results/future.json,Condition,Use\n"
        "E5,5,Claim,blocked,results/future.json,Condition,Use\n"
        "E6,6,Claim,blocked,results/future.json,Condition,Use\n",
        encoding="utf-8",
    )

    with pytest.raises(DissertationEvidenceError, match="prohibited smoke"):
        audit_dissertation_evidence(register, tmp_path)
