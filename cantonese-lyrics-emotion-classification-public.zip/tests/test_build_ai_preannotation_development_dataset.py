import pandas as pd
import pytest

from src.build_ai_preannotation_development_dataset import build_development_frame


def _frame() -> pd.DataFrame:
    return pd.DataFrame(
        {
            "case_id": ["A", "B", "C", "D"],
            "corpus_song_id": ["S1", "S2", "S3", "S4"],
            "lyrics": ["一", "二", "三", "四"],
            "artist": ["甲", "乙", "丙", "丁"],
            "ai_label": ["joy", "sadness", "anger", "calmness"],
            "formal_evaluation_eligible": [False] * 4,
        }
    )


def test_maps_disclosed_ai_label_to_development_target():
    result = build_development_frame(_frame())
    assert result["emotion"].tolist() == ["joy", "sadness", "anger", "calmness"]
    assert result["development_only"].all()
    assert not result["formal_evaluation_eligible"].any()


def test_rejects_ai_rows_marked_as_formal_gold():
    frame = _frame()
    frame.loc[0, "formal_evaluation_eligible"] = True
    with pytest.raises(ValueError, match="formal-evaluation"):
        build_development_frame(frame)
