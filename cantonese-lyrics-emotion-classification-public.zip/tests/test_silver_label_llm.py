from src.silver_label_llm import _consensus, _extract_json


def test_extract_json_accepts_valid_label() -> None:
    result = _extract_json('{"label":"Sadness","confidence":4,"mixed":false,"rationale_chinese":"失落"}')
    assert result is not None
    assert result["label"] == "sadness"


def test_consensus_requires_unique_winner() -> None:
    outputs = [{"label": "joy"}, {"label": "joy"}, {"label": "sadness"}]
    assert _consensus(outputs) == ("joy", 2 / 3, False)


def test_consensus_rejects_all_invalid() -> None:
    assert _consensus([None, None, None]) == (None, 0.0, False)
