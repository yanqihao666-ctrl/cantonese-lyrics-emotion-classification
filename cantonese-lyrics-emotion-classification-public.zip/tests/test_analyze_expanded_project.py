import pandas as pd
import pytest

from src.analyze_expanded_project import paired_imbalance_tests, select_classical_by_validation


def test_classical_selection_uses_validation_not_test_score() -> None:
    rows = []
    for seed in [13, 42, 97]:
        for fold in range(1, 6):
            for model, validation, test in [
                ("honest_choice", 0.8, 0.2),
                ("test_winner", 0.7, 0.9),
            ]:
                for split, score in [("validation", validation), ("test", test)]:
                    rows.append(
                        {
                            "seed": seed,
                            "outer_fold": fold,
                            "feature_set": "word_tfidf",
                            "model": model,
                            "imbalance_strategy": "baseline",
                            "evaluation_split": split,
                            "macro_f1": score,
                        }
                    )

    selected_test, audit = select_classical_by_validation(pd.DataFrame(rows))

    assert len(selected_test) == 15
    assert set(selected_test["model"]) == {"honest_choice"}
    assert set(selected_test["macro_f1"]) == {0.2}
    assert set(audit["validation_macro_f1"]) == {0.8}


def test_paired_imbalance_tests_keep_partition_pairing() -> None:
    rows = []
    for seed in [13, 42, 97]:
        for fold in range(1, 6):
            for strategy, score in [("baseline", 0.2), ("weighted", 0.4)]:
                rows.append(
                    {
                        "seed": seed,
                        "outer_fold": fold,
                        "evaluation_split": "test",
                        "strategy": strategy,
                        "macro_f1": score,
                    }
                )
    result = paired_imbalance_tests(
        pd.DataFrame(rows),
        family="transformer",
        strategy_column="strategy",
        planned_pairs=[("baseline", "weighted")],
    )

    assert result.loc[0, "mean_delta_right_minus_left"] == pytest.approx(0.2)
    assert result.loc[0, "right_wins"] == 15


def test_paired_imbalance_tests_can_restore_fold_from_source_path() -> None:
    rows = []
    for seed in [13, 42, 97]:
        for fold in range(1, 6):
            for strategy, score in [("baseline", 0.2), ("weighted", 0.4)]:
                rows.append(
                    {
                        "seed": seed,
                        "source_path": f"runs/seed_{seed}_fold_{fold}/metrics.csv",
                        "evaluation_split": "test",
                        "strategy": strategy,
                        "macro_f1": score,
                    }
                )
    result = paired_imbalance_tests(
        pd.DataFrame(rows),
        family="transformer",
        strategy_column="strategy",
        planned_pairs=[("baseline", "weighted")],
    )

    assert result.loc[0, "right_wins"] == 15
