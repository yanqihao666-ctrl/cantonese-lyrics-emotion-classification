import pytest

from src.transformer_memory_smoke import validate_dimensions


def test_memory_smoke_dimensions_must_be_positive():
    validate_dimensions(4, 512, 4)
    with pytest.raises(ValueError, match="positive"):
        validate_dimensions(0, 512, 4)

