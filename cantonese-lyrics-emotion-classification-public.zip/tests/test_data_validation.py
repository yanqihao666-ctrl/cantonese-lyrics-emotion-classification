import pandas as pd

from src.data_validation import validate_dataset


def valid_frame() -> pd.DataFrame:
    return pd.DataFrame(
        [
            {
                "song_id": "s1",
                "title": "Example A",
                "artist": "Artist A",
                "lyrics": "lyrics a",
                "source_url": "https://example.org/a",
                "candidate_label": "joy",
                "human_label": "joy",
                "confidence": 5,
                "duplicate_group": "d1",
                "split": "train",
                "label_quality": "gold",
            },
            {
                "song_id": "s2",
                "title": "Example B",
                "artist": "Artist B",
                "lyrics": "lyrics b",
                "source_url": "https://example.org/b",
                "candidate_label": "sadness",
                "human_label": None,
                "confidence": None,
                "duplicate_group": "d2",
                "split": "test",
                "label_quality": "silver",
            },
        ]
    )


def test_valid_dataset_has_no_errors() -> None:
    issues = validate_dataset(valid_frame())
    assert not [issue for issue in issues if issue.severity == "error"]


def test_duplicate_group_leakage_is_an_error() -> None:
    frame = valid_frame()
    frame.loc[1, "duplicate_group"] = "d1"
    issues = validate_dataset(frame)
    assert "duplicate_group_leakage" in {issue.code for issue in issues}


def test_gold_row_requires_human_label() -> None:
    frame = valid_frame()
    frame.loc[0, "human_label"] = None
    issues = validate_dataset(frame)
    assert "gold_without_human_label" in {issue.code for issue in issues}
