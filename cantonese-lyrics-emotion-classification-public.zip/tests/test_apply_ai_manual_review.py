import pandas as pd

from src.apply_ai_manual_review import REVIEWED_LABELS, apply_manual_ai_review


def _frame() -> pd.DataFrame:
    rows = []
    for index in range(680):
        disputed = index < len(REVIEWED_LABELS)
        rows.append(
            {
                "case_id": f"CASE-{index:03d}",
                "corpus_song_id": f"SONG-{index // 7:03d}",
                "title": "測試歌曲",
                "artist": "測試歌手",
                "lyrics": "測試歌詞",
                "ai_label": "calmness",
                "ai_confidence_1_to_5": 2,
                "consensus_method": (
                    "no_majority_nli_tiebreak"
                    if disputed
                    else "three_way_unanimous"
                ),
                "nli_vote": "calmness",
                "qwen_direct_vote": "joy",
                "qwen_strict_vote": "sadness",
                "needs_human_review": disputed,
                "formal_evaluation_eligible": False,
            }
        )
    return pd.DataFrame(rows)


def test_review_list_has_expected_scope_and_valid_labels():
    assert len(REVIEWED_LABELS) == 180
    assert set(REVIEWED_LABELS) <= {"joy", "sadness", "anger", "calmness"}


def test_only_no_majority_rows_are_overridden():
    reviewed, overrides = apply_manual_ai_review(_frame(), quality_control_overrides={})
    assert len(overrides) == 180
    assert reviewed["manual_ai_reviewed"].sum() == 180
    assert reviewed.loc[179, "ai_label"] == REVIEWED_LABELS[179]
    assert reviewed.loc[180, "ai_label"] == "calmness"
    assert reviewed.loc[179, "needs_human_review"]
    assert not reviewed.loc[179, "formal_evaluation_eligible"]
