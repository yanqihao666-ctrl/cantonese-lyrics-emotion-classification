import csv
from pathlib import Path

import pytest

from src.audit_references import ReferenceAuditError, audit_references


PROJECT_ROOT = Path(__file__).resolve().parents[1]


def test_project_reference_artifacts_are_consistent():
    report = audit_references(
        PROJECT_ROOT / "docs" / "literature_matrix.csv",
        PROJECT_ROOT / "docs" / "references.bib",
        [
            PROJECT_ROOT / "docs" / "introduction_draft.md",
            PROJECT_ROOT / "docs" / "literature_synthesis.md",
            PROJECT_ROOT / "docs" / "emotion_taxonomy_rationale.md",
            PROJECT_ROOT / "docs" / "methodology_draft.md",
        ],
        PROJECT_ROOT / "docs" / "literature_search_log.csv",
    )

    assert report["status"] == "pass"
    assert report["matrix_entries"] == 28
    assert report["bibliography_entries"] == 28
    assert report["citation_documents"] == 4
    assert report["cited_bibliography_entries"] >= 15
    assert report["search_log_rows"] >= 15
    assert report["search_logged_entries"] == 28
    assert report["preprint_entries"] == ["zhang_etal_2024"]


def test_missing_bibliography_key_is_rejected(tmp_path):
    matrix = tmp_path / "matrix.csv"
    with matrix.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(
            handle,
            fieldnames=[
                "citation_key",
                "title",
                "year",
                "venue",
                "quality_notes",
                "source_url",
            ],
        )
        writer.writeheader()
        writer.writerow(
            {
                "citation_key": "missing_2020",
                "title": "Missing",
                "year": "2020",
                "venue": "Journal",
                "quality_notes": "Peer-reviewed",
                "source_url": "https://example.org/missing",
            }
        )
    bibliography = tmp_path / "references.bib"
    bibliography.write_text(
        """
@article{other_2020,
  author = {Other, Alice},
  title = {Other},
  year = {2020},
  url = {https://example.org/other}
}
""",
        encoding="utf-8",
    )

    with pytest.raises(ReferenceAuditError, match="keys differ"):
        audit_references(matrix, bibliography)


def test_unregistered_in_text_citation_is_rejected(tmp_path):
    matrix = tmp_path / "matrix.csv"
    matrix.write_text(
        "citation_key,title,year,venue,quality_notes,source_url\n"
        "known_2020,Known,2020,Journal,Peer-reviewed,https://example.org/known\n",
        encoding="utf-8",
    )
    bibliography = tmp_path / "references.bib"
    bibliography.write_text(
        """
@article{known_2020,
  author = {Known, Alice},
  title = {Known},
  year = {2020},
  url = {https://example.org/known}
}
""",
        encoding="utf-8",
    )
    draft = tmp_path / "draft.md"
    draft.write_text("This claim follows Unknown (2021).", encoding="utf-8")

    with pytest.raises(ReferenceAuditError, match="without a matching"):
        audit_references(matrix, bibliography, [draft])
