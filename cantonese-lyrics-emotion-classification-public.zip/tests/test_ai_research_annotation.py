import json

import pytest

from src.ai_research_annotation import (
    LABELS,
    _confidence,
    _json_object,
    _label,
    _label_from_code,
    _mean_nli_scores,
)


def test_json_object_accepts_fenced_json_and_normalises_labels():
    parsed = _json_object('```json\n{"label":"悲傷","confidence":4}\n```')
    assert parsed is not None
    assert _label(parsed["label"]) == "sadness"
    assert _confidence(parsed["confidence"]) == 4


def test_confidence_is_clamped_to_documented_scale():
    assert _confidence(9) == 5
    assert _confidence(-2) == 1
    assert _confidence("invalid") == 2


def test_numeric_label_code_requires_one_of_four_declared_classes():
    assert _label_from_code(1) == "joy"
    assert _label_from_code("4") == "calmness"
    assert _label_from_code(0) is None
    assert _label_from_code(5) is None


def test_mean_nli_scores_preserve_all_four_labels():
    value = json.dumps(
        [
            {"joy": 0.4, "sadness": 0.3, "anger": 0.2, "calmness": 0.1},
            {"joy": 0.2, "sadness": 0.4, "anger": 0.1, "calmness": 0.3},
        ]
    )
    result = _mean_nli_scores(value)
    assert set(result) == set(LABELS)
    assert result["joy"] == pytest.approx(0.3)
    assert result["sadness"] == pytest.approx(0.35)
