import numpy as np
import pandas as pd
import pytest
from pathlib import Path
from transformers import EvalPrediction

from src.transformer_experiment import (
    checkpoint_directory,
    compute_balanced_class_weights,
    compute_balanced_sample_weights,
    compute_metrics,
    compute_warmup_steps,
    fixed_partition_identity,
    fraction_slug,
    head_tail_tokenise,
    learning_curve_identity,
    rename_validation_metrics,
    validate_fixed_splits,
)


def test_checkpoint_directory_uses_short_stable_run_token():
    output = Path("results") / "transformer"
    first = checkpoint_directory(output, "very-long-model-and-partition-identity" * 10)
    second = checkpoint_directory(output, "very-long-model-and-partition-identity" * 10)
    other = checkpoint_directory(output, "other-run")
    assert first == second
    assert first != other
    assert first.parent.name == "_trainer_checkpoints"
    assert len(first.name) == 16


def test_balanced_class_weights_follow_fixed_label_order():
    labels = pd.Series(
        ["joy", "joy", "sadness", "sadness", "sadness", "sadness", "anger", "calmness"]
    )
    assert compute_balanced_class_weights(labels) == [1.0, 0.5, 2.0, 2.0]


def test_balanced_class_weights_reject_missing_class():
    with pytest.raises(ValueError, match="missing classes"):
        compute_balanced_class_weights(pd.Series(["joy", "sadness", "anger"]))


def test_balanced_sample_weights_follow_input_order():
    labels = pd.Series(
        ["joy", "sadness", "sadness", "anger", "calmness"]
    )
    weights = compute_balanced_sample_weights(labels)
    assert weights[1] == weights[2]
    assert weights[0] == weights[3] == weights[4]
    assert weights[0] > weights[1]


class TinyTokenizer:
    model_input_names = ["input_ids", "attention_mask"]

    def __call__(
        self,
        text,
        add_special_tokens=True,
        truncation=False,
        return_special_tokens_mask=False,
    ):
        input_ids = [101] + list(range(len(text))) + [102]
        result = {
            "input_ids": input_ids,
            "attention_mask": [1] * len(input_ids),
        }
        if return_special_tokens_mask:
            result["special_tokens_mask"] = [1] + [0] * len(text) + [1]
        return result


def test_compute_metrics_perfect_predictions():
    truth = np.array([0, 1, 2, 3])
    logits = np.eye(4) * 10
    metrics = compute_metrics(EvalPrediction(predictions=logits, label_ids=truth))
    assert metrics["macro_f1"] == 1.0
    assert metrics["accuracy"] == 1.0
    assert metrics["balanced_accuracy"] == 1.0


def test_fixed_split_validation_rejects_artist_leakage():
    rows = []
    for split in ["train", "validation", "test"]:
        for label in ["joy", "sadness", "anger", "calmness"]:
            rows.append({"lyrics": label, "emotion": label, "split": split, "artist": f"{split}_{label}"})
    frame = pd.DataFrame(rows)
    validate_fixed_splits(frame)
    frame.loc[frame.index[-1], "artist"] = frame.loc[0, "artist"]
    with pytest.raises(ValueError, match="Group leakage"):
        validate_fixed_splits(frame)


def test_fixed_split_validation_rejects_parent_song_leakage():
    rows = []
    for split in ["train", "validation", "test"]:
        for label in ["joy", "sadness", "anger", "calmness"]:
            rows.append(
                {
                    "lyrics": label,
                    "emotion": label,
                    "split": split,
                    "artist": f"{split}_{label}",
                    "corpus_song_id": f"{split}_{label}",
                }
            )
    frame = pd.DataFrame(rows)
    frame.loc[frame.index[-1], "corpus_song_id"] = frame.loc[0, "corpus_song_id"]
    with pytest.raises(ValueError, match="Parent-song leakage"):
        validate_fixed_splits(frame)


def test_head_tail_tokenisation_preserves_both_ends():
    encoded = head_tail_tokenise(TinyTokenizer(), "abcdefghij", max_length=8)
    assert encoded["input_ids"] == [101, 0, 1, 2, 7, 8, 9, 102]
    assert len(encoded["attention_mask"]) == 8


def test_fixed_partition_identity_rejects_mixed_files():
    frame = pd.DataFrame(
        {
            "partition_seed": [13, 13],
            "outer_fold": [1, 2],
        }
    )
    with pytest.raises(ValueError, match="outer_fold"):
        fixed_partition_identity(frame)

    frame["outer_fold"] = 1
    assert fixed_partition_identity(frame) == (13, 1)


def test_warmup_steps_are_explicit_and_nonzero():
    assert compute_warmup_steps(16, batch_size=4, gradient_accumulation_steps=1, epochs=1) == 1
    assert compute_warmup_steps(100, batch_size=4, gradient_accumulation_steps=2, epochs=5) == 7
    with pytest.raises(ValueError, match="positive"):
        compute_warmup_steps(0, batch_size=4, gradient_accumulation_steps=1, epochs=1)


def test_validation_metric_prefix_is_stable():
    renamed = rename_validation_metrics({"eval_macro_f1": 0.5, "epoch": 2.0})
    assert renamed == {"validation_macro_f1": 0.5, "validation_epoch": 2.0}


def test_learning_curve_identity_is_unique_and_collision_safe():
    frame = pd.DataFrame({"learning_curve_fraction": [0.25, 0.25]})
    assert learning_curve_identity(frame) == 0.25
    assert fraction_slug(0.25) == "025"
    frame.loc[1, "learning_curve_fraction"] = 0.5
    with pytest.raises(ValueError, match="one value"):
        learning_curve_identity(frame)
