import pandas as pd

from src.silver_label_robustness import attach_evidence, evidence_composition, partition_metrics, summarise


def _fixtures():
    methods = [
        "retained_reviewed_original_v2_label",
        "unanimous_three_method_consensus",
        "two_of_three_method_consensus",
        "three_way_tie_generation_adjudication_tiebreak",
    ]
    cases = []
    for index, method in enumerate(methods):
        cases.append(
            {
                "case_id": f"c{index}",
                "corpus_song_id": f"s{index}",
                "emotion": ["joy", "sadness", "anger", "calmness"][index],
                "source_cohort": "original_680" if index == 0 else "github_expansion_5320",
                "consensus_method": method,
            }
        )
    predictions = []
    for model in ["m1", "m2", "m3"]:
        for seed in [1, 2, 3]:
            for fold in range(1, 6):
                for case in cases:
                    predictions.append(
                        {
                            "case_id": case["case_id"],
                            "corpus_song_id": case["corpus_song_id"],
                            "model_key": model,
                            "partition_seed": seed,
                            "outer_fold": fold,
                            "true_label": case["emotion"],
                            "predicted_label": case["emotion"],
                        }
                    )
    return pd.DataFrame(cases), pd.DataFrame(predictions)


def test_robustness_builds_five_subsets_for_all_partitions():
    dataset, predictions = _fixtures()
    enriched = attach_evidence(predictions, dataset)
    metrics = partition_metrics(enriched)
    summary = summarise(metrics)
    assert len(metrics) == 5 * 3 * 15
    assert summary["partitions"].eq(15).all()
    assert summary["macro_f1_mean"].between(0, 1).all()


def test_evidence_composition_preserves_all_cases():
    dataset, _ = _fixtures()
    composition = evidence_composition(dataset)
    assert composition["sections"].sum() == 4
    assert set(composition["evidence_tier"]) == {
        "original_reviewed",
        "unanimous_expansion",
        "majority_expansion",
        "tie_break_expansion",
    }
