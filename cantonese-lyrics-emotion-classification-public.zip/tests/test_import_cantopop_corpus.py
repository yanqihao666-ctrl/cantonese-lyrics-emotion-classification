from src.import_cantopop_corpus import COLUMN_MAP


def test_required_seed_metadata_columns_are_defined() -> None:
    required = {"corpus_song_id", "title", "release_year", "artist", "lyricist"}
    assert required.issubset(set(COLUMN_MAP.values()))
