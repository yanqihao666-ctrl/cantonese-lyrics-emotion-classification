from pathlib import Path

import pandas as pd

from src.evaluation_plots import plot_confusion_matrices, plot_partition_performance
from src.statistical_analysis import partition_metrics


def test_evaluation_plots_are_created(tmp_path: Path):
    truth = ["joy", "sadness", "anger", "calmness"]
    rows = []
    for model_key, predicted in [
        ("classical::char::svm", truth),
        ("transformer::xlmr", ["sadness", "anger", "calmness", "joy"]),
    ]:
        for index, (true_label, predicted_label) in enumerate(zip(truth, predicted), start=1):
            rows.append(
                {
                    "corpus_song_id": f"C{index}",
                    "partition_seed": 13,
                    "outer_fold": 1,
                    "model_key": model_key,
                    "true_label": true_label,
                    "predicted_label": predicted_label,
                }
            )
    predictions = pd.DataFrame(rows)
    confusion_paths = plot_confusion_matrices(predictions, tmp_path / "confusions")
    performance_path = plot_partition_performance(
        partition_metrics(predictions),
        tmp_path / "partition_macro_f1.png",
    )

    assert len(confusion_paths) == 2
    assert all(path.exists() and path.stat().st_size > 0 for path in confusion_paths)
    assert performance_path.exists() and performance_path.stat().st_size > 0

