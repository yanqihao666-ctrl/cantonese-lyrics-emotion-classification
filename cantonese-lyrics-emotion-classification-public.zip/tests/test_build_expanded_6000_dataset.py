import pandas as pd
import pytest

from src.build_expanded_6000_dataset import build_expanded_frame


def _frame(prefix: str, rows: int, include_emotion: bool) -> pd.DataFrame:
    result = pd.DataFrame(
        {
            "case_id": [f"{prefix}-{i}" for i in range(rows)],
            "corpus_song_id": [f"{prefix}-song-{i}" for i in range(rows)],
            "lyrics": [f"unique lyric content {prefix} {i}" for i in range(rows)],
            "title": [f"title {prefix} {i}" for i in range(rows)],
            "artist": [f"artist {i % 10}" for i in range(rows)],
        }
    )
    if include_emotion:
        result["emotion"] = ["sadness"] * rows
    return result


def test_builds_exact_6000_and_keeps_historical_labels_separate():
    result = build_expanded_frame(_frame("old", 680, True), _frame("new", 5320, False))
    assert len(result) == 6000
    assert result["emotion"].isna().all()
    assert result["historical_emotion"].notna().sum() == 680
    assert result["normalized_lyric_sha256"].is_unique


def test_rejects_wrong_expansion_size():
    with pytest.raises(ValueError, match="5,320"):
        build_expanded_frame(_frame("old", 680, True), _frame("new", 5, False))
