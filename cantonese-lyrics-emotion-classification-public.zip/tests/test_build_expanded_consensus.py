from src.build_expanded_consensus import choose_consensus


def test_unanimous_and_majority_consensus():
    assert choose_consensus("joy", "joy", "joy")["consensus_vote_count"] == 3
    result = choose_consensus("anger", "sadness", "anger")
    assert result["emotion"] == "anger"
    assert result["consensus_vote_count"] == 2


def test_three_way_tie_prefers_adjudicated_generation_vote():
    result = choose_consensus("joy", "sadness", "calmness")
    assert result["emotion"] == "joy"
    assert result["consensus_tied"] is True
