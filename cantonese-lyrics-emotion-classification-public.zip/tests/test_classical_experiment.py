import pandas as pd

from src.classical_experiment import (
    expected_resampled_counts,
    moderate_undersampling_strategy,
    run_experiment,
    run_fixed_split_experiment,
)


def test_imbalance_targets_are_deterministic_and_moderate():
    labels = pd.Series(
        ["sadness"] * 20 + ["joy"] * 8 + ["calmness"] * 5 + ["anger"] * 3
    )
    assert moderate_undersampling_strategy(labels) == {"sadness": 16}
    assert expected_resampled_counts(labels, "moderate_undersampling") == {
        "joy": 8,
        "sadness": 16,
        "anger": 3,
        "calmness": 5,
    }
    assert expected_resampled_counts(labels, "random_oversampling") == {
        "joy": 20,
        "sadness": 20,
        "anger": 20,
        "calmness": 20,
    }


def test_classical_smoke_run_returns_traceable_outputs():
    labels_and_words = {
        "joy": ["快樂歡笑慶祝", "開心希望陽光", "興奮唱歌成功", "幸福歡欣跳舞"],
        "sadness": ["孤單眼淚失去", "悲傷離別遺憾", "痛苦想念哭泣", "失望寂寞難過"],
        "anger": ["憤怒背叛控訴", "生氣反抗敵人", "仇恨怒火責罵", "不滿衝突抗議"],
        "calmness": ["平靜接受溫柔", "安寧微風陪伴", "放下安心夜空", "寧靜自在回憶"],
    }
    rows = []
    shared = {"joy": "快樂", "sadness": "悲傷", "anger": "憤怒", "calmness": "平靜"}
    for label, texts in labels_and_words.items():
        for index, text in enumerate(texts):
            rows.append({"lyrics": (shared[label] + text) * 3, "emotion": label, "artist": f"{label}_{index}"})
    summary, folds, predictions, metadata = run_experiment(
        pd.DataFrame(rows),
        seeds=[42],
        folds=2,
        feature_sets=["character_tfidf"],
        model_names=["majority", "linear_svm"],
    )
    assert set(summary["model"]) == {"majority", "linear_svm"}
    assert len(folds) == 4
    assert len(predictions) == 32
    assert metadata["observations"] == 16


def test_fixed_split_run_uses_predeclared_roles_and_reports_validation_separately():
    rows = []
    cues = {
        "joy": "快樂歡笑",
        "sadness": "悲傷眼淚",
        "anger": "憤怒反抗",
        "calmness": "平靜安心",
    }
    for split_name in ["train", "validation", "test"]:
        for label, cue in cues.items():
            for index in range(2):
                rows.append(
                    {
                        "lyrics": f"{cue}{cue}{split_name}{index}",
                        "emotion": label,
                        "artist": f"{split_name}_{label}_{index}",
                        "corpus_song_id": f"{split_name}_{label}_{index}",
                        "partition_seed": 42,
                        "outer_fold": 1,
                        "learning_curve_fraction": 0.5,
                        "split": split_name,
                    }
                )
    metrics, predictions, metadata = run_fixed_split_experiment(
        pd.DataFrame(rows),
        seed=42,
        feature_sets=["character_tfidf"],
        model_names=["majority", "logistic_regression", "linear_svm"],
        imbalance_strategies=["baseline", "class_weight"],
    )
    assert set(metrics["evaluation_split"]) == {"validation", "test"}
    assert set(metrics["model"]) == {
        "majority",
        "logistic_regression",
        "linear_svm",
    }
    assert set(predictions["evaluation_split"]) == {"validation", "test"}
    assert predictions["model_key"].str.startswith("classical::").all()
    assert len(predictions) == 80
    assert "balanced_accuracy" in metrics.columns
    assert set(metrics["imbalance_strategy"]) == {"baseline", "class_weight"}
    assert {"case_id", "corpus_song_id", "partition_seed", "outer_fold"}.issubset(
        predictions.columns
    )
    assert predictions["learning_curve_fraction"].eq(0.5).all()
    assert predictions["training_rows"].eq(8).all()
    assert predictions["training_songs"].eq(8).all()
    assert predictions["training_groups"].eq(8).all()
    assert metadata["split_sizes"] == {"train": 8, "validation": 8, "test": 8}
    assert metadata["shared_fixed_partition"] is True
    assert metadata["partition_seed"] == 42
    assert metadata["outer_fold"] == 1
    assert metadata["learning_curve_fraction"] == 0.5
    assert metadata["case_id_column"] == "case_id"
    assert metadata["cluster_unit"] == "corpus_song_id"
