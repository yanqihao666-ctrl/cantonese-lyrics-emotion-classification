from pathlib import Path

import pandas as pd
import pytest

from src.audit_expanded_project_results import audit


def test_final_audit_passes_for_completed_project() -> None:
    root = Path(__file__).resolve().parents[1]
    restricted_dataset = root / "data" / "research_only" / "expanded_6000_consensus_final.csv"
    if not restricted_dataset.exists():
        pytest.skip("research-only lyric dataset is intentionally excluded from the submission repository")
    payload = audit(root)

    assert payload["passed"] is True
    assert payload["dataset"]["rows"] == 6000
    assert set(payload["primary_partition_coverage"].values()) == {15}
    assert payload["checks"]["error_queue_excludes_lyric_text"] is True
    assert payload["checks"]["robustness_does_not_claim_human_gold"] is True
