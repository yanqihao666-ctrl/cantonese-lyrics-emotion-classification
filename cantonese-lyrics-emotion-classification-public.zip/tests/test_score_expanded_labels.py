import numpy as np

from src.score_expanded_labels import aggregate_calibrated_scores, map_option_scores


def test_maps_options_back_to_labels():
    result = map_option_scores(
        np.array([1.0, 2.0, 3.0, 4.0]),
        ("sadness", "anger", "calmness", "joy"),
    )
    assert result == {"sadness": 1.0, "anger": 2.0, "calmness": 3.0, "joy": 4.0}


def test_aggregate_is_invariant_to_option_position_after_mapping():
    values = [
        {"joy": 3.0, "sadness": 1.0, "anger": 0.0, "calmness": 2.0}
        for _ in range(4)
    ]
    result = aggregate_calibrated_scores(values)
    assert result["emotion"] == "joy"
    assert result["permutation_unanimous"] is True
    assert result["permutation_vote_count"] == 4
