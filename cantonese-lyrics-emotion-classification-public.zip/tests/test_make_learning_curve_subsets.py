import pandas as pd

from src.make_learning_curve_subsets import (
    materialise_learning_curve_subsets,
    select_nested_training_groups,
)


def test_learning_curve_subsets_are_nested_and_keep_evaluation_fixed():
    rows = []
    labels = ["joy", "sadness", "anger", "calmness"]
    for label in labels:
        for index in range(4):
            rows.append(
                {
                    "corpus_song_id": f"T_{label}_{index}",
                    "emotion": label,
                    "artist": f"train_{label}_{index}",
                    "split": "train",
                }
            )
        for role in ["validation", "test"]:
            rows.append(
                {
                    "corpus_song_id": f"{role}_{label}",
                    "emotion": label,
                    "artist": f"{role}_{label}",
                    "split": role,
                }
            )
    frame = pd.DataFrame(rows)
    selections, metadata = select_nested_training_groups(
        frame,
        fractions=[0.5, 0.75, 1.0],
        seed=7,
        trials=300,
    )
    subsets = materialise_learning_curve_subsets(frame, selections)

    assert set(selections[0.5]).issubset(selections[0.75])
    assert set(selections[0.75]).issubset(selections[1.0])
    evaluation_ids = set(frame.loc[frame["split"] != "train", "corpus_song_id"])
    for subset in subsets.values():
        assert set(subset.loc[subset["split"] != "train", "corpus_song_id"]) == evaluation_ids
        assert set(subset.loc[subset["split"] == "train", "emotion"]) == set(labels)
    assert metadata["full_training_rows"] == 16

