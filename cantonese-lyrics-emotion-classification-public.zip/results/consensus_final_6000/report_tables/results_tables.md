# Auto-generated formal results tables

These tables are generated from validated artifacts. They contain no AI-estimated or manually copied values.

## Overall model comparison

| Model key | Macro-F1 mean (SD) | Pooled macro-F1 95% CI | Weighted-F1 mean | Accuracy mean | Partitions |
|---|---:|---:|---:|---:|---:|
| `transformer::hfl/chinese-macbert-base` | 0.558 (0.022) | 0.539 to 0.580 | 0.770 | 0.779 | 15 |
| `transformer::FacebookAI/xlm-roberta-base` | 0.368 (0.029) | 0.362 to 0.380 | 0.704 | 0.754 | 15 |
| `classical::validation_selected` | 0.352 (0.015) | 0.340 to 0.365 | 0.655 | 0.681 | 15 |

## Per-class results

| Model key | Label | Partition F1 mean (SD) | Pooled precision | Pooled recall | Pooled F1 | Unique sections | Source songs |
|---|---|---:|---:|---:|---:|---:|---:|
| `classical::validation_selected` | joy | 0.317 (0.032) | 0.344 | 0.293 | 0.317 | 736 | 570 |
| `classical::validation_selected` | sadness | 0.813 (0.010) | 0.773 | 0.859 | 0.814 | 4340 | 2651 |
| `classical::validation_selected` | anger | 0.053 (0.043) | 0.105 | 0.036 | 0.054 | 221 | 191 |
| `classical::validation_selected` | calmness | 0.223 (0.027) | 0.278 | 0.186 | 0.223 | 703 | 585 |
| `transformer::FacebookAI/xlm-roberta-base` | joy | 0.498 (0.035) | 0.453 | 0.553 | 0.498 | 736 | 570 |
| `transformer::FacebookAI/xlm-roberta-base` | sadness | 0.872 (0.006) | 0.815 | 0.938 | 0.872 | 4340 | 2651 |
| `transformer::FacebookAI/xlm-roberta-base` | anger | 0.000 (0.000) | 0.000 | 0.000 | 0.000 | 221 | 191 |
| `transformer::FacebookAI/xlm-roberta-base` | calmness | 0.101 (0.101) | 0.426 | 0.064 | 0.112 | 703 | 585 |
| `transformer::hfl/chinese-macbert-base` | joy | 0.572 (0.036) | 0.565 | 0.582 | 0.574 | 736 | 570 |
| `transformer::hfl/chinese-macbert-base` | sadness | 0.879 (0.007) | 0.861 | 0.898 | 0.879 | 4340 | 2651 |
| `transformer::hfl/chinese-macbert-base` | anger | 0.337 (0.078) | 0.520 | 0.255 | 0.342 | 221 | 191 |
| `transformer::hfl/chinese-macbert-base` | calmness | 0.443 (0.033) | 0.480 | 0.413 | 0.444 | 703 | 585 |

## Paired cluster permutation tests

| Model A | Model B | Macro-F1 difference (A-B) | Raw p | Holm p | Holm reject 0.05 |
|---|---|---:|---:|---:|---|
| `classical::validation_selected` | `transformer::hfl/chinese-macbert-base` | -0.208 | 0.0002 | 0.0006 | True |
| `transformer::FacebookAI/xlm-roberta-base` | `transformer::hfl/chinese-macbert-base` | -0.189 | 0.0002 | 0.0006 | True |
| `classical::validation_selected` | `transformer::FacebookAI/xlm-roberta-base` | -0.019 | 0.0184 | 0.0184 | True |

Interpretation must consider effect magnitude, uncertainty, annotation quality and corpus limits; statistical non-significance is not evidence of equivalence.
