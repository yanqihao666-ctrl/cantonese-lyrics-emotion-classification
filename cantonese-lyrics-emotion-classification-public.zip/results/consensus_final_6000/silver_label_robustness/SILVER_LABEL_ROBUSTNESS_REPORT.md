# Silver-label robustness report

## Purpose

This analysis tests whether the comparative result depends on the weakest AI-assisted labels. It does **not** validate the labels against human judgement and must not be described as human-gold evaluation.

## Result

Chinese MacBERT ranked first in every declared evidence subset: **true**. The weakest tier contains 418 three-way-tie sections and is excluded in the first sensitivity check.

| Subset | Model | Macro-F1 mean | SD | Rank |
|---|---|---:|---:|---:|
| all_silver | Chinese MacBERT | 0.558 | 0.022 | 1 |
| all_silver | XLM-R | 0.368 | 0.029 | 2 |
| all_silver | Classical ML | 0.352 | 0.015 | 3 |
| exclude_tie_breaks | Chinese MacBERT | 0.566 | 0.028 | 1 |
| exclude_tie_breaks | XLM-R | 0.373 | 0.032 | 2 |
| exclude_tie_breaks | Classical ML | 0.352 | 0.015 | 3 |
| original_plus_unanimous | Chinese MacBERT | 0.622 | 0.048 | 1 |
| original_plus_unanimous | XLM-R | 0.418 | 0.050 | 2 |
| original_plus_unanimous | Classical ML | 0.368 | 0.029 | 3 |
| original_reviewed_only | Chinese MacBERT | 0.433 | 0.061 | 1 |
| original_reviewed_only | XLM-R | 0.338 | 0.059 | 2 |
| original_reviewed_only | Classical ML | 0.318 | 0.046 | 3 |
| unanimous_expansion_only | Chinese MacBERT | 0.768 | 0.060 | 1 |
| unanimous_expansion_only | XLM-R | 0.464 | 0.062 | 2 |
| unanimous_expansion_only | Classical ML | 0.385 | 0.033 | 3 |

## Interpretation boundary

Stable model ordering across these subsets strengthens the internal comparative conclusion. Higher performance on unanimous labels may partly reflect agreement between related pretrained language models rather than greater agreement with Cantonese-speaking humans. Therefore the evidence supports a comparison within this disclosed silver-labelled corpus, not a definitive estimate of real-world emotion accuracy.

## Reporting rule

Report the all-silver result as primary, the stricter subsets as sensitivity analyses, and the original-only subset as a small-cohort diagnostic. Do not select a preferred subset after viewing its test score.