from __future__ import annotations

from pathlib import Path

from docx import Document
from docx.enum.section import WD_SECTION
from docx.enum.table import WD_CELL_VERTICAL_ALIGNMENT, WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Inches, Pt, RGBColor


PROJECT_ROOT = Path(__file__).resolve().parents[1]
OUTPUT = PROJECT_ROOT / "deliverables" / "Annotator_Pack_DRAFT.docx"

BLUE = "2E74B5"
DARK_BLUE = "1F4D78"
INK = "203040"
MUTED = "666666"
LIGHT_BLUE = "E8EEF5"
LIGHT_GRAY = "F2F4F7"
PALE_RED = "FDECEC"
RED = "9B1C1C"
WHITE = "FFFFFF"
TABLE_WIDTH_DXA = 9360
TABLE_INDENT_DXA = 120


def set_run_font(
    run,
    *,
    name="Calibri",
    east_asia="Microsoft JhengHei",
    size=11,
    color=INK,
    bold=None,
    italic=None,
):
    run.font.name = name
    run._element.get_or_add_rPr().rFonts.set(qn("w:ascii"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:hAnsi"), name)
    run._element.get_or_add_rPr().rFonts.set(qn("w:eastAsia"), east_asia)
    run.font.size = Pt(size)
    run.font.color.rgb = RGBColor.from_string(color)
    if bold is not None:
        run.bold = bold
    if italic is not None:
        run.italic = italic


def shade_cell(cell, fill):
    tc_pr = cell._tc.get_or_add_tcPr()
    shd = tc_pr.find(qn("w:shd"))
    if shd is None:
        shd = OxmlElement("w:shd")
        tc_pr.append(shd)
    shd.set(qn("w:fill"), fill)


def set_cell_margins(cell, top=80, start=120, bottom=80, end=120):
    tc_pr = cell._tc.get_or_add_tcPr()
    tc_mar = tc_pr.first_child_found_in("w:tcMar")
    if tc_mar is None:
        tc_mar = OxmlElement("w:tcMar")
        tc_pr.append(tc_mar)
    for margin_name, value in (
        ("top", top),
        ("start", start),
        ("bottom", bottom),
        ("end", end),
    ):
        node = tc_mar.find(qn(f"w:{margin_name}"))
        if node is None:
            node = OxmlElement(f"w:{margin_name}")
            tc_mar.append(node)
        node.set(qn("w:w"), str(value))
        node.set(qn("w:type"), "dxa")


def set_table_geometry(table, widths):
    assert sum(widths) == TABLE_WIDTH_DXA
    table.alignment = WD_TABLE_ALIGNMENT.LEFT
    table.autofit = False
    tbl_pr = table._tbl.tblPr
    first_row_pr = table.rows[0]._tr.get_or_add_trPr()
    if first_row_pr.find(qn("w:tblHeader")) is None:
        table_header = OxmlElement("w:tblHeader")
        table_header.set(qn("w:val"), "true")
        first_row_pr.append(table_header)

    tbl_w = tbl_pr.find(qn("w:tblW"))
    if tbl_w is None:
        tbl_w = OxmlElement("w:tblW")
        tbl_pr.append(tbl_w)
    tbl_w.set(qn("w:w"), str(TABLE_WIDTH_DXA))
    tbl_w.set(qn("w:type"), "dxa")

    tbl_ind = tbl_pr.find(qn("w:tblInd"))
    if tbl_ind is None:
        tbl_ind = OxmlElement("w:tblInd")
        tbl_pr.append(tbl_ind)
    tbl_ind.set(qn("w:w"), str(TABLE_INDENT_DXA))
    tbl_ind.set(qn("w:type"), "dxa")

    layout = tbl_pr.find(qn("w:tblLayout"))
    if layout is None:
        layout = OxmlElement("w:tblLayout")
        tbl_pr.append(layout)
    layout.set(qn("w:type"), "fixed")

    grid = table._tbl.tblGrid
    for child in list(grid):
        grid.remove(child)
    for width in widths:
        grid_col = OxmlElement("w:gridCol")
        grid_col.set(qn("w:w"), str(width))
        grid.append(grid_col)

    for row in table.rows:
        for index, (cell, width) in enumerate(zip(row.cells, widths)):
            cell.width = Inches(width / 1440)
            tc_pr = cell._tc.get_or_add_tcPr()
            tc_w = tc_pr.find(qn("w:tcW"))
            if tc_w is None:
                tc_w = OxmlElement("w:tcW")
                tc_pr.append(tc_w)
            tc_w.set(qn("w:w"), str(width))
            tc_w.set(qn("w:type"), "dxa")
            set_cell_margins(cell)
            cell.vertical_alignment = WD_CELL_VERTICAL_ALIGNMENT.CENTER


def style_cell_text(cell, *, bold=False, color=INK, size=10.2, align=None):
    for paragraph in cell.paragraphs:
        if align is not None:
            paragraph.alignment = align
        paragraph.paragraph_format.space_before = Pt(0)
        paragraph.paragraph_format.space_after = Pt(0)
        paragraph.paragraph_format.line_spacing = 1.15
        for run in paragraph.runs:
            set_run_font(run, size=size, color=color, bold=bold)


def add_para(
    doc,
    text="",
    *,
    bold=False,
    italic=False,
    color=INK,
    size=11,
    align=WD_ALIGN_PARAGRAPH.LEFT,
    before=0,
    after=6,
    keep_with_next=False,
):
    paragraph = doc.add_paragraph()
    paragraph.alignment = align
    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = 1.25
    paragraph.paragraph_format.keep_with_next = keep_with_next
    run = paragraph.add_run(text)
    set_run_font(
        run, size=size, color=color, bold=bold, italic=italic
    )
    return paragraph


def add_mixed_para(doc, segments, *, after=6, before=0):
    paragraph = doc.add_paragraph()
    paragraph.paragraph_format.space_before = Pt(before)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = 1.25
    for text, kwargs in segments:
        run = paragraph.add_run(text)
        set_run_font(run, **kwargs)
    return paragraph


def add_bullet(
    doc,
    text,
    level=0,
    *,
    size=11,
    after=4,
    line_spacing=1.25,
):
    paragraph = doc.add_paragraph(style="List Bullet" if level == 0 else "List Bullet 2")
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(after)
    paragraph.paragraph_format.line_spacing = line_spacing
    paragraph.paragraph_format.left_indent = Inches(0.375 + 0.25 * level)
    paragraph.paragraph_format.first_line_indent = Inches(-0.188)
    run = paragraph.add_run(text)
    set_run_font(run, size=size)
    return paragraph


def add_numbered(doc, text):
    paragraph = doc.add_paragraph(style="List Number")
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(4)
    paragraph.paragraph_format.line_spacing = 1.25
    paragraph.paragraph_format.left_indent = Inches(0.375)
    paragraph.paragraph_format.first_line_indent = Inches(-0.188)
    run = paragraph.add_run(text)
    set_run_font(run)
    return paragraph


def add_heading(doc, text, level=1, *, page_break_before=False):
    paragraph = doc.add_paragraph(style=f"Heading {level}")
    paragraph.paragraph_format.keep_with_next = True
    paragraph.paragraph_format.page_break_before = page_break_before
    run = paragraph.add_run(text)
    return paragraph


def add_status_banner(doc, text, *, trailing_gap=True):
    table = doc.add_table(rows=1, cols=1)
    table.style = "Table Grid"
    tr_pr = table.rows[0]._tr.get_or_add_trPr()
    cant_split = OxmlElement("w:cantSplit")
    tr_pr.append(cant_split)
    cell = table.cell(0, 0)
    cell.text = text
    shade_cell(cell, PALE_RED)
    set_table_geometry(table, [TABLE_WIDTH_DXA])
    style_cell_text(
        cell,
        bold=True,
        color=RED,
        size=10.5,
        align=WD_ALIGN_PARAGRAPH.CENTER,
    )
    for paragraph in cell.paragraphs:
        paragraph.paragraph_format.keep_together = True
    if trailing_gap:
        add_para(doc, "", after=3)


def add_page_break(doc):
    doc.add_page_break()


def add_footer_page_field(paragraph):
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT
    paragraph.paragraph_format.space_before = Pt(0)
    paragraph.paragraph_format.space_after = Pt(0)
    run = paragraph.add_run("DRAFT - Annotator pack  |  Page ")
    set_run_font(run, size=8.5, color=MUTED)
    fld_char_1 = OxmlElement("w:fldChar")
    fld_char_1.set(qn("w:fldCharType"), "begin")
    instr_text = OxmlElement("w:instrText")
    instr_text.set(qn("xml:space"), "preserve")
    instr_text.text = " PAGE "
    fld_char_2 = OxmlElement("w:fldChar")
    fld_char_2.set(qn("w:fldCharType"), "end")
    run._r.append(fld_char_1)
    run._r.append(instr_text)
    run._r.append(fld_char_2)


doc = Document()
section = doc.sections[0]
section.page_width = Inches(8.5)
section.page_height = Inches(11)
section.top_margin = Inches(1)
section.bottom_margin = Inches(1)
section.left_margin = Inches(1)
section.right_margin = Inches(1)
section.header_distance = Inches(0.492)
section.footer_distance = Inches(0.492)

styles = doc.styles
normal = styles["Normal"]
normal.font.name = "Calibri"
normal._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
normal._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
normal._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft JhengHei")
normal.font.size = Pt(11)
normal.font.color.rgb = RGBColor.from_string(INK)
normal.paragraph_format.space_before = Pt(0)
normal.paragraph_format.space_after = Pt(6)
normal.paragraph_format.line_spacing = 1.25

for name, size, color, before, after in (
    ("Heading 1", 16, BLUE, 18, 10),
    ("Heading 2", 13, BLUE, 14, 7),
    ("Heading 3", 12, DARK_BLUE, 10, 5),
):
    style = styles[name]
    style.font.name = "Calibri"
    style._element.rPr.rFonts.set(qn("w:ascii"), "Calibri")
    style._element.rPr.rFonts.set(qn("w:hAnsi"), "Calibri")
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft JhengHei")
    style.font.size = Pt(size)
    style.font.color.rgb = RGBColor.from_string(color)
    style.font.bold = True
    style.paragraph_format.space_before = Pt(before)
    style.paragraph_format.space_after = Pt(after)
    style.paragraph_format.keep_with_next = True

for name in ("List Bullet", "List Bullet 2", "List Number"):
    style = styles[name]
    style.font.name = "Calibri"
    style._element.rPr.rFonts.set(qn("w:eastAsia"), "Microsoft JhengHei")
    style.font.size = Pt(11)
    style.paragraph_format.space_after = Pt(4)
    style.paragraph_format.line_spacing = 1.25

header = section.header
header_p = header.paragraphs[0]
header_p.alignment = WD_ALIGN_PARAGRAPH.LEFT
header_p.paragraph_format.space_after = Pt(0)
header_run = header_p.add_run(
    "University of Leeds MSc Project | Annotator Materials"
)
set_run_font(header_run, size=8.5, color=MUTED)

footer = section.footer
add_footer_page_field(footer.paragraphs[0])

settings = doc.settings._element
update_fields = OxmlElement("w:updateFields")
update_fields.set(qn("w:val"), "true")
settings.append(update_fields)

# Cover and control page
add_para(doc, "ANNOTATOR PACK", bold=True, color=BLUE, size=25, after=2)
add_para(
    doc,
    "Emotion Classification in Cantonese Lyrics",
    bold=True,
    color=INK,
    size=16,
    after=2,
)
add_para(
    doc,
    "A comparative study of Transformer-based and classical ML models",
    italic=True,
    color=MUTED,
    size=11.5,
    after=16,
)
add_status_banner(
    doc,
    "DRAFT FOR SUPERVISOR / ETHICS / CANTONESE-LANGUAGE REVIEW - DO NOT DISTRIBUTE",
)

add_heading(doc, "Document control / 文件控制", 1)
control = doc.add_table(rows=6, cols=2)
control.style = "Table Grid"
control_rows = [
    ("Version / 版本", "0.2 draft"),
    ("Date / 日期", "29 July 2026"),
    ("Student researcher / 學生研究員", "[TO COMPLETE / 待填]"),
    ("Supervisor / 導師", "[TO COMPLETE / 待填]"),
    ("Ethics route/reference / 倫理審批", "[TO COMPLETE / 待填]"),
    ("Withdrawal contact / 退出聯絡", "[TO COMPLETE / 待填]"),
]
for row, (label, value) in zip(control.rows, control_rows):
    row.cells[0].text = label
    row.cells[1].text = value
    shade_cell(row.cells[0], LIGHT_BLUE)
    style_cell_text(row.cells[0], bold=True)
    style_cell_text(row.cells[1])
set_table_geometry(control, [2700, 6660])

add_heading(doc, "Release gate / 使用前檢查", 1)
add_para(
    doc,
    "Complete every placeholder, confirm the School ethics route, run a timed mini-pilot, and obtain review from a Cantonese-competent person before distribution. / 派發前必須完成所有待填項目、確認學院倫理程序、完成計時小型試標，並由具粵語能力的人員核對。",
    size=10.5,
)

# English information sheet
add_heading(doc, "Participant information sheet", 1, page_break_before=True)
add_para(
    doc,
    "Please read this sheet before deciding whether to participate.",
    italic=True,
    color=MUTED,
)
add_heading(doc, "Invitation and purpose", 2)
add_para(
    doc,
    "You are invited to help create reliable emotion labels for a University of Leeds MSc Computer Science research project. The study compares computational methods for identifying emotions expressed in Cantonese song lyrics.",
)
add_heading(doc, "Why you have been invited", 2)
add_para(
    doc,
    "The task requires someone aged 18 or over who can understand written Cantonese lyrics, including colloquial expressions and occasional code-switching, well enough to make independent judgements.",
)
add_heading(doc, "What participation involves", 2)
add_para(
    doc,
    "You will receive one workbook containing 680 anonymised lyric sections extracted from 105 songs and presented in random order. Exact repeated sections within the same song are shown once. For each section, you will:",
)
for item in (
    "choose the dominant expressed emotion from joy, sadness, anger or calmness;",
    "give a confidence score from 1 to 5;",
    "mark any applicable ambiguity or data-quality flags; and",
    "write a brief rationale.",
):
    add_bullet(doc, item)
add_para(
    doc,
    "Judge the narrative voice expressed in the supplied section and use only its local textual context. Do not infer the full song or judge its melody, performer or your personal emotional response. You will not see another annotator's decisions or computer-generated suggestions during the independent task.",
)
add_mixed_para(
    doc,
    [
        ("Expected time and completion period: ", {"bold": True, "size": 11}),
        ("[TO COMPLETE AFTER TIMED MINI-PILOT]", {"color": RED, "size": 11}),
    ],
)
add_heading(doc, "Voluntary participation and withdrawal", 2)
add_para(
    doc,
    "Participation is voluntary. You may stop without giving a reason. You may request withdrawal until [TO COMPLETE: DEADLINE OR EVENT]. After anonymised responses have been combined into aggregate analysis, removal may no longer be possible. To withdraw, contact [TO COMPLETE: UNIVERSITY EMAIL] and quote your participant ID.",
)
add_heading(
    doc,
    "Risks, benefits and compensation",
    2,
    page_break_before=True,
)
add_para(
    doc,
    "Some lyric sections may discuss loss, conflict, loneliness, death or other difficult themes. You may skip a section, mark it uncertain, take a break or withdraw. The task is not a test of you, and disagreement is expected in subjective emotion judgements.",
)
add_para(
    doc,
    "There is no guaranteed personal benefit. Your judgements may help evaluate language technology for an under-resourced language variety. Compensation: [TO COMPLETE: APPROVED ARRANGEMENT OR UNPAID].",
)
add_heading(doc, "Data and confidentiality", 2)
add_para(
    doc,
    "Annotations use a pseudonymous participant ID. Names, contact details and consent records will be stored separately from annotation responses. The dissertation will report aggregate agreement and may discuss anonymised rationale excerpts; it will not name or rank annotators.",
)
add_para(
    doc,
    "Data will be stored on [TO COMPLETE: APPROVED STORAGE], retained for [TO COMPLETE: PERIOD], and deleted or anonymised under the approved plan. Identifiable participant data will not be submitted to external generative-AI services. The lyric texts are licensed creative works supplied only for this task; do not redistribute the workbook or lyrics.",
)
add_heading(doc, "Automated tools and contacts", 2)
add_para(
    doc,
    "Machine-generated candidate labels are stored separately and hidden during independent annotation. Human responses form the basis of gold-label evaluation after documented adjudication.",
)
add_para(
    doc,
    "Student researcher: [TO COMPLETE] | Supervisor: [TO COMPLETE] | Independent concern or complaint contact: [TO COMPLETE] | Ethics reference: [TO COMPLETE]",
)

# Traditional Chinese information sheet
add_heading(
    doc,
    "參與者資料說明（繁體中文草稿）",
    1,
    page_break_before=True,
)
add_status_banner(
    doc,
    "本頁翻譯須由具粵語能力的人員核對，並在倫理／導師確認後方可使用。",
)
add_heading(doc, "邀請及研究目的", 2)
add_para(
    doc,
    "現邀請你協助一項英國列斯大學電腦科學碩士研究，為粵語流行曲歌詞建立可靠的情緒標籤。本研究比較不同電腦模型識別粵語歌詞文字所表達情緒的能力。",
)
add_heading(doc, "為何邀請你", 2)
add_para(
    doc,
    "參與者必須年滿 18 歲，並能理解書面粵語歌詞，包括口語表達及偶爾出現的語碼轉換，從而作出獨立判斷。",
)
add_heading(doc, "參與內容", 2)
add_para(
    doc,
    "你會收到一份工作簿，內含從 105 首歌曲抽取的 680 個匿名歌詞段落，並以隨機次序排列。同一歌曲內完全重複的段落只會顯示一次。你需要為每個段落：",
)
for item in (
    "從 joy（喜悅）、sadness（悲傷）、anger（憤怒）或 calmness（平靜）中選出一個主要情緒；",
    "填寫 1 至 5 分的信心分數；",
    "勾選適用的歧義或資料質素旗標；",
    "填寫簡短理由。",
):
    add_bullet(doc, item)
add_para(
    doc,
    "請判斷所提供段落的敘事聲音及局部文字表達，不要推測整首歌曲，亦不要根據旋律、歌手演繹或你的個人感受。獨立標註期間，你不會看到另一位標註者或電腦模型的答案。",
)
add_mixed_para(
    doc,
    [
        ("預計所需時間及完成期限：", {"bold": True, "size": 11}),
        ("[完成計時小型試標後填寫]", {"color": RED, "size": 11}),
    ],
)
add_heading(doc, "自願參與及退出", 2)
add_para(
    doc,
    "參與完全自願。你可以在不提供理由的情況下停止，亦可在 [待填：退出期限或事件] 前要求撤回資料。匿名回應一旦合併作整體分析，可能無法再辨認及移除。如欲退出，請聯絡 [待填：大學電郵] 並提供參與者編號。",
)
add_heading(doc, "風險、得益及報酬", 2, page_break_before=True)
add_para(
    doc,
    "部分歌詞段落可能涉及失去、衝突、孤單、死亡或其他令人不安的內容。你可以略過題目、標記 uncertain、休息或退出。這不是能力測試；主觀情緒判斷出現分歧屬正常情況。",
)
add_para(
    doc,
    "研究不保證為你帶來個人得益，但你的判斷可協助評估資源較少語言的技術。報酬：[待填：已批准安排或註明無報酬]。",
)
add_heading(doc, "資料及保密", 2)
add_para(
    doc,
    "標註只使用化名參與者編號。姓名、聯絡資料及同意書會與標註回應分開儲存。論文只會報告整體一致程度，並可能討論匿名化的簡短理由；不會公開姓名或為標註者排名。",
)
add_para(
    doc,
    "資料會儲存於 [待填：已批准儲存位置]，保存 [待填：期限]，其後按已批准計劃刪除或匿名化。可識別個人身份的資料不會上載至外部生成式 AI 服務。歌詞只供本研究標註使用，請勿轉發工作簿或歌詞。",
)
add_heading(doc, "自動工具及聯絡", 2)
add_para(
    doc,
    "電腦模型產生的候選標籤會另行儲存，在獨立標註期間不會向你展示。人工標註經記錄清楚的裁決後，才會形成研究的金標準。",
)
add_para(
    doc,
    "學生研究員：[待填] | 導師：[待填] | 獨立投訴／查詢聯絡：[待填] | 倫理審批編號：[待填]",
)

# Consent form
add_heading(doc, "Consent form / 參與同意書", 1, page_break_before=True)
add_para(
    doc,
    "Participant ID / 參與者編號：____________________",
    bold=True,
    after=10,
)
add_para(
    doc,
    "Please initial each row only after reading both information sheets. / 閱讀兩份資料說明後，請在每一項填寫姓名簡寫。",
    italic=True,
    color=MUTED,
)
consent_rows = [
    (
        "I have read and understood the information sheet dated ______, version ______.",
        "我已閱讀並明白日期為 ______、版本為 ______ 的參與者資料說明。",
    ),
    (
        "I had an opportunity to ask questions and received satisfactory answers.",
        "我有機會提問，並已獲得滿意答覆。",
    ),
    (
        "I understand participation is voluntary and I may withdraw before the stated deadline without giving a reason.",
        "我明白參與屬自願，並可在指定期限前無須提供理由退出。",
    ),
    (
        "I understand some lyrics may contain emotionally difficult themes, and I may skip an item, take a break or stop.",
        "我明白部分歌詞可能涉及令人不安的題材，亦可略過題目、休息或停止。",
    ),
    (
        "I understand how annotation, contact and consent data will be stored and used.",
        "我明白標註、聯絡及同意資料的儲存和使用方式。",
    ),
    (
        "I agree that anonymised excerpts from my short rationales may be used in the dissertation or related academic outputs.",
        "我同意論文或相關學術成果可使用我簡短理由的匿名節錄。",
    ),
    (
        "I understand my identity will not be reported and annotators will not be individually ranked.",
        "我明白研究不會公開我的身份，亦不會為個別標註者排名。",
    ),
    (
        "I agree not to redistribute the lyric workbook or supplied text.",
        "我同意不會轉發歌詞工作簿或所提供的文字。",
    ),
    (
        "I am at least 18 years old and consent to participate.",
        "我已年滿 18 歲，並同意參與研究。",
    ),
]
consent = doc.add_table(rows=1 + len(consent_rows), cols=3)
consent.style = "Table Grid"
headers = ["Statement", "聲明", "Initials\n簡寫"]
for index, text in enumerate(headers):
    consent.cell(0, index).text = text
    shade_cell(consent.cell(0, index), LIGHT_BLUE)
    style_cell_text(
        consent.cell(0, index),
        bold=True,
        align=WD_ALIGN_PARAGRAPH.CENTER,
    )
for row_index, (english, chinese) in enumerate(consent_rows, start=1):
    consent.cell(row_index, 0).text = english
    consent.cell(row_index, 1).text = chinese
    consent.cell(row_index, 2).text = ""
    style_cell_text(consent.cell(row_index, 0), size=8.5)
    style_cell_text(consent.cell(row_index, 1), size=8.5)
    style_cell_text(
        consent.cell(row_index, 2),
        size=8.5,
        align=WD_ALIGN_PARAGRAPH.CENTER,
    )
set_table_geometry(consent, [3900, 4380, 1080])
for row in consent.rows:
    for cell in row.cells:
        set_cell_margins(cell, top=30, start=90, bottom=30, end=90)
        for paragraph in cell.paragraphs:
            paragraph.paragraph_format.line_spacing = 1.0
add_para(doc, "", after=2)
for line in (
    "Participant name / 參與者姓名：________________________________",
    "Signature / 簽署：________________________  Date / 日期：________________",
    "Researcher name / 研究員姓名：________________________________",
    "Signature / 簽署：________________________  Date / 日期：________________",
):
    add_para(doc, line, size=10.5, after=3)
add_para(
    doc,
    "Withdrawal contact and deadline / 退出聯絡及期限：[TO COMPLETE / 待填]",
    bold=True,
    color=RED,
)
add_status_banner(
    doc,
    "Store this signed form separately from the annotation workbook. / 本同意書必須與標註工作簿分開儲存。",
)

# Annotation guide
add_heading(
    doc,
    "Annotation guide / 情緒標註指引",
    1,
    page_break_before=True,
)
add_para(
    doc,
    "Version 0.2 draft. The English wording is the research master; the Traditional Chinese wording requires Cantonese-language review before use.",
    italic=True,
    color=MUTED,
)
add_heading(doc, "Core question / 核心問題", 2)
add_status_banner(
    doc,
    "Which single emotion is most strongly expressed by the narrative voice in the lyric section shown?\n所顯示歌詞段落的敘事聲音，最強烈地表達了哪一種主要情緒？",
)
add_para(
    doc,
    "Judge only the supplied words and local context, not the full song, melody, singer, production, biography or personal familiarity. / 只判斷所提供文字及局部語境，不要推測整首歌曲，亦不要根據旋律、歌手、編曲、背景資料或個人印象。",
)

labels = [
    (
        "joy / 喜悅",
        "Positive and energetic: delight, hope, excitement, playful affection, triumph or enthusiastic anticipation.",
        "正面而活躍：快樂、希望、興奮、活潑的愛意、成功感或熱切期待。",
        "Love is a topic, not proof of joy. Painful or lost love may be sadness or anger.",
    ),
    (
        "sadness / 悲傷",
        "Negative and low-energy: grief, loneliness, regret, helplessness, loss, disappointment or painful longing.",
        "負面而低活躍：哀傷、孤單、遺憾、無助、失去、失望或以痛苦為主的思念。",
        "Peaceful acceptance or gentle nostalgia may be calmness instead.",
    ),
    (
        "anger / 憤怒",
        "Negative and high-energy: rage, resentment, accusation, hostility, protest, betrayal or confrontation.",
        "負面而高活躍：憤怒、怨恨、指責、敵意、抗議、被背叛的怒氣或對抗意欲。",
        "Conflict alone is not anger; the narrative voice must express an activated negative response.",
    ),
    (
        "calmness / 平靜",
        "Positive or non-negative and low-energy: peace, acceptance, reassurance, contentment, tenderness, serenity or gentle reflection.",
        "正面或非負面而低活躍：平和、接受、安心、滿足、溫柔、寧靜或輕柔反思。",
        "This is not a residual neutral class. Use uncertain when the emotion is genuinely indeterminate.",
    ),
]
label_table = doc.add_table(rows=1 + len(labels), cols=3)
label_table.style = "Table Grid"
for index, text in enumerate(("Label / 標籤", "Meaning / 意思", "Boundary / 邊界")):
    label_table.cell(0, index).text = text
    shade_cell(label_table.cell(0, index), LIGHT_BLUE)
    style_cell_text(label_table.cell(0, index), bold=True)
for row_index, (label, english, chinese, boundary) in enumerate(labels, start=1):
    label_table.cell(row_index, 0).text = label
    label_table.cell(row_index, 1).text = f"{english}\n{chinese}"
    label_table.cell(row_index, 2).text = boundary
    style_cell_text(label_table.cell(row_index, 0), bold=True, size=9.6)
    style_cell_text(label_table.cell(row_index, 1), size=9.2)
    style_cell_text(label_table.cell(row_index, 2), size=9.2)
set_table_geometry(label_table, [1650, 4710, 3000])

add_heading(doc, "Flags / 旗標", 1, page_break_before=True)
flag_rows = [
    ("mixed", "Two or more primary emotions are comparably prominent. / 兩種或以上主要情緒同樣突出。"),
    ("uncertain", "Insufficient evidence or no reliable fit. / 證據不足或無法可靠套用四個標籤。"),
    ("non_cantonese", "The lyric is not predominantly Cantonese. / 歌詞並非以粵語為主。"),
    ("insufficient_text", "The section has too little effective text or context. / 段落的有效文字或語境太少。"),
    ("translation_required", "Important expressions cannot be interpreted reliably. / 無法可靠理解影響判斷的重要用語。"),
]
flags = doc.add_table(rows=1 + len(flag_rows), cols=2)
flags.style = "Table Grid"
for index, text in enumerate(("Flag", "Use when / 使用情況")):
    flags.cell(0, index).text = text
    shade_cell(flags.cell(0, index), LIGHT_GRAY)
    style_cell_text(flags.cell(0, index), bold=True)
for row_index, (flag, meaning) in enumerate(flag_rows, start=1):
    flags.cell(row_index, 0).text = flag
    flags.cell(row_index, 1).text = meaning
    style_cell_text(flags.cell(row_index, 0), bold=True, size=9.5)
    style_cell_text(flags.cell(row_index, 1), size=9.5)
set_table_geometry(flags, [2220, 7140])

# Procedure and confidence
add_heading(
    doc,
    "Decision procedure / 判斷步驟",
    1,
    page_break_before=True,
)
steps = [
    "Read the full supplied section once without assigning a label. / 先完整閱讀所提供的段落，不要立即選標籤。",
    "Identify the local narrative situation and dominant narrative voice. / 確認局部敘事情境及主要敘事聲音。",
    "Identify textual cues for every plausible emotion. / 找出支持每個可能情緒的文字線索。",
    "Decide whether one primary emotion dominates the supplied section. / 判斷所提供段落是否有一種情緒最突出。",
    "Select exactly one primary label and a confidence score from 1 to 5. / 選一個主要標籤及 1 至 5 分信心。",
    "Add every applicable flag and a short rationale. / 加上所有適用旗標及簡短理由。",
]
for step in steps:
    add_numbered(doc, step)

add_heading(doc, "Confidence / 信心分數", 1)
confidence_rows = [
    ("5", "Unambiguous with repeated textual evidence.", "主要情緒毫不含糊，並有多處文字證據。"),
    ("4", "Clear dominant emotion with minor competing cues.", "主要情緒清楚，只有少量其他線索。"),
    ("3", "Defensible label but meaningful ambiguity.", "標籤有合理依據，但存在明顯歧義。"),
    ("2", "Weak judgement; another label may be equally plausible.", "判斷很弱，另一標籤可能同樣合理。"),
    ("1", "Cannot label reliably.", "無法可靠標註。"),
]
confidence = doc.add_table(rows=1 + len(confidence_rows), cols=3)
confidence.style = "Table Grid"
for index, text in enumerate(("Score", "English", "繁體中文")):
    confidence.cell(0, index).text = text
    shade_cell(confidence.cell(0, index), LIGHT_BLUE)
    style_cell_text(
        confidence.cell(0, index),
        bold=True,
        align=WD_ALIGN_PARAGRAPH.CENTER if index == 0 else WD_ALIGN_PARAGRAPH.LEFT,
    )
for row_index, values in enumerate(confidence_rows, start=1):
    for col_index, value in enumerate(values):
        confidence.cell(row_index, col_index).text = value
        style_cell_text(
            confidence.cell(row_index, col_index),
            size=9.7,
            bold=col_index == 0,
            align=WD_ALIGN_PARAGRAPH.CENTER if col_index == 0 else WD_ALIGN_PARAGRAPH.LEFT,
        )
set_table_geometry(confidence, [900, 4230, 4230])
add_para(
    doc,
    "Scores 1-2 always enter adjudication. Score 3 remains visible in ambiguity analysis. / 1-2 分必須進入裁決；3 分會保留在歧義分析中。",
    bold=True,
    color=DARK_BLUE,
    before=8,
)

add_heading(doc, "Edge cases / 特殊情況", 1, page_break_before=True)
edge_cases = [
    ("Event versus emotion", "A death can be described calmly; label expression, not event type. / 死亡可以用平靜語氣描述；請標註表達方式，而非事件類型。"),
    ("Transition", "Choose the emotion that dominates the supplied section, set mixed, and explain the local change. / 選所提供段落內最突出的情緒，標記 mixed 並解釋局部轉變。"),
    ("Irony", "Use the intended emotion only when it is clear, and state the evidence. / 只有在真正意圖清楚時才按該情緒標註，並說明證據。"),
    ("Repetition", "Repeated wording within a section may strengthen an emotion but is not multiple independent items. / 段落內重複文字可加強情緒，但不是多個獨立項目。"),
    ("Multiple voices", "Judge the dominant voice; use mixed when voices compete. / 判斷主要聲音；不同聲音互相競爭時標記 mixed。"),
    ("Code-switching", "Keep the item if it remains predominantly Cantonese and note the mixture. / 如果仍以粵語為主可保留，並記錄語言混合。"),
    ("Fear or anxiety", "Do not automatically relabel them as anger; use uncertain if no label fits. / 不要自動改標為 anger；若四類均不合適則標記 uncertain。"),
]
for label, detail in edge_cases:
    add_mixed_para(
        doc,
        [
            (f"{label}: ", {"bold": True, "color": DARK_BLUE, "size": 10.5}),
            (detail, {"size": 10.5}),
        ],
        after=5,
    )

# Final checklist
add_heading(
    doc,
    "Start and submission checklist / 開始及提交清單",
    1,
    page_break_before=True,
)
add_heading(doc, "Before starting / 開始前", 2)
for item in (
    "I have read the information sheet and completed a separate consent form. / 我已閱讀資料說明並另行完成同意書。",
    "I received only my own blind workbook. / 我只收到自己的盲化工作簿。",
    "I will not search for song titles, singers or other annotators' answers. / 我不會搜尋歌名、歌手或其他標註者答案。",
    "I will not use AI, machine translation or automatic emotion tools to decide labels. / 我不會使用 AI、機器翻譯或自動情緒工具決定標籤。",
):
    add_bullet(doc, item, size=10.5, after=2, line_spacing=1.15)

add_heading(doc, "While annotating / 標註期間", 2)
for item in (
    "Read the complete supplied section before choosing a label. / 選標籤前先閱讀所提供的完整段落。",
    "Choose exactly one primary label, even when mixed is flagged. / 即使標記 mixed，仍須選一個主要標籤。",
    "Use confidence honestly; low confidence is useful research evidence. / 如實填寫信心；低信心亦是有用研究證據。",
    "Do not put your name or contact details in the workbook. / 不要在工作簿填寫姓名或聯絡資料。",
    "Take a break or skip an item if content is distressing. / 如內容令人不安，可休息或略過題目。",
):
    add_bullet(doc, item, size=10.5, after=2, line_spacing=1.15)

add_heading(doc, "Before submission / 提交前", 2)
for item in (
    "Every row has one label, confidence and a rationale. / 每一行均有一個標籤、信心及理由。",
    "All applicable flags are marked. / 已勾選所有適用旗標。",
    "I did not discuss labels with another annotator. / 我沒有與另一位標註者討論答案。",
    "I will return the workbook only through the approved route. / 我只會經已批准途徑交回工作簿。",
    "I will delete local copies when instructed. / 我會按指示刪除本地副本。",
):
    add_bullet(doc, item, size=10.5, after=2, line_spacing=1.15)

add_status_banner(
    doc,
    "Researcher gate: Do not accept a workbook unless the approved consent, withdrawal, storage and compensation wording has been completed.",
    trailing_gap=False,
)
# Core properties and output.
doc.core_properties.title = "Annotator Pack - DRAFT"
doc.core_properties.subject = "Cantonese lyric-section emotion annotation"
doc.core_properties.author = "University of Leeds MSc student researcher"
doc.core_properties.keywords = "annotation, Cantonese, emotion, draft"
doc.core_properties.comments = (
    "Draft for supervisor, ethics and Cantonese-language review. Do not distribute."
)

OUTPUT.parent.mkdir(parents=True, exist_ok=True)
doc.save(OUTPUT)
print(OUTPUT)
