"""Remove reproducible model weights while preserving experiment evidence.

The script is deliberately scoped to ``results`` below the repository root and
only removes directories named ``best_model`` or ``checkpoint-*``. Predictions,
metrics, logs and run metadata are never targeted. The default mode is dry-run.
"""

from __future__ import annotations

import argparse
import shutil
from pathlib import Path


def discover_targets(repository_root: Path) -> list[Path]:
    repository_root = repository_root.resolve(strict=True)
    results_root = (repository_root / "results").resolve(strict=True)
    results_root.relative_to(repository_root)
    targets = [
        path.resolve(strict=True)
        for path in results_root.rglob("*")
        if path.is_dir()
        and (path.name == "best_model" or path.name.startswith("checkpoint-"))
    ]
    for target in targets:
        target.relative_to(results_root)
    return sorted(targets, key=lambda path: len(path.parts), reverse=True)


def directory_bytes(path: Path) -> int:
    return sum(item.stat().st_size for item in path.rglob("*") if item.is_file())


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--repository-root", type=Path, default=Path.cwd())
    parser.add_argument("--execute", action="store_true")
    args = parser.parse_args()

    targets = discover_targets(args.repository_root)
    total_bytes = sum(directory_bytes(path) for path in targets)
    print(f"targets={len(targets)} bytes={total_bytes} execute={args.execute}")
    if not args.execute:
        for target in targets:
            print(target)
        return
    for target in targets:
        if target.exists():
            shutil.rmtree(target)
    print(f"removed={len(targets)} bytes_recoverable_by_rerun={total_bytes}")


if __name__ == "__main__":
    main()
